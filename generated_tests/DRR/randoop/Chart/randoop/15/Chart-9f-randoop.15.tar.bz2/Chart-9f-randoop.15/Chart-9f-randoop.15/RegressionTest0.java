import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12, (int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) -1, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 1, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jan" + "'", str2.equals("Jan"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1, 2, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(8, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Jan");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        boolean boolean4 = month0.equals((java.lang.Object) 1.0d);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(8, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(0, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.lang.Object obj3 = null;
//        boolean boolean4 = fixedMillisecond0.equals(obj3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191456916L + "'", long2 == 1560191456916L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        java.lang.Number number3 = null;
        timeSeriesDataItem2.setValue(number3);
        boolean boolean6 = timeSeriesDataItem2.equals((java.lang.Object) 5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-459));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("31-January-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day7.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "May" + "'", str1.equals("May"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate4);
        java.lang.String str7 = serialDate4.toString();
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 100, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-January-1900" + "'", str7.equals("31-January-1900"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate9);
        java.lang.String str12 = serialDate9.toString();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        int int14 = day13.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.previous();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 1900);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-January-1900" + "'", str12.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year3 = month2.getYear();
        java.lang.Number number4 = null;
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month2, number4);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 10, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate4);
        java.lang.String str7 = serialDate4.toString();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate4.getPreviousDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-January-1900" + "'", str7.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str2 = serialDate1.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate4 = serialDate1.getNearestDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate5);
        java.lang.String str8 = serialDate5.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate5);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate5);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate17);
        java.lang.String str20 = serialDate17.toString();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate17);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate17);
        org.jfree.data.time.SerialDate serialDate24 = serialDate11.getEndOfCurrentMonth(serialDate23);
        try {
            org.jfree.data.time.SerialDate serialDate26 = serialDate11.getPreviousDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-January-1900" + "'", str8.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-January-1900" + "'", str20.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        timeSeries4.removeAgedItems(false);
        try {
            timeSeries4.delete(6, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        try {
            java.lang.Number number6 = timeSeries4.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeriesDataItem2.getPeriod();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.lang.String str5 = month4.toString();
        long long6 = month4.getMiddleMillisecond();
        boolean boolean7 = timeSeriesDataItem2.equals((java.lang.Object) month4);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month4.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setNotify(false);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate6);
        java.lang.String str8 = serialDate7.getDescription();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate7);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        long long9 = day7.getSerialIndex();
        int int10 = day7.getYear();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        long long3 = month0.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        timeSeries1.delete(regularTimePeriod6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate11);
        java.lang.String str14 = serialDate11.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate11);
        int int16 = day15.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            timeSeries1.add(regularTimePeriod20, (java.lang.Number) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-January-1900" + "'", str14.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day7.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = null;
        try {
            timeSeries4.add(timeSeriesDataItem10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate8 = serialDate3.getFollowingDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        long long9 = day7.getSerialIndex();
        int int10 = day7.getMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year3 = month2.getYear();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(3, year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        boolean boolean7 = year3.equals((java.lang.Object) 5);
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 100, year3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries4.createCopy((int) (short) 10, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeriesDataItem2.getPeriod();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.lang.String str5 = month4.toString();
        long long6 = month4.getMiddleMillisecond();
        boolean boolean7 = timeSeriesDataItem2.equals((java.lang.Object) month4);
        int int8 = month4.getYearValue();
        long long9 = month4.getSerialIndex();
        java.lang.String str10 = month4.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24234L + "'", long9 == 24234L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        boolean boolean8 = year4.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(7, year4);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year4.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        try {
            java.lang.Number number5 = timeSeries1.getValue((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -460");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        int int7 = day5.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        long long9 = day7.getSerialIndex();
        java.lang.String str10 = day7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-January-1900" + "'", str10.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean9 = timeSeries2.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.next();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (double) 1);
        int int18 = month15.getMonth();
        int int19 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int21 = fixedMillisecond10.compareTo((java.lang.Object) timeSeriesDataItem20);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 1560191457358L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate4);
        java.lang.String str7 = serialDate6.toString();
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-January-1900" + "'", str7.equals("31-January-1900"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate10);
        java.lang.String str13 = serialDate10.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate10);
        int int15 = day14.getDayOfMonth();
        long long16 = day14.getSerialIndex();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day14, (double) (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-January-1900" + "'", str13.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32L + "'", long16 == 32L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
        int int4 = year2.getYear();
        long long5 = year2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
        java.util.Calendar calendar7 = null;
        try {
            year2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        timeSeries1.setDomainDescription("Jan");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Monday" + "'", str1.equals("Monday"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.Year year5 = month0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191464689L + "'", long2 == 1560191464689L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191464689L + "'", long4 == 1560191464689L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191464689L + "'", long5 == 1560191464689L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560191464689L + "'", long7 == 1560191464689L);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 10);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        java.lang.String str10 = serialDate9.toString();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-January-1900" + "'", str10.equals("31-January-1900"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        timeSeries1.delete(regularTimePeriod6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate11);
        java.lang.String str14 = serialDate11.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate11);
        int int16 = day15.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year24 = month23.getYear();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(3, year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
        boolean boolean28 = year24.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(2, year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year24.previous();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(7, year24);
        long long32 = year24.getFirstMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year24, (double) (byte) 0, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-January-1900" + "'", str14.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        java.lang.Class<?> wildcardClass4 = year2.getClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries(comparable0, (java.lang.Class) wildcardClass4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.String str2 = month0.toString();
        int int3 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        boolean boolean8 = year4.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(7, year4);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year4.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        boolean boolean6 = year2.equals((java.lang.Object) 5);
        long long7 = year2.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        int int2 = month0.getYearValue();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
//        boolean boolean5 = timeSeries4.isEmpty();
//        timeSeries4.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.next();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) 1);
//        int int16 = month13.getMonth();
//        int int17 = month13.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
//        int int19 = fixedMillisecond8.compareTo((java.lang.Object) timeSeriesDataItem18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond8.previous();
//        long long21 = fixedMillisecond8.getSerialIndex();
//        try {
//            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 2);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560191466069L + "'", long21 == 1560191466069L);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-457), 1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '#', serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        int int7 = timeSeries4.getItemCount();
        try {
            timeSeries4.update(0, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        int int6 = day5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day5.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        java.lang.String str5 = serialDate3.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        java.lang.String str5 = serialDate3.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate3.getNearestDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.String str1 = fixedMillisecond0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mon Jun 10 11:31:06 PDT 2019" + "'", str1.equals("Mon Jun 10 11:31:06 PDT 2019"));
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        long long7 = day5.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            day5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2206368000000L) + "'", long7 == (-2206368000000L));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj3 = null;
        boolean boolean4 = timeSeries1.equals(obj3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        int int8 = month5.getMonth();
        int int9 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) (byte) 10);
        int int12 = month5.getMonth();
        org.jfree.data.time.Year year13 = month5.getYear();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        java.lang.String str7 = serialDate3.toString();
        java.lang.String str8 = serialDate3.toString();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-January-1900" + "'", str7.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-January-1900" + "'", str8.equals("31-January-1900"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone4 = null;
//        try {
//            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191467520L + "'", long2 == 1560191467520L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        timeSeries4.removeAgedItems(false);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate10);
        java.lang.String str12 = serialDate11.getDescription();
        java.lang.String str13 = serialDate11.getDescription();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate11);
        int int15 = day14.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.previous();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) 1560191458252L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        long long7 = day5.getFirstMillisecond();
        long long8 = day5.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2206368000000L) + "'", long7 == (-2206368000000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2206281600001L) + "'", long8 == (-2206281600001L));
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
//        int int8 = month5.getMonth();
//        int int9 = month5.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
//        int int11 = fixedMillisecond0.compareTo((java.lang.Object) timeSeriesDataItem10);
//        long long12 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560191467672L + "'", long12 == 1560191467672L);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener11);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 11:31:06 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        boolean boolean8 = year4.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(7, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year4.previous();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year4.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 10);
        java.util.Calendar calendar7 = null;
        try {
            month0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        boolean boolean4 = month0.equals((java.lang.Object) 1.0d);
        java.util.Calendar calendar5 = null;
        try {
            month0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        int int6 = day5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day5);
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy(2, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        java.lang.Comparable comparable30 = timeSeries29.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries29.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(comparable30);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate8 = serialDate3.getNearestDayOfWeek(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day7.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        long long30 = year26.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate34);
        java.lang.String str37 = serialDate34.getDescription();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate41);
        org.jfree.data.time.SerialDate serialDate44 = serialDate34.getEndOfCurrentMonth(serialDate43);
        boolean boolean45 = year26.equals((java.lang.Object) serialDate43);
        java.util.Calendar calendar46 = null;
        try {
            year26.peg(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-460));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-572) + "'", int1 == (-572));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.next();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1560191465944L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        int int4 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDescription("org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        int int9 = month7.getYearValue();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, class10);
        boolean boolean12 = timeSeries11.isEmpty();
        timeSeries11.setDescription("");
        java.util.Collection collection15 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.getDataItem(regularTimePeriod16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-January-1900");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        long long5 = month0.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year6 = month5.getYear();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        long long9 = year6.getLastMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year6, (double) 8);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        timeSeries1.setDomainDescription("Jan");
        timeSeries1.setMaximumItemAge((long) ' ');
        timeSeries1.setNotify(false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        long long7 = day5.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day5.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2206368000000L) + "'", long7 == (-2206368000000L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        timeSeries1.setKey((java.lang.Comparable) "Jan");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries1.update(regularTimePeriod13, (java.lang.Number) 1560191457358L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        timeSeries10.setMaximumItemCount(11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = null;
        try {
            timeSeries10.add(timeSeriesDataItem13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate6);
        java.lang.String str9 = serialDate6.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate6);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate6);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate18);
        java.lang.String str21 = serialDate18.toString();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate18);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate18);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate18);
        org.jfree.data.time.SerialDate serialDate25 = serialDate12.getEndOfCurrentMonth(serialDate24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate12);
        try {
            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2019, serialDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-January-1900" + "'", str9.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-January-1900" + "'", str21.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        boolean boolean30 = timeSeries29.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries29.addChangeListener(seriesChangeListener31);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 10);
        int int7 = month0.getMonth();
        org.jfree.data.time.Year year8 = month0.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        java.lang.Object obj14 = null;
        boolean boolean15 = timeSeriesDataItem12.equals(obj14);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate19);
        java.lang.String str22 = serialDate21.toString();
        boolean boolean23 = timeSeriesDataItem12.equals((java.lang.Object) str22);
        timeSeriesDataItem12.setValue((java.lang.Number) 97);
        try {
            timeSeries9.add(timeSeriesDataItem12);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-January-1900" + "'", str22.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.String str2 = month1.toString();
        int int3 = month1.getYearValue();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month1, class4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        int int10 = timeSeries5.getIndex(regularTimePeriod9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year17 = month16.getYear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(3, year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        boolean boolean21 = year17.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(2, year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(7, year17);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year27 = month26.getYear();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(3, year27);
        long long29 = year27.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year27);
        long long31 = year27.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate35);
        java.lang.String str38 = serialDate35.getDescription();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate42);
        org.jfree.data.time.SerialDate serialDate45 = serialDate35.getEndOfCurrentMonth(serialDate44);
        boolean boolean46 = year27.equals((java.lang.Object) serialDate44);
        try {
            org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        boolean boolean4 = month0.equals((java.lang.Object) 1.0d);
        int int5 = month0.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        long long36 = month33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries37.fireSeriesChanged();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (double) 1);
        int int42 = month39.getMonth();
        int int43 = month39.getMonth();
        org.jfree.data.time.Year year44 = month39.getYear();
        try {
            timeSeries37.add((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 1560668399999L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(year44);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate4);
        java.lang.String str7 = serialDate4.getDescription();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate4.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getPreviousDayOfWeek((int) (byte) 1);
        try {
            org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, class1);
        timeSeries2.setMaximumItemCount(10);
        long long5 = timeSeries2.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long5);
        java.lang.String str7 = seriesChangeEvent6.toString();
        java.lang.String str8 = seriesChangeEvent6.toString();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9223372036854775807]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=9223372036854775807]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9223372036854775807]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=9223372036854775807]"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str3 = serialDate2.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) -1, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        int int7 = timeSeries4.getItemCount();
        timeSeries4.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
        try {
            java.lang.Number number11 = timeSeries4.getValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str3 = serialDate2.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-457), serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        long long5 = year2.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.Year year8 = month3.getYear();
        try {
            int int9 = spreadsheetDate1.compareTo((java.lang.Object) year8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, class1);
        timeSeries2.setMaximumItemCount(10);
        long long5 = timeSeries2.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long5);
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + 9223372036854775807L + "'", obj7.equals(9223372036854775807L));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        boolean boolean4 = month0.equals((java.lang.Object) 1.0d);
        long long5 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-26), (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        timeSeries1.delete(regularTimePeriod6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate11);
        java.lang.String str14 = serialDate11.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate11);
        int int16 = day15.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) (-1.0f));
        int int20 = day15.getYear();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day15.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-January-1900" + "'", str14.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (-26), (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.Year year5 = month0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            year5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2019);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) "Jan");
        int int6 = timeSeriesDataItem2.compareTo((java.lang.Object) (-459));
        java.lang.Number number7 = timeSeriesDataItem2.getValue();
        java.lang.Object obj8 = timeSeriesDataItem2.clone();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.String str11 = month10.toString();
        int int12 = month10.getYearValue();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, class13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
        int int19 = timeSeries14.getIndex(regularTimePeriod18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.previous();
        boolean boolean30 = year26.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(2, year26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year26.previous();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(7, year26);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year36 = month35.getYear();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(3, year36);
        long long38 = year36.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) year36);
        long long40 = year36.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate44);
        java.lang.String str47 = serialDate44.getDescription();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate51);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate51);
        org.jfree.data.time.SerialDate serialDate54 = serialDate44.getEndOfCurrentMonth(serialDate53);
        boolean boolean55 = year36.equals((java.lang.Object) serialDate53);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(2, year36);
        boolean boolean57 = timeSeriesDataItem2.equals((java.lang.Object) year36);
        java.lang.Object obj58 = null;
        boolean boolean59 = year36.equals(obj58);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0d + "'", number7.equals(1.0d));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(3, year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        boolean boolean16 = year12.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(2, year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year12.previous();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year12, (double) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        try {
            timeSeries2.removeAgedItems((long) 31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        int int14 = timeSeries9.getIndex(regularTimePeriod13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(3, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        boolean boolean25 = year21.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year21.previous();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(7, year21);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year31 = month30.getYear();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(3, year31);
        long long33 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year31);
        long long35 = year31.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) year31);
        java.util.Calendar calendar37 = null;
        try {
            year31.peg(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries36);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        long long30 = year26.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate34);
        java.lang.String str37 = serialDate34.getDescription();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate41);
        org.jfree.data.time.SerialDate serialDate44 = serialDate34.getEndOfCurrentMonth(serialDate43);
        boolean boolean45 = year26.equals((java.lang.Object) serialDate43);
        java.util.Calendar calendar46 = null;
        try {
            long long47 = year26.getFirstMillisecond(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        int int6 = day5.getDayOfMonth();
        java.lang.String str7 = day5.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day5.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-January-1900" + "'", str7.equals("31-January-1900"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        int int3 = spreadsheetDate1.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getFollowingDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 10);
        int int7 = month0.getMonth();
        org.jfree.data.time.Year year8 = month0.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        java.lang.String str10 = timeSeries9.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy(regularTimePeriod11, regularTimePeriod12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date4 = spreadsheetDate3.toDate();
        int int5 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(8, serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        boolean boolean8 = year4.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(7, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year4.previous();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year4.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Mon Jun 10 11:31:07 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        int int2 = month0.getMonth();
        int int3 = month0.getMonth();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        java.lang.String str6 = seriesException3.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year3 = month2.getYear();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(3, year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        boolean boolean7 = year3.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(2, year3);
        java.util.Calendar calendar9 = null;
        try {
            month8.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str9 = timeSeries2.getRangeDescription();
        timeSeries2.setMaximumItemCount((int) (byte) 1);
        try {
            java.lang.Number number13 = timeSeries2.getValue((-26));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        int int2 = month0.getYearValue();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        int int9 = timeSeries4.getIndex(regularTimePeriod8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year16 = month15.getYear();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
//        boolean boolean20 = year16.equals((java.lang.Object) 5);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year26 = month25.getYear();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
//        long long28 = year26.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
//        long long36 = month33.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        java.util.Date date41 = fixedMillisecond38.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 31);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond38.getMiddleMillisecond(calendar44);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560191475121L + "'", long40 == 1560191475121L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560191475121L + "'", long45 == 1560191475121L);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate6);
        java.lang.String str9 = serialDate6.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        java.lang.Class<?> wildcardClass17 = year15.getClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, "Last", "hi!", (java.lang.Class) wildcardClass17);
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries(comparable0, "Mon Jun 10 11:31:06 PDT 2019", "Mon Jun 10 11:31:08 PDT 2019", (java.lang.Class) wildcardClass17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-January-1900" + "'", str9.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) (short) 100);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month11.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str7 = serialDate6.getDescription();
        boolean boolean8 = spreadsheetDate4.isOnOrBefore(serialDate6);
        int int9 = spreadsheetDate1.compare(serialDate6);
        org.jfree.data.time.SerialDate serialDate10 = null;
        try {
            org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate1.getEndOfCurrentMonth(serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-26) + "'", int9 == (-26));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=9223372036854775807]");
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        try {
            timeSeries1.delete(3, 1927);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str5 = serialDate4.getDescription();
        boolean boolean6 = spreadsheetDate2.isOnOrBefore(serialDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str11 = serialDate10.getDescription();
        boolean boolean12 = spreadsheetDate8.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate16);
        java.lang.String str19 = serialDate16.getDescription();
        boolean boolean20 = spreadsheetDate8.isOn(serialDate16);
        boolean boolean21 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        try {
            org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((-457), (org.jfree.data.time.SerialDate) spreadsheetDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setNotify(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate4);
        java.lang.String str7 = serialDate4.toString();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate4);
        int int9 = day8.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate10);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-January-1900" + "'", str7.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        timeSeries10.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str9 = timeSeries2.getRangeDescription();
        boolean boolean10 = timeSeries2.isEmpty();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        java.lang.Comparable comparable30 = timeSeries29.getKey();
        int int31 = timeSeries29.getItemCount();
        boolean boolean32 = timeSeries29.getNotify();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(comparable30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 10);
        int int7 = month0.getMonth();
        org.jfree.data.time.Year year8 = month0.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        timeSeries9.removeAgedItems(false);
        java.lang.String str12 = timeSeries9.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        long long7 = day5.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        int int9 = day5.getMonth();
        int int10 = day5.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9999);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.lang.String str15 = month14.toString();
        long long16 = month14.getMiddleMillisecond();
        boolean boolean17 = timeSeriesDataItem12.equals((java.lang.Object) month14);
        int int18 = month14.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1560668399999L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries4.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year24 = month23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
        java.lang.Class<?> wildcardClass26 = year24.getClass();
        int int27 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeriesDataItem2.getPeriod();
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeriesDataItem2.equals(obj4);
        timeSeriesDataItem2.setValue((java.lang.Number) 1551427200000L);
        timeSeriesDataItem2.setValue((java.lang.Number) 1551427200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        long long36 = month33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
        boolean boolean38 = timeSeries37.isEmpty();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Mon Jun 10 11:31:06 PDT 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Mon Jun 10 11:31:06 PDT 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Mon Jun 10 11:31:06 PDT 2019"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Monday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate3);
        java.lang.String str9 = day8.toString();
        int int10 = day8.getDayOfMonth();
        long long11 = day8.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-January-1900" + "'", str9.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2206281600001L) + "'", long11 == (-2206281600001L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(31, 17, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        int int4 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDescription("org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        int int9 = month7.getYearValue();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, class10);
        boolean boolean12 = timeSeries11.isEmpty();
        timeSeries11.setDescription("");
        java.util.Collection collection15 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            timeSeries1.add(regularTimePeriod16, (double) (short) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        java.lang.String str5 = serialDate3.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate3);
        int int7 = day6.getDayOfMonth();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem9.getPeriod();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str13 = serialDate12.getDescription();
        java.lang.String str14 = serialDate12.getDescription();
        int int15 = timeSeriesDataItem9.compareTo((java.lang.Object) str14);
        try {
            timeSeries1.add(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month0.next();
        java.lang.String str8 = month0.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        boolean boolean4 = month0.equals((java.lang.Object) 1.0d);
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getDayOfMonth();
        java.lang.String str4 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1927 + "'", int2 == 1927);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "17-May-1927" + "'", str4.equals("17-May-1927"));
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
//        java.lang.String str4 = serialDate3.getDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        boolean boolean13 = day5.equals((java.lang.Object) year12);
//        int int14 = day5.getYear();
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191479034L + "'", long10 == 1560191479034L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        long long7 = day5.getFirstMillisecond();
        int int8 = day5.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2206368000000L) + "'", long7 == (-2206368000000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.String str2 = month1.toString();
        int int3 = month1.getYearValue();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month1, class4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        int int10 = timeSeries5.getIndex(regularTimePeriod9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year17 = month16.getYear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(3, year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        boolean boolean21 = year17.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(2, year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(7, year17);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year27 = month26.getYear();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(3, year27);
        long long29 = year27.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        int int33 = fixedMillisecond31.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (double) 1);
        long long37 = month34.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (org.jfree.data.time.RegularTimePeriod) month34);
        java.lang.Class<?> wildcardClass39 = timeSeries30.getClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries(comparable0, (java.lang.Class) wildcardClass39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560668399999L + "'", long37 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year3 = month2.getYear();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(3, year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        boolean boolean7 = year3.equals((java.lang.Object) 5);
        long long8 = year3.getSerialIndex();
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(0, year3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12, (int) (byte) 0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.lang.String str15 = month14.toString();
        long long16 = month14.getMiddleMillisecond();
        boolean boolean17 = timeSeriesDataItem12.equals((java.lang.Object) month14);
        int int18 = month14.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1560668399999L);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.String str23 = month22.toString();
        int int24 = month22.getYearValue();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, class25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem29.getPeriod();
        int int31 = timeSeries26.getIndex(regularTimePeriod30);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries26.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year38 = month37.getYear();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(3, year38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.previous();
        boolean boolean42 = year38.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(2, year38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year38.previous();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(7, year38);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year48 = month47.getYear();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(3, year48);
        long long50 = year48.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) year38, (org.jfree.data.time.RegularTimePeriod) year48);
        long long52 = year48.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate56);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate56);
        java.lang.String str59 = serialDate56.getDescription();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate63);
        org.jfree.data.time.SerialDate serialDate66 = serialDate56.getEndOfCurrentMonth(serialDate65);
        boolean boolean67 = year48.equals((java.lang.Object) serialDate65);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(2, year48);
        java.lang.Number number69 = null;
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) month68, number69);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(year48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1546329600000L + "'", long52 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        long long36 = month33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
        try {
            java.lang.Number number39 = timeSeries29.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Jan");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        long long6 = year5.getMiddleMillisecond();
//        long long7 = year5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191480405L + "'", long2 == 1560191480405L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 10);
        int int7 = month0.getMonth();
        org.jfree.data.time.Year year8 = month0.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond10.next();
        java.lang.Object obj13 = null;
        boolean boolean14 = fixedMillisecond10.equals(obj13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        int int4 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDescription("org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.String str8 = month7.toString();
        int int9 = month7.getYearValue();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, class10);
        boolean boolean12 = timeSeries11.isEmpty();
        timeSeries11.setDescription("");
        java.util.Collection collection15 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1);
        int int17 = month14.getMonth();
        int int18 = month14.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) (byte) 10);
        long long21 = month14.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100L);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = month14.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24234L + "'", long21 == 24234L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int3 = spreadsheetDate2.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1927 + "'", int3 == 1927);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        timeSeries1.setDomainDescription("Jan");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        int int11 = timeSeries1.getIndex(regularTimePeriod10);
        java.lang.String str12 = timeSeries1.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries1.add(regularTimePeriod13, (double) (-572));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Jan" + "'", str12.equals("Jan"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        int int7 = timeSeries4.getItemCount();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(comparable8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560191465845L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        java.lang.String str5 = serialDate3.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("9999");
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//        java.util.Calendar calendar7 = null;
//        try {
//            year6.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191481148L + "'", long3 == 1560191481148L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1);
        int int17 = month14.getMonth();
        int int18 = month14.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) (byte) 10);
        long long21 = month14.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100L);
        try {
            timeSeries10.removeAgedItems((long) 6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24234L + "'", long21 == 24234L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str9 = timeSeries2.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (double) 1);
        int int18 = month15.getMonth();
        int int19 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        java.util.Collection collection21 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (double) 1);
        int int25 = month22.getMonth();
        int int26 = month22.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (double) (byte) 10);
        int int29 = month22.getMonth();
        try {
            timeSeries14.update((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeriesDataItem2.getPeriod();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.lang.String str5 = month4.toString();
        long long6 = month4.getMiddleMillisecond();
        boolean boolean7 = timeSeriesDataItem2.equals((java.lang.Object) month4);
        int int8 = month4.getYearValue();
        long long9 = month4.getSerialIndex();
        long long10 = month4.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24234L + "'", long9 == 24234L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Last");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str9 = timeSeries2.getRangeDescription();
        try {
            java.lang.Number number11 = timeSeries2.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        int int9 = day7.getMonth();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day7.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 11:31:08 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getYear();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate10 = serialDate3.getFollowingDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        long long9 = day7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day7.next();
        int int11 = day7.getDayOfMonth();
        java.util.Calendar calendar12 = null;
        try {
            day7.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        int int8 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 1560191475428L);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        boolean boolean4 = month0.equals((java.lang.Object) 1.0d);
        long long5 = month0.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            month0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str4 = serialDate3.getDescription();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate9);
        java.lang.String str12 = serialDate9.getDescription();
        boolean boolean13 = spreadsheetDate1.isOn(serialDate9);
        try {
            org.jfree.data.time.SerialDate serialDate15 = serialDate9.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        java.lang.String str5 = fixedMillisecond0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191483803L + "'", long3 == 1560191483803L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191483803L + "'", long4 == 1560191483803L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Mon Jun 10 11:31:23 PDT 2019" + "'", str5.equals("Mon Jun 10 11:31:23 PDT 2019"));
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        long long5 = year2.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date8 = spreadsheetDate7.toDate();
        boolean boolean9 = year2.equals((java.lang.Object) spreadsheetDate7);
        try {
            org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate7.getFollowingDayOfWeek(17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        int int14 = timeSeries9.getIndex(regularTimePeriod13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(3, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        boolean boolean25 = year21.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year21.previous();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(7, year21);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year31 = month30.getYear();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(3, year31);
        long long33 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year31);
        long long35 = year31.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) year31);
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        java.lang.String str38 = timeSeries36.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        long long3 = month0.getMiddleMillisecond();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str5 = serialDate4.getDescription();
        boolean boolean6 = spreadsheetDate2.isOnOrBefore(serialDate4);
        java.lang.String str7 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            int int10 = spreadsheetDate2.compareTo((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        boolean boolean8 = timeSeries1.isEmpty();
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Month month12 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.jfree.data.time.Year year13 = month12.getYear();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 1560191464867L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(month12);
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        java.util.List list5 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrBefore(serialDate3);
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Mon Jun 10 11:31:24 PDT 2019");
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        boolean boolean8 = year4.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(7, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year4.previous();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = regularTimePeriod12.getMiddleMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month1, (double) 1);
        boolean boolean5 = timeSeriesDataItem3.equals((java.lang.Object) "Jan");
        int int7 = timeSeriesDataItem3.compareTo((java.lang.Object) (-459));
        java.lang.Number number8 = timeSeriesDataItem3.getValue();
        java.lang.Object obj9 = timeSeriesDataItem3.clone();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        int int13 = month11.getYearValue();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem18.getPeriod();
        int int20 = timeSeries15.getIndex(regularTimePeriod19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year27 = month26.getYear();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(3, year27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        boolean boolean31 = year27.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(2, year27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year27.previous();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(7, year27);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year37 = month36.getYear();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(3, year37);
        long long39 = year37.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year37);
        long long41 = year37.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate45);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate45);
        java.lang.String str48 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate52);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate52);
        org.jfree.data.time.SerialDate serialDate55 = serialDate45.getEndOfCurrentMonth(serialDate54);
        boolean boolean56 = year37.equals((java.lang.Object) serialDate54);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(2, year37);
        boolean boolean58 = timeSeriesDataItem3.equals((java.lang.Object) year37);
        try {
            org.jfree.data.time.Month month59 = new org.jfree.data.time.Month((int) (byte) -1, year37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0d + "'", number8.equals(1.0d));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        java.lang.String str5 = serialDate4.getDescription();
        java.lang.String str6 = serialDate4.getDescription();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(12, serialDate4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate10 = serialDate4.getEndOfCurrentMonth(serialDate9);
        serialDate9.setDescription("31-January-1900");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str4 = serialDate3.getDescription();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
        java.util.Date date6 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate7 = null;
        try {
            boolean boolean8 = spreadsheetDate1.isAfter(serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "June 2019", "31-January-1900", class10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191484874L + "'", long2 == 1560191484874L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(5, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, (int) (byte) 1, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        java.util.Date date2 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        long long36 = month33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries37.fireSeriesChanged();
        timeSeries37.clear();
        timeSeries37.setDescription("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.String str2 = month0.toString();
        long long3 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str7 = serialDate6.getDescription();
        boolean boolean8 = spreadsheetDate4.isOnOrBefore(serialDate6);
        int int9 = spreadsheetDate1.compare(serialDate6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean12 = spreadsheetDate1.isOnOrAfter(serialDate11);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate17);
        java.lang.String str20 = serialDate17.toString();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate17);
        serialDate22.setDescription("");
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate30);
        java.lang.String str33 = serialDate30.toString();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate30);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate30);
        boolean boolean38 = spreadsheetDate1.isInRange(serialDate22, serialDate36, (int) (byte) -1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date41 = spreadsheetDate40.toDate();
        int int42 = spreadsheetDate40.getDayOfMonth();
        boolean boolean43 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        try {
            org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate40.getFollowingDayOfWeek(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-26) + "'", int9 == (-26));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-January-1900" + "'", str20.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "31-January-1900" + "'", str33.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 5 + "'", int42 == 5);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        int int6 = day5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        boolean boolean9 = day5.equals((java.lang.Object) 10.0d);
        java.util.Date date10 = day5.getStart();
        int int11 = day5.getDayOfMonth();
        int int12 = day5.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year2 = month1.getYear();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
//        int int4 = year2.getYear();
//        long long5 = year2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 10);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        boolean boolean11 = year2.equals((java.lang.Object) fixedMillisecond7);
//        long long12 = fixedMillisecond7.getMiddleMillisecond();
//        long long13 = fixedMillisecond7.getFirstMillisecond();
//        long long14 = fixedMillisecond7.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191486557L + "'", long10 == 1560191486557L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560191486557L + "'", long12 == 1560191486557L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560191486557L + "'", long13 == 1560191486557L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560191486557L + "'", long14 == 1560191486557L);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        timeSeries1.delete(regularTimePeriod6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate11);
        java.lang.String str14 = serialDate11.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate11);
        int int16 = day15.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) (-1.0f));
        int int20 = day15.getYear();
        long long21 = day15.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-January-1900" + "'", str14.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2206324800001L) + "'", long21 == (-2206324800001L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        int int6 = day5.getDayOfMonth();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int6);
        java.lang.Object obj8 = seriesChangeEvent7.getSource();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + 31 + "'", obj8.equals(31));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        int int6 = day5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        boolean boolean9 = day5.equals((java.lang.Object) 10.0d);
        java.util.Date date10 = day5.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.String str12 = day11.toString();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-January-1900" + "'", str12.equals("31-January-1900"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-January-1900");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year4 = month3.getYear();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(3, year4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
//        boolean boolean8 = year4.equals((java.lang.Object) 5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(7, year4);
//        long long12 = year4.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        int int15 = fixedMillisecond13.compareTo((java.lang.Object) (byte) 10);
//        int int16 = year4.compareTo((java.lang.Object) int15);
//        java.util.Date date17 = year4.getEnd();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond19.getLastMillisecond(calendar20);
//        java.util.Date date22 = fixedMillisecond19.getTime();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.util.Date date26 = spreadsheetDate25.toDate();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date22, timeZone27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date17, timeZone27);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560191486828L + "'", long21 == 1560191486828L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.jfree.data.time.Year year2 = month1.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate5);
        java.lang.String str8 = serialDate5.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate5);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate5);
        try {
            org.jfree.data.time.SerialDate serialDate13 = serialDate5.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-January-1900" + "'", str8.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Last");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        long long5 = year2.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date8 = spreadsheetDate7.toDate();
        boolean boolean9 = year2.equals((java.lang.Object) spreadsheetDate7);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(3, year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        long long15 = year12.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date18 = spreadsheetDate17.toDate();
        boolean boolean19 = year12.equals((java.lang.Object) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.Object obj21 = null;
        try {
            int int22 = spreadsheetDate17.compareTo(obj21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        java.lang.Number number3 = null;
        timeSeriesDataItem2.setValue(number3);
        java.lang.Object obj5 = timeSeriesDataItem2.clone();
        java.lang.Number number6 = null;
        timeSeriesDataItem2.setValue(number6);
        timeSeriesDataItem2.setValue((java.lang.Number) 7);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year13 = month12.getYear();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(3, year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        boolean boolean17 = year13.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(2, year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year13.previous();
        int int20 = timeSeriesDataItem2.compareTo((java.lang.Object) regularTimePeriod19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.lang.String str22 = month21.toString();
        int int23 = month21.getYearValue();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, class24);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.removeChangeListener(seriesChangeListener26);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries25.addChangeListener(seriesChangeListener28);
        boolean boolean30 = timeSeriesDataItem2.equals((java.lang.Object) seriesChangeListener28);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, class1);
        timeSeries2.setMaximumItemCount(10);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate10);
        java.lang.String str13 = serialDate10.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate10);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate22);
        java.lang.String str25 = serialDate22.toString();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate22);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate22);
        org.jfree.data.time.SerialDate serialDate29 = serialDate16.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate16);
        long long32 = day31.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day31, (double) 1560191478448L);
        org.jfree.data.time.SerialDate serialDate35 = day31.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-January-1900" + "'", str13.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "31-January-1900" + "'", str25.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1101916800000L) + "'", long32 == (-1101916800000L));
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(serialDate35);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str4 = serialDate3.getDescription();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
        java.lang.String str6 = spreadsheetDate1.getDescription();
        java.lang.Object obj7 = null;
        try {
            int int8 = spreadsheetDate1.compareTo(obj7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        java.util.Calendar calendar30 = null;
        try {
            long long31 = year26.getLastMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Monday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        boolean boolean6 = year2.equals((java.lang.Object) 5);
        long long7 = year2.getSerialIndex();
        java.util.Date date8 = year2.getStart();
        java.util.Calendar calendar9 = null;
        try {
            year2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        int int7 = timeSeries4.getItemCount();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate11);
        java.lang.String str13 = serialDate12.getDescription();
        java.lang.String str14 = serialDate12.getDescription();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate12);
        int int16 = day15.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day15);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate21);
        java.lang.String str23 = serialDate22.getDescription();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate22);
        int int25 = day24.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate26 = day24.getSerialDate();
        java.lang.Number number27 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day24);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate31);
        java.lang.String str34 = serialDate31.toString();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate31);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate31);
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "31-January-1900" + "'", str34.equals("31-January-1900"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        timeSeries1.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 1);
        int int10 = month7.getMonth();
        int int11 = month7.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month7.next();
        try {
            timeSeries1.add(regularTimePeriod14, (double) 2019);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate3);
        java.lang.String str9 = day8.toString();
        int int10 = day8.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate13 = serialDate11.getFollowingDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-January-1900" + "'", str9.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(serialDate11);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        java.util.Date date0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond1.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
//        try {
//            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date0, timeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191487712L + "'", long4 == 1560191487712L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1);
        int int17 = month14.getMonth();
        int int18 = month14.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) (byte) 10);
        long long21 = month14.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.previous();
        boolean boolean27 = fixedMillisecond24.equals((java.lang.Object) 2019);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) (-1101916800000L));
        try {
            timeSeries10.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24234L + "'", long21 == 24234L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 31, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year2 = month1.getYear();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
//        int int4 = year2.getYear();
//        long long5 = year2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 10);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        boolean boolean11 = year2.equals((java.lang.Object) fixedMillisecond7);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 6);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate18);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate18);
//        java.lang.String str21 = serialDate18.toString();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate18);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate18);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
//        int int25 = fixedMillisecond7.compareTo((java.lang.Object) timeSeries24);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond7.getMiddleMillisecond(calendar26);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191488012L + "'", long10 == 1560191488012L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-January-1900" + "'", str21.equals("31-January-1900"));
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560191488012L + "'", long27 == 1560191488012L);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(3);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries2.update(regularTimePeriod13, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str5 = serialDate4.getDescription();
        boolean boolean6 = spreadsheetDate2.isOnOrBefore(serialDate4);
        java.lang.String str7 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate12);
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str20 = serialDate19.getDescription();
        boolean boolean21 = spreadsheetDate17.isOnOrBefore(serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str26 = serialDate25.getDescription();
        boolean boolean27 = spreadsheetDate23.isOnOrBefore(serialDate25);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate31);
        java.lang.String str34 = serialDate31.getDescription();
        boolean boolean35 = spreadsheetDate23.isOn(serialDate31);
        boolean boolean36 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate39);
        java.lang.String str41 = serialDate40.getDescription();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
        long long44 = day42.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate45 = day42.getSerialDate();
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate23.getEndOfCurrentMonth(serialDate45);
        org.jfree.data.time.SerialDate serialDate47 = serialDate14.getEndOfCurrentMonth(serialDate46);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 32L + "'", long44 == 32L);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str7 = serialDate6.getDescription();
        boolean boolean8 = spreadsheetDate4.isOnOrBefore(serialDate6);
        int int9 = spreadsheetDate1.compare(serialDate6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean12 = spreadsheetDate1.isOnOrAfter(serialDate11);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate17);
        java.lang.String str20 = serialDate17.toString();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate17);
        serialDate22.setDescription("");
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate30);
        java.lang.String str33 = serialDate30.toString();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate30);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate30);
        boolean boolean38 = spreadsheetDate1.isInRange(serialDate22, serialDate36, (int) (byte) -1);
        try {
            org.jfree.data.time.SerialDate serialDate40 = serialDate22.getPreviousDayOfWeek(17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-26) + "'", int9 == (-26));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-January-1900" + "'", str20.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "31-January-1900" + "'", str33.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        int int6 = day5.getDayOfMonth();
        java.util.Calendar calendar7 = null;
        try {
            day5.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year2 = month1.getYear();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
//        int int4 = year2.getYear();
//        long long5 = year2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 10);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        boolean boolean11 = year2.equals((java.lang.Object) fixedMillisecond7);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 6);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate16);
//        java.lang.String str18 = serialDate17.getDescription();
//        java.lang.String str19 = serialDate17.getDescription();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate17);
//        int int21 = day20.getDayOfMonth();
//        int int22 = day20.getDayOfMonth();
//        int int23 = timeSeriesDataItem13.compareTo((java.lang.Object) day20);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191488741L + "'", long10 == 1560191488741L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate4);
        java.lang.String str7 = serialDate4.toString();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate4);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem13.getPeriod();
        java.lang.Number number15 = null;
        timeSeriesDataItem13.setValue(number15);
        boolean boolean17 = timeSeries10.equals((java.lang.Object) number15);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-January-1900" + "'", str7.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("May");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate4);
        java.lang.String str6 = serialDate5.getDescription();
        java.lang.String str7 = serialDate5.getDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
        int int9 = day8.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        boolean boolean11 = spreadsheetDate1.equals((java.lang.Object) day8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.String str13 = month12.toString();
        java.lang.String str14 = month12.toString();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, number15);
        boolean boolean18 = timeSeriesDataItem16.equals((java.lang.Object) 1560191468049L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560191468049L);
        int int20 = day8.compareTo((java.lang.Object) 1560191468049L);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        timeSeries4.removeAgedItems(false);
        java.util.Collection collection7 = timeSeries4.getTimePeriods();
        int int8 = timeSeries4.getItemCount();
        boolean boolean9 = timeSeries4.getNotify();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.lang.String str15 = month14.toString();
        int int16 = month14.getYearValue();
        org.jfree.data.time.Year year17 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) (byte) -1);
        java.lang.Object obj20 = timeSeries10.clone();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        int int14 = timeSeries9.getIndex(regularTimePeriod13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(3, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        boolean boolean25 = year21.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year21.previous();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(7, year21);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year31 = month30.getYear();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(3, year31);
        long long33 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year31);
        long long35 = year31.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) year31);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener37);
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener39);
        try {
            java.lang.Number number42 = timeSeries1.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries36);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date3 = spreadsheetDate2.toDate();
        int int4 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        java.lang.Number number12 = null;
        try {
            timeSeries1.add(regularTimePeriod11, number12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        java.lang.String str4 = serialDate3.getDescription();
//        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        java.lang.String str10 = serialDate9.getDescription();
//        boolean boolean11 = spreadsheetDate7.isOnOrBefore(serialDate9);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate15);
//        java.lang.String str18 = serialDate15.getDescription();
//        boolean boolean19 = spreadsheetDate7.isOn(serialDate15);
//        boolean boolean20 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        java.util.Date date21 = spreadsheetDate1.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        try {
//            int int27 = spreadsheetDate1.compareTo((java.lang.Object) date25);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191489942L + "'", long24 == 1560191489942L);
//        org.junit.Assert.assertNotNull(date25);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("31-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) "Jan");
        int int6 = timeSeriesDataItem2.compareTo((java.lang.Object) (-459));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem2.getPeriod();
        java.lang.String str8 = regularTimePeriod7.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        java.lang.String str6 = day5.toString();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
        int int4 = year2.getYear();
        long long5 = year2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 1);
        int int10 = month7.getMonth();
        int int11 = month7.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem13.getPeriod();
        java.lang.Object obj15 = timeSeriesDataItem13.clone();
        boolean boolean16 = year2.equals((java.lang.Object) timeSeriesDataItem13);
        long long17 = year2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        long long36 = month33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.Class<?> wildcardClass38 = timeSeries29.getClass();
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries29.removePropertyChangeListener(propertyChangeListener39);
        java.lang.String str41 = timeSeries29.getDescription();
        timeSeries29.setRangeDescription("2019");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(serialDate7);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        try {
//            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) ' ', year5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191491784L + "'", long3 == 1560191491784L);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year2 = month1.getYear();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
//        int int4 = year2.getYear();
//        long long5 = year2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 10);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        boolean boolean11 = year2.equals((java.lang.Object) fixedMillisecond7);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 6);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond7.getFirstMillisecond(calendar14);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191491794L + "'", long10 == 1560191491794L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191491794L + "'", long15 == 1560191491794L);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        timeSeries1.setDomainDescription("Jan");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        int int11 = timeSeries1.getIndex(regularTimePeriod10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        boolean boolean5 = timeSeries4.isEmpty();
        long long6 = timeSeries4.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries4.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries4.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(comparable7);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.lang.String str15 = month14.toString();
        long long16 = month14.getMiddleMillisecond();
        boolean boolean17 = timeSeriesDataItem12.equals((java.lang.Object) month14);
        int int18 = month14.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1560668399999L);
        int int21 = month14.getYearValue();
        long long22 = month14.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.Year year8 = month3.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener10);
        long long12 = timeSeries2.getMaximumItemAge();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setNotify(false);
        java.lang.String str4 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(3, year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        long long12 = year9.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date15 = spreadsheetDate14.toDate();
        boolean boolean16 = year9.equals((java.lang.Object) spreadsheetDate14);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj3 = null;
        boolean boolean4 = timeSeries1.equals(obj3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year6 = month5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.addOrUpdate(regularTimePeriod7, (java.lang.Number) 1546329600000L);
        java.lang.Class class10 = timeSeries1.getTimePeriodClass();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1);
        int int17 = month14.getMonth();
        int int18 = month14.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        timeSeries13.setNotify(false);
        java.util.Collection collection22 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.util.List list23 = timeSeries13.getItems();
        java.lang.Object obj24 = timeSeries13.clone();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        boolean boolean8 = timeSeries1.isEmpty();
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Mon Jun 10 11:31:07 PDT 2019");
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        timeSeries1.setDomainDescription("Jan");
        timeSeries1.setMaximumItemAge((long) ' ');
        java.lang.String str10 = timeSeries1.getDescription();
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day7.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
        java.util.Calendar calendar4 = null;
        try {
            year2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(2);
        timeSeries1.setKey((java.lang.Comparable) serialDate6);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-572));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate5);
        java.lang.String str8 = serialDate5.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate5);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate5);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate17);
        java.lang.String str20 = serialDate17.toString();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate17);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate17);
        org.jfree.data.time.SerialDate serialDate24 = serialDate11.getEndOfCurrentMonth(serialDate23);
        org.jfree.data.time.SerialDate serialDate26 = serialDate11.getPreviousDayOfWeek(7);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-January-1900" + "'", str8.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-January-1900" + "'", str20.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=9223372036854775807]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("31-January-1900");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str6 = seriesException5.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        int int6 = day5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        boolean boolean9 = day5.equals((java.lang.Object) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.previous();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        long long7 = day5.getSerialIndex();
        int int8 = day5.getMonth();
        java.lang.String str9 = day5.toString();
        int int10 = day5.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-January-1900" + "'", str9.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        int int2 = month0.getYearValue();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        int int9 = timeSeries4.getIndex(regularTimePeriod8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year16 = month15.getYear();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
//        boolean boolean20 = year16.equals((java.lang.Object) 5);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year26 = month25.getYear();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
//        long long28 = year26.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
//        long long36 = month33.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        java.util.Date date41 = fixedMillisecond38.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) 31);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(10, (int) (short) 100);
//        try {
//            timeSeries29.add((org.jfree.data.time.RegularTimePeriod) month46, (double) '#', false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560191493368L + "'", long40 == 1560191493368L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 11:31:07 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj3 = null;
        boolean boolean4 = timeSeries1.equals(obj3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year6 = month5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.addOrUpdate(regularTimePeriod7, (java.lang.Number) 1546329600000L);
        java.lang.Class class10 = timeSeries1.getTimePeriodClass();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1);
        int int17 = month14.getMonth();
        int int18 = month14.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        timeSeries13.setNotify(false);
        java.util.Collection collection22 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.util.List list23 = timeSeries13.getItems();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate26);
        java.lang.String str28 = serialDate27.getDescription();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate27);
        int int30 = day29.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate31 = day29.getSerialDate();
        boolean boolean33 = day29.equals((java.lang.Object) 10.0d);
        java.util.Date date34 = day29.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year40 = month39.getYear();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(3, year40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.previous();
        boolean boolean44 = year40.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(2, year40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year40.previous();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(7, year40);
        long long48 = year40.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) year40);
        java.util.Calendar calendar50 = null;
        try {
            year40.peg(calendar50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(year40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1546329600000L + "'", long48 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries49);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1);
        int int17 = month14.getMonth();
        int int18 = month14.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) (byte) 10);
        long long21 = month14.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100L);
        java.util.Calendar calendar24 = null;
        try {
            month14.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24234L + "'", long21 == 24234L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        java.lang.String str4 = serialDate3.getDescription();
//        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        java.lang.String str10 = serialDate9.getDescription();
//        boolean boolean11 = spreadsheetDate7.isOnOrBefore(serialDate9);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate15);
//        java.lang.String str18 = serialDate15.getDescription();
//        boolean boolean19 = spreadsheetDate7.isOn(serialDate15);
//        boolean boolean20 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        int int21 = spreadsheetDate7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate25);
//        java.lang.String str28 = serialDate25.toString();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate25);
//        int int30 = day29.getDayOfMonth();
//        long long31 = day29.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day29.next();
//        org.jfree.data.time.SerialDate serialDate33 = day29.getSerialDate();
//        boolean boolean34 = spreadsheetDate7.isAfter(serialDate33);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year37 = month36.getYear();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(3, year37);
//        int int39 = year37.getYear();
//        long long40 = year37.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year37.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        int int44 = fixedMillisecond42.compareTo((java.lang.Object) (byte) 10);
//        long long45 = fixedMillisecond42.getFirstMillisecond();
//        boolean boolean46 = year37.equals((java.lang.Object) fixedMillisecond42);
//        java.util.Date date47 = year37.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond48.next();
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond48.getFirstMillisecond(calendar50);
//        java.util.Date date52 = fixedMillisecond48.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date52, timeZone53);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date47, timeZone53);
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date47);
//        boolean boolean57 = spreadsheetDate7.isOnOrAfter(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31-January-1900" + "'", str28.equals("31-January-1900"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 32L + "'", long31 == 32L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560191493463L + "'", long45 == 1560191493463L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560191493464L + "'", long51 == 1560191493464L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        java.lang.Number number6 = null;
        try {
            timeSeries1.add(regularTimePeriod5, number6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1);
        int int17 = month14.getMonth();
        int int18 = month14.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) (byte) 10);
        long long21 = month14.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100L);
        java.lang.String str24 = timeSeries10.getRangeDescription();
        timeSeries10.setMaximumItemAge((long) 1927);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24234L + "'", long21 == 24234L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2958465, 9, 1927);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year9 = month8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
//        java.lang.Class<?> wildcardClass11 = year9.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191494417L + "'", long4 == 1560191494417L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191494417L + "'", long5 == 1560191494417L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Mon Jun 10 11:31:24 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        int int9 = day7.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day7.previous();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 97, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        java.lang.String str5 = serialDate3.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate3);
        int int7 = day6.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
        java.util.Calendar calendar9 = null;
        try {
            day6.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        int int14 = timeSeries9.getIndex(regularTimePeriod13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(3, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        boolean boolean25 = year21.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year21.previous();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(7, year21);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year31 = month30.getYear();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(3, year31);
        long long33 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year31);
        long long35 = year31.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) year31);
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        timeSeries36.setRangeDescription("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(collection37);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year2 = month1.getYear();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
//        int int4 = year2.getYear();
//        long long5 = year2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 10);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        boolean boolean11 = year2.equals((java.lang.Object) fixedMillisecond7);
//        java.util.Date date12 = year2.getStart();
//        long long13 = year2.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191495087L + "'", long10 == 1560191495087L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate4);
        java.lang.String str7 = serialDate4.toString();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate4);
        int int9 = day8.getDayOfMonth();
        long long10 = day8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.next();
        org.jfree.data.time.SerialDate serialDate12 = day8.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) ' ', serialDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-January-1900" + "'", str7.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, class1);
        timeSeries2.setMaximumItemCount(10);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate10);
        java.lang.String str13 = serialDate10.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate10);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate22);
        java.lang.String str25 = serialDate22.toString();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate22);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate22);
        org.jfree.data.time.SerialDate serialDate29 = serialDate16.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate16);
        long long32 = day31.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day31, (double) 1560191478448L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.next();
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) 1);
        int int43 = month40.getMonth();
        int int44 = month40.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries39.getDataItem((org.jfree.data.time.RegularTimePeriod) month40);
        int int46 = fixedMillisecond35.compareTo((java.lang.Object) timeSeriesDataItem45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond35.previous();
        int int48 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.String str50 = month49.toString();
        int int51 = month49.getYearValue();
        long long52 = month49.getSerialIndex();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month49, (double) 1560191481336L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-January-1900" + "'", str13.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "31-January-1900" + "'", str25.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1101916800000L) + "'", long32 == (-1101916800000L));
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 24234L + "'", long52 == 24234L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.addChangeListener(seriesChangeListener8);
        timeSeries7.setMaximumItemCount((int) 'a');
        timeSeries7.setDomainDescription("Jan");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        int int17 = timeSeries7.getIndex(regularTimePeriod16);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod16);
        try {
            timeSeries1.update(regularTimePeriod16, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        java.util.List list11 = timeSeries10.getItems();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.String str2 = month1.toString();
        int int3 = month1.getYearValue();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month1, class4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        int int10 = timeSeries5.getIndex(regularTimePeriod9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year17 = month16.getYear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(3, year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        boolean boolean21 = year17.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(2, year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(7, year17);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year27 = month26.getYear();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(3, year27);
        long long29 = year27.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year27);
        long long31 = year27.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate35);
        java.lang.String str38 = serialDate35.getDescription();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate42);
        org.jfree.data.time.SerialDate serialDate45 = serialDate35.getEndOfCurrentMonth(serialDate44);
        boolean boolean46 = year27.equals((java.lang.Object) serialDate44);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(2, year27);
        java.util.Calendar calendar48 = null;
        try {
            long long49 = year27.getFirstMillisecond(calendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.next();
        java.lang.Object obj8 = null;
        boolean boolean9 = fixedMillisecond5.equals(obj8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond5.previous();
        java.util.Calendar calendar11 = null;
        fixedMillisecond5.peg(calendar11);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries1.setDomainDescription("Mon Jun 10 11:31:08 PDT 2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(1560191478526L);
        java.lang.Number number18 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) 1);
        int int22 = month19.getMonth();
        int int23 = month19.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) (byte) 10);
        int int26 = month19.getMonth();
        org.jfree.data.time.Year year27 = month19.getYear();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 97);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.createCopy(8, (int) ' ');
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy(2019, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        boolean boolean4 = month0.equals((java.lang.Object) 1.0d);
        int int5 = month0.getYearValue();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate9);
        java.lang.String str12 = serialDate9.toString();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year18 = month17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        java.lang.Class<?> wildcardClass20 = year18.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, "Last", "hi!", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int5, (java.lang.Class) wildcardClass20);
        timeSeries22.setMaximumItemCount((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-January-1900" + "'", str12.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getFirstMillisecond(calendar8);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191495671L + "'", long4 == 1560191495671L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191495671L + "'", long5 == 1560191495671L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191495671L + "'", long9 == 1560191495671L);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        timeSeries1.delete(regularTimePeriod6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate11);
        java.lang.String str14 = serialDate11.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate11);
        int int16 = day15.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) (-1.0f));
        timeSeries1.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class23);
        java.lang.Class<?> wildcardClass25 = timeSeries24.getClass();
        boolean boolean26 = timeSeries1.equals((java.lang.Object) wildcardClass25);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-January-1900" + "'", str14.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(class27);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str10 = serialDate9.getDescription();
        java.lang.String str11 = serialDate9.getDescription();
        int int12 = timeSeriesDataItem6.compareTo((java.lang.Object) str11);
        java.lang.Object obj13 = timeSeriesDataItem6.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str4 = serialDate3.getDescription();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(6);
        boolean boolean9 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        long long36 = month33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.Class<?> wildcardClass38 = timeSeries29.getClass();
        java.lang.String str39 = timeSeries29.getDescription();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) 1);
        int int43 = month40.getMonth();
        int int44 = month40.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) (byte) 10);
        int int47 = month40.getMonth();
        org.jfree.data.time.Year year48 = month40.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 1560191462161L);
        java.util.Calendar calendar51 = null;
        try {
            long long52 = month40.getLastMillisecond(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(year48);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(100, 7, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        long long36 = month33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.String str38 = month33.toString();
        java.util.Calendar calendar39 = null;
        try {
            long long40 = month33.getLastMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str4 = serialDate3.getDescription();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate9);
        java.lang.String str12 = serialDate9.getDescription();
        boolean boolean13 = spreadsheetDate1.isOn(serialDate9);
        try {
            org.jfree.data.time.SerialDate serialDate15 = serialDate9.getNearestDayOfWeek((-572));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        int int10 = day7.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        long long10 = day7.getLastMillisecond();
        long long11 = day7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2206281600001L) + "'", long10 == (-2206281600001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2206368000000L) + "'", long11 == (-2206368000000L));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        timeSeries1.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Object obj7 = timeSeries1.clone();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year10 = month9.getYear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(3, year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
        long long13 = year10.getFirstMillisecond();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1.0f);
        int int17 = year10.getYear();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year2 = month1.getYear();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
//        int int4 = year2.getYear();
//        long long5 = year2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 10);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        boolean boolean11 = year2.equals((java.lang.Object) fixedMillisecond7);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 6);
//        java.lang.String str14 = fixedMillisecond7.toString();
//        long long15 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond7.next();
//        long long17 = fixedMillisecond7.getSerialIndex();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191496786L + "'", long10 == 1560191496786L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Mon Jun 10 11:31:36 PDT 2019" + "'", str14.equals("Mon Jun 10 11:31:36 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191496786L + "'", long15 == 1560191496786L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560191496786L + "'", long17 == 1560191496786L);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond0.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4);
//        long long8 = day7.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191496834L + "'", long3 == 1560191496834L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        timeSeries4.fireSeriesChanged();
        boolean boolean13 = timeSeries4.getNotify();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1);
        int int17 = month14.getMonth();
        int int18 = month14.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem20.getPeriod();
        try {
            timeSeries4.add(regularTimePeriod21, (java.lang.Number) 1560191488012L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        java.lang.Comparable comparable30 = timeSeries29.getKey();
        int int31 = timeSeries29.getItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year34 = month33.getYear();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(3, year34);
        long long36 = year34.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) year34);
        boolean boolean39 = year34.equals((java.lang.Object) 1560191488012L);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(comparable30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        int int10 = day7.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
        int int12 = day7.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        int int14 = timeSeries9.getIndex(regularTimePeriod13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(3, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        boolean boolean25 = year21.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year21.previous();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(7, year21);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year31 = month30.getYear();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(3, year31);
        long long33 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year31);
        long long35 = year31.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) year31);
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = null;
        try {
            timeSeries36.add(timeSeriesDataItem38, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(collection37);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        long long36 = month33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.Class<?> wildcardClass38 = timeSeries29.getClass();
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries29.removePropertyChangeListener(propertyChangeListener39);
        java.lang.String str41 = timeSeries29.getDescription();
        java.lang.String str42 = timeSeries29.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Time" + "'", str42.equals("Time"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str7 = serialDate6.getDescription();
        boolean boolean8 = spreadsheetDate4.isOnOrBefore(serialDate6);
        int int9 = spreadsheetDate1.compare(serialDate6);
        int int10 = spreadsheetDate1.getYYYY();
        try {
            int int12 = spreadsheetDate1.compareTo((java.lang.Object) 1560191492556L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-26) + "'", int9 == (-26));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) (byte) 10);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191497957L + "'", long3 == 1560191497957L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(97);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
//        int int8 = month5.getMonth();
//        int int9 = month5.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
//        int int11 = fixedMillisecond0.compareTo((java.lang.Object) timeSeriesDataItem10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond0.next();
//        long long13 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560191497982L + "'", long13 == 1560191497982L);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        timeSeries1.setDomainDescription("Jan");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        int int11 = timeSeries1.getIndex(regularTimePeriod10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod10);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        boolean boolean8 = timeSeries1.isEmpty();
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        java.lang.String str10 = timeSeries1.getDescription();
        timeSeries1.setDescription("June 2019");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener13);
        timeSeries1.setDomainDescription("Mon Jun 10 11:31:08 PDT 2019");
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        long long36 = month33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.Class<?> wildcardClass38 = timeSeries29.getClass();
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries29.removePropertyChangeListener(propertyChangeListener39);
        java.lang.String str41 = timeSeries29.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries29.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str4 = serialDate3.getDescription();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
        int int6 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 10);
        int int7 = month0.getMonth();
        long long8 = month0.getLastMillisecond();
        int int9 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=9223372036854775807]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeriesDataItem2.getPeriod();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.lang.String str5 = month4.toString();
        long long6 = month4.getMiddleMillisecond();
        boolean boolean7 = timeSeriesDataItem2.equals((java.lang.Object) month4);
        long long8 = month4.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        java.lang.String str7 = serialDate6.getDescription();
//        boolean boolean8 = spreadsheetDate4.isOnOrBefore(serialDate6);
//        int int9 = spreadsheetDate1.compare(serialDate6);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
//        boolean boolean12 = spreadsheetDate1.isOnOrAfter(serialDate11);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year15 = month14.getYear();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(3, year15);
//        int int17 = year15.getYear();
//        long long18 = year15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) (byte) 10);
//        long long23 = fixedMillisecond20.getFirstMillisecond();
//        boolean boolean24 = year15.equals((java.lang.Object) fixedMillisecond20);
//        java.util.Date date25 = year15.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond26.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond26.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date25, timeZone31);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.SerialDate serialDate35 = null;
//        try {
//            boolean boolean37 = spreadsheetDate1.isInRange(serialDate34, serialDate35, (-2));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-26) + "'", int9 == (-26));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191499182L + "'", long23 == 1560191499182L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560191499183L + "'", long29 == 1560191499183L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(serialDate34);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        int int10 = day7.getYear();
        java.util.Calendar calendar11 = null;
        try {
            day7.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        int int4 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDescription("org.jfree.data.general.SeriesException: hi!");
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        timeSeries1.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
        java.lang.String str4 = serialDate3.getDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        int int6 = day5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day5);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (double) 1);
        int int15 = month12.getMonth();
        int int16 = month12.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
        java.lang.String str18 = timeSeries11.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener19);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 1);
        int int27 = month24.getMonth();
        int int28 = month24.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) month24);
        java.util.Collection collection30 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year35 = month34.getYear();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(3, year35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.previous();
        boolean boolean39 = year35.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(2, year35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year35.previous();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(7, year35);
        long long43 = year35.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        int int46 = fixedMillisecond44.compareTo((java.lang.Object) (byte) 10);
        int int47 = year35.compareTo((java.lang.Object) int46);
        java.lang.Number number48 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year35);
        int int49 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year35);
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, class51);
        timeSeries52.setMaximumItemCount(10);
        boolean boolean55 = year35.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(3, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        boolean boolean8 = year4.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(7, year4);
        long long12 = year4.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        int int15 = fixedMillisecond13.compareTo((java.lang.Object) (byte) 10);
        int int16 = year4.compareTo((java.lang.Object) int15);
        long long17 = year4.getSerialIndex();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.jfree.data.time.Year year2 = month1.getYear();
        long long3 = month1.getLastMillisecond();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, class1);
        timeSeries2.setMaximumItemCount(10);
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.removeAgedItems(false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) 1);
        int int11 = month8.getMonth();
        int int12 = month8.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) (byte) 10);
        int int15 = month8.getMonth();
        org.jfree.data.time.Year year16 = month8.getYear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year19 = month18.getYear();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(3, year19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        boolean boolean23 = year19.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) year19);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = month8.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) (byte) 10);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year6 = month5.getYear();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
//        boolean boolean10 = year6.equals((java.lang.Object) 5);
//        long long11 = year6.getSerialIndex();
//        long long12 = year6.getFirstMillisecond();
//        int int13 = fixedMillisecond0.compareTo((java.lang.Object) long12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191500610L + "'", long3 == 1560191500610L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate2);
//        java.lang.String str4 = serialDate3.getDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        boolean boolean13 = day5.equals((java.lang.Object) year12);
//        long long14 = year12.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191500811L + "'", long10 == 1560191500811L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        int int14 = timeSeries9.getIndex(regularTimePeriod13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(3, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        boolean boolean25 = year21.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year21.previous();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(7, year21);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year31 = month30.getYear();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(3, year31);
        long long33 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year31);
        long long35 = year31.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) year31);
        java.util.Date date37 = day4.getEnd();
        java.util.Calendar calendar38 = null;
        try {
            long long39 = day4.getFirstMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        long long2 = timeSeries1.getMaximumItemAge();
        int int3 = timeSeries1.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        int int8 = month6.getYearValue();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, class9);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate14);
        java.lang.String str17 = serialDate14.toString();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        int int20 = day18.getMonth();
        java.lang.Number number21 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) day18);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 1560191499661L, true);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-January-1900" + "'", str17.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(number21);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        long long2 = timeSeries1.getMaximumItemAge();
        boolean boolean3 = timeSeries1.getNotify();
        java.lang.String str4 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) "Jan");
        int int11 = timeSeriesDataItem7.compareTo((java.lang.Object) (-459));
        java.lang.Number number12 = timeSeriesDataItem7.getValue();
        try {
            timeSeries1.add(timeSeriesDataItem7, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1.0d + "'", number12.equals(1.0d));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) (byte) 10);
        int int7 = month0.getMonth();
        org.jfree.data.time.Year year8 = month0.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
        int int10 = timeSeries9.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.createCopy(10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        int int10 = day7.getDayOfMonth();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        java.lang.String str13 = month11.toString();
        java.lang.Number number14 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, number14);
        java.lang.Number number16 = timeSeriesDataItem15.getValue();
        timeSeriesDataItem15.setValue((java.lang.Number) 0.0d);
        boolean boolean19 = day7.equals((java.lang.Object) timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str5 = serialDate4.getDescription();
        boolean boolean6 = spreadsheetDate2.isOnOrBefore(serialDate4);
        java.lang.String str7 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate12);
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate14);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate19);
        boolean boolean22 = spreadsheetDate2.isOn(serialDate21);
        java.lang.Object obj23 = null;
        try {
            int int24 = spreadsheetDate2.compareTo(obj23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        timeSeries1.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Object obj7 = timeSeries1.clone();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year10 = month9.getYear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(3, year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
        long long13 = year10.getFirstMillisecond();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1.0f);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate20);
        java.lang.String str23 = serialDate20.toString();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate20);
        int int25 = day24.getDayOfMonth();
        long long26 = day24.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day24.next();
        int int28 = day24.getDayOfMonth();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day24, (double) 1560191500811L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 31-January-1900 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 7 + "'", comparable4.equals(7));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-January-1900" + "'", str23.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 32L + "'", long26 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 31 + "'", int28 == 31);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("May");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
        int int6 = month3.getMonth();
        int int7 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str9 = timeSeries2.getRangeDescription();
        timeSeries2.setMaximumItemCount((int) (byte) 1);
        java.lang.String str12 = timeSeries2.getDescription();
        timeSeries2.setRangeDescription("Value");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year2 = month1.getYear();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
//        int int4 = year2.getYear();
//        long long5 = year2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 10);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        boolean boolean11 = year2.equals((java.lang.Object) fixedMillisecond7);
//        long long12 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long12);
//        timeSeries13.setRangeDescription("Mon Jun 10 11:31:24 PDT 2019");
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191501228L + "'", long10 == 1560191501228L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560191501228L + "'", long12 == 1560191501228L);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        long long5 = year2.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date8 = spreadsheetDate7.toDate();
        boolean boolean9 = year2.equals((java.lang.Object) spreadsheetDate7);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(3, year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        long long15 = year12.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date18 = spreadsheetDate17.toDate();
        boolean boolean19 = year12.equals((java.lang.Object) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int21 = spreadsheetDate17.getMonth();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}

