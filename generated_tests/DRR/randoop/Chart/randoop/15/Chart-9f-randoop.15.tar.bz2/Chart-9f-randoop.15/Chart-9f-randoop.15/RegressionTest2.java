import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) (short) 100);
        long long14 = month11.getFirstMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            month11.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test02");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191551215L + "'", long2 == 1560191551215L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191551215L + "'", long4 == 1560191551215L);
//    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test04");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) (byte) 10);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191551233L + "'", long3 == 1560191551233L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        int int14 = timeSeries9.getIndex(regularTimePeriod13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(3, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        boolean boolean25 = year21.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(2, year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year21.previous();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(7, year21);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year31 = month30.getYear();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(3, year31);
        long long33 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year31);
        long long35 = year31.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) year31);
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries36.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year43 = month42.getYear();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(3, year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.previous();
        long long46 = year43.getFirstMillisecond();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(1, year43);
        int int48 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) month47);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(year43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test06");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year2 = month1.getYear();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year2);
//        int int4 = year2.getYear();
//        long long5 = year2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 10);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        boolean boolean11 = year2.equals((java.lang.Object) fixedMillisecond7);
//        java.util.Date date12 = year2.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond13.next();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond13.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond13.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date12, timeZone18);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date12);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year24 = month23.getYear();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(3, year24);
//        int int26 = year24.getYear();
//        long long27 = year24.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        int int31 = fixedMillisecond29.compareTo((java.lang.Object) (byte) 10);
//        long long32 = fixedMillisecond29.getFirstMillisecond();
//        boolean boolean33 = year24.equals((java.lang.Object) fixedMillisecond29);
//        java.util.Date date34 = year24.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.next();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond35.getFirstMillisecond(calendar37);
//        java.util.Date date39 = fixedMillisecond35.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39, timeZone40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date34, timeZone40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date12, timeZone40);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191551599L + "'", long10 == 1560191551599L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560191551600L + "'", long16 == 1560191551600L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560191551602L + "'", long32 == 1560191551602L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560191551603L + "'", long38 == 1560191551603L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate4);
        java.lang.String str7 = serialDate4.toString();
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getPreviousDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(17, serialDate9);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-January-1900" + "'", str7.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str4 = serialDate3.getDescription();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str10 = serialDate9.getDescription();
        boolean boolean11 = spreadsheetDate7.isOnOrBefore(serialDate9);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate15);
        java.lang.String str18 = serialDate15.getDescription();
        boolean boolean19 = spreadsheetDate7.isOn(serialDate15);
        boolean boolean20 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.util.Date date21 = spreadsheetDate1.toDate();
        int int22 = spreadsheetDate1.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate1.getNearestDayOfWeek((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test09");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) (byte) 10);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        long long8 = fixedMillisecond7.getLastMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond7.getLastMillisecond(calendar9);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191552116L + "'", long3 == 1560191552116L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191552116L + "'", long8 == 1560191552116L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191552116L + "'", long10 == 1560191552116L);
//    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        timeSeries1.setDomainDescription("Jan");
        timeSeries1.setMaximumItemAge((long) ' ');
        java.lang.String str10 = timeSeries1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate16);
        java.lang.String str18 = serialDate17.getDescription();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        long long21 = day19.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        int int23 = day19.getMonth();
        long long24 = day19.getSerialIndex();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 1560191469267L);
        int int28 = day19.compareTo((java.lang.Object) 1560191493045L);
        java.util.Calendar calendar29 = null;
        try {
            day19.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Jan" + "'", str10.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Jan" + "'", str13.equals("Jan"));
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 32L + "'", long21 == 32L);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 32L + "'", long24 == 32L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate6);
        java.lang.String str9 = serialDate8.toString();
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate8);
        spreadsheetDate1.setDescription("9999");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-January-1900" + "'", str9.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str5 = serialDate4.getDescription();
        boolean boolean6 = spreadsheetDate2.isOnOrBefore(serialDate4);
        java.lang.String str7 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate12);
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate20);
        java.lang.String str22 = serialDate21.getDescription();
        java.lang.String str23 = serialDate21.getDescription();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate21);
        int int25 = day24.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.previous();
        boolean boolean27 = spreadsheetDate17.equals((java.lang.Object) day24);
        boolean boolean28 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int29 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date33 = spreadsheetDate32.toDate();
        int int34 = spreadsheetDate32.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean36 = spreadsheetDate2.isAfter(serialDate35);
        try {
            org.jfree.data.time.SerialDate serialDate38 = serialDate35.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5 + "'", int34 == 5);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        timeSeries9.setDescription("5-January-1900");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        int int9 = timeSeries4.getIndex(regularTimePeriod8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        boolean boolean20 = year16.equals((java.lang.Object) 5);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
        long long28 = year26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) (byte) 10);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        long long36 = month33.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.String str38 = month33.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, 0.0d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560668399999L + "'", long36 == 1560668399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.lang.Class<?> wildcardClass3 = year1.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        long long5 = year1.getSerialIndex();
        long long6 = year1.getLastMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj3 = null;
        boolean boolean4 = timeSeries1.equals(obj3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year6 = month5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.addOrUpdate(regularTimePeriod7, (java.lang.Number) 1546329600000L);
        java.lang.Class class10 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        int int14 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-2) + "'", int14 == (-2));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        timeSeries1.setMaximumItemCount((int) (short) 10);
        timeSeries1.setNotify(false);
        java.lang.Object obj6 = timeSeries1.clone();
        timeSeries1.removeAgedItems(1560191464689L, true);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate12);
        java.lang.String str14 = serialDate13.getDescription();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
        int int16 = day15.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
        boolean boolean19 = day15.equals((java.lang.Object) 10.0d);
        java.util.Date date20 = day15.getStart();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 24234L);
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.createCopy((int) (short) 10, 1927);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560191458160L);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191458160L + "'", long3 == 1560191458160L);
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test20");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
//        int int6 = month3.getMonth();
//        int int7 = month3.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
//        java.lang.String str9 = timeSeries2.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year14 = month13.getYear();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(3, year14);
//        int int16 = year14.getYear();
//        long long17 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        int int21 = fixedMillisecond19.compareTo((java.lang.Object) (byte) 10);
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        boolean boolean23 = year14.equals((java.lang.Object) fixedMillisecond19);
//        long long24 = fixedMillisecond19.getMiddleMillisecond();
//        long long25 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond19.next();
//        java.lang.Number number27 = timeSeries2.getValue(regularTimePeriod26);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year30 = month29.getYear();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(3, year30);
//        int int32 = year30.getYear();
//        long long33 = year30.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year30.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year30, (double) 1560191499663L);
//        int int37 = timeSeries2.getItemCount();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560191552516L + "'", long22 == 1560191552516L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191552516L + "'", long24 == 1560191552516L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560191552516L + "'", long25 == 1560191552516L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        int int10 = day7.getYear();
        java.lang.String str11 = day7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.next();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-January-1900" + "'", str11.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate3);
        java.lang.String str9 = day8.toString();
        int int10 = day8.getDayOfMonth();
        long long11 = day8.getSerialIndex();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day8.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-January-1900" + "'", str9.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-572));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465, class1);
        timeSeries2.setKey((java.lang.Comparable) 1560191493464L);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        timeSeries1.setDomainDescription("Jan");
        timeSeries1.setMaximumItemAge((long) ' ');
        java.lang.String str10 = timeSeries1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.removeChangeListener(seriesChangeListener11);
        java.lang.String str13 = timeSeries1.getDomainDescription();
        java.lang.Object obj14 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Jan" + "'", str10.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Jan" + "'", str13.equals("Jan"));
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test26");
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
//        java.lang.String str6 = serialDate3.toString();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year12 = month11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
//        java.lang.Class<?> wildcardClass14 = year12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate3, "Last", "hi!", (java.lang.Class) wildcardClass14);
//        java.util.Date date16 = null;
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year19 = month18.getYear();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(3, year19);
//        int int21 = year19.getYear();
//        long long22 = year19.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int26 = fixedMillisecond24.compareTo((java.lang.Object) (byte) 10);
//        long long27 = fixedMillisecond24.getFirstMillisecond();
//        boolean boolean28 = year19.equals((java.lang.Object) fixedMillisecond24);
//        java.util.Date date29 = year19.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.next();
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond30.getFirstMillisecond(calendar32);
//        java.util.Date date34 = fixedMillisecond30.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date29, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date16, timeZone35);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560191552652L + "'", long27 == 1560191552652L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560191552653L + "'", long33 == 1560191552653L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test27");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) (byte) 10);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) 1);
//        boolean boolean12 = month8.equals((java.lang.Object) 1.0d);
//        int int13 = day7.compareTo((java.lang.Object) month8);
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day7.getLastMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191552908L + "'", long3 == 1560191552908L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        int int9 = day7.getMonth();
        int int10 = day7.getMonth();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day7.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test29() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test29");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        int int2 = month0.getYearValue();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        int int9 = timeSeries4.getIndex(regularTimePeriod8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year16 = month15.getYear();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
//        boolean boolean20 = year16.equals((java.lang.Object) 5);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2, year16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(7, year16);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year26 = month25.getYear();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(3, year26);
//        long long28 = year26.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) year26);
//        java.lang.String str30 = timeSeries4.getDomainDescription();
//        java.util.Collection collection31 = timeSeries4.getTimePeriods();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, class33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        int int37 = fixedMillisecond35.compareTo((java.lang.Object) (byte) 10);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.lang.Number number39 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        java.lang.Comparable comparable40 = timeSeries34.getKey();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year43 = month42.getYear();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(3, year43);
//        int int45 = year43.getYear();
//        long long46 = year43.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year43.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        int int50 = fixedMillisecond48.compareTo((java.lang.Object) (byte) 10);
//        long long51 = fixedMillisecond48.getFirstMillisecond();
//        boolean boolean52 = year43.equals((java.lang.Object) fixedMillisecond48);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 6);
//        java.lang.String str55 = fixedMillisecond48.toString();
//        long long56 = fixedMillisecond48.getMiddleMillisecond();
//        java.lang.Number number57 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 0.0f);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Time" + "'", str30.equals("Time"));
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNull(number39);
//        org.junit.Assert.assertTrue("'" + comparable40 + "' != '" + (short) 0 + "'", comparable40.equals((short) 0));
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560191552940L + "'", long51 == 1560191552940L);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Mon Jun 10 11:32:32 PDT 2019" + "'", str55.equals("Mon Jun 10 11:32:32 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560191552940L + "'", long56 == 1560191552940L);
//        org.junit.Assert.assertNull(number57);
//    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test30");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 1);
//        int int6 = month3.getMonth();
//        int int7 = month3.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
//        java.lang.String str9 = timeSeries2.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year14 = month13.getYear();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(3, year14);
//        int int16 = year14.getYear();
//        long long17 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        int int21 = fixedMillisecond19.compareTo((java.lang.Object) (byte) 10);
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        boolean boolean23 = year14.equals((java.lang.Object) fixedMillisecond19);
//        long long24 = fixedMillisecond19.getMiddleMillisecond();
//        long long25 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond19.next();
//        java.lang.Number number27 = timeSeries2.getValue(regularTimePeriod26);
//        java.util.List list28 = timeSeries2.getItems();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560191552963L + "'", long22 == 1560191552963L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191552963L + "'", long24 == 1560191552963L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560191552963L + "'", long25 == 1560191552963L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertNotNull(list28);
//    }

//    @Test
//    public void test31() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test31");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date3);
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191553014L + "'", long2 == 1560191553014L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191553014L + "'", long8 == 1560191553014L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        timeSeries1.setDomainDescription("Time");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.String str9 = month8.toString();
        int int10 = month8.getYearValue();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, class11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
        int int17 = timeSeries12.getIndex(regularTimePeriod16);
        java.lang.Number number18 = timeSeries1.getValue(regularTimePeriod16);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 2019);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) (-1101916800000L));
        java.lang.Class<?> wildcardClass6 = fixedMillisecond0.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class3);
        boolean boolean5 = timeSeries4.isEmpty();
        long long6 = timeSeries4.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long6);
        java.lang.Object obj8 = seriesChangeEvent7.getSource();
        java.lang.Object obj9 = seriesChangeEvent7.getSource();
        java.lang.Object obj10 = seriesChangeEvent7.getSource();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + 9223372036854775807L + "'", obj8.equals(9223372036854775807L));
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + 9223372036854775807L + "'", obj9.equals(9223372036854775807L));
        org.junit.Assert.assertTrue("'" + obj10 + "' != '" + 9223372036854775807L + "'", obj10.equals(9223372036854775807L));
    }

//    @Test
//    public void test35() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test35");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        long long5 = fixedMillisecond4.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond4.getLastMillisecond(calendar6);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 3);
//        long long10 = fixedMillisecond4.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191553084L + "'", long2 == 1560191553084L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191553084L + "'", long5 == 1560191553084L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560191553084L + "'", long7 == 1560191553084L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191553084L + "'", long10 == 1560191553084L);
//    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.lang.String str6 = month5.toString();
        int int7 = month5.getYearValue();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (double) (short) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1);
        int int17 = month14.getMonth();
        int int18 = month14.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) (byte) 10);
        long long21 = month14.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 100L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeries10.getNextTimePeriod();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate28);
        java.lang.String str31 = serialDate28.toString();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day32.previous();
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day32, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24234L + "'", long21 == 24234L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-January-1900" + "'", str31.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate3);
        java.lang.String str6 = serialDate3.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate3);
        java.lang.String str9 = day8.toString();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day8.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "31-January-1900" + "'", str6.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-January-1900" + "'", str9.equals("31-January-1900"));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getMonth();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate5);
        java.lang.String str8 = serialDate5.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate5);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate5);
        try {
            org.jfree.data.time.SerialDate serialDate13 = serialDate5.getFollowingDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-January-1900" + "'", str8.equals("31-January-1900"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 12);
    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test41");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getLastMillisecond(calendar4);
//        java.util.Date date6 = fixedMillisecond3.getTime();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
//        long long9 = year8.getSerialIndex();
//        java.lang.String str10 = year8.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, year8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (double) 1560191472925L);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1);
//        int int17 = month14.getMonth();
//        int int18 = month14.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem20.getPeriod();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate25);
//        java.lang.String str28 = serialDate25.toString();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate25);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate25);
//        java.lang.String str31 = day30.toString();
//        int int32 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate33 = day30.getSerialDate();
//        int int34 = timeSeriesDataItem20.compareTo((java.lang.Object) serialDate33);
//        try {
//            timeSeries1.add(timeSeriesDataItem20);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191553160L + "'", long5 == 1560191553160L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31-January-1900" + "'", str28.equals("31-January-1900"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-January-1900" + "'", str31.equals("31-January-1900"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 31 + "'", int32 == 31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        boolean boolean8 = timeSeries1.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            timeSeries1.add(regularTimePeriod9, (java.lang.Number) 1560191520964L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str5 = serialDate4.getDescription();
        boolean boolean6 = spreadsheetDate2.isOnOrBefore(serialDate4);
        java.lang.String str7 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate12);
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate14);
        java.util.Date date16 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str22 = serialDate21.getDescription();
        boolean boolean23 = spreadsheetDate19.isOnOrBefore(serialDate21);
        java.lang.String str24 = spreadsheetDate19.getDescription();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate29);
        boolean boolean32 = spreadsheetDate19.isOnOrBefore(serialDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate37);
        java.lang.String str39 = serialDate38.getDescription();
        java.lang.String str40 = serialDate38.getDescription();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate38);
        int int42 = day41.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.previous();
        boolean boolean44 = spreadsheetDate34.equals((java.lang.Object) day41);
        boolean boolean45 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean46 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate51);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate53);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays(5, serialDate53);
        boolean boolean56 = spreadsheetDate2.isBefore(serialDate53);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 31 + "'", int42 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str4 = serialDate3.getDescription();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str10 = serialDate9.getDescription();
        boolean boolean11 = spreadsheetDate7.isOnOrBefore(serialDate9);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate15);
        java.lang.String str18 = serialDate15.getDescription();
        boolean boolean19 = spreadsheetDate7.isOn(serialDate15);
        boolean boolean20 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year23 = month22.getYear();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(3, year23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        boolean boolean26 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str31 = serialDate30.getDescription();
        boolean boolean32 = spreadsheetDate28.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str37 = serialDate36.getDescription();
        boolean boolean38 = spreadsheetDate34.isOnOrBefore(serialDate36);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate42);
        java.lang.String str45 = serialDate42.getDescription();
        boolean boolean46 = spreadsheetDate34.isOn(serialDate42);
        boolean boolean47 = spreadsheetDate28.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year50 = month49.getYear();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(3, year50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
        boolean boolean53 = spreadsheetDate28.equals((java.lang.Object) regularTimePeriod52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str58 = serialDate57.getDescription();
        boolean boolean59 = spreadsheetDate55.isOnOrBefore(serialDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        java.lang.String str64 = serialDate63.getDescription();
        boolean boolean65 = spreadsheetDate61.isOnOrBefore(serialDate63);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate69);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate69);
        java.lang.String str72 = serialDate69.getDescription();
        boolean boolean73 = spreadsheetDate61.isOn(serialDate69);
        boolean boolean74 = spreadsheetDate55.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate77);
        java.lang.String str79 = serialDate78.getDescription();
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(serialDate78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day80.next();
        long long82 = day80.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate83 = day80.getSerialDate();
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate61.getEndOfCurrentMonth(serialDate83);
        boolean boolean85 = spreadsheetDate28.isBefore(serialDate83);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate87 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate91);
        org.jfree.data.time.SerialDate serialDate93 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate91);
        java.lang.String str94 = serialDate91.toString();
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(serialDate91);
        int int96 = day95.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate97 = day95.getSerialDate();
        boolean boolean98 = spreadsheetDate87.isOnOrAfter(serialDate97);
        boolean boolean99 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, serialDate97);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 32L + "'", long82 == 32L);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "31-January-1900" + "'", str94.equals("31-January-1900"));
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 31 + "'", int96 == 31);
        org.junit.Assert.assertNotNull(serialDate97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + true + "'", boolean99 == true);
    }

//    @Test
//    public void test45() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test45");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        java.util.Date date5 = spreadsheetDate4.toDate();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(1560191458160L);
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        java.util.Date date13 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) (byte) 10);
//        long long17 = fixedMillisecond14.getMiddleMillisecond();
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond14.peg(calendar18);
//        java.util.Date date20 = fixedMillisecond14.getTime();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        java.lang.String str27 = serialDate26.getDescription();
//        boolean boolean28 = spreadsheetDate24.isOnOrBefore(serialDate26);
//        java.lang.String str29 = spreadsheetDate24.getDescription();
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate34);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate34);
//        boolean boolean37 = spreadsheetDate24.isOnOrBefore(serialDate36);
//        java.lang.Class<?> wildcardClass38 = spreadsheetDate24.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getLastMillisecond(calendar40);
//        java.util.Date date42 = fixedMillisecond39.getTime();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year45 = month44.getYear();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(3, year45);
//        int int47 = year45.getYear();
//        long long48 = year45.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        int int52 = fixedMillisecond50.compareTo((java.lang.Object) (byte) 10);
//        long long53 = fixedMillisecond50.getFirstMillisecond();
//        boolean boolean54 = year45.equals((java.lang.Object) fixedMillisecond50);
//        java.util.Date date55 = year45.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond56.next();
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond56.getFirstMillisecond(calendar58);
//        java.util.Date date60 = fixedMillisecond56.getEnd();
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date60, timeZone61);
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(date55, timeZone61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date42, timeZone61);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date20, timeZone61);
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(date13, timeZone61);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date2, timeZone61);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560191554553L + "'", long17 == 1560191554553L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560191554556L + "'", long41 == 1560191554556L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560191554560L + "'", long53 == 1560191554560L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560191554561L + "'", long59 == 1560191554561L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//    }
//}

