import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray4 = new float[] { 100.0f, 1L };
        try {
            float[] floatArray5 = color0.getComponents(colorSpace1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 'a', (double) 1L, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.axis.AxisState axisState7 = dateAxis0.draw(graphics2D1, (double) (-1), rectangle2D3, rectangle2D4, rectangleEdge5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.Plot plot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace6 = dateAxis0.reserveSpace(graphics2D1, plot2, rectangle2D3, rectangleEdge4, axisSpace5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        java.lang.Object obj3 = null;
        objectList1.set((int) ' ', obj3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = null;
        try {
            dateAxis0.setLeftArrow(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        java.awt.Shape shape4 = null;
        try {
            dateAxis0.setRightArrow(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            categoryPlot5.addRangeMarker(marker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(layer8);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        try {
            categoryPlot5.setRangeAxisLocation(axisLocation8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        try {
            categoryPlot0.mapDatasetToDomainAxis((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=192,b=192]" + "'", str1.equals("java.awt.Color[r=0,g=192,b=192]"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        double double3 = valueMarker1.getValue();
        java.lang.Class class4 = null;
        try {
            java.util.EventListener[] eventListenerArray5 = valueMarker1.getListeners(class4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            categoryPlot5.drawBackground(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        try {
            categoryPlot5.setDomainAxisLocation(axisLocation8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.Range range8 = null;
        try {
            dateAxis0.setRange(range8, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        float float8 = dateAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getUpArrow();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = categoryPlot15.removeDomainMarker(marker21, layer22);
        categoryPlot5.addDomainMarker(2, categoryMarker9, layer22);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            categoryPlot5.drawOutline(graphics2D25, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double6 = rectangleInsets4.calculateBottomOutset((double) 0L);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createOutsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        int int12 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        try {
            categoryPlot5.setRangeAxisLocation((int) (byte) -1, axisLocation14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double6 = rectangleInsets4.calculateBottomOutset((double) 0L);
        double double8 = rectangleInsets4.calculateLeftOutset(100.0d);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets4.createInsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        boolean boolean10 = categoryPlot5.isDomainZoomable();
        try {
            categoryPlot5.mapDatasetToRangeAxis((-1), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            java.awt.Color color1 = java.awt.Color.decode("java.awt.Color[r=0,g=192,b=192]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java.awt.Color[r=0,g=192,b=192]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.lang.Class class3 = null;
        try {
            java.util.EventListener[] eventListenerArray4 = valueMarker1.getListeners(class3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Color color0 = java.awt.Color.orange;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double6 = rectangleInsets4.calculateBottomInset((double) 1.0f);
        java.lang.String str7 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=0.2,l=8.0,b=1.0,r=32.0]" + "'", str7.equals("RectangleInsets[t=0.2,l=8.0,b=1.0,r=32.0]"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        int int12 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setAutoTickUnitSelection(true, false);
        dateAxis14.setLabel("");
        dateAxis14.setLowerBound((double) (short) 10);
        categoryPlot5.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis14, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo25, point2D26, true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        categoryPlot5.markerChanged(markerChangeEvent29);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint20 = valueMarker19.getPaint();
        double double21 = valueMarker19.getValue();
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker19.setLabelTextAnchor(textAnchor22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot29.setAnchorValue((double) 10L, false);
        boolean boolean34 = categoryPlot29.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean37 = categoryPlot29.removeDomainMarker(marker35, layer36);
        boolean boolean38 = categoryPlot5.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker19, layer36);
        java.awt.Paint paint39 = valueMarker19.getLabelPaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        java.awt.Paint paint3 = valueMarker1.getLabelPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = valueMarker1.getLabelOffsetType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        boolean boolean13 = categoryPlot5.isOutlineVisible();
        java.awt.Font font14 = null;
        try {
            categoryPlot5.setNoDataMessageFont(font14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        categoryPlot5.setOutlineVisible(false);
        categoryPlot5.setAnchorValue((double) (-1.0f));
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.util.SortOrder sortOrder12 = null;
        try {
            categoryPlot5.setRowRenderingOrder(sortOrder12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        java.util.Calendar calendar3 = null;
        try {
            day1.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            boolean boolean13 = categoryPlot5.removeAnnotation(categoryAnnotation11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double5 = rectangleInsets4.getLeft();
        double double6 = rectangleInsets4.getRight();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double5 = rectangleInsets4.getLeft();
        double double7 = rectangleInsets4.calculateTopInset(10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        categoryPlot5.setRangeCrosshairValue((double) (short) -1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        categoryPlot5.mapDatasetToRangeAxis(100, 1);
        org.jfree.chart.util.SortOrder sortOrder16 = null;
        try {
            categoryPlot5.setRowRenderingOrder(sortOrder16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        int int12 = categoryPlot5.getDomainAxisCount();
        categoryPlot5.setBackgroundImageAlignment(1);
        org.jfree.chart.plot.Plot plot15 = categoryPlot5.getParent();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(plot15);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) tickUnitSource1, jFreeChart2);
        java.lang.Object obj4 = chartChangeEvent3.getSource();
        java.lang.String str5 = chartChangeEvent3.toString();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        categoryPlot5.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot8.axisChanged(axisChangeEvent9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot8.zoomDomainAxes((double) (byte) 10, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint23 = valueMarker22.getPaint();
        double double24 = valueMarker22.getValue();
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker22.setLabelTextAnchor(textAnchor25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = dateAxis29.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer31);
        java.awt.Stroke stroke33 = categoryPlot32.getRangeGridlineStroke();
        categoryPlot32.setAnchorValue((double) 10L, false);
        boolean boolean37 = categoryPlot32.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean40 = categoryPlot32.removeDomainMarker(marker38, layer39);
        boolean boolean41 = categoryPlot8.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer39);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        java.lang.Class class43 = null;
        try {
            java.util.EventListener[] eventListenerArray44 = valueMarker1.getListeners(class43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        dateAxis0.setFixedDimension(0.2d);
        double double18 = dateAxis0.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = null;
        try {
            dateAxis0.setTickLabelInsets(rectangleInsets19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        dateAxis0.setAxisLineVisible(true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Color color0 = java.awt.Color.CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray4 = new float[] { 9, 0.0f };
        try {
            float[] floatArray5 = color0.getComponents(colorSpace1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.awt.Shape shape30 = dateAxis21.getUpArrow();
        dateAxis21.resizeRange((double) (short) 0, (double) (-1L));
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        java.awt.Paint paint4 = dateAxis0.getTickMarkPaint();
        dateAxis0.setLabelURL("java.awt.Color[r=0,g=192,b=192]");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        categoryPlot15.axisChanged(axisChangeEvent16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot15.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot15.zoomDomainAxes((double) (-1L), plotRenderingInfo21, point2D22, false);
        categoryPlot15.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot15.getRangeAxisEdge();
        try {
            java.util.List list28 = dateAxis0.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape7 = dateAxis6.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        categoryPlot9.axisChanged(axisChangeEvent10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot9.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot9.zoomDomainAxes((double) (-1L), plotRenderingInfo15, point2D16, false);
        categoryPlot9.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot9.getRangeAxisEdge();
        try {
            double double22 = dateAxis0.lengthToJava2D((double) 15, rectangle2D3, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        java.awt.Stroke stroke8 = categoryPlot5.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation(1, axisLocation2, false);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot0.setDataset(categoryDataset5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        java.lang.Object obj2 = objectList1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape7 = dateAxis6.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        objectList1.set(7, (java.lang.Object) categoryDataset4);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker1.setOutlinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker1.setLabelPaint((java.awt.Paint) color5);
        java.awt.Color color7 = java.awt.Color.CYAN;
        int int8 = color7.getGreen();
        valueMarker1.setOutlinePaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = categoryPlot15.removeDomainMarker(marker21, layer22);
        categoryPlot5.addDomainMarker(2, categoryMarker9, layer22);
        categoryMarker9.setDrawAsLine(true);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int28 = color27.getBlue();
        int int29 = color27.getAlpha();
        categoryMarker9.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Color color34 = java.awt.Color.RED;
        java.awt.Color color35 = color34.brighter();
        int int36 = color35.getRed();
        java.awt.Color color37 = java.awt.Color.RED;
        java.awt.Color color38 = java.awt.Color.orange;
        float[] floatArray39 = null;
        float[] floatArray40 = color38.getComponents(floatArray39);
        float[] floatArray41 = color37.getRGBColorComponents(floatArray40);
        float[] floatArray42 = color35.getColorComponents(floatArray41);
        float[] floatArray43 = java.awt.Color.RGBtoHSB(8, 0, 7, floatArray42);
        float[] floatArray44 = color27.getRGBColorComponents(floatArray42);
        int int45 = color27.getBlue();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 255 + "'", int36 == 255);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 255 + "'", int45 == 255);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis0.getTickUnit();
        double double9 = dateAxis0.getUpperMargin();
        float float10 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.resizeRange((double) 100.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        categoryPlot5.setBackgroundImageAlignment(3);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation32 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation32, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot8.axisChanged(axisChangeEvent9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot8.zoomDomainAxes((double) (byte) 10, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint23 = valueMarker22.getPaint();
        double double24 = valueMarker22.getValue();
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker22.setLabelTextAnchor(textAnchor25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = dateAxis29.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer31);
        java.awt.Stroke stroke33 = categoryPlot32.getRangeGridlineStroke();
        categoryPlot32.setAnchorValue((double) 10L, false);
        boolean boolean37 = categoryPlot32.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean40 = categoryPlot32.removeDomainMarker(marker38, layer39);
        boolean boolean41 = categoryPlot8.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer39);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        valueMarker1.setValue((double) (byte) 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot5.setRenderer((int) (byte) 1, categoryItemRenderer14);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        boolean boolean8 = dateAxis0.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getRangeGridlineStroke();
        categoryPlot14.setAnchorValue((double) 10L, false);
        boolean boolean19 = categoryPlot14.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        boolean boolean22 = categoryPlot14.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = dateAxis25.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getRangeGridlineStroke();
        categoryPlot14.setRangeCrosshairStroke(stroke29);
        dateAxis0.setTickMarkStroke(stroke29);
        java.awt.Color color32 = java.awt.Color.RED;
        java.awt.Color color33 = color32.brighter();
        boolean boolean34 = dateAxis0.equals((java.lang.Object) color32);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 15, (double) 10, (double) 0.0f, (double) (short) 10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Font font6 = dateAxis2.getTickLabelFont();
        dateAxis2.setRangeAboutValue(0.0d, 0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        try {
            java.util.Date date11 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.axis.AxisState axisState7 = numberAxis0.draw(graphics2D1, (double) ' ', rectangle2D3, rectangle2D4, rectangleEdge5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-12517377) + "'", int1 == (-12517377));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint13 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets14, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        categoryPlot22.axisChanged(axisChangeEvent23);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint27 = valueMarker26.getPaint();
        categoryPlot22.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = dateAxis31.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = null;
        categoryPlot34.axisChanged(axisChangeEvent35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot34.getRenderer(8);
        boolean boolean39 = categoryPlot34.isDomainZoomable();
        java.awt.Stroke stroke40 = categoryPlot34.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape45 = dateAxis44.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer46);
        java.awt.Stroke stroke48 = categoryPlot47.getRangeGridlineStroke();
        categoryPlot47.setAnchorValue((double) 10L, false);
        boolean boolean52 = categoryPlot47.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker53 = null;
        org.jfree.chart.util.Layer layer54 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean55 = categoryPlot47.removeDomainMarker(marker53, layer54);
        java.util.Collection collection56 = categoryPlot34.getDomainMarkers((int) (byte) 1, layer54);
        boolean boolean57 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker26, layer54);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(layer54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(collection56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setAutoTickUnitSelection(true, false);
        dateAxis13.setLabel("");
        dateAxis13.setLowerBound((double) (short) 10);
        org.jfree.data.Range range21 = dateAxis13.getDefaultAutoRange();
        dateAxis11.setRange(range21);
        dateAxis11.setLabel("UnitType.ABSOLUTE");
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.Plot plot26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape31 = dateAxis30.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer32);
        java.awt.Stroke stroke34 = categoryPlot33.getRangeGridlineStroke();
        double double35 = categoryPlot33.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot33.zoomDomainAxes((double) 255, plotRenderingInfo37, point2D38);
        int int40 = categoryPlot33.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot33.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace43 = dateAxis11.reserveSpace(graphics2D25, plot26, rectangle2D27, rectangleEdge41, axisSpace42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = categoryPlot15.removeDomainMarker(marker21, layer22);
        categoryPlot5.addDomainMarker(2, categoryMarker9, layer22);
        boolean boolean25 = categoryMarker9.getDrawAsLine();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis0.getTickUnit();
        java.awt.Paint paint9 = dateAxis0.getLabelPaint();
        boolean boolean10 = dateAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot5.removeChangeListener(plotChangeListener10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        plot12.setNoDataMessageFont(font13);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        java.lang.Object obj3 = objectList1.get((-1));
        java.lang.Object obj4 = objectList1.clone();
        int int5 = objectList1.size();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.Font font16 = dateAxis0.getLabelFont();
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str18 = unitType17.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(unitType17, 8.0d, 0.2d, (double) 255, (double) 2.0f);
        dateAxis0.setTickLabelInsets(rectangleInsets23);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets23.createInsetRectangle(rectangle2D25, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UnitType.ABSOLUTE" + "'", str18.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker18, layer21);
        boolean boolean23 = categoryPlot5.isOutlineVisible();
        categoryPlot5.zoom((double) 2.0f);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent26);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(8.0d);
        java.lang.String str2 = valueMarker1.getLabel();
        java.awt.Stroke stroke3 = valueMarker1.getStroke();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 1, plotRenderingInfo12, point2D13);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot8.axisChanged(axisChangeEvent9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot8.zoomDomainAxes((double) (byte) 10, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint23 = valueMarker22.getPaint();
        double double24 = valueMarker22.getValue();
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker22.setLabelTextAnchor(textAnchor25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = dateAxis29.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer31);
        java.awt.Stroke stroke33 = categoryPlot32.getRangeGridlineStroke();
        categoryPlot32.setAnchorValue((double) 10L, false);
        boolean boolean37 = categoryPlot32.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean40 = categoryPlot32.removeDomainMarker(marker38, layer39);
        boolean boolean41 = categoryPlot8.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer39);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor43);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 12, 3.0d, 0.05d, 100.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot5.render(graphics2D9, rectangle2D10, (int) (short) 10, plotRenderingInfo12);
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        boolean boolean16 = categoryPlot5.isDomainZoomable();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double5 = rectangleInsets4.getLeft();
        double double7 = rectangleInsets4.extendHeight(3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.2d + "'", double7 == 4.2d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.awt.Font font3 = null;
        try {
            valueMarker1.setLabelFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 10, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        chartChangeEvent2.setChart(jFreeChart4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=10]"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis0.java2DToValue(0.0d, rectangle2D17, rectangleEdge18);
        boolean boolean20 = dateAxis0.isVerticalTickLabels();
        java.lang.String str21 = dateAxis0.getLabel();
        dateAxis0.setLabelToolTip("hi!");
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(12);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Color color1 = color0.brighter();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, (java.awt.Paint) color9, stroke10);
        java.awt.Color color12 = java.awt.Color.RED;
        java.awt.Color color13 = color12.brighter();
        int int14 = color13.getRed();
        java.awt.Color color15 = java.awt.Color.RED;
        java.awt.Color color16 = java.awt.Color.orange;
        float[] floatArray17 = null;
        float[] floatArray18 = color16.getComponents(floatArray17);
        float[] floatArray19 = color15.getRGBColorComponents(floatArray18);
        float[] floatArray20 = color13.getColorComponents(floatArray19);
        float[] floatArray21 = color9.getComponents(floatArray19);
        float[] floatArray22 = color1.getRGBColorComponents(floatArray19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke4 = valueMarker3.getOutlineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        valueMarker3.notifyListeners(markerChangeEvent5);
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) markerChangeEvent5);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        categoryPlot5.mapDatasetToRangeAxis(100, 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = null;
        try {
            categoryPlot5.setDomainGridlinePosition(categoryAnchor16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        java.lang.Object obj3 = objectList1.get((-1));
        java.lang.Object obj4 = objectList1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot10.axisChanged(axisChangeEvent11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot10.getRenderer(8);
        boolean boolean15 = categoryPlot10.isDomainZoomable();
        java.awt.Stroke stroke16 = categoryPlot10.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        java.awt.Stroke stroke24 = categoryPlot23.getRangeGridlineStroke();
        categoryPlot23.setAnchorValue((double) 10L, false);
        boolean boolean28 = categoryPlot23.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean31 = categoryPlot23.removeDomainMarker(marker29, layer30);
        java.util.Collection collection32 = categoryPlot10.getDomainMarkers((int) (byte) 1, layer30);
        int int33 = objectList1.indexOf((java.lang.Object) (byte) 1);
        java.lang.Object obj34 = objectList1.clone();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis0.getTickUnit();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getRangeGridlineStroke();
        categoryPlot14.setAnchorValue((double) 10L, false);
        boolean boolean19 = categoryPlot14.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.setAutoTickUnitSelection(true, false);
        dateAxis22.setLabel("");
        dateAxis22.setLowerBound((double) (short) 10);
        org.jfree.data.Range range30 = dateAxis22.getDefaultAutoRange();
        dateAxis20.setRange(range30);
        dateAxis0.setRange(range30, true, true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        try {
            dateAxis0.zoomRange((double) 10.0f, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Color color1 = java.awt.Color.RED;
        java.awt.Color color2 = color1.brighter();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setAutoTickUnitSelection(true, false);
        dateAxis3.setLabel("");
        java.awt.Paint paint9 = dateAxis3.getAxisLinePaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, (java.awt.Paint) color11, stroke12);
        dateAxis3.setTickMarkStroke(stroke12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        java.awt.Stroke stroke21 = categoryPlot20.getRangeGridlineStroke();
        double double22 = categoryPlot20.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot20.getIndexOf(categoryItemRenderer23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.setAutoTickUnitSelection(true, false);
        dateAxis27.setLabel("");
        java.awt.Paint paint33 = dateAxis27.getAxisLinePaint();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, (java.awt.Paint) color35, stroke36);
        dateAxis27.setTickMarkStroke(stroke36);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker(1.0E-8d, (java.awt.Paint) color2, stroke12, (java.awt.Paint) color25, stroke36, (float) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(8.0d);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = dateAxis4.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        categoryPlot7.axisChanged(axisChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker11);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot7.getDomainGridlinePosition();
        java.awt.Paint paint15 = categoryPlot7.getNoDataMessagePaint();
        categoryPlot7.setRangeCrosshairValue(100.0d);
        boolean boolean18 = categoryPlot7.isSubplot();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot7);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot5.render(graphics2D9, rectangle2D10, (int) (short) 10, plotRenderingInfo12);
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot5.getDomainAxisForDataset(0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryAxis17);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Class class0 = null;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        java.lang.Object obj5 = null;
        int int6 = day4.compareTo(obj5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        java.awt.Paint paint17 = categoryPlot5.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot5.getAxisOffset();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        categoryPlot5.setOutlineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot5.setDomainAxisLocation(10, axisLocation20, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape28 = dateAxis27.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer29);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = null;
        categoryPlot30.axisChanged(axisChangeEvent31);
        categoryPlot30.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace35 = categoryPlot30.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent36 = null;
        categoryPlot30.rendererChanged(rendererChangeEvent36);
        categoryPlot30.mapDatasetToRangeAxis(100, 1);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot30.setDomainAxisLocation(axisLocation41);
        boolean boolean43 = rectangleAnchor24.equals((java.lang.Object) axisLocation41);
        try {
            categoryPlot5.setRangeAxisLocation((int) (short) -1, axisLocation41, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(axisSpace35);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            java.awt.Color color1 = java.awt.Color.decode("CategoryAnchor.MIDDLE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CategoryAnchor.MIDDLE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setAutoTickUnitSelection(true, false);
        dateAxis7.setVerticalTickLabels(false);
        float float13 = dateAxis7.getTickMarkInsideLength();
        java.lang.String str14 = dateAxis7.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis7.getTickUnit();
        java.awt.Shape shape16 = dateAxis7.getUpArrow();
        dateAxis2.setLeftArrow(shape16);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint3 = valueMarker2.getOutlinePaint();
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Color color5 = color4.brighter();
        int int6 = color5.getRed();
        java.awt.Color color7 = java.awt.Color.RED;
        java.awt.Color color8 = java.awt.Color.orange;
        float[] floatArray9 = null;
        float[] floatArray10 = color8.getComponents(floatArray9);
        float[] floatArray11 = color7.getRGBColorComponents(floatArray10);
        float[] floatArray12 = color5.getColorComponents(floatArray11);
        valueMarker2.setLabelPaint((java.awt.Paint) color5);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, (java.awt.Paint) color15, stroke16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = dateAxis21.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        java.util.List list25 = categoryPlot24.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = dateAxis31.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeGridlineStroke();
        categoryPlot34.setAnchorValue((double) 10L, false);
        boolean boolean39 = categoryPlot34.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot34.removeDomainMarker(marker40, layer41);
        categoryPlot24.addDomainMarker(2, categoryMarker28, layer41);
        categoryMarker28.setDrawAsLine(true);
        java.awt.Color color46 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int47 = color46.getBlue();
        int int48 = color46.getAlpha();
        categoryMarker28.setOutlinePaint((java.awt.Paint) color46);
        java.awt.Stroke stroke50 = categoryMarker28.getOutlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) 6, (java.awt.Paint) color5, stroke16, (java.awt.Paint) color18, stroke50, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(list25);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 255 + "'", int47 == 255);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 255 + "'", int48 == 255);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setLabel("");
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        org.jfree.data.Range range8 = dateAxis1.getRange();
        boolean boolean9 = rectangleAnchor0.equals((java.lang.Object) dateAxis1);
        java.text.DateFormat dateFormat10 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(dateFormat10);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        categoryPlot5.mapDatasetToRangeAxis(100, 1);
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        try {
            categoryPlot5.setDomainAxisLocation(0, axisLocation17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = categoryPlot15.removeDomainMarker(marker21, layer22);
        categoryPlot5.addDomainMarker(2, categoryMarker9, layer22);
        categoryPlot5.clearRangeMarkers(255);
        categoryPlot5.zoom((double) 100);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        try {
            dateAxis0.setRangeWithMargins(32.0d, (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (32.0) <= upper (8.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        dateAxis0.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot5.getDomainAxis((int) (short) 0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNull(categoryAxis12);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightInset((double) 100);
        double double4 = rectangleInsets0.calculateLeftOutset((double) 255);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker18, layer21);
        java.lang.Class class23 = null;
        try {
            java.util.EventListener[] eventListenerArray24 = valueMarker18.getListeners(class23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        boolean boolean17 = categoryPlot5.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis0.getTickUnit();
        boolean boolean9 = dateAxis0.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Paint paint1 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, (java.awt.Paint) color3, stroke4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        java.awt.Stroke stroke12 = categoryPlot11.getRangeGridlineStroke();
        categoryPlot11.setAnchorValue((double) 10L, false);
        boolean boolean16 = categoryPlot11.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint19 = categoryPlot11.getRangeCrosshairPaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 255, paint1, stroke4, paint19, stroke20, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setLabel("");
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        double double8 = dateAxis1.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getRangeGridlineStroke();
        dateAxis1.setAxisLineStroke(stroke15);
        dateAxis1.setFixedDimension(0.2d);
        boolean boolean19 = rectangleInsets0.equals((java.lang.Object) dateAxis1);
        double double21 = rectangleInsets0.calculateLeftOutset((double) '4');
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets0.createInsetRectangle(rectangle2D22, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color5 = java.awt.Color.RED;
        java.awt.Color color6 = color5.brighter();
        int int7 = color6.getRed();
        java.awt.Color color8 = java.awt.Color.RED;
        java.awt.Color color9 = java.awt.Color.orange;
        float[] floatArray10 = null;
        float[] floatArray11 = color9.getComponents(floatArray10);
        float[] floatArray12 = color8.getRGBColorComponents(floatArray11);
        float[] floatArray13 = color6.getColorComponents(floatArray12);
        float[] floatArray14 = java.awt.Color.RGBtoHSB(8, 0, 7, floatArray13);
        try {
            float[] floatArray15 = color0.getColorComponents(colorSpace1, floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        org.jfree.data.Range range7 = dateAxis0.getRange();
        dateAxis0.setVisible(true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int1 = color0.getBlue();
        int int2 = color0.getAlpha();
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = color0.getColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        java.lang.Object obj12 = categoryPlot5.clone();
        org.jfree.chart.plot.Plot plot13 = categoryPlot5.getParent();
        categoryPlot5.clearDomainAxes();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(plot13);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color10);
        java.lang.String str12 = categoryPlot5.getNoDataMessage();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot5.setNoDataMessageFont(font15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        try {
            categoryPlot5.setDomainAxis((int) (byte) -1, categoryAxis21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(8.0d);
        java.lang.Class class2 = null;
        try {
            java.util.EventListener[] eventListenerArray3 = valueMarker1.getListeners(class2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot5.setNoDataMessageFont(font15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot5.configureDomainAxes();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        boolean boolean24 = categoryPlot5.render(graphics2D20, rectangle2D21, 15, plotRenderingInfo23);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke13 = valueMarker12.getOutlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker12.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker12.setLabelPaint((java.awt.Paint) color16);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        java.awt.Paint paint19 = valueMarker12.getLabelPaint();
        java.awt.Stroke stroke20 = valueMarker12.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis0.java2DToValue(0.0d, rectangle2D17, rectangleEdge18);
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = null;
        try {
            java.util.Date date21 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Font font6 = dateAxis2.getTickLabelFont();
        dateAxis2.resizeRange((double) (-12517377));
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot5.render(graphics2D9, rectangle2D10, (int) (short) 10, plotRenderingInfo12);
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot5.setRenderer((int) (byte) 100, categoryItemRenderer17, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Color color1 = color0.brighter();
        int int2 = color1.getRed();
        java.awt.Color color3 = java.awt.Color.RED;
        java.awt.Color color4 = java.awt.Color.orange;
        float[] floatArray5 = null;
        float[] floatArray6 = color4.getComponents(floatArray5);
        float[] floatArray7 = color3.getRGBColorComponents(floatArray6);
        float[] floatArray8 = color1.getColorComponents(floatArray7);
        java.lang.String str9 = color1.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str9.equals("java.awt.Color[r=255,g=0,b=0]"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        boolean boolean7 = dateAxis0.isVisible();
        java.util.Date date8 = dateAxis0.getMaximumDate();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        int int2 = day1.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = null;
        categoryPlot12.axisChanged(axisChangeEvent13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot12.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot12.zoomDomainAxes((double) (-1L), plotRenderingInfo18, point2D19, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot12.getRangeAxisEdge(6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = numberAxis0.draw(graphics2D3, (double) 0L, rectangle2D5, rectangle2D6, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        valueMarker1.setLabelTextAnchor(textAnchor3);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, (java.awt.Paint) color8, stroke9);
        dateAxis0.setTickMarkStroke(stroke9);
        java.util.Date date12 = dateAxis0.getMaximumDate();
        dateAxis0.setUpperMargin((double) (byte) 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis(0, valueAxis3, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (short) 0);
        int int3 = color2.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=10]");
        numberAxis1.setAutoRangeStickyZero(false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double5 = rectangleInsets4.getLeft();
        double double6 = rectangleInsets4.getRight();
        double double8 = rectangleInsets4.calculateBottomOutset(4.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("AxisLocation.TOP_OR_LEFT", timeZone1);
        dateAxis2.setVerticalTickLabels(true);
        java.awt.Paint paint5 = dateAxis2.getAxisLinePaint();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.configureDomainAxes();
        categoryPlot5.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = java.awt.Color.black;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 1560409200000L, (java.awt.Paint) color2);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getRangeGridlineStroke();
        double double16 = categoryPlot14.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot14.zoomDomainAxes((double) 255, plotRenderingInfo18, point2D19);
        int int21 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot14.getRangeAxisEdge();
        try {
            double double23 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) (byte) 1, (java.lang.Comparable) (short) 1, categoryDataset6, (double) (-1.0f), rectangle2D8, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Color color1 = color0.brighter();
        java.lang.String str2 = color1.toString();
        boolean boolean4 = color1.equals((java.lang.Object) "java.awt.Color[r=255,g=0,b=0]");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str2.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVerticalTickLabels(true);
        dateAxis0.setTickMarkInsideLength(100.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setLabel("");
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        double double8 = dateAxis1.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getRangeGridlineStroke();
        dateAxis1.setAxisLineStroke(stroke15);
        dateAxis1.setFixedDimension(0.2d);
        boolean boolean19 = rectangleInsets0.equals((java.lang.Object) dateAxis1);
        boolean boolean20 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        java.awt.Stroke stroke13 = categoryPlot12.getRangeGridlineStroke();
        categoryPlot12.setAnchorValue((double) 10L, false);
        boolean boolean17 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        categoryPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setAutoTickUnitSelection(true, false);
        dateAxis20.setLabel("");
        dateAxis20.setLowerBound((double) (short) 10);
        org.jfree.data.Range range28 = dateAxis20.getDefaultAutoRange();
        dateAxis18.setRange(range28);
        dateAxis2.setRange(range28);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition31 = null;
        try {
            dateAxis2.setTickMarkPosition(dateTickMarkPosition31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            boolean boolean5 = xYPlot0.removeAnnotation(xYAnnotation3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener3 = null;
        valueMarker1.addChangeListener(markerChangeListener3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker1.getLabelAnchor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        boolean boolean8 = lengthAdjustmentType0.equals((java.lang.Object) dateAxis1);
        double double9 = dateAxis1.getFixedAutoRange();
        dateAxis1.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis1.getLabelInsets();
        dateAxis1.setFixedDimension((double) '4');
        try {
            dateAxis1.zoomRange((double) 'a', (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        java.awt.Stroke stroke10 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        xYPlot0.setOrientation(plotOrientation15);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot0.getDomainAxisForDataset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=10]");
        org.jfree.data.RangeType rangeType2 = null;
        try {
            numberAxis1.setRangeType(rangeType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        java.awt.Stroke stroke11 = categoryPlot10.getRangeGridlineStroke();
        java.awt.Stroke stroke12 = categoryPlot10.getRangeGridlineStroke();
        categoryPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot10.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation16, plotOrientation17);
        try {
            double double19 = categoryAxis0.getCategoryEnd((int) (byte) 100, (int) (byte) -1, rectangle2D4, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getUpperBound();
        dateAxis2.setLowerBound(0.05d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomRangeAxes((double) (short) 10, plotRenderingInfo13, point2D14);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        dateAxis0.setRangeWithMargins((double) 2.0f, (double) '#');
        dateAxis0.setTickMarkOutsideLength((float) (-1));
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setAutoTickUnitSelection(true, false);
        dateAxis13.setLabel("");
        java.awt.Paint paint19 = dateAxis13.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis13.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit20);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(dateTickUnit20);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = dateAxis4.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        categoryPlot7.axisChanged(axisChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot7.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D16, false);
        categoryPlot7.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextOutlinePaint();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        java.awt.Paint paint24 = defaultDrawingSupplier21.getNextFillPaint();
        dateAxis0.setLabelPaint(paint24);
        dateAxis0.setAutoTickUnitSelection(true, false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL");
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double6 = rectangleInsets4.calculateBottomOutset((double) 0L);
        java.lang.String str7 = rectangleInsets4.toString();
        double double8 = rectangleInsets4.getTop();
        double double10 = rectangleInsets4.trimWidth((double) 3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=0.2,l=8.0,b=1.0,r=32.0]" + "'", str7.equals("RectangleInsets[t=0.2,l=8.0,b=1.0,r=32.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-37.0d) + "'", double10 == (-37.0d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.Color color1 = java.awt.Color.CYAN;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint5 = valueMarker4.getPaint();
        double double6 = valueMarker4.getValue();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        valueMarker4.setPaint((java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = dateAxis21.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getRangeGridlineStroke();
        categoryPlot24.setAnchorValue((double) 10L, false);
        boolean boolean29 = categoryPlot24.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean32 = categoryPlot24.removeDomainMarker(marker30, layer31);
        categoryPlot14.addDomainMarker(2, categoryMarker18, layer31);
        categoryMarker18.setDrawAsLine(true);
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int37 = color36.getBlue();
        int int38 = color36.getAlpha();
        categoryMarker18.setOutlinePaint((java.awt.Paint) color36);
        java.awt.Color color43 = java.awt.Color.RED;
        java.awt.Color color44 = color43.brighter();
        int int45 = color44.getRed();
        java.awt.Color color46 = java.awt.Color.RED;
        java.awt.Color color47 = java.awt.Color.orange;
        float[] floatArray48 = null;
        float[] floatArray49 = color47.getComponents(floatArray48);
        float[] floatArray50 = color46.getRGBColorComponents(floatArray49);
        float[] floatArray51 = color44.getColorComponents(floatArray50);
        float[] floatArray52 = java.awt.Color.RGBtoHSB(8, 0, 7, floatArray51);
        float[] floatArray53 = color36.getRGBColorComponents(floatArray51);
        float[] floatArray54 = color7.getRGBColorComponents(floatArray53);
        float[] floatArray55 = color2.getRGBColorComponents(floatArray54);
        float[] floatArray56 = color1.getColorComponents(floatArray54);
        float[] floatArray57 = color0.getComponents(floatArray56);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(list15);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 255 + "'", int38 == 255);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 255 + "'", int45 == 255);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 10, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent2.setChart(jFreeChart3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent2.setChart(jFreeChart5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation(1, axisLocation2, false);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setAutoTickUnitSelection(true, false);
        dateAxis7.setVerticalTickLabels(false);
        java.lang.String str13 = dateAxis7.getLabelURL();
        org.jfree.data.Range range14 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        java.awt.Stroke stroke11 = categoryPlot10.getRangeGridlineStroke();
        double double12 = categoryPlot10.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot10.zoomDomainAxes((double) 255, plotRenderingInfo14, point2D15);
        int int17 = categoryPlot10.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot10.getRangeAxisEdge();
        try {
            double double19 = categoryAxis0.getCategoryStart((int) (byte) 1, (int) (short) 10, rectangle2D4, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Font font9 = dateAxis5.getTickLabelFont();
        dateAxis5.setFixedDimension((double) 12);
        try {
            xYPlot0.setDomainAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) dateAxis5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = categoryPlot5.getDrawingSupplier();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation31 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(drawingSupplier30);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        boolean boolean6 = dateAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        java.awt.Paint paint3 = valueMarker1.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        valueMarker1.setLabelOffset(rectangleInsets4);
        double double6 = rectangleInsets4.getBottom();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            rectangleInsets4.trim(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        int int2 = categoryPlot0.getDatasetCount();
        java.lang.String str3 = categoryPlot0.getPlotType();
        try {
            categoryPlot0.setBackgroundImageAlpha((float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint20 = valueMarker19.getPaint();
        double double21 = valueMarker19.getValue();
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker19.setLabelTextAnchor(textAnchor22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot29.setAnchorValue((double) 10L, false);
        boolean boolean34 = categoryPlot29.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean37 = categoryPlot29.removeDomainMarker(marker35, layer36);
        boolean boolean38 = categoryPlot5.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker19, layer36);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent39 = null;
        valueMarker19.notifyListeners(markerChangeEvent39);
        java.awt.Paint paint41 = valueMarker19.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean10 = categoryMarker9.getDrawAsLine();
        categoryPlot5.addDomainMarker(categoryMarker9);
        categoryPlot5.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke13 = valueMarker12.getOutlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker12.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker12.setLabelPaint((java.awt.Paint) color16);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        categoryPlot5.setRangeCrosshairValue((double) (-1L));
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        valueMarker1.notifyListeners(markerChangeEvent3);
        java.awt.Paint paint5 = valueMarker1.getPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setLabel("");
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        double double8 = dateAxis1.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getRangeGridlineStroke();
        dateAxis1.setAxisLineStroke(stroke15);
        dateAxis1.setFixedDimension(0.2d);
        boolean boolean19 = rectangleInsets0.equals((java.lang.Object) dateAxis1);
        double double21 = rectangleInsets0.calculateLeftOutset((double) '4');
        double double23 = rectangleInsets0.extendHeight((double) (-12517377));
        double double25 = rectangleInsets0.calculateBottomInset((double) 10);
        double double27 = rectangleInsets0.extendHeight((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.2517371E7d) + "'", double23 == (-1.2517371E7d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.0d + "'", double27 == 6.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot5.getDomainGridlinePosition();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke13);
        java.awt.Stroke stroke15 = categoryPlot5.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker18, layer21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection23);
        categoryPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot5.getDomainAxis();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(categoryAxis27);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color1 = java.awt.Color.RED;
        java.awt.Color color2 = color1.brighter();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke5 = valueMarker4.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color1, stroke5);
        java.awt.Color color7 = color1.darker();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        boolean boolean2 = dateAxis0.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setAutoTickUnitSelection(true, false);
        dateAxis2.setLabel("");
        java.awt.Paint paint8 = dateAxis2.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis2.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis0.getTickLabelInsets();
        dateAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        java.lang.Object obj2 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        categoryPlot13.axisChanged(axisChangeEvent14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot13.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot13.zoomDomainAxes((double) (-1L), plotRenderingInfo19, point2D20, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot13.getRangeAxisEdge(6);
        try {
            double double25 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) (-1.2517371E7d), (java.lang.Comparable) 6, categoryDataset5, (double) 1.0f, rectangle2D7, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        java.lang.Object obj3 = objectList1.get((-1));
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape7 = dateAxis6.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        java.awt.Stroke stroke10 = categoryPlot9.getRangeGridlineStroke();
        categoryPlot9.setAnchorValue((double) 10L, false);
        boolean boolean14 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot9.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint17 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot9.getFixedRangeAxisSpace();
        categoryPlot9.setBackgroundImageAlignment(10);
        boolean boolean24 = objectList1.equals((java.lang.Object) 10);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot5.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray31 = null;
        try {
            categoryPlot5.setRenderers(categoryItemRendererArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(sortOrder30);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        java.awt.Stroke stroke7 = categoryPlot5.getRangeGridlineStroke();
        boolean boolean8 = categoryPlot5.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = dateAxis4.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.util.List list8 = categoryPlot7.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.awt.Stroke stroke18 = categoryPlot17.getRangeGridlineStroke();
        categoryPlot17.setAnchorValue((double) 10L, false);
        boolean boolean22 = categoryPlot17.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = categoryPlot17.removeDomainMarker(marker23, layer24);
        categoryPlot7.addDomainMarker(2, categoryMarker11, layer24);
        categoryMarker11.setDrawAsLine(true);
        categoryPlot0.addDomainMarker(categoryMarker11);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        java.awt.Color color3 = java.awt.Color.RED;
        java.awt.Color color4 = color3.brighter();
        int int5 = color4.getRed();
        java.awt.Color color6 = java.awt.Color.RED;
        java.awt.Color color7 = java.awt.Color.orange;
        float[] floatArray8 = null;
        float[] floatArray9 = color7.getComponents(floatArray8);
        float[] floatArray10 = color6.getRGBColorComponents(floatArray9);
        float[] floatArray11 = color4.getColorComponents(floatArray10);
        valueMarker1.setLabelPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke13 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot5.removeChangeListener(plotChangeListener10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        java.awt.Color color14 = java.awt.Color.RED;
        java.awt.Color color15 = color14.brighter();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke18 = valueMarker17.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color14, stroke18);
        categoryPlot5.setRangeCrosshairStroke(stroke18);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double6 = rectangleInsets4.calculateBottomOutset((double) 0L);
        double double8 = rectangleInsets4.calculateLeftOutset(100.0d);
        double double9 = rectangleInsets4.getRight();
        double double11 = rectangleInsets4.calculateTopOutset((double) (byte) 1);
        double double13 = rectangleInsets4.calculateLeftInset((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.lang.Object obj6 = dateAxis0.clone();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        double double13 = dateAxis9.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.awt.Stroke stroke20 = categoryPlot19.getRangeGridlineStroke();
        categoryPlot19.setAnchorValue((double) 10L, false);
        boolean boolean24 = categoryPlot19.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        categoryPlot19.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.setAutoTickUnitSelection(true, false);
        dateAxis27.setLabel("");
        dateAxis27.setLowerBound((double) (short) 10);
        org.jfree.data.Range range35 = dateAxis27.getDefaultAutoRange();
        dateAxis25.setRange(range35);
        dateAxis9.setRange(range35);
        dateAxis0.setRange(range35);
        java.awt.Font font39 = dateAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(font39);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, (java.awt.Paint) color8, stroke9);
        dateAxis0.setTickMarkStroke(stroke9);
        java.util.Date date12 = dateAxis0.getMaximumDate();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = dateAxis15.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        java.awt.Stroke stroke19 = categoryPlot18.getRangeGridlineStroke();
        categoryPlot18.setAnchorValue((double) 10L, false);
        boolean boolean23 = categoryPlot18.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        categoryPlot18.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        java.lang.String str26 = dateAxis24.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint29 = valueMarker28.getPaint();
        dateAxis24.setLabelPaint(paint29);
        java.awt.Shape shape31 = dateAxis24.getLeftArrow();
        dateAxis0.setRightArrow(shape31);
        dateAxis0.centerRange((double) ' ');
        dateAxis0.setLabelAngle((double) (short) 100);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot5.getRangeAxisEdge();
        boolean boolean18 = categoryPlot5.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeStickyZero();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot10.axisChanged(axisChangeEvent11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot10.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot10.zoomDomainAxes((double) (-1L), plotRenderingInfo16, point2D17, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot10.getRangeAxisEdge(6);
        try {
            java.util.List list22 = numberAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        java.lang.Class class0 = null;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
//        int int5 = day4.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        boolean boolean10 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot5.markerChanged(markerChangeEvent11);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis12);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean3 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Stroke stroke4 = null;
        try {
            xYPlot0.setDomainGridlineStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation(1, axisLocation2, false);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeCrosshairStroke();
        int int6 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.setRangeCrosshairValue((double) 10);
        java.lang.String str6 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        boolean boolean8 = dateAxis0.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getRangeGridlineStroke();
        categoryPlot14.setAnchorValue((double) 10L, false);
        boolean boolean19 = categoryPlot14.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        boolean boolean22 = categoryPlot14.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = dateAxis25.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getRangeGridlineStroke();
        categoryPlot14.setRangeCrosshairStroke(stroke29);
        dateAxis0.setTickMarkStroke(stroke29);
        dateAxis0.resizeRange(0.0d, (double) 2.0f);
        dateAxis0.setLowerBound((double) 1560409200000L);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        java.lang.Comparable comparable3 = categoryMarker1.getKey();
        categoryMarker1.setKey((java.lang.Comparable) (-12517377));
        java.lang.Comparable comparable6 = categoryMarker1.getKey();
        java.awt.Font font7 = categoryMarker1.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (byte) -1 + "'", comparable3.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (-12517377) + "'", comparable6.equals((-12517377)));
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean3 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = null;
        try {
            xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        xYPlot0.clearRangeMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        java.awt.geom.Point2D point2D11 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.Paint paint16 = dateAxis0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot5.getDomainGridlinePosition();
        java.awt.Paint paint13 = categoryPlot5.getNoDataMessagePaint();
        categoryPlot5.setRangeCrosshairValue(100.0d);
        boolean boolean16 = categoryPlot5.isSubplot();
        double double17 = categoryPlot5.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setAutoTickUnitSelection(true, false);
        dateAxis7.setLabel("");
        java.awt.Paint paint13 = dateAxis7.getAxisLinePaint();
        double double14 = dateAxis7.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        java.awt.Stroke stroke21 = categoryPlot20.getRangeGridlineStroke();
        dateAxis7.setAxisLineStroke(stroke21);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = dateAxis7.java2DToValue(0.0d, rectangle2D24, rectangleEdge25);
        boolean boolean27 = dateAxis7.isVerticalTickLabels();
        java.lang.String str28 = dateAxis7.getLabel();
        org.jfree.data.Range range29 = dateAxis7.getRange();
        dateAxis0.setRange(range29);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot5.getRangeAxisEdge();
        int int18 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = dateAxis21.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getRangeGridlineStroke();
        java.awt.Stroke stroke26 = categoryPlot24.getRangeGridlineStroke();
        categoryPlot24.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot24.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation31);
        categoryPlot5.setRangeAxisLocation(axisLocation30, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = categoryPlot15.removeDomainMarker(marker21, layer22);
        categoryPlot5.addDomainMarker(2, categoryMarker9, layer22);
        categoryMarker9.setDrawAsLine(true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = categoryMarker9.getLabelOffsetType();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder28 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.Object obj29 = null;
        boolean boolean30 = seriesRenderingOrder28.equals(obj29);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint32 = defaultDrawingSupplier31.getNextOutlinePaint();
        boolean boolean33 = seriesRenderingOrder28.equals((java.lang.Object) defaultDrawingSupplier31);
        java.awt.Stroke stroke34 = defaultDrawingSupplier31.getNextOutlineStroke();
        categoryMarker9.setStroke(stroke34);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot10.axisChanged(axisChangeEvent11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot10.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot10.zoomDomainAxes((double) (-1L), plotRenderingInfo16, point2D17, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot10.getRangeAxisEdge(6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            org.jfree.chart.axis.AxisState axisState23 = categoryAxis0.draw(graphics2D1, 6.0d, rectangle2D3, rectangle2D4, rectangleEdge21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        java.awt.Stroke stroke13 = categoryPlot12.getRangeGridlineStroke();
        categoryPlot12.setAnchorValue((double) 10L, false);
        boolean boolean17 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        categoryPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.lang.String str20 = dateAxis18.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint23 = valueMarker22.getPaint();
        dateAxis18.setLabelPaint(paint23);
        java.awt.Shape shape25 = dateAxis18.getLeftArrow();
        dateAxis0.setLeftArrow(shape25);
        boolean boolean27 = dateAxis0.isVisible();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        double double12 = dateAxis8.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setAutoTickUnitSelection(true, false);
        dateAxis13.setLabel("");
        java.awt.Paint paint19 = dateAxis13.getAxisLinePaint();
        org.jfree.data.Range range20 = dateAxis13.getRange();
        dateAxis8.setRange(range20, true, false);
        dateAxis0.setRange(range20);
        double double25 = dateAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(15);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        java.awt.Paint paint3 = valueMarker1.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = valueMarker1.getLabelAnchor();
        java.awt.Color color5 = java.awt.Color.RED;
        java.awt.Color color6 = color5.brighter();
        int int7 = color6.getRed();
        java.awt.Color color8 = java.awt.Color.RED;
        java.awt.Color color9 = java.awt.Color.orange;
        float[] floatArray10 = null;
        float[] floatArray11 = color9.getComponents(floatArray10);
        float[] floatArray12 = color8.getRGBColorComponents(floatArray11);
        float[] floatArray13 = color6.getColorComponents(floatArray12);
        valueMarker1.setPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis0.java2DToValue(0.0d, rectangle2D17, rectangleEdge18);
        dateAxis0.setRange(0.0d, (double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        dateAxis23.setAutoTickUnitSelection(true, false);
        dateAxis23.setLabel("");
        dateAxis23.setLowerBound((double) (short) 10);
        dateAxis23.setRangeWithMargins((double) 2.0f, (double) '#');
        java.awt.Font font34 = dateAxis23.getTickLabelFont();
        dateAxis0.setLabelFont(font34);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        java.lang.Object obj3 = objectList1.get((-1));
        java.lang.Object obj4 = objectList1.clone();
        java.lang.Object obj5 = objectList1.clone();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        java.lang.String str6 = dateAxis0.getLabelURL();
        boolean boolean7 = dateAxis0.isPositiveArrowVisible();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        boolean boolean8 = dateAxis0.isNegativeArrowVisible();
        java.lang.String str9 = dateAxis0.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        double double13 = valueMarker11.getValue();
        valueMarker11.setLabel("java.awt.Color[r=255,g=0,b=0]");
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        valueMarker11.setPaint((java.awt.Paint) color16);
        dateAxis0.setAxisLinePaint((java.awt.Paint) color16);
        dateAxis0.setInverted(false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setAutoTickUnitSelection(true, false);
        dateAxis8.setVerticalTickLabels(false);
        float float14 = dateAxis8.getTickMarkInsideLength();
        java.lang.String str15 = dateAxis8.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis8.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(dateTickUnit16);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        dateAxis0.setFixedDimension(0.2d);
        double double18 = dateAxis0.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = dateAxis0.getStandardTickUnits();
        try {
            dateAxis0.setAutoRangeMinimumSize((-37.0d), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource19);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        java.awt.Stroke stroke13 = categoryPlot12.getRangeGridlineStroke();
        categoryPlot12.setAnchorValue((double) 10L, false);
        boolean boolean17 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        categoryPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setAutoTickUnitSelection(true, false);
        dateAxis20.setLabel("");
        dateAxis20.setLowerBound((double) (short) 10);
        org.jfree.data.Range range28 = dateAxis20.getDefaultAutoRange();
        dateAxis18.setRange(range28);
        dateAxis2.setRange(range28);
        boolean boolean31 = dateAxis2.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = null;
        dateAxis2.setStandardTickUnits(tickUnitSource32);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker1.setOutlinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker1.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = valueMarker1.getLabelOffset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 500, (float) (byte) 1, (float) ' ');
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        categoryPlot5.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextOutlinePaint();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot5.setAnchorValue((double) 100L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot5.markerChanged(markerChangeEvent24);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis0.java2DToValue(0.0d, rectangle2D17, rectangleEdge18);
        boolean boolean20 = dateAxis0.isVerticalTickLabels();
        java.lang.String str21 = dateAxis0.getLabel();
        float float22 = dateAxis0.getTickMarkOutsideLength();
        try {
            dateAxis0.zoomRange((double) 0.8f, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker18, layer21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection23);
        categoryPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot5.addChangeListener(plotChangeListener27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot5.getRenderer((int) (short) -1);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot5.getDatasetGroup();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertNull(datasetGroup31);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        categoryPlot5.clearAnnotations();
        categoryPlot5.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot5.removeChangeListener(plotChangeListener11);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        java.awt.Stroke stroke7 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot5.getRowRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            categoryPlot5.handleClick(12, 0, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(sortOrder8);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        xYPlot0.clearRangeMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            xYPlot0.setRangeAxisLocation((int) (short) -1, axisLocation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        int int12 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot5.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot5.zoomDomainAxes((double) 100, 8.0d, plotRenderingInfo16, point2D17);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        boolean boolean11 = categoryPlot5.isOutlineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis();
        boolean boolean13 = categoryPlot5.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 10, 100, 1);
        java.awt.Color color4 = java.awt.Color.CYAN;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint8 = valueMarker7.getPaint();
        double double9 = valueMarker7.getValue();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        valueMarker7.setPaint((java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.util.List list18 = categoryPlot17.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape25 = dateAxis24.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        java.awt.Stroke stroke28 = categoryPlot27.getRangeGridlineStroke();
        categoryPlot27.setAnchorValue((double) 10L, false);
        boolean boolean32 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean35 = categoryPlot27.removeDomainMarker(marker33, layer34);
        categoryPlot17.addDomainMarker(2, categoryMarker21, layer34);
        categoryMarker21.setDrawAsLine(true);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int40 = color39.getBlue();
        int int41 = color39.getAlpha();
        categoryMarker21.setOutlinePaint((java.awt.Paint) color39);
        java.awt.Color color46 = java.awt.Color.RED;
        java.awt.Color color47 = color46.brighter();
        int int48 = color47.getRed();
        java.awt.Color color49 = java.awt.Color.RED;
        java.awt.Color color50 = java.awt.Color.orange;
        float[] floatArray51 = null;
        float[] floatArray52 = color50.getComponents(floatArray51);
        float[] floatArray53 = color49.getRGBColorComponents(floatArray52);
        float[] floatArray54 = color47.getColorComponents(floatArray53);
        float[] floatArray55 = java.awt.Color.RGBtoHSB(8, 0, 7, floatArray54);
        float[] floatArray56 = color39.getRGBColorComponents(floatArray54);
        float[] floatArray57 = color10.getRGBColorComponents(floatArray56);
        float[] floatArray58 = color5.getRGBColorComponents(floatArray57);
        float[] floatArray59 = color4.getColorComponents(floatArray57);
        float[] floatArray60 = chartColor3.getComponents(floatArray57);
        java.awt.Color color61 = chartColor3.brighter();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 255 + "'", int41 == 255);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 255 + "'", int48 == 255);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(color61);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        double double3 = numberAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot5.setNoDataMessageFont(font15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot5.clearRangeAxes();
        categoryPlot5.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = dateAxis23.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        java.awt.Stroke stroke27 = categoryPlot26.getRangeGridlineStroke();
        double double28 = categoryPlot26.getRangeCrosshairValue();
        boolean boolean29 = categoryPlot26.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        boolean boolean34 = categoryPlot26.render(graphics2D30, rectangle2D31, (int) (short) 10, plotRenderingInfo33);
        categoryPlot26.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot26.setRenderer(categoryItemRenderer37);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str40 = axisLocation39.toString();
        categoryPlot26.setDomainAxisLocation(axisLocation39);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot26.setDomainGridlineStroke(stroke42);
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape48 = dateAxis47.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer49);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent51 = null;
        categoryPlot50.axisChanged(axisChangeEvent51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = categoryPlot50.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        java.awt.geom.Point2D point2D57 = null;
        categoryPlot50.zoomDomainAxes((double) (-1L), plotRenderingInfo56, point2D57, false);
        categoryPlot50.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot50.getRangeAxisEdge();
        categoryPlot50.setForegroundAlpha((float) (short) 1);
        java.awt.Stroke stroke65 = categoryPlot50.getDomainGridlineStroke();
        categoryPlot26.setOutlineStroke(stroke65);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str40.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNull(categoryItemRenderer54);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        double double3 = valueMarker1.getValue();
        valueMarker1.setLabel("java.awt.Color[r=255,g=0,b=0]");
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        valueMarker1.setPaint((java.awt.Paint) color6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        double double15 = categoryPlot13.getRangeCrosshairValue();
        boolean boolean16 = categoryPlot13.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setAutoTickUnitSelection(true, false);
        dateAxis18.setLabel("");
        java.awt.Paint paint24 = dateAxis18.getAxisLinePaint();
        double double25 = dateAxis18.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape29 = dateAxis28.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer30);
        java.awt.Stroke stroke32 = categoryPlot31.getRangeGridlineStroke();
        dateAxis18.setAxisLineStroke(stroke32);
        dateAxis18.setFixedDimension(0.2d);
        boolean boolean36 = rectangleInsets17.equals((java.lang.Object) dateAxis18);
        categoryPlot13.setInsets(rectangleInsets17, false);
        double double40 = rectangleInsets17.calculateBottomInset(0.0d);
        valueMarker1.setLabelOffset(rectangleInsets17);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker1.setStroke(stroke42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape47 = dateAxis46.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis46, categoryItemRenderer48);
        java.util.List list50 = categoryPlot49.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape57 = dateAxis56.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset54, categoryAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis56, categoryItemRenderer58);
        java.awt.Stroke stroke60 = categoryPlot59.getRangeGridlineStroke();
        categoryPlot59.setAnchorValue((double) 10L, false);
        boolean boolean64 = categoryPlot59.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker65 = null;
        org.jfree.chart.util.Layer layer66 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean67 = categoryPlot59.removeDomainMarker(marker65, layer66);
        categoryPlot49.addDomainMarker(2, categoryMarker53, layer66);
        java.awt.Paint paint69 = categoryPlot49.getRangeCrosshairPaint();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot49);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.0d + "'", double40 == 3.0d);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNull(list50);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(layer66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(paint69);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        org.jfree.chart.axis.ValueAxis valueAxis47 = xYPlot0.getDomainAxis((int) (short) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray49 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer48 };
        xYPlot0.setRenderers(xYItemRendererArray49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        xYPlot0.zoomRangeAxes(0.0d, (double) 'a', plotRenderingInfo53, point2D54);
        int int56 = xYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(xYItemRendererArray49);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 15 + "'", int56 == 15);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot5.getColumnRenderingOrder();
        boolean boolean32 = sortOrder30.equals((java.lang.Object) 8);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType0, 8.0d, 0.2d, (double) 255, (double) 2.0f);
        java.lang.String str7 = unitType0.toString();
        java.lang.String str8 = unitType0.toString();
        java.lang.String str9 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.ABSOLUTE" + "'", str7.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UnitType.ABSOLUTE" + "'", str8.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UnitType.ABSOLUTE" + "'", str9.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke7 = valueMarker6.getOutlineStroke();
        java.awt.Stroke stroke8 = valueMarker6.getOutlineStroke();
        xYPlot0.setRangeGridlineStroke(stroke8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            xYPlot0.handleClick(255, (int) (short) -1, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        java.lang.String str8 = dateAxis1.getLabel();
        boolean boolean9 = dateAxis1.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean23 = categoryPlot15.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot15.setRangeCrosshairStroke(stroke30);
        dateAxis1.setTickMarkStroke(stroke30);
        dateAxis1.resizeRange(0.0d, (double) 2.0f);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis36.setNumberFormatOverride(numberFormat37);
        java.text.NumberFormat numberFormat39 = null;
        numberAxis36.setNumberFormatOverride(numberFormat39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer41);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder43 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot42.setSeriesRenderingOrder(seriesRenderingOrder43);
        org.jfree.chart.axis.AxisSpace axisSpace45 = xYPlot42.getFixedRangeAxisSpace();
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        try {
            xYPlot42.drawBackground(graphics2D46, rectangle2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder43);
        org.junit.Assert.assertNull(axisSpace45);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.Font font16 = dateAxis0.getLabelFont();
        dateAxis0.setVisible(false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setRangeAxisLocation(1, axisLocation5, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot3.getFixedDomainAxisSpace();
        java.awt.Stroke stroke9 = categoryPlot3.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke16 = valueMarker15.getOutlineStroke();
        java.awt.Stroke stroke17 = valueMarker15.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color2, stroke9, (java.awt.Paint) chartColor13, stroke17, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer20);
        intervalMarker19.setEndValue((double) (short) -1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        java.lang.String str8 = dateAxis1.getLabel();
        boolean boolean9 = dateAxis1.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean23 = categoryPlot15.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot15.setRangeCrosshairStroke(stroke30);
        dateAxis1.setTickMarkStroke(stroke30);
        dateAxis1.resizeRange(0.0d, (double) 2.0f);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis36.setNumberFormatOverride(numberFormat37);
        java.text.NumberFormat numberFormat39 = null;
        numberAxis36.setNumberFormatOverride(numberFormat39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer41);
        java.awt.Stroke stroke43 = numberAxis36.getAxisLineStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = null;
        try {
            numberAxis36.setTickUnit(numberTickUnit44, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke13 = valueMarker12.getOutlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker12.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker12.setLabelPaint((java.awt.Paint) color16);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.text.TextAnchor textAnchor19 = valueMarker12.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis0.getTickUnit();
        double double9 = dateAxis0.getUpperMargin();
        java.awt.Stroke stroke10 = dateAxis0.getTickMarkStroke();
        dateAxis0.setRangeWithMargins((double) 9, 12.0d);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = dateAxis18.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        java.awt.Stroke stroke22 = categoryPlot21.getRangeGridlineStroke();
        double double23 = categoryPlot21.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot21.zoomDomainAxes((double) 255, plotRenderingInfo25, point2D26);
        int int28 = categoryPlot21.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot21.getRangeAxisEdge();
        try {
            double double30 = dateAxis0.java2DToValue((double) 11, rectangle2D15, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot8.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot8.getOrientation();
        xYPlot0.setOrientation(plotOrientation12);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(plotOrientation12);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Color color1 = java.awt.Color.RED;
        java.awt.Color color2 = color1.brighter();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke5 = valueMarker4.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color1, stroke5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setAutoTickUnitSelection(true, false);
        dateAxis7.setLabel("");
        java.lang.Object obj13 = dateAxis7.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setAutoTickUnitSelection(true, false);
        dateAxis15.setLabel("");
        java.awt.Paint paint21 = dateAxis15.getAxisLinePaint();
        double double22 = dateAxis15.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = dateAxis25.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getRangeGridlineStroke();
        dateAxis15.setAxisLineStroke(stroke29);
        dateAxis15.setFixedDimension(0.2d);
        boolean boolean33 = rectangleInsets14.equals((java.lang.Object) dateAxis15);
        double double35 = rectangleInsets14.calculateLeftOutset((double) '4');
        dateAxis7.setTickLabelInsets(rectangleInsets14);
        valueMarker6.setLabelOffset(rectangleInsets14);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35 == 3.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis0.getTickUnit();
        dateAxis0.setAutoTickUnitSelection(true);
        dateAxis0.setFixedAutoRange(100.0d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = xYPlot0.getAxisOffset();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            xYPlot0.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        dateAxis0.setFixedDimension(10.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke19 = valueMarker18.getOutlineStroke();
        categoryPlot5.setRangeGridlineStroke(stroke19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = dateAxis23.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        java.awt.Stroke stroke27 = categoryPlot26.getRangeGridlineStroke();
        java.awt.Stroke stroke28 = categoryPlot26.getRangeGridlineStroke();
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot26.getRowRenderingOrder();
        boolean boolean30 = categoryPlot26.isOutlineVisible();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(sortOrder29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        java.lang.String str8 = dateAxis1.getLabel();
        boolean boolean9 = dateAxis1.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean23 = categoryPlot15.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot15.setRangeCrosshairStroke(stroke30);
        dateAxis1.setTickMarkStroke(stroke30);
        dateAxis1.resizeRange(0.0d, (double) 2.0f);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis36.setNumberFormatOverride(numberFormat37);
        java.text.NumberFormat numberFormat39 = null;
        numberAxis36.setNumberFormatOverride(numberFormat39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer41);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder43 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot42.setSeriesRenderingOrder(seriesRenderingOrder43);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent45 = null;
        xYPlot42.axisChanged(axisChangeEvent45);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder43);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        int int12 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot5.getRenderer();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer13);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot5.getColumnRenderingOrder();
        int int14 = categoryPlot5.getDatasetCount();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Point2D point2D17 = null;
        org.jfree.chart.plot.PlotState plotState18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            categoryPlot5.draw(graphics2D15, rectangle2D16, point2D17, plotState18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setAutoTickUnitSelection(true, false);
        java.awt.Paint paint17 = dateAxis13.getTickMarkPaint();
        dateAxis13.setLabelURL("java.awt.Color[r=0,g=192,b=192]");
        java.awt.Paint paint20 = dateAxis13.getLabelPaint();
        boolean boolean21 = categoryAnchor12.equals((java.lang.Object) dateAxis13);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean3 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean4 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        dateAxis0.setNegativeArrowVisible(true);
        float float4 = dateAxis0.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis0.getTickMarkPosition();
        java.awt.Paint paint6 = dateAxis0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = dateAxis4.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.util.List list8 = categoryPlot7.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.awt.Stroke stroke18 = categoryPlot17.getRangeGridlineStroke();
        categoryPlot17.setAnchorValue((double) 10L, false);
        boolean boolean22 = categoryPlot17.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = categoryPlot17.removeDomainMarker(marker23, layer24);
        categoryPlot7.addDomainMarker(2, categoryMarker11, layer24);
        categoryMarker11.setDrawAsLine(true);
        categoryPlot0.addDomainMarker(categoryMarker11);
        java.lang.Object obj30 = null;
        boolean boolean31 = categoryMarker11.equals(obj30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.lang.String str13 = dateAxis11.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        dateAxis11.setLabelPaint(paint16);
        java.lang.String str18 = dateAxis11.getLabelToolTip();
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis11.getTickUnit();
        dateAxis11.setLabelURL("");
        dateAxis11.setAutoRange(false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(dateTickUnit19);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        java.awt.Stroke stroke13 = categoryPlot12.getRangeGridlineStroke();
        categoryPlot12.setAnchorValue((double) 10L, false);
        boolean boolean17 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        categoryPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setAutoTickUnitSelection(true, false);
        dateAxis20.setLabel("");
        dateAxis20.setLowerBound((double) (short) 10);
        org.jfree.data.Range range28 = dateAxis20.getDefaultAutoRange();
        dateAxis18.setRange(range28);
        dateAxis2.setRange(range28);
        dateAxis2.setAutoRange(false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        xYPlot0.clearRangeMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        xYPlot0.clearDomainMarkers((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation(1, axisLocation2, false);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        float float8 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = color0.brighter();
        int int2 = color1.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        categoryPlot5.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextOutlinePaint();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        java.awt.Paint paint22 = defaultDrawingSupplier19.getNextFillPaint();
        java.awt.Paint paint23 = defaultDrawingSupplier19.getNextPaint();
        java.awt.Paint paint24 = defaultDrawingSupplier19.getNextPaint();
        java.lang.Object obj25 = defaultDrawingSupplier19.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 15);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot5.render(graphics2D9, rectangle2D10, (int) (short) 10, plotRenderingInfo12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        int int16 = categoryAxis15.getMaximumCategoryLabelLines();
        java.awt.Font font18 = categoryAxis15.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        categoryPlot5.setDomainAxis(0, categoryAxis15, false);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = null;
        categoryPlot29.axisChanged(axisChangeEvent30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot29.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot29.zoomDomainAxes((double) (-1L), plotRenderingInfo35, point2D36, false);
        categoryPlot29.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot29.getRangeAxisEdge();
        try {
            double double42 = categoryAxis15.getCategoryStart(9, 100, rectangle2D23, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(categoryItemRenderer33);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        xYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot5.setNoDataMessageFont(font15);
        categoryPlot5.clearRangeMarkers(13);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        numberAxis1.zoomRange((double) 0L, (double) 10);
        org.jfree.data.RangeType rangeType5 = null;
        try {
            numberAxis1.setRangeType(rangeType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        boolean boolean7 = dateAxis0.isVisible();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        categoryPlot13.axisChanged(axisChangeEvent14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint18 = valueMarker17.getPaint();
        categoryPlot13.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot13.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot13.setNoDataMessageFont(font23);
        dateAxis0.setLabelFont(font23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace29 = xYPlot26.getFixedRangeAxisSpace();
        xYPlot26.setRangeCrosshairValue((double) 10);
        boolean boolean32 = dateAxis0.hasListener((java.util.EventListener) xYPlot26);
        dateAxis0.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        xYPlot0.zoomRangeAxes((double) 2, plotRenderingInfo50, point2D51, true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot5.getRangeAxisLocation(10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        dateAxis0.setRangeWithMargins((double) 2.0f, (double) '#');
        dateAxis0.setTickMarkOutsideLength((float) (-1));
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setAutoTickUnitSelection(true, false);
        dateAxis13.setLabel("");
        java.awt.Paint paint19 = dateAxis13.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis13.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.setAutoTickUnitSelection(true, false);
        dateAxis21.setLabel("");
        java.awt.Paint paint27 = dateAxis21.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = dateAxis21.getTickUnit();
        java.util.Date date29 = dateAxis13.calculateLowestVisibleTickValue(dateTickUnit28);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.setDomainGridlinesVisible(false);
        xYPlot31.setDomainGridlinesVisible(false);
        double double36 = xYPlot31.getDomainCrosshairValue();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot31.setDomainGridlineStroke(stroke37);
        int int39 = xYPlot31.getSeriesCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot31.getRangeAxisEdge();
        try {
            double double41 = dateAxis0.dateToJava2D(date29, rectangle2D30, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(dateTickUnit28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setAutoTickUnitSelection(true, false);
        dateAxis6.setLabel("");
        java.awt.Paint paint12 = dateAxis6.getAxisLinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, (java.awt.Paint) color14, stroke15);
        dateAxis6.setTickMarkStroke(stroke15);
        java.util.Date date18 = dateAxis6.getMaximumDate();
        dateAxis0.setMinimumDate(date18);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker18, layer21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection23);
        categoryPlot5.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape31 = dateAxis30.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer32);
        java.util.List list34 = categoryPlot33.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape41 = dateAxis40.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer42);
        java.awt.Stroke stroke44 = categoryPlot43.getRangeGridlineStroke();
        categoryPlot43.setAnchorValue((double) 10L, false);
        boolean boolean48 = categoryPlot43.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker49 = null;
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean51 = categoryPlot43.removeDomainMarker(marker49, layer50);
        categoryPlot33.addDomainMarker(2, categoryMarker37, layer50);
        java.util.Collection collection53 = categoryPlot5.getRangeMarkers((-1), layer50);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(list34);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(collection53);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker1.setOutlinePaint((java.awt.Paint) color3);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str6 = lengthAdjustmentType5.toString();
        valueMarker1.setLabelOffsetType(lengthAdjustmentType5);
        try {
            valueMarker1.setAlpha((float) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "NO_CHANGE" + "'", str6.equals("NO_CHANGE"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot5.getRangeAxisEdge();
        categoryPlot5.setForegroundAlpha((float) (short) 1);
        float float20 = categoryPlot5.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = dateAxis23.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = null;
        categoryPlot26.axisChanged(axisChangeEvent27);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint31 = valueMarker30.getPaint();
        categoryPlot26.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker30);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = categoryPlot26.getDomainGridlinePosition();
        java.lang.String str34 = categoryAnchor33.toString();
        categoryPlot5.setDomainGridlinePosition(categoryAnchor33);
        java.lang.String str36 = categoryAnchor33.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str34.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str36.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color10);
        categoryPlot5.setWeight(8);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot20.axisChanged(axisChangeEvent21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot20.getRenderer(8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = categoryPlot20.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot20.getRenderer(0);
        categoryPlot20.setRangeCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = dateAxis33.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = null;
        categoryPlot36.axisChanged(axisChangeEvent37);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape43 = dateAxis42.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer44);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent46 = null;
        categoryPlot45.axisChanged(axisChangeEvent46);
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint50 = valueMarker49.getPaint();
        categoryPlot45.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker49);
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean53 = categoryPlot36.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker49, layer52);
        java.util.Collection collection54 = categoryPlot20.getDomainMarkers((int) '4', layer52);
        java.util.Collection collection55 = categoryPlot5.getRangeMarkers((int) (byte) 100, layer52);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertNull(collection55);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        boolean boolean8 = dateAxis0.isAutoRange();
        boolean boolean9 = dateAxis0.isAutoTickUnitSelection();
        double double10 = dateAxis0.getAutoRangeMinimumSize();
        boolean boolean11 = dateAxis0.isTickMarksVisible();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        categoryPlot17.axisChanged(axisChangeEvent18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot17.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot17.zoomDomainAxes((double) (-1L), plotRenderingInfo23, point2D24, false);
        categoryPlot17.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot17.getRangeAxisEdge();
        int int30 = categoryPlot17.getBackgroundImageAlignment();
        java.awt.Image image31 = null;
        categoryPlot17.setBackgroundImage(image31);
        boolean boolean33 = dateAxis0.hasListener((java.util.EventListener) categoryPlot17);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot5.getColumnRenderingOrder();
        java.lang.String str14 = sortOrder13.toString();
        java.lang.String str15 = sortOrder13.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "SortOrder.ASCENDING" + "'", str14.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "SortOrder.ASCENDING" + "'", str15.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        double double10 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot8.getIndexOf(categoryItemRenderer11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot8.removeChangeListener(plotChangeListener13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color15);
        valueMarker1.setOutlinePaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        categoryPlot5.setWeight(0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot5.addChangeListener(plotChangeListener12);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        int int9 = categoryPlot8.getWeight();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.util.List list16 = categoryPlot15.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = dateAxis22.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getRangeGridlineStroke();
        categoryPlot25.setAnchorValue((double) 10L, false);
        boolean boolean30 = categoryPlot25.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker31 = null;
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean33 = categoryPlot25.removeDomainMarker(marker31, layer32);
        categoryPlot15.addDomainMarker(2, categoryMarker19, layer32);
        categoryMarker19.setDrawAsLine(true);
        categoryPlot8.addDomainMarker(categoryMarker19);
        java.awt.Stroke stroke38 = categoryMarker19.getOutlineStroke();
        categoryPlot5.setRangeGridlineStroke(stroke38);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(list16);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setVerticalTickLabels(true);
        dateAxis0.setAxisLineVisible(false);
        dateAxis0.setTickMarksVisible(true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setAutoTickUnitSelection(true, false);
        dateAxis13.setLabel("");
        dateAxis13.setLowerBound((double) (short) 10);
        org.jfree.data.Range range21 = dateAxis13.getDefaultAutoRange();
        dateAxis11.setRange(range21);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis11.setStandardTickUnits(tickUnitSource23);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(tickUnitSource23);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.setAutoTickUnitSelection(true, false);
        dateAxis5.setVerticalTickLabels(false);
        float float11 = dateAxis5.getTickMarkInsideLength();
        boolean boolean12 = lengthAdjustmentType4.equals((java.lang.Object) dateAxis5);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = dateAxis15.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        categoryPlot18.axisChanged(axisChangeEvent19);
        categoryPlot18.clearRangeAxes();
        boolean boolean22 = lengthAdjustmentType4.equals((java.lang.Object) categoryPlot18);
        categoryMarker3.setLabelOffsetType(lengthAdjustmentType4);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        xYPlot0.clearRangeMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        categoryPlot17.axisChanged(axisChangeEvent18);
        categoryPlot17.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot17.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot17.rendererChanged(rendererChangeEvent23);
        categoryPlot17.mapDatasetToRangeAxis(100, 1);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot17.setDomainAxisLocation(axisLocation28);
        boolean boolean30 = rectangleAnchor11.equals((java.lang.Object) axisLocation28);
        xYPlot0.setDomainAxisLocation(axisLocation28, false);
        try {
            java.awt.Paint paint34 = xYPlot0.getQuadrantPaint((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setAutoTickUnitSelection(true, false);
        dateAxis7.setLabel("");
        java.awt.Paint paint13 = dateAxis7.getAxisLinePaint();
        org.jfree.data.Range range14 = dateAxis7.getRange();
        dateAxis2.setRange(range14, true, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setAutoTickUnitSelection(true, false);
        dateAxis18.setLabel("");
        java.lang.Object obj24 = dateAxis18.clone();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.setAutoTickUnitSelection(true, false);
        dateAxis25.setLabel("");
        dateAxis25.setLowerBound((double) (short) 10);
        dateAxis25.setRangeWithMargins((double) 2.0f, (double) '#');
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis25.getTickUnit();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition37 = dateAxis25.getTickMarkPosition();
        dateAxis18.setTickMarkPosition(dateTickMarkPosition37);
        dateAxis2.setTickMarkPosition(dateTickMarkPosition37);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertNotNull(dateTickMarkPosition37);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) 6);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.0d + "'", double2 == 12.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setAutoTickUnitSelection(true, false);
        dateAxis2.setLabel("");
        java.awt.Paint paint8 = dateAxis2.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis2.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit9);
        dateAxis0.setLabelAngle(8.0d);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(dateTickUnit9);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        double double4 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        java.awt.Paint paint11 = categoryPlot5.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        dateAxis0.setFixedDimension(0.2d);
        double double18 = dateAxis0.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = dateAxis0.getStandardTickUnits();
        double double20 = dateAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.START" + "'", str1.equals("CategoryAnchor.START"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.lang.Object obj6 = dateAxis0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setAutoTickUnitSelection(true, false);
        dateAxis8.setLabel("");
        java.awt.Paint paint14 = dateAxis8.getAxisLinePaint();
        double double15 = dateAxis8.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = dateAxis18.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        java.awt.Stroke stroke22 = categoryPlot21.getRangeGridlineStroke();
        dateAxis8.setAxisLineStroke(stroke22);
        dateAxis8.setFixedDimension(0.2d);
        boolean boolean26 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        double double28 = rectangleInsets7.calculateLeftOutset((double) '4');
        dateAxis0.setTickLabelInsets(rectangleInsets7);
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis0.setTimeline(timeline30);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double38 = rectangleInsets36.calculateBottomOutset((double) 0L);
        java.lang.String str39 = rectangleInsets36.toString();
        dateAxis0.setLabelInsets(rectangleInsets36);
        java.awt.Stroke stroke41 = dateAxis0.getAxisLineStroke();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=0.2,l=8.0,b=1.0,r=32.0]" + "'", str39.equals("RectangleInsets[t=0.2,l=8.0,b=1.0,r=32.0]"));
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        int int12 = categoryPlot5.getDomainAxisCount();
        boolean boolean13 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("13-June-2019");
        dateAxis15.resizeRange(1.0d);
        org.jfree.data.Range range18 = categoryPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis15);
        dateAxis15.setFixedDimension((double) 15);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        java.awt.Stroke stroke10 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        xYPlot0.setOrientation(plotOrientation15);
        xYPlot0.mapDatasetToRangeAxis(13, 6);
        java.awt.Stroke stroke21 = null;
        try {
            xYPlot0.setRangeZeroBaselineStroke(stroke21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean3 = chartChangeEventType0.equals((java.lang.Object) (byte) -1);
        java.lang.String str4 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str4.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.clearDomainMarkers(500);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot5.getRangeAxisEdge();
        categoryPlot5.setForegroundAlpha((float) (short) 1);
        float float20 = categoryPlot5.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = dateAxis23.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = null;
        categoryPlot26.axisChanged(axisChangeEvent27);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint31 = valueMarker30.getPaint();
        categoryPlot26.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker30);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = categoryPlot26.getDomainGridlinePosition();
        java.lang.String str34 = categoryAnchor33.toString();
        categoryPlot5.setDomainGridlinePosition(categoryAnchor33);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace38);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str34.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot5.getDomainGridlinePosition();
        java.awt.Paint paint13 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot5.getRenderer((int) (short) 0);
        categoryPlot5.clearRangeAxes();
        categoryPlot5.setNoDataMessage("SortOrder.ASCENDING");
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection17 = categoryPlot5.getDomainMarkers(8, layer16);
        java.util.List list18 = categoryPlot5.getCategories();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNull(list18);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 15);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        int int9 = categoryPlot8.getWeight();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.util.List list16 = categoryPlot15.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = dateAxis22.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getRangeGridlineStroke();
        categoryPlot25.setAnchorValue((double) 10L, false);
        boolean boolean30 = categoryPlot25.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker31 = null;
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean33 = categoryPlot25.removeDomainMarker(marker31, layer32);
        categoryPlot15.addDomainMarker(2, categoryMarker19, layer32);
        categoryMarker19.setDrawAsLine(true);
        categoryPlot8.addDomainMarker(categoryMarker19);
        categoryPlot8.setWeight(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot8.getRangeAxisEdge((int) (short) 1);
        try {
            double double42 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) "NO_CHANGE", (java.lang.Comparable) 1.0d, categoryDataset5, (double) 9, rectangle2D7, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(list16);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=0.2,l=8.0,b=1.0,r=32.0]");
        boolean boolean15 = categoryAnchor12.equals((java.lang.Object) dateAxis14);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        categoryPlot5.zoom((double) (byte) 100);
        java.lang.String str14 = categoryPlot5.getNoDataMessage();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Font font6 = dateAxis2.getTickLabelFont();
        dateAxis2.setRangeAboutValue(0.0d, 0.0d);
        org.jfree.data.Range range10 = dateAxis2.getRange();
        boolean boolean11 = dateAxis2.isVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot5.removeChangeListener(plotChangeListener10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot5.getRendererForDataset(categoryDataset14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = dateAxis18.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        java.awt.Stroke stroke22 = categoryPlot21.getRangeGridlineStroke();
        java.awt.Stroke stroke23 = categoryPlot21.getRangeGridlineStroke();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot21.getRowRenderingOrder();
        java.lang.String str25 = sortOrder24.toString();
        categoryPlot5.setRowRenderingOrder(sortOrder24);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "SortOrder.ASCENDING" + "'", str25.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint13 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets14, false);
        double double18 = rectangleInsets14.calculateRightOutset((double) 8);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        xYPlot0.clearRangeMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setDomainGridlinesVisible(false);
        xYPlot11.setDomainGridlinesVisible(false);
        double double16 = xYPlot11.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        categoryPlot22.axisChanged(axisChangeEvent23);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint27 = valueMarker26.getPaint();
        categoryPlot22.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot22.zoomDomainAxes((double) (byte) 10, plotRenderingInfo30, point2D31, false);
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint37 = valueMarker36.getPaint();
        double double38 = valueMarker36.getValue();
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker36.setLabelTextAnchor(textAnchor39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape44 = dateAxis43.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis43, categoryItemRenderer45);
        java.awt.Stroke stroke47 = categoryPlot46.getRangeGridlineStroke();
        categoryPlot46.setAnchorValue((double) 10L, false);
        boolean boolean51 = categoryPlot46.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker52 = null;
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean54 = categoryPlot46.removeDomainMarker(marker52, layer53);
        boolean boolean55 = categoryPlot22.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker36, layer53);
        java.util.Collection collection56 = xYPlot11.getRangeMarkers(layer53);
        java.util.Collection collection57 = xYPlot0.getDomainMarkers(layer53);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 10.0d + "'", double38 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(collection56);
        org.junit.Assert.assertNull(collection57);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        org.jfree.data.Range range7 = dateAxis0.getRange();
        org.jfree.chart.plot.Plot plot8 = null;
        dateAxis0.setPlot(plot8);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.lang.Class class0 = null;
        java.lang.Class class1 = null;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("AxisLocation.TOP_OR_LEFT", timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date2, timeZone7);
        java.lang.Class class10 = null;
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone12);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        java.util.List list9 = categoryPlot5.getAnnotations();
        categoryPlot5.clearDomainAxes();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(3.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation(1, axisLocation2, false);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.plot.Plot plot6 = categoryPlot0.getParent();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        categoryPlot5.mapDatasetToRangeAxis(100, 1);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot5.setDomainAxisLocation(axisLocation16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot5.setDataset(categoryDataset18);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.lang.Object obj6 = dateAxis0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setAutoTickUnitSelection(true, false);
        dateAxis8.setLabel("");
        java.awt.Paint paint14 = dateAxis8.getAxisLinePaint();
        double double15 = dateAxis8.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = dateAxis18.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        java.awt.Stroke stroke22 = categoryPlot21.getRangeGridlineStroke();
        dateAxis8.setAxisLineStroke(stroke22);
        dateAxis8.setFixedDimension(0.2d);
        boolean boolean26 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        double double28 = rectangleInsets7.calculateLeftOutset((double) '4');
        dateAxis0.setTickLabelInsets(rectangleInsets7);
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis0.setTimeline(timeline30);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double38 = rectangleInsets36.calculateBottomOutset((double) 0L);
        java.lang.String str39 = rectangleInsets36.toString();
        dateAxis0.setLabelInsets(rectangleInsets36);
        double double42 = rectangleInsets36.calculateTopOutset((double) (byte) 10);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=0.2,l=8.0,b=1.0,r=32.0]" + "'", str39.equals("RectangleInsets[t=0.2,l=8.0,b=1.0,r=32.0]"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.2d + "'", double42 == 0.2d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.setRangeCrosshairValue((double) 10);
        xYPlot0.mapDatasetToRangeAxis(9, (-1));
        java.awt.Stroke stroke9 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        java.awt.Paint paint11 = valueMarker9.getLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.util.List list18 = categoryPlot17.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape25 = dateAxis24.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        java.awt.Stroke stroke28 = categoryPlot27.getRangeGridlineStroke();
        categoryPlot27.setAnchorValue((double) 10L, false);
        boolean boolean32 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean35 = categoryPlot27.removeDomainMarker(marker33, layer34);
        categoryPlot17.addDomainMarker(2, categoryMarker21, layer34);
        boolean boolean37 = xYPlot0.removeRangeMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker9, layer34);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke41 = valueMarker40.getOutlineStroke();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker40.setOutlinePaint((java.awt.Paint) color42);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color42);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(legendItemCollection38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        java.lang.String str4 = xYPlot0.getNoDataMessage();
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(0, axisLocation4, false);
        xYPlot0.setDomainCrosshairValue((double) (short) 0, false);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.Date date6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setAutoTickUnitSelection(true, false);
        dateAxis7.setVerticalTickLabels(false);
        float float13 = dateAxis7.getTickMarkInsideLength();
        java.lang.String str14 = dateAxis7.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis7.getTickUnit();
        java.util.Date date16 = dateAxis7.getMinimumDate();
        try {
            dateAxis2.setRange(date6, date16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setRangeAxisLocation(1, axisLocation5, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot3.getFixedDomainAxisSpace();
        java.awt.Stroke stroke9 = categoryPlot3.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke16 = valueMarker15.getOutlineStroke();
        java.awt.Stroke stroke17 = valueMarker15.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color2, stroke9, (java.awt.Paint) chartColor13, stroke17, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer20);
        java.lang.Object obj22 = intervalMarker19.clone();
        double double23 = intervalMarker19.getStartValue();
        double double24 = intervalMarker19.getEndValue();
        java.lang.Object obj25 = intervalMarker19.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        java.lang.String str8 = dateAxis1.getLabel();
        boolean boolean9 = dateAxis1.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean23 = categoryPlot15.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot15.setRangeCrosshairStroke(stroke30);
        dateAxis1.setTickMarkStroke(stroke30);
        dateAxis1.resizeRange(0.0d, (double) 2.0f);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis36.setNumberFormatOverride(numberFormat37);
        java.text.NumberFormat numberFormat39 = null;
        numberAxis36.setNumberFormatOverride(numberFormat39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer41);
        java.awt.Stroke stroke43 = numberAxis36.getAxisLineStroke();
        numberAxis36.centerRange((double) 0.0f);
        java.text.NumberFormat numberFormat46 = null;
        numberAxis36.setNumberFormatOverride(numberFormat46);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis0.getTickUnit();
        java.awt.Paint paint9 = dateAxis0.getLabelPaint();
        boolean boolean10 = dateAxis0.isVisible();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        dateAxis0.setMinimumDate(date11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setAutoTickUnitSelection(true, false);
        dateAxis14.setLabel("");
        dateAxis14.setLowerBound((double) (short) 10);
        dateAxis14.setRangeWithMargins((double) 2.0f, (double) '#');
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = dateAxis14.getTickUnit();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition26 = dateAxis14.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition26);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(dateTickMarkPosition26);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        double double12 = dateAxis8.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setAutoTickUnitSelection(true, false);
        dateAxis13.setLabel("");
        java.awt.Paint paint19 = dateAxis13.getAxisLinePaint();
        org.jfree.data.Range range20 = dateAxis13.getRange();
        dateAxis8.setRange(range20, true, false);
        dateAxis0.setRange(range20);
        dateAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot5.getColumnRenderingOrder();
        java.lang.String str31 = sortOrder30.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "SortOrder.ASCENDING" + "'", str31.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setAutoTickUnitSelection(true, false);
        dateAxis2.setLabel("");
        java.awt.Paint paint8 = dateAxis2.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis2.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis0.getTickLabelInsets();
        double double13 = rectangleInsets11.extendWidth(3.0d);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 11.0d + "'", double13 == 11.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot11.setOrientation(plotOrientation15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot11.getDomainAxisLocation(0);
        xYPlot0.setDomainAxisLocation(4, axisLocation18);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(0, axisLocation4, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation7 = null;
        try {
            boolean boolean9 = xYPlot0.removeAnnotation(xYAnnotation7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType1 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setAutoTickUnitSelection(true, false);
        dateAxis2.setVerticalTickLabels(false);
        float float8 = dateAxis2.getTickMarkInsideLength();
        boolean boolean9 = lengthAdjustmentType1.equals((java.lang.Object) dateAxis2);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        categoryPlot15.axisChanged(axisChangeEvent16);
        categoryPlot15.clearRangeAxes();
        boolean boolean19 = lengthAdjustmentType1.equals((java.lang.Object) categoryPlot15);
        boolean boolean20 = textAnchor0.equals((java.lang.Object) categoryPlot15);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(lengthAdjustmentType1);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setAutoTickUnitSelection(true, false);
        dateAxis4.setVerticalTickLabels(false);
        float float10 = dateAxis4.getTickMarkInsideLength();
        boolean boolean11 = lengthAdjustmentType3.equals((java.lang.Object) dateAxis4);
        boolean boolean12 = chartChangeEventType2.equals((java.lang.Object) lengthAdjustmentType3);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = dateAxis15.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        java.util.List list19 = categoryPlot18.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = dateAxis25.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer27);
        java.awt.Stroke stroke29 = categoryPlot28.getRangeGridlineStroke();
        categoryPlot28.setAnchorValue((double) 10L, false);
        boolean boolean33 = categoryPlot28.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean36 = categoryPlot28.removeDomainMarker(marker34, layer35);
        categoryPlot18.addDomainMarker(2, categoryMarker22, layer35);
        categoryMarker22.setDrawAsLine(true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = categoryMarker22.getLabelOffsetType();
        try {
            java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType3, lengthAdjustmentType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(list19);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType40);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis0.java2DToValue(0.0d, rectangle2D17, rectangleEdge18);
        double double20 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Paint paint6 = dateAxis2.getLabelPaint();
        java.awt.Shape shape7 = dateAxis2.getLeftArrow();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot5.setRenderer(2, categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        try {
            categoryPlot5.zoomRangeAxes((double) 'a', plotRenderingInfo16, point2D17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean3 = defaultDrawingSupplier0.equals((java.lang.Object) textAnchor2);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setRangeAxisLocation(1, axisLocation5, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot3.getFixedDomainAxisSpace();
        java.awt.Stroke stroke9 = categoryPlot3.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke16 = valueMarker15.getOutlineStroke();
        java.awt.Stroke stroke17 = valueMarker15.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color2, stroke9, (java.awt.Paint) chartColor13, stroke17, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer20);
        java.lang.Object obj22 = intervalMarker19.clone();
        double double23 = intervalMarker19.getStartValue();
        double double24 = intervalMarker19.getEndValue();
        intervalMarker19.setStartValue((double) 4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.Font font16 = dateAxis0.getLabelFont();
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str18 = unitType17.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(unitType17, 8.0d, 0.2d, (double) 255, (double) 2.0f);
        dateAxis0.setTickLabelInsets(rectangleInsets23);
        double double25 = rectangleInsets23.getTop();
        double double27 = rectangleInsets23.calculateLeftOutset(12.0d);
        double double29 = rectangleInsets23.calculateTopOutset(6.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UnitType.ABSOLUTE" + "'", str18.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 8.0d + "'", double25 == 8.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.0d + "'", double29 == 8.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        xYPlot0.clearRangeMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        numberAxis1.setAutoRangeStickyZero(true);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setDomainGridlinesVisible(false);
        xYPlot5.setDomainGridlinesVisible(false);
        double double10 = xYPlot5.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot16.axisChanged(axisChangeEvent17);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint21 = valueMarker20.getPaint();
        categoryPlot16.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot16.zoomDomainAxes((double) (byte) 10, plotRenderingInfo24, point2D25, false);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint31 = valueMarker30.getPaint();
        double double32 = valueMarker30.getValue();
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker30.setLabelTextAnchor(textAnchor33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape38 = dateAxis37.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        java.awt.Stroke stroke41 = categoryPlot40.getRangeGridlineStroke();
        categoryPlot40.setAnchorValue((double) 10L, false);
        boolean boolean45 = categoryPlot40.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker46 = null;
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean48 = categoryPlot40.removeDomainMarker(marker46, layer47);
        boolean boolean49 = categoryPlot16.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker30, layer47);
        java.util.Collection collection50 = xYPlot5.getRangeMarkers(layer47);
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot5.getDomainAxis((int) (short) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray54 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer53 };
        xYPlot5.setRenderers(xYItemRendererArray54);
        boolean boolean56 = numberAxis1.equals((java.lang.Object) xYPlot5);
        org.jfree.data.RangeType rangeType57 = null;
        try {
            numberAxis1.setRangeType(rangeType57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 10.0d + "'", double32 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(xYItemRendererArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        java.awt.Stroke stroke5 = xYPlot0.getDomainZeroBaselineStroke();
        boolean boolean6 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint11 = valueMarker10.getPaint();
        double double12 = valueMarker10.getValue();
        valueMarker10.setLabel("java.awt.Color[r=255,g=0,b=0]");
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        valueMarker10.setPaint((java.awt.Paint) color15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.awt.Stroke stroke23 = categoryPlot22.getRangeGridlineStroke();
        double double24 = categoryPlot22.getRangeCrosshairValue();
        boolean boolean25 = categoryPlot22.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.setAutoTickUnitSelection(true, false);
        dateAxis27.setLabel("");
        java.awt.Paint paint33 = dateAxis27.getAxisLinePaint();
        double double34 = dateAxis27.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape38 = dateAxis37.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        java.awt.Stroke stroke41 = categoryPlot40.getRangeGridlineStroke();
        dateAxis27.setAxisLineStroke(stroke41);
        dateAxis27.setFixedDimension(0.2d);
        boolean boolean45 = rectangleInsets26.equals((java.lang.Object) dateAxis27);
        categoryPlot22.setInsets(rectangleInsets26, false);
        double double49 = rectangleInsets26.calculateBottomInset(0.0d);
        valueMarker10.setLabelOffset(rectangleInsets26);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation53 = null;
        categoryPlot51.setRangeAxisLocation(1, axisLocation53, false);
        org.jfree.chart.axis.AxisSpace axisSpace56 = categoryPlot51.getFixedDomainAxisSpace();
        categoryPlot51.setRangeCrosshairLockedOnData(false);
        valueMarker10.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot51);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape64 = dateAxis63.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, (org.jfree.chart.axis.ValueAxis) dateAxis63, categoryItemRenderer65);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent67 = null;
        categoryPlot66.axisChanged(axisChangeEvent67);
        categoryPlot66.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace71 = categoryPlot66.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent72 = null;
        categoryPlot66.rendererChanged(rendererChangeEvent72);
        categoryPlot66.mapDatasetToRangeAxis(100, 1);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot66.setDomainAxisLocation(axisLocation77);
        boolean boolean79 = rectangleAnchor60.equals((java.lang.Object) axisLocation77);
        valueMarker10.setLabelAnchor(rectangleAnchor60);
        org.jfree.chart.util.Layer layer81 = null;
        boolean boolean82 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker10, layer81);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 3.0d + "'", double49 == 3.0d);
        org.junit.Assert.assertNull(axisSpace56);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNull(axisSpace71);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        java.awt.Stroke stroke10 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        xYPlot0.setOrientation(plotOrientation15);
        xYPlot0.setRangeCrosshairValue((double) (short) 0, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        try {
            xYPlot0.setRenderer((-1), xYItemRenderer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot5.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot5.getRenderer((-1));
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        double double3 = valueMarker1.getValue();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        valueMarker1.setPaint((java.awt.Paint) color4);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint8 = valueMarker7.getPaint();
        java.awt.Paint paint9 = valueMarker7.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        valueMarker7.setLabelOffset(rectangleInsets10);
        boolean boolean12 = color4.equals((java.lang.Object) valueMarker7);
        java.lang.String str13 = valueMarker7.getLabel();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        boolean boolean17 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setBackgroundAlpha((-1.0f));
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot5.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        double double2 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setAutoTickUnitSelection(true, false);
        dateAxis4.setLabel("");
        java.awt.Paint paint10 = dateAxis4.getAxisLinePaint();
        double double11 = dateAxis4.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.awt.Stroke stroke18 = categoryPlot17.getRangeGridlineStroke();
        dateAxis4.setAxisLineStroke(stroke18);
        dateAxis4.setUpperBound((double) 2);
        xYPlot0.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.lang.String str23 = dateAxis4.getLabelToolTip();
        org.junit.Assert.assertNull(xYItemRenderer1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        org.jfree.chart.axis.ValueAxis valueAxis47 = xYPlot0.getDomainAxis((int) (short) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray49 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer48 };
        xYPlot0.setRenderers(xYItemRendererArray49);
        double double51 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        dateAxis52.setAutoTickUnitSelection(true, false);
        java.awt.Paint paint56 = dateAxis52.getTickMarkPaint();
        dateAxis52.setLabelURL("java.awt.Color[r=0,g=192,b=192]");
        java.awt.Paint paint59 = dateAxis52.getLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource60 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis52.setStandardTickUnits(tickUnitSource60);
        int int62 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis52);
        xYPlot0.setBackgroundImageAlignment((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(xYItemRendererArray49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(tickUnitSource60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.calculateLeftOutset((double) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.util.List list20 = categoryPlot19.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot29.setAnchorValue((double) 10L, false);
        boolean boolean34 = categoryPlot29.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean37 = categoryPlot29.removeDomainMarker(marker35, layer36);
        categoryPlot19.addDomainMarker(2, categoryMarker23, layer36);
        categoryMarker23.setDrawAsLine(true);
        org.jfree.chart.util.Layer layer41 = null;
        categoryPlot5.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker23, layer41);
        categoryPlot5.setDrawSharedDomainAxis(false);
        org.jfree.data.category.CategoryDataset categoryDataset46 = categoryPlot5.getDataset(12);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(list20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(categoryDataset46);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        boolean boolean8 = lengthAdjustmentType0.equals((java.lang.Object) dateAxis1);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        categoryPlot14.clearRangeAxes();
        boolean boolean18 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot14);
        boolean boolean20 = lengthAdjustmentType0.equals((java.lang.Object) 0.05d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis0.lengthToJava2D((double) 0L, rectangle2D9, rectangleEdge10);
        dateAxis0.setVerticalTickLabels(false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        dateAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = dateAxis0.getStandardTickUnits();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot14.zoomDomainAxes((double) (byte) 10, plotRenderingInfo22, point2D23, false);
        categoryPlot14.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint29 = defaultDrawingSupplier28.getNextOutlinePaint();
        categoryPlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier28);
        java.awt.Paint paint31 = defaultDrawingSupplier28.getNextFillPaint();
        java.awt.Paint paint32 = defaultDrawingSupplier28.getNextPaint();
        dateAxis0.setTickMarkPaint(paint32);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        dateAxis0.setRangeWithMargins((double) 2.0f, (double) '#');
        double double11 = dateAxis0.getLabelAngle();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setUpperBound(0.0d);
        dateAxis12.setRangeAboutValue((double) 1.0f, (double) 'a');
        org.jfree.data.Range range18 = dateAxis12.getRange();
        dateAxis0.setRange(range18, true, true);
        boolean boolean22 = dateAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        numberAxis1.setAutoRangeStickyZero(true);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setDomainGridlinesVisible(false);
        xYPlot5.setDomainGridlinesVisible(false);
        double double10 = xYPlot5.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot16.axisChanged(axisChangeEvent17);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint21 = valueMarker20.getPaint();
        categoryPlot16.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot16.zoomDomainAxes((double) (byte) 10, plotRenderingInfo24, point2D25, false);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint31 = valueMarker30.getPaint();
        double double32 = valueMarker30.getValue();
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker30.setLabelTextAnchor(textAnchor33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape38 = dateAxis37.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        java.awt.Stroke stroke41 = categoryPlot40.getRangeGridlineStroke();
        categoryPlot40.setAnchorValue((double) 10L, false);
        boolean boolean45 = categoryPlot40.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker46 = null;
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean48 = categoryPlot40.removeDomainMarker(marker46, layer47);
        boolean boolean49 = categoryPlot16.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker30, layer47);
        java.util.Collection collection50 = xYPlot5.getRangeMarkers(layer47);
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot5.getDomainAxis((int) (short) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray54 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer53 };
        xYPlot5.setRenderers(xYItemRendererArray54);
        boolean boolean56 = numberAxis1.equals((java.lang.Object) xYPlot5);
        java.lang.Object obj57 = numberAxis1.clone();
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 10.0d + "'", double32 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(xYItemRendererArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(obj57);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Font font3 = numberAxis1.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot5.getDomainAxis();
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        java.util.List list21 = categoryPlot20.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape28 = dateAxis27.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer29);
        java.awt.Stroke stroke31 = categoryPlot30.getRangeGridlineStroke();
        categoryPlot30.setAnchorValue((double) 10L, false);
        boolean boolean35 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean38 = categoryPlot30.removeDomainMarker(marker36, layer37);
        categoryPlot20.addDomainMarker(2, categoryMarker24, layer37);
        boolean boolean40 = categoryPlot5.removeDomainMarker(marker14, layer37);
        categoryPlot5.zoom((double) 13);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(list21);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot5.setRangeAxisLocation(255, axisLocation14, false);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.Point2D point2D19 = null;
        org.jfree.chart.plot.PlotState plotState20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            categoryPlot5.draw(graphics2D17, rectangle2D18, point2D19, plotState20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 2);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Font font9 = dateAxis5.getTickLabelFont();
        categoryAxis0.setLabelFont(font9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.awt.Stroke stroke20 = categoryPlot19.getRangeGridlineStroke();
        java.awt.Stroke stroke21 = categoryPlot19.getRangeGridlineStroke();
        categoryPlot19.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot19.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation25, plotOrientation26);
        try {
            java.util.List list28 = categoryAxis0.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        boolean boolean17 = categoryPlot5.isDomainZoomable();
        categoryPlot5.setBackgroundAlpha((-1.0f));
        java.awt.Paint paint20 = null;
        categoryPlot5.setOutlinePaint(paint20);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setCategoryMargin((double) 11);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("13-June-2019");
        dateAxis5.resizeRange(1.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        java.util.List list10 = categoryPlot9.getCategories();
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        java.awt.Stroke stroke10 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        xYPlot0.setOrientation(plotOrientation15);
        xYPlot0.mapDatasetToRangeAxis(13, 6);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(500, axisLocation22, false);
        boolean boolean25 = xYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        java.awt.Paint paint17 = categoryPlot5.getBackgroundPaint();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        categoryPlot5.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        java.lang.String str8 = dateAxis1.getLabel();
        boolean boolean9 = dateAxis1.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean23 = categoryPlot15.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot15.setRangeCrosshairStroke(stroke30);
        dateAxis1.setTickMarkStroke(stroke30);
        dateAxis1.resizeRange(0.0d, (double) 2.0f);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis36.setNumberFormatOverride(numberFormat37);
        java.text.NumberFormat numberFormat39 = null;
        numberAxis36.setNumberFormatOverride(numberFormat39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer41);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation43 = null;
        try {
            xYPlot42.addAnnotation(xYAnnotation43, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        xYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot8.axisChanged(axisChangeEvent9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot8.zoomDomainAxes((double) (byte) 10, plotRenderingInfo16, point2D17, false);
        categoryPlot8.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        java.awt.Paint paint25 = defaultDrawingSupplier22.getNextFillPaint();
        java.awt.Paint paint26 = defaultDrawingSupplier22.getNextPaint();
        java.awt.Paint paint27 = defaultDrawingSupplier22.getNextPaint();
        xYPlot0.setDomainGridlinePaint(paint27);
        org.jfree.data.xy.XYDataset xYDataset29 = xYPlot0.getDataset();
        java.awt.Color color31 = java.awt.Color.DARK_GRAY;
        java.awt.Color color32 = java.awt.Color.getColor("java.awt.Color[r=0,g=192,b=192]", color31);
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(xYDataset29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setAutoTickUnitSelection(true, false);
        dateAxis4.setLabel("");
        java.awt.Paint paint10 = dateAxis4.getAxisLinePaint();
        double double11 = dateAxis4.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.awt.Stroke stroke18 = categoryPlot17.getRangeGridlineStroke();
        dateAxis4.setAxisLineStroke(stroke18);
        dateAxis4.setFixedDimension(0.2d);
        double double22 = dateAxis4.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis4.getStandardTickUnits();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis4.setTimeZone(timeZone24);
        org.jfree.data.Range range26 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(valueAxis27);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection50 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
        org.junit.Assert.assertNull(valueAxis49);
        org.junit.Assert.assertNull(legendItemCollection50);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        categoryPlot5.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (byte) -1);
        double double3 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        java.awt.Stroke stroke10 = categoryPlot5.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        xYPlot0.setDomainGridlinesVisible(false);
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.util.List list50 = null;
        xYPlot0.drawRangeTickBands(graphics2D48, rectangle2D49, list50);
        xYPlot0.setRangeCrosshairValue((double) (short) 1, false);
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot55.getRangeAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot55.setDomainAxisLocation(0, axisLocation59, false);
        xYPlot0.setRangeAxisLocation(axisLocation59, true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(axisLocation59);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) 6);
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.0d + "'", double2 == 12.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        java.awt.Stroke stroke10 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        xYPlot0.setOrientation(plotOrientation15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        categoryPlot23.axisChanged(axisChangeEvent24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot23.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot23.zoomDomainAxes((double) (-1L), plotRenderingInfo29, point2D30, false);
        categoryPlot23.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot23.getRangeAxisEdge();
        categoryPlot23.setForegroundAlpha((float) (short) 1);
        float float38 = categoryPlot23.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape42 = dateAxis41.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis41, categoryItemRenderer43);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent45 = null;
        categoryPlot44.axisChanged(axisChangeEvent45);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint49 = valueMarker48.getPaint();
        categoryPlot44.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker48);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor51 = categoryPlot44.getDomainGridlinePosition();
        java.lang.String str52 = categoryAnchor51.toString();
        categoryPlot23.setDomainGridlinePosition(categoryAnchor51);
        categoryPlot23.setDrawSharedDomainAxis(false);
        java.awt.Color color56 = java.awt.Color.RED;
        java.awt.Color color57 = color56.brighter();
        int int58 = color57.getRed();
        java.awt.Color color59 = java.awt.Color.RED;
        java.awt.Color color60 = java.awt.Color.orange;
        float[] floatArray61 = null;
        float[] floatArray62 = color60.getComponents(floatArray61);
        float[] floatArray63 = color59.getRGBColorComponents(floatArray62);
        float[] floatArray64 = color57.getColorComponents(floatArray63);
        categoryPlot23.setOutlinePaint((java.awt.Paint) color57);
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color57);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(categoryAnchor51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str52.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 255 + "'", int58 == 255);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray64);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        boolean boolean10 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setAutoTickUnitSelection(true, false);
        dateAxis14.setVerticalTickLabels(false);
        float float20 = dateAxis14.getTickMarkInsideLength();
        boolean boolean21 = lengthAdjustmentType13.equals((java.lang.Object) dateAxis14);
        boolean boolean22 = chartChangeEventType12.equals((java.lang.Object) lengthAdjustmentType13);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot5, jFreeChart11, chartChangeEventType12);
        int int24 = categoryPlot5.getRangeAxisCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray5 = null;
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray4, strokeArray5, strokeArray6, shapeArray7);
        java.awt.Stroke[] strokeArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        java.awt.Paint paint17 = dateAxis13.getLabelPaint();
        java.awt.Shape shape18 = dateAxis13.getLeftArrow();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = dateAxis21.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = null;
        categoryPlot24.axisChanged(axisChangeEvent25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot24.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = dateAxis31.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeGridlineStroke();
        categoryPlot34.setAnchorValue((double) 10L, false);
        boolean boolean39 = categoryPlot34.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        categoryPlot34.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis40);
        java.lang.String str42 = dateAxis40.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint45 = valueMarker44.getPaint();
        dateAxis40.setLabelPaint(paint45);
        java.awt.Shape shape47 = dateAxis40.getLeftArrow();
        categoryPlot24.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis40);
        java.awt.Shape shape49 = dateAxis40.getUpArrow();
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] { shape10, shape18, shape49 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray5, strokeArray9, shapeArray50);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(shapeArray50);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = categoryPlot15.removeDomainMarker(marker21, layer22);
        categoryPlot5.addDomainMarker(2, categoryMarker9, layer22);
        categoryMarker9.setDrawAsLine(true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = categoryMarker9.getLabelOffsetType();
        java.lang.String str28 = lengthAdjustmentType27.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "EXPAND" + "'", str28.equals("EXPAND"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot5.setDataset(categoryDataset13);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        boolean boolean6 = xYPlot0.isDomainCrosshairLockedOnData();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        xYPlot0.clearRangeMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer14, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        xYPlot0.setRenderer(0, xYItemRenderer18);
        boolean boolean20 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        java.awt.Stroke stroke5 = xYPlot0.getDomainZeroBaselineStroke();
        boolean boolean6 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setAutoTickUnitSelection(true, false);
        dateAxis8.setLabel("");
        dateAxis8.setLowerBound((double) (short) 10);
        dateAxis8.setRangeWithMargins((double) 2.0f, (double) '#');
        double double19 = dateAxis8.getLabelAngle();
        java.text.DateFormat dateFormat20 = dateAxis8.getDateFormatOverride();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        float float22 = dateAxis8.getTickMarkInsideLength();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(dateFormat20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot5.setNoDataMessageFont(font15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color17);
        java.awt.Color color19 = color17.darker();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        numberAxis1.setAutoRangeStickyZero(true);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setDomainGridlinesVisible(false);
        xYPlot5.setDomainGridlinesVisible(false);
        double double10 = xYPlot5.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot16.axisChanged(axisChangeEvent17);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint21 = valueMarker20.getPaint();
        categoryPlot16.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot16.zoomDomainAxes((double) (byte) 10, plotRenderingInfo24, point2D25, false);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint31 = valueMarker30.getPaint();
        double double32 = valueMarker30.getValue();
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker30.setLabelTextAnchor(textAnchor33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape38 = dateAxis37.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        java.awt.Stroke stroke41 = categoryPlot40.getRangeGridlineStroke();
        categoryPlot40.setAnchorValue((double) 10L, false);
        boolean boolean45 = categoryPlot40.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker46 = null;
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean48 = categoryPlot40.removeDomainMarker(marker46, layer47);
        boolean boolean49 = categoryPlot16.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker30, layer47);
        java.util.Collection collection50 = xYPlot5.getRangeMarkers(layer47);
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot5.getDomainAxis((int) (short) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray54 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer53 };
        xYPlot5.setRenderers(xYItemRendererArray54);
        boolean boolean56 = numberAxis1.equals((java.lang.Object) xYPlot5);
        double double57 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 10.0d + "'", double32 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(xYItemRendererArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = color0.brighter();
        int int2 = color1.getRGB();
        java.awt.Color color5 = java.awt.Color.getColor("", (int) (short) 0);
        java.awt.Color color6 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint11 = valueMarker10.getPaint();
        double double12 = valueMarker10.getValue();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_RED;
        valueMarker10.setPaint((java.awt.Paint) color13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        java.util.List list21 = categoryPlot20.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape28 = dateAxis27.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer29);
        java.awt.Stroke stroke31 = categoryPlot30.getRangeGridlineStroke();
        categoryPlot30.setAnchorValue((double) 10L, false);
        boolean boolean35 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean38 = categoryPlot30.removeDomainMarker(marker36, layer37);
        categoryPlot20.addDomainMarker(2, categoryMarker24, layer37);
        categoryMarker24.setDrawAsLine(true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int43 = color42.getBlue();
        int int44 = color42.getAlpha();
        categoryMarker24.setOutlinePaint((java.awt.Paint) color42);
        java.awt.Color color49 = java.awt.Color.RED;
        java.awt.Color color50 = color49.brighter();
        int int51 = color50.getRed();
        java.awt.Color color52 = java.awt.Color.RED;
        java.awt.Color color53 = java.awt.Color.orange;
        float[] floatArray54 = null;
        float[] floatArray55 = color53.getComponents(floatArray54);
        float[] floatArray56 = color52.getRGBColorComponents(floatArray55);
        float[] floatArray57 = color50.getColorComponents(floatArray56);
        float[] floatArray58 = java.awt.Color.RGBtoHSB(8, 0, 7, floatArray57);
        float[] floatArray59 = color42.getRGBColorComponents(floatArray57);
        float[] floatArray60 = color13.getRGBColorComponents(floatArray59);
        float[] floatArray61 = color8.getRGBColorComponents(floatArray60);
        float[] floatArray62 = color5.getComponents(colorSpace7, floatArray61);
        java.awt.Color color63 = java.awt.Color.RED;
        java.awt.Color color64 = java.awt.Color.orange;
        float[] floatArray65 = null;
        float[] floatArray66 = color64.getComponents(floatArray65);
        float[] floatArray67 = color63.getRGBColorComponents(floatArray66);
        float[] floatArray68 = color1.getComponents(colorSpace7, floatArray67);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(list21);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 255 + "'", int44 == 255);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 255 + "'", int51 == 255);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        boolean boolean8 = lengthAdjustmentType0.equals((java.lang.Object) dateAxis1);
        double double9 = dateAxis1.getFixedAutoRange();
        dateAxis1.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis1.getLabelInsets();
        dateAxis1.setFixedDimension((double) '4');
        double double14 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.lang.String str13 = dateAxis11.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        dateAxis11.setLabelPaint(paint16);
        java.awt.Shape shape18 = dateAxis11.getLeftArrow();
        java.awt.Shape shape19 = dateAxis11.getLeftArrow();
        org.jfree.chart.axis.Timeline timeline20 = dateAxis11.getTimeline();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(timeline20);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke13 = valueMarker12.getOutlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker12.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker12.setLabelPaint((java.awt.Paint) color16);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker12, jFreeChart19);
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 10, jFreeChart22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean26 = chartChangeEventType24.equals((java.lang.Object) (short) 1);
        chartChangeEvent23.setType(chartChangeEventType24);
        org.jfree.chart.util.UnitType unitType28 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str29 = unitType28.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType28, 8.0d, 0.2d, (double) 255, (double) 2.0f);
        java.lang.String str35 = unitType28.toString();
        java.lang.String str36 = unitType28.toString();
        boolean boolean37 = chartChangeEventType24.equals((java.lang.Object) str36);
        chartChangeEvent20.setType(chartChangeEventType24);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(unitType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnitType.ABSOLUTE" + "'", str29.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "UnitType.ABSOLUTE" + "'", str35.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnitType.ABSOLUTE" + "'", str36.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        boolean boolean13 = categoryPlot5.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.awt.Stroke stroke20 = categoryPlot19.getRangeGridlineStroke();
        categoryPlot5.setRangeCrosshairStroke(stroke20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        try {
            categoryPlot5.setDataset((-1), categoryDataset23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("RectangleInsets[t=0.2,l=8.0,b=1.0,r=32.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        java.awt.Stroke stroke13 = categoryPlot12.getRangeGridlineStroke();
        categoryPlot12.setAnchorValue((double) 10L, false);
        boolean boolean17 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        categoryPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setAutoTickUnitSelection(true, false);
        dateAxis20.setLabel("");
        dateAxis20.setLowerBound((double) (short) 10);
        org.jfree.data.Range range28 = dateAxis20.getDefaultAutoRange();
        dateAxis18.setRange(range28);
        dateAxis2.setRange(range28);
        boolean boolean31 = dateAxis2.isInverted();
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setDownArrow(shape32);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        int int12 = categoryPlot5.getDomainAxisCount();
        categoryPlot5.setBackgroundImageAlignment(1);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        java.awt.Stroke stroke21 = categoryPlot20.getRangeGridlineStroke();
        java.awt.Stroke stroke22 = categoryPlot20.getRangeGridlineStroke();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot20.getRowRenderingOrder();
        categoryPlot5.setColumnRenderingOrder(sortOrder23);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(sortOrder23);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setRangeAxisLocation(1, axisLocation5, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot3.getFixedDomainAxisSpace();
        java.awt.Stroke stroke9 = categoryPlot3.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke16 = valueMarker15.getOutlineStroke();
        java.awt.Stroke stroke17 = valueMarker15.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color2, stroke9, (java.awt.Paint) chartColor13, stroke17, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer20);
        java.lang.Object obj22 = intervalMarker19.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer23);
        org.jfree.chart.text.TextAnchor textAnchor25 = intervalMarker19.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation();
        java.lang.String str5 = axisLocation4.toString();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str5.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }
}

