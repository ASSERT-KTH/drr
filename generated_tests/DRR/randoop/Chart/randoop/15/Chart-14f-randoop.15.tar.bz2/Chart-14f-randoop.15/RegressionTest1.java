import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str1 = rectangleInsets0.toString();
        java.lang.String str2 = rectangleInsets0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str2.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        dateAxis0.setLabelAngle((double) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        categoryPlot15.axisChanged(axisChangeEvent16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot15.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = dateAxis22.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getRangeGridlineStroke();
        categoryPlot25.setAnchorValue((double) 10L, false);
        boolean boolean30 = categoryPlot25.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        java.lang.String str33 = dateAxis31.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint36 = valueMarker35.getPaint();
        dateAxis31.setLabelPaint(paint36);
        java.awt.Shape shape38 = dateAxis31.getLeftArrow();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        java.awt.Shape shape40 = dateAxis31.getUpArrow();
        dateAxis0.setLeftArrow(shape40);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(shape40);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace13 = xYPlot10.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot10.getOrientation();
        categoryPlot5.setOrientation(plotOrientation14);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(plotOrientation14);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str1.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = dateAxis4.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        categoryPlot7.axisChanged(axisChangeEvent8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot16.axisChanged(axisChangeEvent17);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint21 = valueMarker20.getPaint();
        categoryPlot16.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean24 = categoryPlot7.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker20, layer23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryPlot7.getAxisOffset();
        valueMarker1.setLabelOffset(rectangleInsets25);
        valueMarker1.setAlpha((float) 0L);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Color color2 = java.awt.Color.getColor("", 12);
        java.awt.Color color3 = color2.brighter();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation(1, axisLocation2, false);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        java.lang.Object obj3 = objectList1.get((-1));
        java.lang.Object obj4 = objectList1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot10.axisChanged(axisChangeEvent11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot10.getRenderer(8);
        boolean boolean15 = categoryPlot10.isDomainZoomable();
        java.awt.Stroke stroke16 = categoryPlot10.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        java.awt.Stroke stroke24 = categoryPlot23.getRangeGridlineStroke();
        categoryPlot23.setAnchorValue((double) 10L, false);
        boolean boolean28 = categoryPlot23.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean31 = categoryPlot23.removeDomainMarker(marker29, layer30);
        java.util.Collection collection32 = categoryPlot10.getDomainMarkers((int) (byte) 1, layer30);
        int int33 = objectList1.indexOf((java.lang.Object) (byte) 1);
        int int34 = objectList1.size();
        objectList1.clear();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        dateAxis0.setVerticalTickLabels(false);
        dateAxis0.setTickLabelsVisible(true);
        java.awt.Stroke stroke12 = dateAxis0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot20.axisChanged(axisChangeEvent21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = null;
        categoryPlot29.axisChanged(axisChangeEvent30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint34 = valueMarker33.getPaint();
        categoryPlot29.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean37 = categoryPlot20.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker33, layer36);
        java.awt.Paint paint38 = valueMarker33.getPaint();
        boolean boolean39 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        boolean boolean8 = lengthAdjustmentType0.equals((java.lang.Object) dateAxis1);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        categoryPlot14.clearRangeAxes();
        boolean boolean18 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot14);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = dateAxis21.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getRangeGridlineStroke();
        categoryPlot24.setAnchorValue((double) 10L, false);
        boolean boolean29 = categoryPlot24.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot24.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint32 = categoryPlot24.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot24.setInsets(rectangleInsets33, false);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape39 = dateAxis38.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer40);
        java.util.List list42 = categoryPlot41.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape49 = dateAxis48.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis48, categoryItemRenderer50);
        java.awt.Stroke stroke52 = categoryPlot51.getRangeGridlineStroke();
        categoryPlot51.setAnchorValue((double) 10L, false);
        boolean boolean56 = categoryPlot51.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker57 = null;
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = categoryPlot51.removeDomainMarker(marker57, layer58);
        categoryPlot41.addDomainMarker(2, categoryMarker45, layer58);
        categoryPlot41.clearRangeMarkers(255);
        double double63 = categoryPlot41.getRangeCrosshairValue();
        categoryPlot24.setParent((org.jfree.chart.plot.Plot) categoryPlot41);
        org.jfree.chart.util.Layer layer65 = null;
        java.util.Collection collection66 = categoryPlot24.getDomainMarkers(layer65);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent67 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot24);
        categoryPlot14.notifyListeners(plotChangeEvent67);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(list42);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNull(collection66);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.lang.Object obj6 = dateAxis0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setAutoTickUnitSelection(true, false);
        dateAxis8.setLabel("");
        java.awt.Paint paint14 = dateAxis8.getAxisLinePaint();
        double double15 = dateAxis8.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = dateAxis18.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        java.awt.Stroke stroke22 = categoryPlot21.getRangeGridlineStroke();
        dateAxis8.setAxisLineStroke(stroke22);
        dateAxis8.setFixedDimension(0.2d);
        boolean boolean26 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        double double28 = rectangleInsets7.calculateLeftOutset((double) '4');
        dateAxis0.setTickLabelInsets(rectangleInsets7);
        double double30 = dateAxis0.getUpperBound();
        dateAxis0.setLabelURL("AxisLocation.TOP_OR_LEFT");
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape10 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        java.awt.Stroke stroke13 = categoryPlot12.getRangeGridlineStroke();
        double double14 = categoryPlot12.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot12.zoomDomainAxes((double) 255, plotRenderingInfo16, point2D17);
        int int19 = categoryPlot12.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot12.getRangeAxisEdge();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape25 = dateAxis24.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        java.awt.Stroke stroke28 = categoryPlot27.getRangeGridlineStroke();
        java.awt.Stroke stroke29 = categoryPlot27.getRangeGridlineStroke();
        categoryPlot27.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot27.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation33, plotOrientation34);
        categoryPlot5.setRangeAxisLocation(axisLocation33);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setAutoTickUnitSelection(true, false);
        dateAxis2.setLabel("");
        java.awt.Paint paint8 = dateAxis2.getAxisLinePaint();
        double double9 = dateAxis2.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        dateAxis2.setAxisLineStroke(stroke16);
        java.awt.Font font18 = dateAxis2.getLabelFont();
        org.jfree.chart.util.UnitType unitType19 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str20 = unitType19.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets(unitType19, 8.0d, 0.2d, (double) 255, (double) 2.0f);
        dateAxis2.setTickLabelInsets(rectangleInsets25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer27);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnitType.ABSOLUTE" + "'", str20.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis0.java2DToValue(0.0d, rectangle2D17, rectangleEdge18);
        dateAxis0.setVisible(true);
        dateAxis0.centerRange((double) 4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color3 = java.awt.Color.black;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 1560409200000L, (java.awt.Paint) color3);
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color3.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setAutoTickUnitSelection(true, false);
        dateAxis11.setLabel("");
        java.awt.Paint paint17 = dateAxis11.getAxisLinePaint();
        java.awt.Stroke stroke18 = dateAxis11.getAxisLineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT", (java.awt.Paint) color3, stroke18);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        java.awt.Stroke stroke7 = categoryPlot5.getRangeGridlineStroke();
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot5.getRowRenderingOrder();
        boolean boolean9 = categoryPlot5.isOutlineVisible();
        java.awt.Color color10 = java.awt.Color.BLACK;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        java.awt.Paint paint4 = dateAxis0.getTickMarkPaint();
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6);
        dateAxis0.setMinimumDate(date6);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint13 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets14, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.util.List list23 = categoryPlot22.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = dateAxis29.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer31);
        java.awt.Stroke stroke33 = categoryPlot32.getRangeGridlineStroke();
        categoryPlot32.setAnchorValue((double) 10L, false);
        boolean boolean37 = categoryPlot32.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean40 = categoryPlot32.removeDomainMarker(marker38, layer39);
        categoryPlot22.addDomainMarker(2, categoryMarker26, layer39);
        categoryPlot22.clearRangeMarkers(255);
        double double44 = categoryPlot22.getRangeCrosshairValue();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot5.getDomainMarkers(layer46);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(list23);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNull(collection47);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        xYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot8.axisChanged(axisChangeEvent9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot8.zoomDomainAxes((double) (byte) 10, plotRenderingInfo16, point2D17, false);
        categoryPlot8.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        java.awt.Paint paint25 = defaultDrawingSupplier22.getNextFillPaint();
        java.awt.Paint paint26 = defaultDrawingSupplier22.getNextPaint();
        java.awt.Paint paint27 = defaultDrawingSupplier22.getNextPaint();
        xYPlot0.setDomainGridlinePaint(paint27);
        org.jfree.data.xy.XYDataset xYDataset29 = xYPlot0.getDataset();
        java.awt.Stroke stroke30 = xYPlot0.getOutlineStroke();
        xYPlot0.setRangeCrosshairValue((double) 43629L, true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(xYDataset29);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot5.setNoDataMessageFont(font15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double25 = rectangleInsets24.getLeft();
        double double26 = rectangleInsets24.getBottom();
        boolean boolean27 = categoryPlot5.equals((java.lang.Object) double26);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 8.0d + "'", double25 == 8.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean10 = categoryMarker9.getDrawAsLine();
        categoryPlot5.addDomainMarker(categoryMarker9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot5.getRendererForDataset(categoryDataset12);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryItemRenderer13);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 2);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Font font9 = dateAxis5.getTickLabelFont();
        categoryAxis0.setLabelFont(font9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace17 = xYPlot14.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = xYPlot14.getOrientation();
        java.awt.Stroke stroke19 = xYPlot14.getDomainZeroBaselineStroke();
        boolean boolean20 = xYPlot14.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot14.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation22);
        try {
            double double24 = categoryAxis0.getCategoryStart((int) '#', 4, rectangle2D13, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType0, 8.0d, 0.2d, (double) 255, (double) 2.0f);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setAutoTickUnitSelection(true, false);
        dateAxis8.setVerticalTickLabels(false);
        float float14 = dateAxis8.getTickMarkInsideLength();
        boolean boolean15 = lengthAdjustmentType7.equals((java.lang.Object) dateAxis8);
        boolean boolean16 = unitType0.equals((java.lang.Object) boolean15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.setAutoTickUnitSelection(true, false);
        dateAxis17.setVerticalTickLabels(false);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape26 = dateAxis25.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer27);
        double double29 = dateAxis25.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        dateAxis30.setAutoTickUnitSelection(true, false);
        dateAxis30.setLabel("");
        java.awt.Paint paint36 = dateAxis30.getAxisLinePaint();
        org.jfree.data.Range range37 = dateAxis30.getRange();
        dateAxis25.setRange(range37, true, false);
        dateAxis17.setRange(range37);
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis17.setTickUnit(dateTickUnit42, false, false);
        boolean boolean46 = unitType0.equals((java.lang.Object) dateAxis17);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(dateTickUnit42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        java.lang.String str8 = dateAxis1.getLabel();
        boolean boolean9 = dateAxis1.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean23 = categoryPlot15.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot15.setRangeCrosshairStroke(stroke30);
        dateAxis1.setTickMarkStroke(stroke30);
        dateAxis1.resizeRange(0.0d, (double) 2.0f);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis36.setNumberFormatOverride(numberFormat37);
        java.text.NumberFormat numberFormat39 = null;
        numberAxis36.setNumberFormatOverride(numberFormat39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer41);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder43 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot42.setSeriesRenderingOrder(seriesRenderingOrder43);
        xYPlot42.setDomainGridlinesVisible(true);
        xYPlot42.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder43);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setUpperBound(0.0d);
        java.awt.Color color3 = java.awt.Color.orange;
        float[] floatArray4 = null;
        float[] floatArray5 = color3.getComponents(floatArray4);
        dateAxis0.setTickMarkPaint((java.awt.Paint) color3);
        java.util.Date date7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot9.setRangeAxisLocation(1, axisLocation11, false);
        int int14 = categoryPlot9.getDatasetCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot9.getRangeAxisEdge(6);
        try {
            double double17 = dateAxis0.dateToJava2D(date7, rectangle2D8, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        boolean boolean8 = dateAxis0.isNegativeArrowVisible();
        java.util.Date date9 = dateAxis0.getMinimumDate();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.clearRangeAxes();
        java.awt.Paint paint9 = categoryPlot5.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.Object obj1 = null;
        boolean boolean2 = seriesRenderingOrder0.equals(obj1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint4 = defaultDrawingSupplier3.getNextOutlinePaint();
        boolean boolean5 = seriesRenderingOrder0.equals((java.lang.Object) defaultDrawingSupplier3);
        java.awt.Shape shape6 = defaultDrawingSupplier3.getNextShape();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        java.awt.Stroke stroke10 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        xYPlot0.setOrientation(plotOrientation15);
        java.awt.Paint paint18 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = dateAxis23.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = null;
        categoryPlot26.axisChanged(axisChangeEvent27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot26.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot26.zoomDomainAxes((double) (-1L), plotRenderingInfo32, point2D33, false);
        categoryPlot26.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot26.getRangeAxisEdge();
        boolean boolean39 = rectangleAnchor20.equals((java.lang.Object) categoryPlot26);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape44 = dateAxis43.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis43, categoryItemRenderer45);
        java.awt.Stroke stroke47 = categoryPlot46.getRangeGridlineStroke();
        categoryPlot46.setAnchorValue((double) 10L, false);
        boolean boolean51 = categoryPlot46.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker52 = null;
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean54 = categoryPlot46.removeDomainMarker(marker52, layer53);
        java.util.Collection collection55 = categoryPlot26.getDomainMarkers((int) '4', layer53);
        try {
            boolean boolean56 = xYPlot0.removeRangeMarker(marker19, layer53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(collection55);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean3 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            xYPlot0.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        double double30 = dateAxis21.getFixedDimension();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot5.getRenderer(0);
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot5.setRenderer(categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot5.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setAutoTickUnitSelection(true, false);
        dateAxis7.setLabel("");
        java.awt.Paint paint13 = dateAxis7.getAxisLinePaint();
        org.jfree.data.Range range14 = dateAxis7.getRange();
        dateAxis2.setRange(range14, true, false);
        dateAxis2.setLabelURL("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        xYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) 9, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getRangeGridlineStroke();
        double double16 = categoryPlot14.getRangeCrosshairValue();
        boolean boolean17 = categoryPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        boolean boolean22 = categoryPlot14.render(graphics2D18, rectangle2D19, (int) (short) 10, plotRenderingInfo21);
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot14.setRenderer(categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str28 = axisLocation27.toString();
        categoryPlot14.setDomainAxisLocation(axisLocation27);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = dateAxis33.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = null;
        categoryPlot36.axisChanged(axisChangeEvent37);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint41 = valueMarker40.getPaint();
        categoryPlot36.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot36.zoomDomainAxes((double) (byte) 10, plotRenderingInfo44, point2D45, false);
        categoryPlot36.setOutlineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot36.setDomainAxisLocation(10, axisLocation51, true);
        categoryPlot14.setDomainAxisLocation(0, axisLocation51, false);
        xYPlot0.setDomainAxisLocation((int) '#', axisLocation51, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation58 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation58, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str28.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(axisLocation51);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        numberAxis1.zoomRange((double) 0L, (double) 10);
        numberAxis1.configure();
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot5.removeChangeListener(plotChangeListener10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        categoryPlot5.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection17 = categoryPlot5.getDomainMarkers(8, layer16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier18);
        java.awt.Stroke stroke21 = defaultDrawingSupplier18.getNextStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        boolean boolean3 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setFixedAutoRange((double) '#');
        org.jfree.data.Range range6 = numberAxis0.getDefaultAutoRange();
        boolean boolean7 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 15);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot6.getOrientation();
        java.awt.Stroke stroke11 = xYPlot6.getDomainZeroBaselineStroke();
        boolean boolean12 = xYPlot6.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot6.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        try {
            double double16 = categoryAxis0.getCategoryEnd((-1), 15, rectangle2D5, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(0, axisLocation4, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean9 = categoryMarker8.getDrawAsLine();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot16.axisChanged(axisChangeEvent17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot16.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot16.zoomDomainAxes((double) (-1L), plotRenderingInfo22, point2D23, false);
        categoryPlot16.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot16.getRangeAxisEdge();
        boolean boolean29 = rectangleAnchor10.equals((java.lang.Object) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = dateAxis33.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        java.awt.Stroke stroke37 = categoryPlot36.getRangeGridlineStroke();
        categoryPlot36.setAnchorValue((double) 10L, false);
        boolean boolean41 = categoryPlot36.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker42 = null;
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean44 = categoryPlot36.removeDomainMarker(marker42, layer43);
        java.util.Collection collection45 = categoryPlot16.getDomainMarkers((int) '4', layer43);
        boolean boolean46 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer43);
        java.awt.Stroke stroke47 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.util.List list16 = categoryPlot15.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = dateAxis22.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getRangeGridlineStroke();
        categoryPlot25.setAnchorValue((double) 10L, false);
        boolean boolean30 = categoryPlot25.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker31 = null;
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean33 = categoryPlot25.removeDomainMarker(marker31, layer32);
        categoryPlot15.addDomainMarker(2, categoryMarker19, layer32);
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection36);
        categoryPlot5.clearAnnotations();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(list16);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        java.awt.Stroke stroke10 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        xYPlot0.setOrientation(plotOrientation15);
        java.awt.Paint paint18 = xYPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = dateAxis21.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getRangeGridlineStroke();
        categoryPlot24.setAnchorValue((double) 10L, false);
        boolean boolean29 = categoryPlot24.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot24.getRangeAxis((int) (byte) 100);
        boolean boolean32 = xYPlot0.equals((java.lang.Object) valueAxis31);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        java.awt.Stroke stroke10 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        xYPlot0.setOrientation(plotOrientation15);
        xYPlot0.setRangeCrosshairValue((double) (short) 0, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            xYPlot0.handleClick((int) 'a', (int) (byte) 10, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextFillPaint();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot8.axisChanged(axisChangeEvent9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot8.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot8.zoomDomainAxes((double) (-1L), plotRenderingInfo14, point2D15, false);
        categoryPlot8.setAnchorValue((double) 0);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke22 = valueMarker21.getOutlineStroke();
        categoryPlot8.setRangeGridlineStroke(stroke22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        dateAxis24.setAutoTickUnitSelection(true, false);
        dateAxis24.setLabel("");
        java.lang.Object obj30 = dateAxis24.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        dateAxis32.setAutoTickUnitSelection(true, false);
        dateAxis32.setLabel("");
        java.awt.Paint paint38 = dateAxis32.getAxisLinePaint();
        double double39 = dateAxis32.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape43 = dateAxis42.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer44);
        java.awt.Stroke stroke46 = categoryPlot45.getRangeGridlineStroke();
        dateAxis32.setAxisLineStroke(stroke46);
        dateAxis32.setFixedDimension(0.2d);
        boolean boolean50 = rectangleInsets31.equals((java.lang.Object) dateAxis32);
        double double52 = rectangleInsets31.calculateLeftOutset((double) '4');
        dateAxis24.setTickLabelInsets(rectangleInsets31);
        dateAxis24.zoomRange((double) 1L, 1.0d);
        boolean boolean57 = categoryPlot8.equals((java.lang.Object) 1L);
        boolean boolean58 = defaultDrawingSupplier0.equals((java.lang.Object) categoryPlot8);
        java.awt.Stroke stroke59 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.0d + "'", double52 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.setRangeCrosshairValue((double) 10);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setAutoTickUnitSelection(true, false);
        dateAxis6.setVerticalTickLabels(false);
        float float12 = dateAxis6.getTickMarkInsideLength();
        java.lang.String str13 = dateAxis6.getLabel();
        boolean boolean14 = dateAxis6.isAutoRange();
        dateAxis6.setLabel("org.jfree.chart.event.ChartChangeEvent[source=10]");
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot0.getFixedLegendItems();
        float float19 = xYPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        java.awt.Stroke stroke5 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getRangeAxis((-12517377));
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        categoryPlot13.axisChanged(axisChangeEvent14);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        categoryPlot22.axisChanged(axisChangeEvent23);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint27 = valueMarker26.getPaint();
        categoryPlot22.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker26);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean30 = categoryPlot13.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer29);
        categoryPlot13.setBackgroundAlpha((float) 10L);
        org.jfree.data.general.Dataset dataset33 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 10L, dataset33);
        org.jfree.data.general.Dataset dataset35 = datasetChangeEvent34.getDataset();
        xYPlot0.datasetChanged(datasetChangeEvent34);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(dataset35);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Color color2 = color1.brighter();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke5 = valueMarker4.getOutlineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        valueMarker4.notifyListeners(markerChangeEvent6);
        java.awt.Color color8 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        boolean boolean10 = valueMarker4.equals((java.lang.Object) colorSpace9);
        java.awt.Color color11 = java.awt.Color.orange;
        float[] floatArray12 = null;
        float[] floatArray13 = color11.getComponents(floatArray12);
        float[] floatArray14 = color1.getComponents(colorSpace9, floatArray13);
        java.awt.Color color15 = java.awt.Color.RED;
        java.awt.Color color16 = java.awt.Color.orange;
        float[] floatArray17 = null;
        float[] floatArray18 = color16.getComponents(floatArray17);
        float[] floatArray19 = color15.getRGBColorComponents(floatArray18);
        float[] floatArray20 = color0.getColorComponents(colorSpace9, floatArray18);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        java.awt.Stroke stroke7 = categoryPlot5.getRangeGridlineStroke();
        java.awt.Paint paint8 = categoryPlot5.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        dateAxis0.setVerticalTickLabels(false);
        dateAxis0.setFixedAutoRange(1.0E-8d);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setAutoTickUnitSelection(true, false);
        dateAxis12.setLabel("");
        java.awt.Paint paint18 = dateAxis12.getAxisLinePaint();
        java.awt.Stroke stroke19 = dateAxis12.getAxisLineStroke();
        dateAxis0.setTickMarkStroke(stroke19);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        categoryPlot5.setRangeCrosshairVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        categoryPlot20.axisChanged(axisChangeEvent21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = null;
        categoryPlot29.axisChanged(axisChangeEvent30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint34 = valueMarker33.getPaint();
        categoryPlot29.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean37 = categoryPlot20.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker33, layer36);
        java.awt.Paint paint38 = valueMarker33.getPaint();
        boolean boolean39 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        categoryPlot5.clearAnnotations();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        xYPlot0.clearRangeMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer14, false);
        boolean boolean17 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean3 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Stroke stroke4 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        java.awt.Stroke stroke12 = categoryPlot11.getRangeGridlineStroke();
        double double13 = categoryPlot11.getRangeCrosshairValue();
        boolean boolean14 = categoryPlot11.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        boolean boolean19 = categoryPlot11.render(graphics2D15, rectangle2D16, (int) (short) 10, plotRenderingInfo18);
        categoryPlot11.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot11.setRenderer(categoryItemRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str25 = axisLocation24.toString();
        categoryPlot11.setDomainAxisLocation(axisLocation24);
        xYPlot0.setRangeAxisLocation(6, axisLocation24);
        boolean boolean28 = xYPlot0.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = dateAxis31.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = null;
        categoryPlot34.axisChanged(axisChangeEvent35);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape41 = dateAxis40.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer42);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent44 = null;
        categoryPlot43.axisChanged(axisChangeEvent44);
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint48 = valueMarker47.getPaint();
        categoryPlot43.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker47);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean51 = categoryPlot34.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker47, layer50);
        categoryPlot34.setBackgroundAlpha((float) 10L);
        org.jfree.data.general.Dataset dataset54 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent55 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 10L, dataset54);
        xYPlot0.datasetChanged(datasetChangeEvent55);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str25.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.awt.Stroke stroke20 = categoryPlot19.getRangeGridlineStroke();
        java.awt.Stroke stroke21 = categoryPlot19.getRangeGridlineStroke();
        categoryPlot19.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot19.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation25, plotOrientation26);
        xYPlot11.setOrientation(plotOrientation26);
        xYPlot11.mapDatasetToRangeAxis(13, 6);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot11.setRangeAxisLocation(500, axisLocation33, false);
        categoryPlot5.setRangeAxisLocation(axisLocation33);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape40 = dateAxis39.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis39, categoryItemRenderer41);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent43 = null;
        categoryPlot42.axisChanged(axisChangeEvent43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot42.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape50 = dateAxis49.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis49, categoryItemRenderer51);
        java.awt.Stroke stroke53 = categoryPlot52.getRangeGridlineStroke();
        categoryPlot52.setAnchorValue((double) 10L, false);
        boolean boolean57 = categoryPlot52.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        categoryPlot52.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis58);
        java.lang.String str60 = dateAxis58.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint63 = valueMarker62.getPaint();
        dateAxis58.setLabelPaint(paint63);
        java.awt.Shape shape65 = dateAxis58.getLeftArrow();
        categoryPlot42.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis58);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier67 = categoryPlot42.getDrawingSupplier();
        org.jfree.data.general.DatasetGroup datasetGroup68 = categoryPlot42.getDatasetGroup();
        org.jfree.chart.LegendItemCollection legendItemCollection69 = categoryPlot42.getLegendItems();
        categoryPlot5.setFixedLegendItems(legendItemCollection69);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNull(categoryItemRenderer46);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(drawingSupplier67);
        org.junit.Assert.assertNull(datasetGroup68);
        org.junit.Assert.assertNotNull(legendItemCollection69);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("DatasetRenderingOrder.REVERSE");
        numberAxis1.setAutoRangeMinimumSize(6.0d);
        java.awt.Paint paint4 = numberAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        xYPlot0.clearRangeMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot16.axisChanged(axisChangeEvent17);
        java.awt.Stroke stroke19 = categoryPlot16.getOutlineStroke();
        xYPlot0.setDomainGridlineStroke(stroke19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot0.getRangeAxis((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(valueAxis22);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        double double6 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setAutoTickUnitSelection(true, false);
        dateAxis7.setLabel("");
        java.awt.Paint paint13 = dateAxis7.getAxisLinePaint();
        org.jfree.data.Range range14 = dateAxis7.getRange();
        dateAxis2.setRange(range14, true, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = dateAxis18.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setAutoTickUnitSelection(true, false);
        dateAxis20.setLabel("");
        java.awt.Paint paint26 = dateAxis20.getAxisLinePaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis20.getTickUnit();
        dateAxis18.setTickUnit(dateTickUnit27);
        java.util.Date date29 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit27);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation35 = null;
        categoryPlot33.setRangeAxisLocation(1, axisLocation35, false);
        org.jfree.chart.axis.AxisSpace axisSpace38 = categoryPlot33.getFixedDomainAxisSpace();
        java.awt.Stroke stroke39 = categoryPlot33.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor43 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke46 = valueMarker45.getOutlineStroke();
        java.awt.Stroke stroke47 = valueMarker45.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color32, stroke39, (java.awt.Paint) chartColor43, stroke47, (float) 1L);
        dateAxis2.setTickMarkStroke(stroke39);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(axisSpace38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        dateAxis0.setRangeWithMargins((double) 2.0f, (double) '#');
        boolean boolean11 = dateAxis0.isAutoRange();
        org.jfree.data.Range range12 = null;
        try {
            dateAxis0.setRangeWithMargins(range12, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        categoryAxis0.setUpperMargin(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot5.setOrientation(plotOrientation9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(plotOrientation9);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint13 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets14, false);
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot5.getFixedRangeAxisSpace();
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        float float20 = categoryPlot5.getBackgroundAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace21);
        double double23 = categoryPlot5.getAnchorValue();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition30 = dateAxis21.getTickMarkPosition();
        java.util.TimeZone timeZone31 = dateAxis21.getTimeZone();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = dateAxis21.getTickLabelInsets();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(dateTickMarkPosition30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        numberAxis0.setAutoRangeStickyZero(true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean10 = categoryMarker9.getDrawAsLine();
        categoryPlot5.addDomainMarker(categoryMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomRangeAxes(10.0d, plotRenderingInfo13, point2D14);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.awt.Stroke stroke20 = categoryPlot19.getRangeGridlineStroke();
        java.awt.Stroke stroke21 = categoryPlot19.getRangeGridlineStroke();
        categoryPlot19.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot19.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation25, plotOrientation26);
        xYPlot11.setOrientation(plotOrientation26);
        xYPlot11.mapDatasetToRangeAxis(13, 6);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot11.setRangeAxisLocation(500, axisLocation33, false);
        categoryPlot5.setRangeAxisLocation(axisLocation33);
        categoryPlot5.clearDomainAxes();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        categoryPlot5.mapDatasetToRangeAxis(100, 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = dateAxis18.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = null;
        categoryPlot21.axisChanged(axisChangeEvent22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot21.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot21.zoomDomainAxes((double) (-1L), plotRenderingInfo27, point2D28, false);
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot21);
        int int32 = categoryPlot5.getDatasetCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("AxisLocation.TOP_OR_LEFT", timeZone1);
        dateAxis2.setVerticalTickLabels(true);
        boolean boolean5 = dateAxis2.isVerticalTickLabels();
        boolean boolean6 = dateAxis2.isAxisLineVisible();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Color color3 = java.awt.Color.RED;
        java.awt.Color color4 = java.awt.Color.orange;
        float[] floatArray5 = null;
        float[] floatArray6 = color4.getComponents(floatArray5);
        float[] floatArray7 = color3.getRGBColorComponents(floatArray6);
        float[] floatArray8 = java.awt.Color.RGBtoHSB((int) (short) 100, 0, (int) (byte) 100, floatArray7);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_LEFT" + "'", str1.equals("TextAnchor.HALF_ASCENT_LEFT"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis0.getTickUnit();
        java.awt.Shape shape9 = dateAxis0.getUpArrow();
        boolean boolean10 = dateAxis0.isTickLabelsVisible();
        boolean boolean11 = dateAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.lang.Object obj6 = dateAxis0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setAutoTickUnitSelection(true, false);
        dateAxis8.setLabel("");
        java.awt.Paint paint14 = dateAxis8.getAxisLinePaint();
        double double15 = dateAxis8.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape19 = dateAxis18.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer20);
        java.awt.Stroke stroke22 = categoryPlot21.getRangeGridlineStroke();
        dateAxis8.setAxisLineStroke(stroke22);
        dateAxis8.setFixedDimension(0.2d);
        boolean boolean26 = rectangleInsets7.equals((java.lang.Object) dateAxis8);
        double double28 = rectangleInsets7.calculateLeftOutset((double) '4');
        dateAxis0.setTickLabelInsets(rectangleInsets7);
        dateAxis0.zoomRange((double) 1L, 1.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        int int34 = categoryPlot33.getWeight();
        int int35 = categoryPlot33.getDatasetCount();
        boolean boolean36 = dateAxis0.equals((java.lang.Object) int35);
        java.awt.Paint paint37 = dateAxis0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace46);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = xYPlot0.getOrientation();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(plotOrientation48);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        boolean boolean13 = categoryPlot5.isOutlineVisible();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot5.setDomainGridlineStroke(stroke14);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        categoryPlot6.axisChanged(axisChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot6.getRenderer(8);
        boolean boolean11 = categoryPlot6.isDomainZoomable();
        java.awt.Stroke stroke12 = categoryPlot6.getOutlineStroke();
        categoryAxis0.setAxisLineStroke(stroke12);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        java.lang.String str8 = dateAxis1.getLabel();
        boolean boolean9 = dateAxis1.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean23 = categoryPlot15.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot15.setRangeCrosshairStroke(stroke30);
        dateAxis1.setTickMarkStroke(stroke30);
        dateAxis1.resizeRange(0.0d, (double) 2.0f);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis36.setNumberFormatOverride(numberFormat37);
        java.text.NumberFormat numberFormat39 = null;
        numberAxis36.setNumberFormatOverride(numberFormat39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer41);
        java.awt.Stroke stroke43 = numberAxis36.getAxisLineStroke();
        numberAxis36.centerRange((double) 0.0f);
        java.text.NumberFormat numberFormat46 = numberAxis36.getNumberFormatOverride();
        numberAxis36.setTickMarkOutsideLength((float) 500);
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape54 = dateAxis53.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis53, categoryItemRenderer55);
        java.awt.Stroke stroke57 = categoryPlot56.getRangeGridlineStroke();
        double double58 = categoryPlot56.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot56.getRangeAxisEdge(15);
        try {
            double double61 = numberAxis36.java2DToValue((double) 2, rectangle2D50, rectangleEdge60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(numberFormat46);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot5.getDomainGridlinePosition();
        java.awt.Paint paint13 = categoryPlot5.getNoDataMessagePaint();
        categoryPlot5.setRangeCrosshairValue(100.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot5.setRenderer(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker18, layer21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection23);
        categoryPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot5.addChangeListener(plotChangeListener27);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = dateAxis31.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeGridlineStroke();
        double double36 = categoryPlot34.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot34.zoomDomainAxes((double) 255, plotRenderingInfo38, point2D39);
        int int41 = categoryPlot34.getDomainAxisCount();
        boolean boolean42 = categoryPlot34.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot34.getDomainAxisLocation((int) (byte) -1);
        categoryPlot5.setDomainAxisLocation(axisLocation44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray47 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer46 };
        categoryPlot5.setRenderers(categoryItemRendererArray47);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot5.setDomainAxis((int) '#', categoryAxis50, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = categoryPlot5.getRenderer();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(categoryItemRendererArray47);
        org.junit.Assert.assertNull(categoryItemRenderer53);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("DatasetRenderingOrder.REVERSE");
        java.awt.Paint paint2 = numberAxis1.getAxisLinePaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        java.awt.Paint paint11 = valueMarker9.getLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.util.List list18 = categoryPlot17.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape25 = dateAxis24.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        java.awt.Stroke stroke28 = categoryPlot27.getRangeGridlineStroke();
        categoryPlot27.setAnchorValue((double) 10L, false);
        boolean boolean32 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean35 = categoryPlot27.removeDomainMarker(marker33, layer34);
        categoryPlot17.addDomainMarker(2, categoryMarker21, layer34);
        boolean boolean37 = xYPlot0.removeRangeMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker9, layer34);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent39 = null;
        xYPlot0.markerChanged(markerChangeEvent39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot0.getRangeAxisLocation();
        java.awt.geom.Point2D point2D42 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(legendItemCollection38);
        org.junit.Assert.assertNotNull(axisLocation41);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(0, axisLocation4, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean9 = categoryMarker8.getDrawAsLine();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot16.axisChanged(axisChangeEvent17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot16.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot16.zoomDomainAxes((double) (-1L), plotRenderingInfo22, point2D23, false);
        categoryPlot16.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot16.getRangeAxisEdge();
        boolean boolean29 = rectangleAnchor10.equals((java.lang.Object) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = dateAxis33.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        java.awt.Stroke stroke37 = categoryPlot36.getRangeGridlineStroke();
        categoryPlot36.setAnchorValue((double) 10L, false);
        boolean boolean41 = categoryPlot36.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker42 = null;
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean44 = categoryPlot36.removeDomainMarker(marker42, layer43);
        java.util.Collection collection45 = categoryPlot16.getDomainMarkers((int) '4', layer43);
        boolean boolean46 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer43);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        dateAxis47.setAutoTickUnitSelection(true, false);
        dateAxis47.setLabel("");
        java.awt.Paint paint53 = dateAxis47.getAxisLinePaint();
        double double54 = dateAxis47.getUpperBound();
        java.awt.Stroke stroke55 = dateAxis47.getAxisLineStroke();
        boolean boolean56 = xYPlot0.equals((java.lang.Object) stroke55);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(8.0d);
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke4 = valueMarker3.getOutlineStroke();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker3.setOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str8 = lengthAdjustmentType7.toString();
        valueMarker3.setLabelOffsetType(lengthAdjustmentType7);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker1.setLabelAnchor(rectangleAnchor11);
        java.awt.Paint paint13 = null;
        try {
            valueMarker1.setLabelPaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "NO_CHANGE" + "'", str8.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.util.List list20 = categoryPlot19.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot29.setAnchorValue((double) 10L, false);
        boolean boolean34 = categoryPlot29.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean37 = categoryPlot29.removeDomainMarker(marker35, layer36);
        categoryPlot19.addDomainMarker(2, categoryMarker23, layer36);
        categoryMarker23.setDrawAsLine(true);
        org.jfree.chart.util.Layer layer41 = null;
        categoryPlot5.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) categoryMarker23, layer41);
        categoryPlot5.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.ValueAxis valueAxis46 = categoryPlot5.getRangeAxisForDataset(255);
        categoryPlot5.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(list20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(valueAxis46);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.8f, (float) 11, (float) 1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.awt.Shape shape30 = dateAxis21.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis31.getStandardTickUnits();
        dateAxis21.setStandardTickUnits(tickUnitSource32);
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = dateAxis21.getTickUnit();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNotNull(dateTickUnit34);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean10 = categoryMarker9.getDrawAsLine();
        categoryPlot5.addDomainMarker(categoryMarker9);
        categoryPlot5.setAnchorValue((-37.0d), true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = null;
        try {
            categoryPlot5.setDatasetRenderingOrder(datasetRenderingOrder15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint13 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets14, false);
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot5.getFixedRangeAxisSpace();
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        int int20 = categoryPlot5.getRangeAxisCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setAutoTickUnitSelection(true, false);
        dateAxis10.setLabel("");
        java.awt.Paint paint16 = dateAxis10.getAxisLinePaint();
        double double17 = dateAxis10.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        java.awt.Stroke stroke24 = categoryPlot23.getRangeGridlineStroke();
        dateAxis10.setAxisLineStroke(stroke24);
        dateAxis10.setFixedDimension(0.2d);
        boolean boolean28 = rectangleInsets9.equals((java.lang.Object) dateAxis10);
        categoryPlot5.setInsets(rectangleInsets9, false);
        double double32 = rectangleInsets9.calculateLeftInset((double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            rectangleInsets9.trim(rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.clearRangeAxes();
        java.lang.String str9 = categoryPlot5.getNoDataMessage();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        java.awt.Paint paint3 = valueMarker1.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = valueMarker1.getLabelAnchor();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker1.setOutlineStroke(stroke5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(stroke5);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        java.lang.Class class0 = null;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("AxisLocation.TOP_OR_LEFT", timeZone6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date1, timeZone6);
//        java.lang.String str9 = day8.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot5.render(graphics2D9, rectangle2D10, (int) (short) 10, plotRenderingInfo12);
        boolean boolean14 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot5.getDomainAxisLocation((int) '#');
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot0.getRangeAxisEdge((int) (short) 0);
        java.awt.Paint paint51 = xYPlot0.getDomainGridlinePaint();
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        org.jfree.chart.plot.CrosshairState crosshairState56 = null;
        boolean boolean57 = xYPlot0.render(graphics2D52, rectangle2D53, 0, plotRenderingInfo55, crosshairState56);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        org.jfree.chart.axis.ValueAxis valueAxis47 = xYPlot0.getDomainAxis((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation48);
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke50);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        xYPlot0.setDomainGridlinesVisible(false);
        int int48 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        xYPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo50, point2D51, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        numberAxis1.zoomRange((double) 0L, (double) 10);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot10.axisChanged(axisChangeEvent11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot10.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot10.zoomDomainAxes((double) (-1L), plotRenderingInfo16, point2D17, false);
        categoryPlot10.setAnchorValue((double) 0);
        java.awt.Paint paint22 = categoryPlot10.getBackgroundPaint();
        boolean boolean23 = numberAxis1.equals((java.lang.Object) paint22);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        int int2 = objectList0.size();
        int int3 = objectList0.size();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.Class class0 = null;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("AxisLocation.TOP_OR_LEFT", timeZone6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date1, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        java.util.Date date10 = regularTimePeriod9.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.TOP_OR_LEFT");
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType0, 8.0d, 0.2d, (double) 255, (double) 2.0f);
        double double8 = rectangleInsets6.trimHeight(0.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-263.0d) + "'", double8 == (-263.0d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        categoryPlot5.mapDatasetToRangeAxis(100, 1);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot5.setDomainAxisLocation(axisLocation16);
        categoryPlot5.setForegroundAlpha((float) (byte) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        categoryPlot5.setRenderer(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setLabel("");
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        double double8 = dateAxis1.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getRangeGridlineStroke();
        dateAxis1.setAxisLineStroke(stroke15);
        dateAxis1.setFixedDimension(0.2d);
        boolean boolean19 = rectangleInsets0.equals((java.lang.Object) dateAxis1);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis1.java2DToValue((double) 9, rectangle2D21, rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 9.223372036854776E18d + "'", double23 == 9.223372036854776E18d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis0.getTickUnit();
        java.awt.Shape shape9 = dateAxis0.getUpArrow();
        boolean boolean10 = dateAxis0.isInverted();
        double double11 = dateAxis0.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        xYPlot0.setDomainGridlinesVisible(false);
        int int48 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        xYPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo50, point2D51, true);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = xYPlot0.getRendererForDataset(xYDataset54);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNull(xYItemRenderer55);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        java.awt.Paint paint46 = xYPlot0.getRangeGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        int int48 = xYPlot0.indexOf(xYDataset47);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint13 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = xYPlot15.getOrientation();
        java.awt.Stroke stroke20 = xYPlot15.getDomainZeroBaselineStroke();
        boolean boolean21 = xYPlot15.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot15.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation22, plotOrientation23);
        categoryPlot5.setRangeAxisLocation(0, axisLocation22);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        double double3 = valueMarker1.getValue();
        valueMarker1.setLabel("java.awt.Color[r=255,g=0,b=0]");
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        valueMarker1.setPaint((java.awt.Paint) color6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        double double15 = categoryPlot13.getRangeCrosshairValue();
        boolean boolean16 = categoryPlot13.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setAutoTickUnitSelection(true, false);
        dateAxis18.setLabel("");
        java.awt.Paint paint24 = dateAxis18.getAxisLinePaint();
        double double25 = dateAxis18.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape29 = dateAxis28.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer30);
        java.awt.Stroke stroke32 = categoryPlot31.getRangeGridlineStroke();
        dateAxis18.setAxisLineStroke(stroke32);
        dateAxis18.setFixedDimension(0.2d);
        boolean boolean36 = rectangleInsets17.equals((java.lang.Object) dateAxis18);
        categoryPlot13.setInsets(rectangleInsets17, false);
        double double40 = rectangleInsets17.calculateBottomInset(0.0d);
        valueMarker1.setLabelOffset(rectangleInsets17);
        double double42 = rectangleInsets17.getBottom();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.0d + "'", double40 == 3.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.0d + "'", double42 == 3.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        org.jfree.chart.axis.ValueAxis valueAxis47 = xYPlot0.getDomainAxis((int) (short) 10);
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(axisLocation48);
        java.util.List list50 = xYPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(list50);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        double double2 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setAutoTickUnitSelection(true, false);
        dateAxis4.setLabel("");
        java.awt.Paint paint10 = dateAxis4.getAxisLinePaint();
        double double11 = dateAxis4.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.awt.Stroke stroke18 = categoryPlot17.getRangeGridlineStroke();
        dateAxis4.setAxisLineStroke(stroke18);
        dateAxis4.setUpperBound((double) 2);
        xYPlot0.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.Object obj24 = null;
        boolean boolean25 = seriesRenderingOrder23.equals(obj24);
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder23);
        org.junit.Assert.assertNull(xYItemRenderer1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = categoryPlot15.removeDomainMarker(marker21, layer22);
        categoryPlot5.addDomainMarker(2, categoryMarker9, layer22);
        categoryPlot5.clearRangeMarkers(255);
        categoryPlot5.setWeight(9);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation(1, axisLocation2, false);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str7 = axisLocation6.toString();
        categoryPlot0.setRangeAxisLocation(axisLocation6);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str7.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        int int12 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setAutoTickUnitSelection(true, false);
        dateAxis14.setLabel("");
        dateAxis14.setLowerBound((double) (short) 10);
        categoryPlot5.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis14, true);
        java.awt.Image image24 = null;
        categoryPlot5.setBackgroundImage(image24);
        categoryPlot5.mapDatasetToDomainAxis(12, (int) 'a');
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType0, 8.0d, 0.2d, (double) 255, (double) 2.0f);
        java.lang.String str7 = unitType0.toString();
        java.lang.String str8 = unitType0.toString();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.setDomainGridlinesVisible(false);
        xYPlot9.setDomainGridlinesVisible(false);
        double double14 = xYPlot9.getDomainCrosshairValue();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot9.setDomainGridlineStroke(stroke15);
        int int17 = xYPlot9.getSeriesCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot9.setRenderer(500, xYItemRenderer19, true);
        boolean boolean22 = unitType0.equals((java.lang.Object) true);
        java.lang.String str23 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.ABSOLUTE" + "'", str7.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UnitType.ABSOLUTE" + "'", str8.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnitType.ABSOLUTE" + "'", str23.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.Object obj1 = null;
        boolean boolean2 = seriesRenderingOrder0.equals(obj1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint4 = defaultDrawingSupplier3.getNextOutlinePaint();
        boolean boolean5 = seriesRenderingOrder0.equals((java.lang.Object) defaultDrawingSupplier3);
        java.awt.Stroke stroke6 = defaultDrawingSupplier3.getNextOutlineStroke();
        java.awt.Shape shape7 = defaultDrawingSupplier3.getNextShape();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1.0f, (double) 10.0f, (double) (short) 10, 10.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint8 = valueMarker7.getPaint();
        java.awt.Paint paint9 = valueMarker7.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        valueMarker7.setLabelOffset(rectangleInsets10);
        float float12 = valueMarker7.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker7.setLabelOffsetType(lengthAdjustmentType13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape18 = dateAxis17.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        java.util.List list21 = categoryPlot20.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape28 = dateAxis27.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer29);
        java.awt.Stroke stroke31 = categoryPlot30.getRangeGridlineStroke();
        categoryPlot30.setAnchorValue((double) 10L, false);
        boolean boolean35 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker36 = null;
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean38 = categoryPlot30.removeDomainMarker(marker36, layer37);
        categoryPlot20.addDomainMarker(2, categoryMarker24, layer37);
        categoryMarker24.setDrawAsLine(true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = categoryMarker24.getLabelOffsetType();
        try {
            java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets4.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType13, lengthAdjustmentType42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.8f + "'", float12 == 0.8f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(list21);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType42);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setRangeAxisLocation(1, axisLocation5, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot3.getFixedDomainAxisSpace();
        java.awt.Stroke stroke9 = categoryPlot3.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke16 = valueMarker15.getOutlineStroke();
        java.awt.Stroke stroke17 = valueMarker15.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color2, stroke9, (java.awt.Paint) chartColor13, stroke17, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer20);
        java.lang.Object obj22 = intervalMarker19.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer23);
        java.awt.Color color27 = java.awt.Color.getColor("", (int) (short) 0);
        java.awt.Color color28 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint33 = valueMarker32.getPaint();
        double double34 = valueMarker32.getValue();
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_RED;
        valueMarker32.setPaint((java.awt.Paint) color35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape40 = dateAxis39.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis39, categoryItemRenderer41);
        java.util.List list43 = categoryPlot42.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape50 = dateAxis49.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis49, categoryItemRenderer51);
        java.awt.Stroke stroke53 = categoryPlot52.getRangeGridlineStroke();
        categoryPlot52.setAnchorValue((double) 10L, false);
        boolean boolean57 = categoryPlot52.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker58 = null;
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean60 = categoryPlot52.removeDomainMarker(marker58, layer59);
        categoryPlot42.addDomainMarker(2, categoryMarker46, layer59);
        categoryMarker46.setDrawAsLine(true);
        java.awt.Color color64 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int65 = color64.getBlue();
        int int66 = color64.getAlpha();
        categoryMarker46.setOutlinePaint((java.awt.Paint) color64);
        java.awt.Color color71 = java.awt.Color.RED;
        java.awt.Color color72 = color71.brighter();
        int int73 = color72.getRed();
        java.awt.Color color74 = java.awt.Color.RED;
        java.awt.Color color75 = java.awt.Color.orange;
        float[] floatArray76 = null;
        float[] floatArray77 = color75.getComponents(floatArray76);
        float[] floatArray78 = color74.getRGBColorComponents(floatArray77);
        float[] floatArray79 = color72.getColorComponents(floatArray78);
        float[] floatArray80 = java.awt.Color.RGBtoHSB(8, 0, 7, floatArray79);
        float[] floatArray81 = color64.getRGBColorComponents(floatArray79);
        float[] floatArray82 = color35.getRGBColorComponents(floatArray81);
        float[] floatArray83 = color30.getRGBColorComponents(floatArray82);
        float[] floatArray84 = color27.getComponents(colorSpace29, floatArray83);
        intervalMarker19.setLabelPaint((java.awt.Paint) color27);
        double double86 = intervalMarker19.getStartValue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNull(list43);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 255 + "'", int65 == 255);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 255 + "'", int66 == 255);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 255 + "'", int73 == 255);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(floatArray77);
        org.junit.Assert.assertNotNull(floatArray78);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertNotNull(floatArray80);
        org.junit.Assert.assertNotNull(floatArray81);
        org.junit.Assert.assertNotNull(floatArray82);
        org.junit.Assert.assertNotNull(floatArray83);
        org.junit.Assert.assertNotNull(floatArray84);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke13 = valueMarker12.getOutlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker12.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker12.setLabelPaint((java.awt.Paint) color16);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        java.awt.Paint paint19 = valueMarker12.getLabelPaint();
        java.awt.Font font20 = valueMarker12.getLabelFont();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Paint paint6 = dateAxis2.getLabelPaint();
        dateAxis2.setTickMarkOutsideLength((float) 1560409200000L);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setAutoTickUnitSelection(true, false);
        dateAxis2.setLabel("");
        dateAxis2.setLowerBound((double) (short) 10);
        org.jfree.data.Range range10 = dateAxis2.getDefaultAutoRange();
        dateAxis0.setRangeWithMargins(range10, false, true);
        dateAxis0.setVisible(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        org.jfree.data.Range range7 = dateAxis0.getRange();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange8, false, false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(dateRange8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.lang.String str13 = dateAxis11.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        dateAxis11.setLabelPaint(paint16);
        java.lang.String str18 = dateAxis11.getLabelToolTip();
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.setAutoTickUnitSelection(true, false);
        dateAxis22.setVerticalTickLabels(false);
        float float28 = dateAxis22.getTickMarkInsideLength();
        boolean boolean29 = lengthAdjustmentType21.equals((java.lang.Object) dateAxis22);
        boolean boolean30 = chartChangeEventType20.equals((java.lang.Object) lengthAdjustmentType21);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) str18, jFreeChart19, chartChangeEventType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke13 = valueMarker12.getOutlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker12.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker12.setLabelPaint((java.awt.Paint) color16);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker12, jFreeChart19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        valueMarker12.notifyListeners(markerChangeEvent21);
        valueMarker12.setLabel("java.awt.Color[r=0,g=192,b=192]");
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0d, (java.awt.Paint) color26, stroke27);
        java.awt.Color color29 = java.awt.Color.RED;
        java.awt.Color color30 = color29.brighter();
        int int31 = color30.getRed();
        java.awt.Color color32 = java.awt.Color.RED;
        java.awt.Color color33 = java.awt.Color.orange;
        float[] floatArray34 = null;
        float[] floatArray35 = color33.getComponents(floatArray34);
        float[] floatArray36 = color32.getRGBColorComponents(floatArray35);
        float[] floatArray37 = color30.getColorComponents(floatArray36);
        float[] floatArray38 = color26.getComponents(floatArray36);
        valueMarker12.setPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 255 + "'", int31 == 255);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        categoryPlot6.axisChanged(axisChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot6.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomDomainAxes((double) (-1L), plotRenderingInfo12, point2D13, false);
        categoryPlot6.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot6.getRangeAxisEdge();
        boolean boolean19 = rectangleAnchor0.equals((java.lang.Object) categoryPlot6);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        categoryPlot6.drawBackgroundImage(graphics2D20, rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        xYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot8.axisChanged(axisChangeEvent9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint13 = valueMarker12.getPaint();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot8.zoomDomainAxes((double) (byte) 10, plotRenderingInfo16, point2D17, false);
        categoryPlot8.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextOutlinePaint();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        java.awt.Paint paint25 = defaultDrawingSupplier22.getNextFillPaint();
        java.awt.Paint paint26 = defaultDrawingSupplier22.getNextPaint();
        java.awt.Paint paint27 = defaultDrawingSupplier22.getNextPaint();
        xYPlot0.setDomainGridlinePaint(paint27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot0.getDomainAxisLocation(4);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation31 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot5.getDomainGridlinePosition();
        java.awt.Paint paint13 = categoryPlot5.getNoDataMessagePaint();
        categoryPlot5.setRangeCrosshairValue(100.0d);
        categoryPlot5.zoom((double) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        try {
            categoryPlot5.setDomainAxisLocation(axisLocation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot5.setRenderer(2, categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot5.getRenderer();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        dateAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit9);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        valueMarker1.notifyListeners(markerChangeEvent3);
        try {
            valueMarker1.setAlpha((float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        boolean boolean7 = dateAxis0.isVisible();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        categoryPlot13.axisChanged(axisChangeEvent14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint18 = valueMarker17.getPaint();
        categoryPlot13.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot13.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot13.setNoDataMessageFont(font23);
        dateAxis0.setLabelFont(font23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace29 = xYPlot26.getFixedRangeAxisSpace();
        xYPlot26.setRangeCrosshairValue((double) 10);
        boolean boolean32 = dateAxis0.hasListener((java.util.EventListener) xYPlot26);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot26.getRangeAxisLocation(7);
        org.jfree.chart.util.UnitType unitType35 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str36 = unitType35.toString();
        boolean boolean37 = axisLocation34.equals((java.lang.Object) str36);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(unitType35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnitType.ABSOLUTE" + "'", str36.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean3 = categoryMarker2.getDrawAsLine();
        java.lang.Comparable comparable4 = categoryMarker2.getKey();
        boolean boolean5 = color0.equals((java.lang.Object) categoryMarker2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) -1 + "'", comparable4.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean3 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Stroke stroke4 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        xYPlot0.axisChanged(axisChangeEvent5);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint8 = defaultDrawingSupplier7.getNextOutlinePaint();
        java.awt.Paint paint9 = defaultDrawingSupplier7.getNextFillPaint();
        xYPlot0.setRangeGridlinePaint(paint9);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getDownArrow();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = dateAxis4.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        categoryPlot7.axisChanged(axisChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot7.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D16, false);
        categoryPlot7.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextOutlinePaint();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        java.awt.Paint paint24 = defaultDrawingSupplier21.getNextFillPaint();
        dateAxis0.setLabelPaint(paint24);
        dateAxis0.resizeRange(0.0d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        int int8 = xYPlot0.getSeriesCount();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint12 = valueMarker11.getPaint();
        double double13 = valueMarker11.getValue();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker11.setLabelTextAnchor(textAnchor14);
        valueMarker11.setAlpha((float) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        categoryPlot23.axisChanged(axisChangeEvent24);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = dateAxis29.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer31);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent33 = null;
        categoryPlot32.axisChanged(axisChangeEvent33);
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint37 = valueMarker36.getPaint();
        categoryPlot32.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker36);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean40 = categoryPlot23.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker36, layer39);
        boolean boolean41 = xYPlot0.removeRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker11, layer39);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setRangeAxisLocation(1, axisLocation5, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot3.getFixedDomainAxisSpace();
        java.awt.Stroke stroke9 = categoryPlot3.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke16 = valueMarker15.getOutlineStroke();
        java.awt.Stroke stroke17 = valueMarker15.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color2, stroke9, (java.awt.Paint) chartColor13, stroke17, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer20);
        java.lang.Object obj22 = intervalMarker19.clone();
        double double23 = intervalMarker19.getStartValue();
        double double24 = intervalMarker19.getEndValue();
        float float25 = intervalMarker19.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        numberAxis1.setAutoRangeStickyZero(true);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        try {
            categoryPlot5.zoomRangeAxes((double) 13, (double) (short) -1, plotRenderingInfo17, point2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (13.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Color color1 = color0.brighter();
        int int2 = color1.getRed();
        int int3 = color1.getRed();
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Color color5 = color4.brighter();
        int int6 = color5.getRed();
        java.awt.Color color7 = java.awt.Color.RED;
        java.awt.Color color8 = java.awt.Color.orange;
        float[] floatArray9 = null;
        float[] floatArray10 = color8.getComponents(floatArray9);
        float[] floatArray11 = color7.getRGBColorComponents(floatArray10);
        float[] floatArray12 = color5.getColorComponents(floatArray11);
        float[] floatArray13 = color1.getRGBComponents(floatArray12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint13 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets14, false);
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot5.getFixedRangeAxisSpace();
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        float float20 = categoryPlot5.getBackgroundAlpha();
        org.jfree.chart.util.SortOrder sortOrder21 = null;
        try {
            categoryPlot5.setRowRenderingOrder(sortOrder21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot5.getColumnRenderingOrder();
        java.awt.Stroke stroke31 = categoryPlot5.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = dateAxis4.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        java.util.List list8 = categoryPlot7.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.awt.Stroke stroke18 = categoryPlot17.getRangeGridlineStroke();
        categoryPlot17.setAnchorValue((double) 10L, false);
        boolean boolean22 = categoryPlot17.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = categoryPlot17.removeDomainMarker(marker23, layer24);
        categoryPlot7.addDomainMarker(2, categoryMarker11, layer24);
        categoryMarker11.setDrawAsLine(true);
        categoryPlot0.addDomainMarker(categoryMarker11);
        categoryPlot0.setWeight(8);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace32, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double5 = rectangleInsets4.getLeft();
        double double6 = rectangleInsets4.getRight();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets4.createInsetRectangle(rectangle2D7, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 2);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        double double15 = categoryPlot13.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot13.zoomDomainAxes((double) 255, plotRenderingInfo17, point2D18);
        int int20 = categoryPlot13.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot13.getRangeAxisEdge();
        try {
            java.util.List list22 = categoryAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean3 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot10.axisChanged(axisChangeEvent11);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        categoryPlot19.axisChanged(axisChangeEvent20);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint24 = valueMarker23.getPaint();
        categoryPlot19.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean27 = categoryPlot10.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker23, layer26);
        java.util.Collection collection28 = xYPlot0.getDomainMarkers((int) ' ', layer26);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot29.getRangeAxisForDataset(0);
        boolean boolean32 = xYPlot29.isRangeGridlinesVisible();
        java.awt.Stroke stroke33 = xYPlot29.getDomainZeroBaselineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke33);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Paint paint6 = dateAxis2.getLabelPaint();
        dateAxis2.setLabelAngle(0.2d);
        dateAxis2.setAutoRangeMinimumSize((double) 500);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke13 = valueMarker12.getOutlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker12.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker12.setLabelPaint((java.awt.Paint) color16);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        java.awt.Paint paint19 = valueMarker12.getLabelPaint();
        valueMarker12.setLabel("DatasetRenderingOrder.REVERSE");
        java.lang.String str22 = valueMarker12.getLabel();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str22.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.String str1 = dateAxis0.getLabel();
        dateAxis0.zoomRange(10.0d, (double) 10L);
        java.awt.Shape shape5 = dateAxis0.getDownArrow();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot5.getRenderer((int) '#');
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryItemRenderer10);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
//        long long3 = day1.getFirstMillisecond();
//        long long4 = day1.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setAutoTickUnitSelection(true, false);
        dateAxis4.setLabel("");
        java.awt.Paint paint10 = dateAxis4.getAxisLinePaint();
        double double11 = dateAxis4.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.awt.Stroke stroke18 = categoryPlot17.getRangeGridlineStroke();
        dateAxis4.setAxisLineStroke(stroke18);
        dateAxis4.setFixedDimension(0.2d);
        double double22 = dateAxis4.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis4.getStandardTickUnits();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis4.setTimeZone(timeZone24);
        org.jfree.data.Range range26 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.lang.Class class27 = null;
        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        dateAxis4.setMinimumDate(date28);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setAutoTickUnitSelection(true, false);
        dateAxis34.setLabel("");
        dateAxis34.setLowerBound((double) (short) 10);
        org.jfree.data.Range range42 = dateAxis34.getDefaultAutoRange();
        dateAxis32.setRangeWithMargins(range42, false, true);
        dateAxis4.setRange(range42);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(range42);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = dateAxis4.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        categoryPlot7.axisChanged(axisChangeEvent8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot7.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot7.zoomDomainAxes((double) (-1L), plotRenderingInfo13, point2D14, false);
        categoryPlot7.setAnchorValue((double) 0);
        java.awt.Paint paint19 = categoryPlot7.getBackgroundPaint();
        org.jfree.chart.util.ObjectList objectList20 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj21 = objectList20.clone();
        int int22 = objectList20.size();
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot26.setRangeAxisLocation(1, axisLocation28, false);
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot26.getFixedDomainAxisSpace();
        java.awt.Stroke stroke32 = categoryPlot26.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor36 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke39 = valueMarker38.getOutlineStroke();
        java.awt.Stroke stroke40 = valueMarker38.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color25, stroke32, (java.awt.Paint) chartColor36, stroke40, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer43 = null;
        intervalMarker42.setGradientPaintTransformer(gradientPaintTransformer43);
        int int45 = objectList20.indexOf((java.lang.Object) gradientPaintTransformer43);
        boolean boolean46 = categoryPlot7.equals((java.lang.Object) objectList20);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot7);
        categoryAxis0.setUpperMargin((-1.2517371E7d));
        float float50 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.0f + "'", float50 == 0.0f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        categoryPlot6.axisChanged(axisChangeEvent7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        categoryPlot15.axisChanged(axisChangeEvent16);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint20 = valueMarker19.getPaint();
        categoryPlot15.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker19);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = categoryPlot6.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker19, layer22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = null;
        categoryPlot6.setFixedLegendItems(legendItemCollection24);
        categoryPlot6.setRangeCrosshairVisible(true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot6.addChangeListener(plotChangeListener28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        double double37 = categoryPlot35.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot35.zoomDomainAxes((double) 255, plotRenderingInfo39, point2D40);
        int int42 = categoryPlot35.getDomainAxisCount();
        boolean boolean43 = categoryPlot35.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation45 = categoryPlot35.getDomainAxisLocation((int) (byte) -1);
        categoryPlot6.setDomainAxisLocation(axisLocation45);
        boolean boolean47 = seriesRenderingOrder0.equals((java.lang.Object) axisLocation45);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Font font6 = dateAxis2.getTickLabelFont();
        dateAxis2.setRangeAboutValue(0.0d, 0.0d);
        org.jfree.data.Range range10 = dateAxis2.getRange();
        dateAxis2.setLowerMargin((double) 100);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        categoryPlot5.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot5.zoomRangeAxes((double) (-1.0f), plotRenderingInfo19, point2D20);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setAutoTickUnitSelection(true, false);
        dateAxis10.setLabel("");
        java.awt.Paint paint16 = dateAxis10.getAxisLinePaint();
        double double17 = dateAxis10.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        java.awt.Stroke stroke24 = categoryPlot23.getRangeGridlineStroke();
        dateAxis10.setAxisLineStroke(stroke24);
        dateAxis10.setFixedDimension(0.2d);
        boolean boolean28 = rectangleInsets9.equals((java.lang.Object) dateAxis10);
        categoryPlot5.setInsets(rectangleInsets9, false);
        double double32 = rectangleInsets9.extendWidth(4.2d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 10.2d + "'", double32 == 10.2d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        dateAxis2.setTickMarkOutsideLength((float) (-1));
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.setRangeCrosshairValue((double) 10);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.2d);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.awt.Stroke stroke18 = categoryPlot17.getRangeGridlineStroke();
        java.awt.Stroke stroke19 = categoryPlot17.getRangeGridlineStroke();
        categoryPlot17.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot17.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation23, plotOrientation24);
        xYPlot9.setOrientation(plotOrientation24);
        xYPlot9.setRangeCrosshairValue((double) (short) 0, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean33 = categoryMarker32.getDrawAsLine();
        java.lang.Comparable comparable34 = categoryMarker32.getKey();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape38 = dateAxis37.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer39);
        java.awt.Stroke stroke41 = categoryPlot40.getRangeGridlineStroke();
        double double42 = categoryPlot40.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        int int44 = categoryPlot40.getIndexOf(categoryItemRenderer43);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot40.getRendererForDataset(categoryDataset45);
        java.awt.Image image47 = null;
        categoryPlot40.setBackgroundImage(image47);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape52 = dateAxis51.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer53);
        java.awt.Stroke stroke55 = categoryPlot54.getRangeGridlineStroke();
        categoryPlot54.setAnchorValue((double) 10L, false);
        boolean boolean59 = categoryPlot54.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker60 = null;
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean62 = categoryPlot54.removeDomainMarker(marker60, layer61);
        java.util.Collection collection63 = categoryPlot40.getDomainMarkers(layer61);
        xYPlot9.addDomainMarker((-12517377), (org.jfree.chart.plot.Marker) categoryMarker32, layer61, true);
        boolean boolean67 = xYPlot0.removeDomainMarker(13, (org.jfree.chart.plot.Marker) valueMarker8, layer61, true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (byte) -1 + "'", comparable34.equals((byte) -1));
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer46);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(collection63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        categoryPlot5.setOutlineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot5.setDomainAxisLocation(10, axisLocation20, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation20, plotOrientation23);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = xYPlot0.getRenderer();
        double double2 = xYPlot0.getDomainCrosshairValue();
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNull(xYItemRenderer1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        int int8 = xYPlot0.getSeriesCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        xYPlot0.setRenderer(500, xYItemRenderer10, true);
        boolean boolean13 = xYPlot0.isRangeZeroBaselineVisible();
        int int14 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        java.awt.Stroke stroke11 = categoryPlot5.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color14 = java.awt.Color.black;
        categoryAxis12.setTickLabelPaint((java.lang.Comparable) 1560409200000L, (java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.removeCategoryLabelToolTip((java.lang.Comparable) 2);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        int int20 = categoryAxis19.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        double double22 = categoryAxis21.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.removeCategoryLabelToolTip((java.lang.Comparable) 2);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color28 = java.awt.Color.black;
        categoryAxis26.setTickLabelPaint((java.lang.Comparable) 1560409200000L, (java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray30 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis12, categoryAxis16, categoryAxis19, categoryAxis21, categoryAxis23, categoryAxis26 };
        categoryPlot5.setDomainAxes(categoryAxisArray30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot32.getRangeAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot32.setDomainAxisLocation(0, axisLocation36, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean41 = categoryMarker40.getDrawAsLine();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape46 = dateAxis45.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer47);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = null;
        categoryPlot48.axisChanged(axisChangeEvent49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = categoryPlot48.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        categoryPlot48.zoomDomainAxes((double) (-1L), plotRenderingInfo54, point2D55, false);
        categoryPlot48.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot48.getRangeAxisEdge();
        boolean boolean61 = rectangleAnchor42.equals((java.lang.Object) categoryPlot48);
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape66 = dateAxis65.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset63, categoryAxis64, (org.jfree.chart.axis.ValueAxis) dateAxis65, categoryItemRenderer67);
        java.awt.Stroke stroke69 = categoryPlot68.getRangeGridlineStroke();
        categoryPlot68.setAnchorValue((double) 10L, false);
        boolean boolean73 = categoryPlot68.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker74 = null;
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean76 = categoryPlot68.removeDomainMarker(marker74, layer75);
        java.util.Collection collection77 = categoryPlot48.getDomainMarkers((int) '4', layer75);
        boolean boolean78 = xYPlot32.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker40, layer75);
        categoryPlot5.addDomainMarker(categoryMarker40);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(categoryAxisArray30);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNull(categoryItemRenderer52);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(collection77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, 0.0d, plotRenderingInfo10, point2D11);
        categoryPlot5.setBackgroundImageAlignment(8);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot5.setDataset((int) '#', categoryDataset16);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke7 = valueMarker6.getOutlineStroke();
        java.awt.Stroke stroke8 = valueMarker6.getOutlineStroke();
        xYPlot0.setRangeGridlineStroke(stroke8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        java.awt.Stroke stroke5 = xYPlot0.getDomainZeroBaselineStroke();
        xYPlot0.clearRangeMarkers((-1));
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot0.getRangeAxisLocation((int) '4');
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setRangeAxisLocation(1, axisLocation5, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot3.getFixedDomainAxisSpace();
        java.awt.Stroke stroke9 = categoryPlot3.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke16 = valueMarker15.getOutlineStroke();
        java.awt.Stroke stroke17 = valueMarker15.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color2, stroke9, (java.awt.Paint) chartColor13, stroke17, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer20);
        java.lang.Object obj22 = intervalMarker19.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = intervalMarker19.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(gradientPaintTransformer23);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot8.getRangeGridlineStroke();
        java.awt.Stroke stroke10 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        xYPlot0.setOrientation(plotOrientation15);
        java.awt.Paint paint18 = xYPlot0.getDomainGridlinePaint();
        xYPlot0.mapDatasetToRangeAxis(500, (int) (short) 100);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        categoryPlot6.axisChanged(axisChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot6.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot6.zoomDomainAxes((double) (-1L), plotRenderingInfo12, point2D13, false);
        categoryPlot6.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot6.getRangeAxisEdge();
        boolean boolean19 = rectangleAnchor0.equals((java.lang.Object) categoryPlot6);
        boolean boolean20 = categoryPlot6.isSubplot();
        categoryPlot6.setAnchorValue((double) 0);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        java.lang.Comparable comparable3 = categoryMarker1.getKey();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        java.awt.Stroke stroke7 = valueMarker5.getOutlineStroke();
        categoryMarker1.setStroke(stroke7);
        categoryMarker1.setAlpha((float) 1L);
        boolean boolean11 = categoryMarker1.getDrawAsLine();
        categoryMarker1.setLabel("PlotOrientation.VERTICAL");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (byte) -1 + "'", comparable3.equals((byte) -1));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        categoryPlot6.axisChanged(axisChangeEvent7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint11 = valueMarker10.getPaint();
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = categoryPlot6.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot6.getColumnRenderingOrder();
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor((int) '#', 10, (int) (byte) 10);
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) chartColor18);
        boolean boolean20 = seriesRenderingOrder0.equals((java.lang.Object) chartColor18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        org.jfree.chart.axis.ValueAxis valueAxis47 = xYPlot0.getDomainAxis((int) (short) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray49 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer48 };
        xYPlot0.setRenderers(xYItemRendererArray49);
        org.jfree.chart.LegendItemCollection legendItemCollection51 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(xYItemRendererArray49);
        org.junit.Assert.assertNull(legendItemCollection51);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        int int12 = categoryPlot5.getDomainAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setAutoTickUnitSelection(true, false);
        dateAxis14.setLabel("");
        dateAxis14.setLowerBound((double) (short) 10);
        categoryPlot5.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis14, true);
        java.awt.Image image24 = null;
        categoryPlot5.setBackgroundImage(image24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot5.setDataset(categoryDataset26);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint13 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets14, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = dateAxis19.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        java.util.List list23 = categoryPlot22.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape30 = dateAxis29.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer31);
        java.awt.Stroke stroke33 = categoryPlot32.getRangeGridlineStroke();
        categoryPlot32.setAnchorValue((double) 10L, false);
        boolean boolean37 = categoryPlot32.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean40 = categoryPlot32.removeDomainMarker(marker38, layer39);
        categoryPlot22.addDomainMarker(2, categoryMarker26, layer39);
        categoryPlot22.clearRangeMarkers(255);
        double double44 = categoryPlot22.getRangeCrosshairValue();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot5.getDomainMarkers(layer46);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation48 = null;
        try {
            boolean boolean49 = categoryPlot5.removeAnnotation(categoryAnnotation48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(list23);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNull(collection47);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot5.getRendererForDataset(categoryDataset10);
        java.awt.Image image12 = null;
        categoryPlot5.setBackgroundImage(image12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.awt.Stroke stroke20 = categoryPlot19.getRangeGridlineStroke();
        categoryPlot19.setAnchorValue((double) 10L, false);
        boolean boolean24 = categoryPlot19.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean27 = categoryPlot19.removeDomainMarker(marker25, layer26);
        java.util.Collection collection28 = categoryPlot5.getDomainMarkers(layer26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str30 = datasetRenderingOrder29.toString();
        categoryPlot5.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str30.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        categoryPlot5.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent11);
        categoryPlot5.configureDomainAxes();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        boolean boolean7 = dateAxis0.isVisible();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        categoryPlot13.axisChanged(axisChangeEvent14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint18 = valueMarker17.getPaint();
        categoryPlot13.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot13.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot13.setNoDataMessageFont(font23);
        dateAxis0.setLabelFont(font23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace29 = xYPlot26.getFixedRangeAxisSpace();
        xYPlot26.setRangeCrosshairValue((double) 10);
        boolean boolean32 = dateAxis0.hasListener((java.util.EventListener) xYPlot26);
        java.lang.String str33 = xYPlot26.getPlotType();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "XY Plot" + "'", str33.equals("XY Plot"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker18, layer21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets25, true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        try {
            java.awt.Paint paint4 = xYPlot0.getQuadrantPaint(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (255) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        categoryPlot5.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextOutlinePaint();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot5.setAnchorValue((double) 100L);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        dateAxis24.setAutoTickUnitSelection(true, false);
        dateAxis24.setVerticalTickLabels(false);
        float float30 = dateAxis24.getTickMarkInsideLength();
        java.lang.String str31 = dateAxis24.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis24.getTickUnit();
        dateAxis24.setAutoTickUnitSelection(true);
        int int35 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis24);
        boolean boolean36 = categoryPlot5.isOutlineVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        java.awt.Paint paint4 = dateAxis0.getTickMarkPaint();
        dateAxis0.setAutoRange(false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        org.jfree.chart.axis.ValueAxis valueAxis47 = xYPlot0.getDomainAxis((int) (short) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray49 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer48 };
        xYPlot0.setRenderers(xYItemRendererArray49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        xYPlot0.zoomRangeAxes(0.0d, (double) 'a', plotRenderingInfo53, point2D54);
        org.jfree.chart.LegendItemCollection legendItemCollection56 = xYPlot0.getLegendItems();
        boolean boolean57 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(xYItemRendererArray49);
        org.junit.Assert.assertNotNull(legendItemCollection56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 2);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Font font9 = dateAxis5.getTickLabelFont();
        categoryAxis0.setLabelFont(font9);
        double double11 = categoryAxis0.getLowerMargin();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = dateAxis15.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        categoryPlot18.axisChanged(axisChangeEvent19);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint23 = valueMarker22.getPaint();
        categoryPlot18.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker22);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot18.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker26);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot18.setNoDataMessageFont(font28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryPlot18.setRangeCrosshairPaint((java.awt.Paint) color30);
        categoryPlot18.clearRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape37 = dateAxis36.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer38);
        java.awt.Stroke stroke40 = categoryPlot39.getRangeGridlineStroke();
        double double41 = categoryPlot39.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot39.getRangeAxisEdge(15);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace45 = categoryAxis0.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot18, rectangle2D33, rectangleEdge43, axisSpace44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot5.getRangeAxisEdge();
        categoryPlot5.setForegroundAlpha((float) (short) 1);
        float float20 = categoryPlot5.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = dateAxis23.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = null;
        categoryPlot26.axisChanged(axisChangeEvent27);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint31 = valueMarker30.getPaint();
        categoryPlot26.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker30);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = categoryPlot26.getDomainGridlinePosition();
        java.lang.String str34 = categoryAnchor33.toString();
        categoryPlot5.setDomainGridlinePosition(categoryAnchor33);
        categoryPlot5.setDrawSharedDomainAxis(false);
        java.awt.Color color38 = java.awt.Color.RED;
        java.awt.Color color39 = color38.brighter();
        int int40 = color39.getRed();
        java.awt.Color color41 = java.awt.Color.RED;
        java.awt.Color color42 = java.awt.Color.orange;
        float[] floatArray43 = null;
        float[] floatArray44 = color42.getComponents(floatArray43);
        float[] floatArray45 = color41.getRGBColorComponents(floatArray44);
        float[] floatArray46 = color39.getColorComponents(floatArray45);
        categoryPlot5.setOutlinePaint((java.awt.Paint) color39);
        java.util.List list48 = categoryPlot5.getCategories();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str34.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNull(list48);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setAutoTickUnitSelection(true, false);
        dateAxis13.setLabel("");
        dateAxis13.setLowerBound((double) (short) 10);
        org.jfree.data.Range range21 = dateAxis13.getDefaultAutoRange();
        dateAxis11.setRange(range21);
        dateAxis11.setLabel("UnitType.ABSOLUTE");
        org.jfree.chart.plot.Plot plot25 = dateAxis11.getPlot();
        java.util.TimeZone timeZone26 = dateAxis11.getTimeZone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(plot25);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(8.0d);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        java.awt.Stroke stroke11 = categoryPlot10.getRangeGridlineStroke();
        java.awt.Stroke stroke12 = categoryPlot10.getRangeGridlineStroke();
        categoryPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot10.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation16, plotOrientation17);
        xYPlot2.setOrientation(plotOrientation17);
        java.awt.Paint paint20 = xYPlot2.getDomainGridlinePaint();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.util.List list23 = null;
        xYPlot2.drawDomainTickBands(graphics2D21, rectangle2D22, list23);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        int int8 = xYPlot0.getSeriesCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        xYPlot0.setRenderer(500, xYItemRenderer10, true);
        float float13 = xYPlot0.getBackgroundImageAlpha();
        java.lang.String str14 = xYPlot0.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setAutoTickUnitSelection(true, false);
        dateAxis16.setLabel("");
        java.awt.Paint paint22 = dateAxis16.getAxisLinePaint();
        double double23 = dateAxis16.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        dateAxis16.setAxisLineStroke(stroke30);
        dateAxis16.setUpperBound((double) 2);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        dateAxis16.setTickMarkPaint((java.awt.Paint) color34);
        org.jfree.data.Range range36 = dateAxis16.getRange();
        dateAxis16.centerRange((-37.0d));
        try {
            xYPlot0.setRangeAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) dateAxis16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "XY Plot" + "'", str14.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(range36);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis0.getTickUnit();
        double double9 = dateAxis0.getUpperMargin();
        float float10 = dateAxis0.getTickMarkOutsideLength();
        boolean boolean11 = dateAxis0.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        java.awt.Stroke stroke5 = xYPlot0.getDomainZeroBaselineStroke();
        boolean boolean6 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setAutoTickUnitSelection(true, false);
        dateAxis8.setLabel("");
        dateAxis8.setLowerBound((double) (short) 10);
        dateAxis8.setRangeWithMargins((double) 2.0f, (double) '#');
        double double19 = dateAxis8.getLabelAngle();
        java.text.DateFormat dateFormat20 = dateAxis8.getDateFormatOverride();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.CrosshairState crosshairState26 = null;
        boolean boolean27 = xYPlot0.render(graphics2D22, rectangle2D23, 2, plotRenderingInfo25, crosshairState26);
        java.awt.Color color28 = java.awt.Color.white;
        java.awt.Color color29 = color28.brighter();
        int int30 = color29.getRGB();
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color29);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(dateFormat20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setCategoryMargin((double) 11);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("13-June-2019");
        dateAxis5.resizeRange(1.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.setDomainGridlinesVisible(false);
        xYPlot17.setDomainGridlinesVisible(false);
        double double22 = xYPlot17.getDomainCrosshairValue();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot17.setDomainGridlineStroke(stroke23);
        int int25 = xYPlot17.getSeriesCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot17.getRangeAxisEdge();
        try {
            double double27 = categoryAxis1.getCategoryMiddle((int) (byte) 0, 0, rectangle2D16, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        dateAxis0.setVerticalTickLabels(false);
        dateAxis0.setFixedAutoRange(1.0E-8d);
        dateAxis0.setLowerMargin(100.0d);
        org.jfree.chart.axis.Timeline timeline14 = dateAxis0.getTimeline();
        org.junit.Assert.assertNotNull(timeline14);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        try {
            java.awt.Color color1 = java.awt.Color.decode("13-June-2019");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"13-June-2019\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = categoryPlot5.getDrawingSupplier();
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot5.getDatasetGroup();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot5.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot5.getAxisOffset();
        java.util.List list34 = categoryPlot5.getAnnotations();
        categoryPlot5.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke19 = valueMarker18.getOutlineStroke();
        categoryPlot5.setRangeGridlineStroke(stroke19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot5.getDomainAxis();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(categoryAxis21);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        categoryPlot5.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation(1, axisLocation2, false);
        int int5 = categoryPlot0.getDatasetCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getRangeAxisEdge(6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        dateAxis0.setRangeWithMargins((double) 2.0f, (double) '#');
        dateAxis0.setTickMarkOutsideLength((float) (-1));
        dateAxis0.setLowerBound((double) 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 10, plotRenderingInfo13, point2D14, false);
        categoryPlot5.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextOutlinePaint();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        java.awt.Paint paint22 = defaultDrawingSupplier19.getNextFillPaint();
        java.awt.Paint paint23 = defaultDrawingSupplier19.getNextPaint();
        java.lang.Object obj24 = defaultDrawingSupplier19.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        java.awt.Stroke stroke5 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getRangeAxis((-12517377));
        boolean boolean8 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis0.java2DToValue(0.0d, rectangle2D17, rectangleEdge18);
        boolean boolean20 = dateAxis0.isVerticalTickLabels();
        dateAxis0.configure();
        org.jfree.data.Range range22 = dateAxis0.getRange();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation(1, axisLocation2, false);
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.setWeight(1);
        org.junit.Assert.assertNull(axisSpace5);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryLabelPositionOffset((int) ' ');
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "PlotOrientation.VERTICAL");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean3 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Stroke stroke4 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        xYPlot0.axisChanged(axisChangeEvent5);
        boolean boolean7 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        xYPlot0.setDomainAxis(0, valueAxis9, true);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = xYPlot0.getOrientation();
        java.awt.Stroke stroke5 = xYPlot0.getDomainZeroBaselineStroke();
        try {
            java.awt.Paint paint7 = xYPlot0.getQuadrantPaint((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 2);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape6 = dateAxis5.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer7);
        java.awt.Font font9 = dateAxis5.getTickLabelFont();
        categoryAxis0.setLabelFont(font9);
        double double11 = categoryAxis0.getLowerMargin();
        categoryAxis0.setLowerMargin(0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType0, 8.0d, 0.2d, (double) 255, (double) 2.0f);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setAutoTickUnitSelection(true, false);
        dateAxis8.setVerticalTickLabels(false);
        float float14 = dateAxis8.getTickMarkInsideLength();
        boolean boolean15 = lengthAdjustmentType7.equals((java.lang.Object) dateAxis8);
        boolean boolean16 = unitType0.equals((java.lang.Object) boolean15);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 0, (double) 6, 10.0d, (double) 12);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker18, layer21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection23);
        boolean boolean25 = categoryPlot5.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        java.awt.Paint paint3 = valueMarker1.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        valueMarker1.setLabelOffset(rectangleInsets4);
        float float6 = valueMarker1.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType7);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.8f + "'", float6 == 0.8f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setAutoTickUnitSelection(true, false);
        dateAxis4.setLabel("");
        java.awt.Paint paint10 = dateAxis4.getAxisLinePaint();
        double double11 = dateAxis4.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        java.awt.Stroke stroke18 = categoryPlot17.getRangeGridlineStroke();
        dateAxis4.setAxisLineStroke(stroke18);
        dateAxis4.setFixedDimension(0.2d);
        double double22 = dateAxis4.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis4.getStandardTickUnits();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis4.setTimeZone(timeZone24);
        org.jfree.data.Range range26 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            xYPlot0.drawBackground(graphics2D27, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainCrosshairVisible(false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        java.lang.String str8 = dateAxis1.getLabel();
        boolean boolean9 = dateAxis1.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean23 = categoryPlot15.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot15.setRangeCrosshairStroke(stroke30);
        dateAxis1.setTickMarkStroke(stroke30);
        dateAxis1.resizeRange(0.0d, (double) 2.0f);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis36.setNumberFormatOverride(numberFormat37);
        java.text.NumberFormat numberFormat39 = null;
        numberAxis36.setNumberFormatOverride(numberFormat39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer41);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder43 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot42.setSeriesRenderingOrder(seriesRenderingOrder43);
        xYPlot42.mapDatasetToDomainAxis((int) (short) 1, (int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot42.getDomainAxis((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder43);
        org.junit.Assert.assertNull(valueAxis49);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str23 = dateAxis21.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        dateAxis21.setLabelPaint(paint26);
        java.awt.Shape shape28 = dateAxis21.getLeftArrow();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = categoryPlot5.getDrawingSupplier();
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot5.getDatasetGroup();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot5.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot5.getAxisOffset();
        java.util.List list34 = categoryPlot5.getAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot5.zoomDomainAxes((double) (byte) 1, plotRenderingInfo36, point2D37);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke13 = valueMarker12.getOutlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker12.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker12.setLabelPaint((java.awt.Paint) color16);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        categoryPlot5.clearDomainAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 8, (double) 1.0f, (double) ' ');
        double double26 = rectangleInsets24.calculateBottomInset((double) 1.0f);
        double double28 = rectangleInsets24.calculateBottomOutset(32.0d);
        categoryPlot5.setInsets(rectangleInsets24, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot5.zoomDomainAxes((double) 10L, plotRenderingInfo32, point2D33);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("NO_CHANGE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        double double3 = valueMarker1.getValue();
        valueMarker1.setLabel("java.awt.Color[r=255,g=0,b=0]");
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        valueMarker1.setPaint((java.awt.Paint) color6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        double double15 = categoryPlot13.getRangeCrosshairValue();
        boolean boolean16 = categoryPlot13.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setAutoTickUnitSelection(true, false);
        dateAxis18.setLabel("");
        java.awt.Paint paint24 = dateAxis18.getAxisLinePaint();
        double double25 = dateAxis18.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape29 = dateAxis28.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer30);
        java.awt.Stroke stroke32 = categoryPlot31.getRangeGridlineStroke();
        dateAxis18.setAxisLineStroke(stroke32);
        dateAxis18.setFixedDimension(0.2d);
        boolean boolean36 = rectangleInsets17.equals((java.lang.Object) dateAxis18);
        categoryPlot13.setInsets(rectangleInsets17, false);
        double double40 = rectangleInsets17.calculateBottomInset(0.0d);
        valueMarker1.setLabelOffset(rectangleInsets17);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
        categoryPlot42.setRangeAxisLocation(1, axisLocation44, false);
        org.jfree.chart.axis.AxisSpace axisSpace47 = categoryPlot42.getFixedDomainAxisSpace();
        categoryPlot42.setRangeCrosshairLockedOnData(false);
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot42);
        boolean boolean51 = categoryPlot42.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape55 = dateAxis54.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, (org.jfree.chart.axis.ValueAxis) dateAxis54, categoryItemRenderer56);
        java.awt.Stroke stroke58 = categoryPlot57.getRangeGridlineStroke();
        java.awt.Stroke stroke59 = categoryPlot57.getRangeGridlineStroke();
        categoryPlot57.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot57.getRangeAxisLocation((int) (short) 10);
        categoryPlot42.setRangeAxisLocation(axisLocation63, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.0d + "'", double40 == 3.0d);
        org.junit.Assert.assertNull(axisSpace47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(axisLocation63);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setAutoTickUnitSelection(true, false);
        dateAxis13.setLabel("");
        dateAxis13.setLowerBound((double) (short) 10);
        org.jfree.data.Range range21 = dateAxis13.getDefaultAutoRange();
        dateAxis11.setRange(range21);
        dateAxis11.setLabel("UnitType.ABSOLUTE");
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.setAutoTickUnitSelection(true, false);
        dateAxis25.setLabel("");
        dateAxis25.setLowerBound((double) (short) 10);
        dateAxis25.setRangeWithMargins((double) 2.0f, (double) '#');
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis25.getTickUnit();
        java.util.Date date37 = dateAxis11.calculateHighestVisibleTickValue(dateTickUnit36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        dateAxis39.setAutoTickUnitSelection(true, false);
        dateAxis39.setLabel("");
        java.awt.Paint paint45 = dateAxis39.getAxisLinePaint();
        double double46 = dateAxis39.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape50 = dateAxis49.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis49, categoryItemRenderer51);
        java.awt.Stroke stroke53 = categoryPlot52.getRangeGridlineStroke();
        dateAxis39.setAxisLineStroke(stroke53);
        dateAxis39.setFixedDimension(0.2d);
        boolean boolean57 = rectangleInsets38.equals((java.lang.Object) dateAxis39);
        double double59 = rectangleInsets38.calculateLeftOutset((double) '4');
        double double61 = rectangleInsets38.extendHeight((double) (-12517377));
        dateAxis11.setTickLabelInsets(rectangleInsets38);
        java.awt.Stroke stroke63 = dateAxis11.getTickMarkStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 3.0d + "'", double59 == 3.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + (-1.2517371E7d) + "'", double61 == (-1.2517371E7d));
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        java.lang.Object obj3 = objectList1.get((-1));
        java.lang.Object obj4 = objectList1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot10.axisChanged(axisChangeEvent11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot10.getRenderer(8);
        boolean boolean15 = categoryPlot10.isDomainZoomable();
        java.awt.Stroke stroke16 = categoryPlot10.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        java.awt.Stroke stroke24 = categoryPlot23.getRangeGridlineStroke();
        categoryPlot23.setAnchorValue((double) 10L, false);
        boolean boolean28 = categoryPlot23.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean31 = categoryPlot23.removeDomainMarker(marker29, layer30);
        java.util.Collection collection32 = categoryPlot10.getDomainMarkers((int) (byte) 1, layer30);
        int int33 = objectList1.indexOf((java.lang.Object) (byte) 1);
        objectList1.clear();
        java.lang.Object obj35 = objectList1.clone();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape5 = dateAxis4.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        categoryPlot7.axisChanged(axisChangeEvent8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot7.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot7.zoomDomainAxes((double) (-1L), plotRenderingInfo13, point2D14, false);
        categoryPlot7.setAnchorValue((double) 0);
        java.awt.Paint paint19 = categoryPlot7.getBackgroundPaint();
        org.jfree.chart.util.ObjectList objectList20 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj21 = objectList20.clone();
        int int22 = objectList20.size();
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot26.setRangeAxisLocation(1, axisLocation28, false);
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot26.getFixedDomainAxisSpace();
        java.awt.Stroke stroke32 = categoryPlot26.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor36 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke39 = valueMarker38.getOutlineStroke();
        java.awt.Stroke stroke40 = valueMarker38.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color25, stroke32, (java.awt.Paint) chartColor36, stroke40, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer43 = null;
        intervalMarker42.setGradientPaintTransformer(gradientPaintTransformer43);
        int int45 = objectList20.indexOf((java.lang.Object) gradientPaintTransformer43);
        boolean boolean46 = categoryPlot7.equals((java.lang.Object) objectList20);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot7);
        categoryAxis0.setUpperMargin((-1.2517371E7d));
        double double50 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("CategoryAnchor.MIDDLE");
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SortOrder.ASCENDING");
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        java.awt.Stroke stroke8 = categoryPlot5.getOutlineStroke();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(0, axisLocation4, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        boolean boolean9 = categoryMarker8.getDrawAsLine();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot16.axisChanged(axisChangeEvent17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot16.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot16.zoomDomainAxes((double) (-1L), plotRenderingInfo22, point2D23, false);
        categoryPlot16.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot16.getRangeAxisEdge();
        boolean boolean29 = rectangleAnchor10.equals((java.lang.Object) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = dateAxis33.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        java.awt.Stroke stroke37 = categoryPlot36.getRangeGridlineStroke();
        categoryPlot36.setAnchorValue((double) 10L, false);
        boolean boolean41 = categoryPlot36.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker42 = null;
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean44 = categoryPlot36.removeDomainMarker(marker42, layer43);
        java.util.Collection collection45 = categoryPlot16.getDomainMarkers((int) '4', layer43);
        boolean boolean46 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer43);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        xYPlot0.setDataset((int) '#', xYDataset48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 10, 4.2d, plotRenderingInfo52, point2D53);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        java.awt.Stroke stroke8 = categoryPlot5.getOutlineStroke();
        categoryPlot5.configureDomainAxes();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        categoryPlot17.axisChanged(axisChangeEvent18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot17.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot17.zoomDomainAxes((double) (-1L), plotRenderingInfo23, point2D24, false);
        categoryPlot17.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot17.getRangeAxisEdge();
        boolean boolean30 = rectangleAnchor11.equals((java.lang.Object) categoryPlot17);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape35 = dateAxis34.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer36);
        java.awt.Stroke stroke38 = categoryPlot37.getRangeGridlineStroke();
        categoryPlot37.setAnchorValue((double) 10L, false);
        boolean boolean42 = categoryPlot37.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker43 = null;
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean45 = categoryPlot37.removeDomainMarker(marker43, layer44);
        java.util.Collection collection46 = categoryPlot17.getDomainMarkers((int) '4', layer44);
        java.util.Collection collection47 = categoryPlot5.getDomainMarkers(0, layer44);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNull(collection47);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Font font6 = dateAxis2.getTickLabelFont();
        dateAxis2.setRangeAboutValue(0.0d, 0.0d);
        boolean boolean10 = dateAxis2.isAutoRange();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        java.lang.String str2 = day1.toString();
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
//        dateAxis3.setAutoTickUnitSelection(true, false);
//        dateAxis3.setVerticalTickLabels(false);
//        float float9 = dateAxis3.getTickMarkInsideLength();
//        java.lang.String str10 = dateAxis3.getLabel();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis3.getTickUnit();
//        dateAxis3.setAutoTickUnitSelection(true);
//        java.awt.Font font14 = dateAxis3.getLabelFont();
//        int int15 = day1.compareTo((java.lang.Object) dateAxis3);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(dateTickUnit11);
//        org.junit.Assert.assertNotNull(font14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        boolean boolean8 = lengthAdjustmentType0.equals((java.lang.Object) dateAxis1);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        categoryPlot14.clearRangeAxes();
        boolean boolean18 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot14);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            boolean boolean20 = categoryPlot14.removeAnnotation(categoryAnnotation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape17 = dateAxis16.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        java.awt.Paint paint20 = dateAxis16.getLabelPaint();
        dateAxis16.setLowerMargin(100.0d);
        categoryPlot5.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis16, true);
        dateAxis16.setTickMarkOutsideLength((float) 10L);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(6);
        java.awt.Stroke stroke7 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Image image8 = xYPlot0.getBackgroundImage();
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        float float4 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        java.awt.Stroke stroke15 = categoryPlot13.getRangeGridlineStroke();
        categoryPlot13.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot13.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation19, plotOrientation20);
        xYPlot5.setOrientation(plotOrientation20);
        xYPlot5.mapDatasetToRangeAxis(13, 6);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot5.setRangeAxisLocation(500, axisLocation27, false);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape7 = dateAxis6.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, categoryItemRenderer8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        categoryPlot9.axisChanged(axisChangeEvent10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot9.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot9.zoomDomainAxes((double) (-1L), plotRenderingInfo15, point2D16, false);
        categoryPlot9.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot9.getRangeAxisEdge();
        boolean boolean22 = rectangleAnchor3.equals((java.lang.Object) categoryPlot9);
        try {
            java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) 0.0f, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        java.lang.Class<?> wildcardClass7 = xYPlot0.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.util.List list16 = categoryPlot15.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = dateAxis22.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getRangeGridlineStroke();
        categoryPlot25.setAnchorValue((double) 10L, false);
        boolean boolean30 = categoryPlot25.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker31 = null;
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean33 = categoryPlot25.removeDomainMarker(marker31, layer32);
        categoryPlot15.addDomainMarker(2, categoryMarker19, layer32);
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        java.awt.Stroke stroke36 = categoryPlot5.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(list16);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.String str2 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str2.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        categoryPlot14.axisChanged(axisChangeEvent15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint19 = valueMarker18.getPaint();
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker18, layer21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection23);
        categoryPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot5.addChangeListener(plotChangeListener27);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape32 = dateAxis31.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer33);
        java.awt.Stroke stroke35 = categoryPlot34.getRangeGridlineStroke();
        double double36 = categoryPlot34.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot34.zoomDomainAxes((double) 255, plotRenderingInfo38, point2D39);
        int int41 = categoryPlot34.getDomainAxisCount();
        boolean boolean42 = categoryPlot34.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot34.getDomainAxisLocation((int) (byte) -1);
        categoryPlot5.setDomainAxisLocation(axisLocation44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray47 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer46 };
        categoryPlot5.setRenderers(categoryItemRendererArray47);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot5.setDomainAxis((int) '#', categoryAxis50, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot5.setRenderer(1, categoryItemRenderer54, true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(categoryItemRendererArray47);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        boolean boolean11 = categoryPlot5.isOutlineVisible();
        java.awt.Stroke stroke12 = categoryPlot5.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint10 = valueMarker9.getPaint();
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        java.awt.Color color12 = java.awt.Color.white;
        java.awt.Color color13 = color12.brighter();
        valueMarker9.setOutlinePaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.setRangeCrosshairValue((double) 10);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setAutoTickUnitSelection(true, false);
        dateAxis6.setVerticalTickLabels(false);
        float float12 = dateAxis6.getTickMarkInsideLength();
        java.lang.String str13 = dateAxis6.getLabel();
        boolean boolean14 = dateAxis6.isAutoRange();
        dateAxis6.setLabel("org.jfree.chart.event.ChartChangeEvent[source=10]");
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape22 = dateAxis21.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getRangeGridlineStroke();
        categoryPlot24.setAnchorValue((double) 10L, false);
        boolean boolean29 = categoryPlot24.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        categoryPlot24.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        dateAxis32.setAutoTickUnitSelection(true, false);
        dateAxis32.setLabel("");
        dateAxis32.setLowerBound((double) (short) 10);
        org.jfree.data.Range range40 = dateAxis32.getDefaultAutoRange();
        dateAxis30.setRange(range40);
        dateAxis30.setLabel("UnitType.ABSOLUTE");
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        dateAxis44.setAutoTickUnitSelection(true, false);
        dateAxis44.setLabel("");
        dateAxis44.setLowerBound((double) (short) 10);
        dateAxis44.setRangeWithMargins((double) 2.0f, (double) '#');
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = dateAxis44.getTickUnit();
        java.util.Date date56 = dateAxis30.calculateHighestVisibleTickValue(dateTickUnit55);
        xYPlot0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis) dateAxis30);
        java.awt.Graphics2D graphics2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape63 = dateAxis62.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, (org.jfree.chart.axis.ValueAxis) dateAxis62, categoryItemRenderer64);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent66 = null;
        categoryPlot65.axisChanged(axisChangeEvent66);
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint70 = valueMarker69.getPaint();
        categoryPlot65.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker69);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        java.awt.geom.Point2D point2D74 = null;
        categoryPlot65.zoomDomainAxes((double) (byte) 10, plotRenderingInfo73, point2D74, false);
        categoryPlot65.setOutlineVisible(false);
        java.awt.Stroke stroke79 = categoryPlot65.getOutlineStroke();
        java.util.List list80 = categoryPlot65.getAnnotations();
        xYPlot0.drawDomainTickBands(graphics2D58, rectangle2D59, list80);
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(dateTickUnit55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(list80);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxisForDataset(0);
        boolean boolean3 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Stroke stroke4 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        java.awt.Stroke stroke12 = categoryPlot11.getRangeGridlineStroke();
        double double13 = categoryPlot11.getRangeCrosshairValue();
        boolean boolean14 = categoryPlot11.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        boolean boolean19 = categoryPlot11.render(graphics2D15, rectangle2D16, (int) (short) 10, plotRenderingInfo18);
        categoryPlot11.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot11.setRenderer(categoryItemRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str25 = axisLocation24.toString();
        categoryPlot11.setDomainAxisLocation(axisLocation24);
        xYPlot0.setRangeAxisLocation(6, axisLocation24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot0.getRenderer();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str25.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNull(xYItemRenderer28);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setAutoTickUnitSelection(true, false);
        dateAxis1.setVerticalTickLabels(false);
        float float7 = dateAxis1.getTickMarkInsideLength();
        java.lang.String str8 = dateAxis1.getLabel();
        boolean boolean9 = dateAxis1.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.awt.Stroke stroke16 = categoryPlot15.getRangeGridlineStroke();
        categoryPlot15.setAnchorValue((double) 10L, false);
        boolean boolean20 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean23 = categoryPlot15.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape27 = dateAxis26.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer28);
        java.awt.Stroke stroke30 = categoryPlot29.getRangeGridlineStroke();
        categoryPlot15.setRangeCrosshairStroke(stroke30);
        dateAxis1.setTickMarkStroke(stroke30);
        dateAxis1.resizeRange(0.0d, (double) 2.0f);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat37 = null;
        numberAxis36.setNumberFormatOverride(numberFormat37);
        java.text.NumberFormat numberFormat39 = null;
        numberAxis36.setNumberFormatOverride(numberFormat39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer41);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder43 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot42.setSeriesRenderingOrder(seriesRenderingOrder43);
        xYPlot42.clearRangeMarkers((int) '4');
        java.lang.Object obj47 = null;
        boolean boolean48 = xYPlot42.equals(obj47);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(seriesRenderingOrder43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot5.getRenderer(0);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot5.getRangeAxisLocation((int) (byte) 10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis0.java2DToValue(0.0d, rectangle2D17, rectangleEdge18);
        double double20 = dateAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        xYPlot0.clearRangeMarkers(1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getDomainAxis();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot5.getRenderer(0);
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot5.zoomRangeAxes(0.0d, 6.0d, plotRenderingInfo17, point2D18);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNull(categoryItemRenderer12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        xYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomRangeAxes((double) 9, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getRangeGridlineStroke();
        double double16 = categoryPlot14.getRangeCrosshairValue();
        boolean boolean17 = categoryPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        boolean boolean22 = categoryPlot14.render(graphics2D18, rectangle2D19, (int) (short) 10, plotRenderingInfo21);
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot14.setRenderer(categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str28 = axisLocation27.toString();
        categoryPlot14.setDomainAxisLocation(axisLocation27);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = dateAxis33.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = null;
        categoryPlot36.axisChanged(axisChangeEvent37);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint41 = valueMarker40.getPaint();
        categoryPlot36.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot36.zoomDomainAxes((double) (byte) 10, plotRenderingInfo44, point2D45, false);
        categoryPlot36.setOutlineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot36.setDomainAxisLocation(10, axisLocation51, true);
        categoryPlot14.setDomainAxisLocation(0, axisLocation51, false);
        xYPlot0.setDomainAxisLocation((int) '#', axisLocation51, true);
        xYPlot0.mapDatasetToDomainAxis((int) (short) 1, 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str28.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(axisLocation51);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        org.jfree.chart.axis.ValueAxis valueAxis47 = xYPlot0.getDomainAxis((int) (short) 10);
        java.awt.Stroke stroke48 = xYPlot0.getRangeCrosshairStroke();
        xYPlot0.configureRangeAxes();
        xYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        org.jfree.chart.axis.ValueAxis valueAxis47 = xYPlot0.getDomainAxis((int) (short) 10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray49 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer48 };
        xYPlot0.setRenderers(xYItemRendererArray49);
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = xYPlot0.getRendererForDataset(xYDataset51);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(xYItemRendererArray49);
        org.junit.Assert.assertNull(xYItemRenderer52);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        boolean boolean7 = dateAxis0.isInverted();
        java.lang.String str8 = dateAxis0.getLabel();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        dateAxis9.setAutoTickUnitSelection(true, false);
        dateAxis9.setLabel("");
        dateAxis9.setLowerBound((double) (short) 10);
        dateAxis9.setRangeWithMargins((double) 2.0f, (double) '#');
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis9.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit20, false, true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(dateTickUnit20);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.util.List list6 = categoryPlot5.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot5.zoomDomainAxes((double) 0.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke13 = valueMarker12.getOutlineStroke();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        valueMarker12.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        valueMarker12.setLabelPaint((java.awt.Paint) color16);
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker12);
        double double19 = valueMarker12.getValue();
        valueMarker12.setLabel("org.jfree.chart.event.ChartChangeEvent[source=10]");
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape13 = dateAxis12.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer14);
        java.util.List list16 = categoryPlot15.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape23 = dateAxis22.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer24);
        java.awt.Stroke stroke26 = categoryPlot25.getRangeGridlineStroke();
        categoryPlot25.setAnchorValue((double) 10L, false);
        boolean boolean30 = categoryPlot25.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker31 = null;
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean33 = categoryPlot25.removeDomainMarker(marker31, layer32);
        categoryPlot15.addDomainMarker(2, categoryMarker19, layer32);
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = null;
        categoryPlot5.setFixedLegendItems(legendItemCollection36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot5.getRangeAxisLocation((int) (short) 10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(list16);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Color color1 = color0.brighter();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        int int8 = color1.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke6);
        int int8 = xYPlot0.getSeriesCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot0.getRangeAxisEdge();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getDomainAxisForDataset(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 255 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        xYPlot0.setDomainGridlinesVisible(false);
        double double5 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot11.axisChanged(axisChangeEvent12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint16 = valueMarker15.getPaint();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint26 = valueMarker25.getPaint();
        double double27 = valueMarker25.getValue();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker25.setLabelTextAnchor(textAnchor28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape33 = dateAxis32.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getRangeGridlineStroke();
        categoryPlot35.setAnchorValue((double) 10L, false);
        boolean boolean40 = categoryPlot35.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean43 = categoryPlot35.removeDomainMarker(marker41, layer42);
        boolean boolean44 = categoryPlot11.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer42);
        java.util.Collection collection45 = xYPlot0.getRangeMarkers(layer42);
        java.awt.Paint paint46 = xYPlot0.getRangeGridlinePaint();
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_CYAN;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color47);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(color47);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) 6);
        double double4 = rectangleInsets0.extendHeight((double) 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.0d + "'", double2 == 12.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.5d + "'", double4 == 6.5d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        float float4 = dateAxis2.getTickMarkInsideLength();
        java.awt.Stroke stroke5 = dateAxis2.getTickMarkStroke();
        boolean boolean6 = rectangleAnchor1.equals((java.lang.Object) stroke5);
        try {
            java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape8 = dateAxis7.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        java.awt.Stroke stroke11 = categoryPlot10.getRangeGridlineStroke();
        categoryPlot10.setAnchorValue((double) 10L, false);
        boolean boolean15 = categoryPlot10.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean18 = categoryPlot10.removeDomainMarker(marker16, layer17);
        try {
            xYPlot0.addRangeMarker(marker4, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("AxisLocation.TOP_OR_LEFT", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", timeZone2);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        java.awt.Paint paint3 = valueMarker1.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        valueMarker1.setLabelOffset(rectangleInsets4);
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            valueMarker1.setLabelTextAnchor(textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot5.render(graphics2D9, rectangle2D10, (int) (short) 10, plotRenderingInfo12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        int int16 = categoryAxis15.getMaximumCategoryLabelLines();
        java.awt.Font font18 = categoryAxis15.getTickLabelFont((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT");
        categoryPlot5.setDomainAxis(0, categoryAxis15, false);
        int int21 = categoryPlot5.getDomainAxisCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        double double7 = dateAxis0.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        java.awt.Stroke stroke14 = categoryPlot13.getRangeGridlineStroke();
        dateAxis0.setAxisLineStroke(stroke14);
        dateAxis0.setUpperBound((double) 2);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        dateAxis0.setTickMarkPaint((java.awt.Paint) color18);
        org.jfree.data.Range range20 = dateAxis0.getRange();
        dateAxis0.centerRange((-37.0d));
        dateAxis0.setInverted(true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setVerticalTickLabels(false);
        float float6 = dateAxis0.getTickMarkInsideLength();
        java.lang.String str7 = dateAxis0.getLabel();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis0.valueToJava2D((double) 2, rectangle2D9, rectangleEdge10);
        dateAxis0.resizeRange((double) ' ');
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape4 = dateAxis3.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        categoryPlot6.axisChanged(axisChangeEvent7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot6.getRenderer(8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer15);
        java.awt.Stroke stroke17 = categoryPlot16.getRangeGridlineStroke();
        categoryPlot16.setAnchorValue((double) 10L, false);
        boolean boolean21 = categoryPlot16.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        categoryPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.lang.String str24 = dateAxis22.getLabelURL();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint27 = valueMarker26.getPaint();
        dateAxis22.setLabelPaint(paint27);
        java.awt.Shape shape29 = dateAxis22.getLeftArrow();
        categoryPlot6.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition31 = dateAxis22.getTickMarkPosition();
        java.util.TimeZone timeZone32 = dateAxis22.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("", timeZone32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setAutoTickUnitSelection(true, false);
        dateAxis34.setLabel("");
        java.lang.Object obj40 = dateAxis34.clone();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape44 = dateAxis43.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis43, categoryItemRenderer45);
        double double47 = dateAxis43.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape51 = dateAxis50.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer52);
        java.awt.Stroke stroke54 = categoryPlot53.getRangeGridlineStroke();
        categoryPlot53.setAnchorValue((double) 10L, false);
        boolean boolean58 = categoryPlot53.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis();
        categoryPlot53.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis59);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        dateAxis61.setAutoTickUnitSelection(true, false);
        dateAxis61.setLabel("");
        dateAxis61.setLowerBound((double) (short) 10);
        org.jfree.data.Range range69 = dateAxis61.getDefaultAutoRange();
        dateAxis59.setRange(range69);
        dateAxis43.setRange(range69);
        dateAxis34.setRange(range69);
        dateAxis33.setRange(range69, false, false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(dateTickMarkPosition31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(range69);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot5.zoomDomainAxes((double) 255, plotRenderingInfo9, point2D10);
        int int12 = categoryPlot5.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot5.getRendererForDataset(categoryDataset13);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        boolean boolean7 = dateAxis0.isVisible();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape11 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        categoryPlot13.axisChanged(axisChangeEvent14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint18 = valueMarker17.getPaint();
        categoryPlot13.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(8.0d);
        categoryPlot13.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot13.setNoDataMessageFont(font23);
        dateAxis0.setLabelFont(font23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace29 = xYPlot26.getFixedRangeAxisSpace();
        xYPlot26.setRangeCrosshairValue((double) 10);
        boolean boolean32 = dateAxis0.hasListener((java.util.EventListener) xYPlot26);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot26.getRangeAxisLocation(7);
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot26.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNull(axisSpace35);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot5.removeChangeListener(plotChangeListener10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        categoryPlot5.setBackgroundImageAlignment(100);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(plot12);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.jfree.chart.JFreeChart jFreeChart1 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 10, jFreeChart1);
//        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent2.getChart();
//        org.jfree.chart.JFreeChart jFreeChart5 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 10, jFreeChart5);
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
//        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) (short) 1);
//        chartChangeEvent6.setType(chartChangeEventType7);
//        org.jfree.chart.util.UnitType unitType11 = org.jfree.chart.util.UnitType.ABSOLUTE;
//        java.lang.String str12 = unitType11.toString();
//        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType11, 8.0d, 0.2d, (double) 255, (double) 2.0f);
//        java.lang.String str18 = unitType11.toString();
//        java.lang.String str19 = unitType11.toString();
//        boolean boolean20 = chartChangeEventType7.equals((java.lang.Object) str19);
//        chartChangeEvent2.setType(chartChangeEventType7);
//        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
//        long long26 = day25.getSerialIndex();
//        boolean boolean27 = chartChangeEventType7.equals((java.lang.Object) day25);
//        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day25);
//        org.junit.Assert.assertNull(jFreeChart3);
//        org.junit.Assert.assertNotNull(chartChangeEventType7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(unitType11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnitType.ABSOLUTE" + "'", str12.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UnitType.ABSOLUTE" + "'", str18.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UnitType.ABSOLUTE" + "'", str19.equals("UnitType.ABSOLUTE"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43629L + "'", long26 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = xYPlot0.getAxisOffset();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot0.getSeriesRenderingOrder();
        xYPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setCategoryMargin((double) 11);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("13-June-2019");
        dateAxis5.resizeRange(1.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer8);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape16 = dateAxis15.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis15, categoryItemRenderer17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        categoryPlot18.axisChanged(axisChangeEvent19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot18.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot18.zoomDomainAxes((double) (-1L), plotRenderingInfo24, point2D25, false);
        categoryPlot18.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot18.getRangeAxisEdge();
        try {
            double double31 = categoryAxis1.getCategoryMiddle((int) (byte) 10, (-12517377), rectangle2D12, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot5.getIndexOf(categoryItemRenderer8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color10);
        categoryPlot5.setWeight(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot5.handleClick((int) (short) -1, 4, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        categoryPlot5.setAnchorValue((double) 10L, false);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot5.getRangeAxis((int) (byte) 100);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot5.setDomainGridlineStroke(stroke13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        double double17 = categoryAxis16.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        categoryPlot23.axisChanged(axisChangeEvent24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot23.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot23.zoomDomainAxes((double) (-1L), plotRenderingInfo29, point2D30, false);
        categoryPlot23.setAnchorValue((double) 0);
        java.awt.Paint paint35 = categoryPlot23.getBackgroundPaint();
        org.jfree.chart.util.ObjectList objectList36 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj37 = objectList36.clone();
        int int38 = objectList36.size();
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
        categoryPlot42.setRangeAxisLocation(1, axisLocation44, false);
        org.jfree.chart.axis.AxisSpace axisSpace47 = categoryPlot42.getFixedDomainAxisSpace();
        java.awt.Stroke stroke48 = categoryPlot42.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor52 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke55 = valueMarker54.getOutlineStroke();
        java.awt.Stroke stroke56 = valueMarker54.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker58 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color41, stroke48, (java.awt.Paint) chartColor52, stroke56, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer59 = null;
        intervalMarker58.setGradientPaintTransformer(gradientPaintTransformer59);
        int int61 = objectList36.indexOf((java.lang.Object) gradientPaintTransformer59);
        boolean boolean62 = categoryPlot23.equals((java.lang.Object) objectList36);
        categoryAxis16.setPlot((org.jfree.chart.plot.Plot) categoryPlot23);
        categoryAxis16.setUpperMargin((-1.2517371E7d));
        try {
            categoryPlot5.setDomainAxis((-1), categoryAxis16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNull(axisSpace47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot5.getRangeAxisEdge();
        categoryPlot5.setForegroundAlpha((float) (short) 1);
        float float20 = categoryPlot5.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape24 = dateAxis23.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer25);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = null;
        categoryPlot26.axisChanged(axisChangeEvent27);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint31 = valueMarker30.getPaint();
        categoryPlot26.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker30);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = categoryPlot26.getDomainGridlinePosition();
        java.lang.String str34 = categoryAnchor33.toString();
        categoryPlot5.setDomainGridlinePosition(categoryAnchor33);
        categoryPlot5.setDrawSharedDomainAxis(false);
        java.awt.Color color38 = java.awt.Color.RED;
        java.awt.Color color39 = color38.brighter();
        int int40 = color39.getRed();
        java.awt.Color color41 = java.awt.Color.RED;
        java.awt.Color color42 = java.awt.Color.orange;
        float[] floatArray43 = null;
        float[] floatArray44 = color42.getComponents(floatArray43);
        float[] floatArray45 = color41.getRGBColorComponents(floatArray44);
        float[] floatArray46 = color39.getColorComponents(floatArray45);
        categoryPlot5.setOutlinePaint((java.awt.Paint) color39);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape52 = dateAxis51.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer53);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent55 = null;
        categoryPlot54.axisChanged(axisChangeEvent55);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = categoryPlot54.getRenderer(8);
        boolean boolean59 = categoryPlot54.isDomainZoomable();
        java.awt.Stroke stroke60 = categoryPlot54.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape65 = dateAxis64.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, (org.jfree.chart.axis.ValueAxis) dateAxis64, categoryItemRenderer66);
        java.awt.Stroke stroke68 = categoryPlot67.getRangeGridlineStroke();
        categoryPlot67.setAnchorValue((double) 10L, false);
        boolean boolean72 = categoryPlot67.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker73 = null;
        org.jfree.chart.util.Layer layer74 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean75 = categoryPlot67.removeDomainMarker(marker73, layer74);
        java.util.Collection collection76 = categoryPlot54.getDomainMarkers((int) (byte) 1, layer74);
        java.util.Collection collection77 = categoryPlot5.getDomainMarkers((int) '#', layer74);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str34.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNull(categoryItemRenderer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(layer74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNull(collection76);
        org.junit.Assert.assertNull(collection77);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(true, false);
        dateAxis0.setLabel("");
        dateAxis0.setLowerBound((double) (short) 10);
        dateAxis0.setVerticalTickLabels(false);
        dateAxis0.setFixedAutoRange(1.0E-8d);
        dateAxis0.setLowerMargin(100.0d);
        try {
            dateAxis0.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot5.getRenderer(0);
        java.util.List list13 = categoryPlot5.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot5.getRenderer((int) (byte) 100);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNull(list13);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        categoryPlot5.axisChanged(axisChangeEvent6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot5.getRenderer(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) (-1L), plotRenderingInfo11, point2D12, false);
        categoryPlot5.setAnchorValue((double) 0);
        java.awt.Paint paint17 = categoryPlot5.getBackgroundPaint();
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj19 = objectList18.clone();
        int int20 = objectList18.size();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot24.setRangeAxisLocation(1, axisLocation26, false);
        org.jfree.chart.axis.AxisSpace axisSpace29 = categoryPlot24.getFixedDomainAxisSpace();
        java.awt.Stroke stroke30 = categoryPlot24.getRangeGridlineStroke();
        org.jfree.chart.ChartColor chartColor34 = new org.jfree.chart.ChartColor(255, 0, (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Stroke stroke37 = valueMarker36.getOutlineStroke();
        java.awt.Stroke stroke38 = valueMarker36.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker(0.0d, 1.0d, (java.awt.Paint) color23, stroke30, (java.awt.Paint) chartColor34, stroke38, (float) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer41 = null;
        intervalMarker40.setGradientPaintTransformer(gradientPaintTransformer41);
        int int43 = objectList18.indexOf((java.lang.Object) gradientPaintTransformer41);
        boolean boolean44 = categoryPlot5.equals((java.lang.Object) objectList18);
        java.lang.Object obj45 = null;
        int int46 = objectList18.indexOf(obj45);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape3 = dateAxis2.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, categoryItemRenderer4);
        java.awt.Stroke stroke6 = categoryPlot5.getRangeGridlineStroke();
        double double7 = categoryPlot5.getRangeCrosshairValue();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setAutoTickUnitSelection(true, false);
        dateAxis10.setLabel("");
        java.awt.Paint paint16 = dateAxis10.getAxisLinePaint();
        double double17 = dateAxis10.getUpperBound();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer22);
        java.awt.Stroke stroke24 = categoryPlot23.getRangeGridlineStroke();
        dateAxis10.setAxisLineStroke(stroke24);
        dateAxis10.setFixedDimension(0.2d);
        boolean boolean28 = rectangleInsets9.equals((java.lang.Object) dateAxis10);
        categoryPlot5.setInsets(rectangleInsets9, false);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape34 = dateAxis33.getDownArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = null;
        categoryPlot36.axisChanged(axisChangeEvent37);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 10.0f);
        java.awt.Paint paint41 = valueMarker40.getPaint();
        categoryPlot36.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot36.zoomDomainAxes((double) (byte) 10, plotRenderingInfo44, point2D45, false);
        categoryPlot36.setOutlineVisible(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint51 = defaultDrawingSupplier50.getNextOutlinePaint();
        categoryPlot36.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier50);
        java.awt.Paint paint53 = defaultDrawingSupplier50.getNextFillPaint();
        categoryPlot5.setDomainGridlinePaint(paint53);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        categoryPlot5.setRenderer(8, categoryItemRenderer56, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint53);
    }
}

