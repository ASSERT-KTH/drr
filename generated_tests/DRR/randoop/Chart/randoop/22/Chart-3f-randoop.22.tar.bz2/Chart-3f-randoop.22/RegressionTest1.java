import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.addPropertyChangeListener(propertyChangeListener22);
        long long24 = timeSeries21.getMaximumItemAge();
        java.lang.Comparable comparable25 = timeSeries21.getKey();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo33 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year27, seriesChangeInfo33);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
        long long41 = timeSeries38.getMaximumItemAge();
        java.lang.Comparable comparable42 = timeSeries38.getKey();
        boolean boolean43 = year27.equals((java.lang.Object) timeSeries38);
        java.lang.Number number44 = null;
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year27, number44, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year27);
        java.lang.Object obj48 = timeSeries3.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 100.0d + "'", comparable25.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 100.0d + "'", comparable42.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(obj48);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.clear();
        timeSeries3.removeAgedItems(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.addChangeListener(seriesChangeListener13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries3.addChangeListener(seriesChangeListener15);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        timeSeriesDataItem14.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        long long27 = timeSeries24.getMaximumItemAge();
        java.lang.Comparable comparable28 = timeSeries24.getKey();
        java.util.Collection collection29 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        long long43 = year39.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year39.previous();
        int int45 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year39.previous();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 100.0d + "'", comparable28.equals(100.0d));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-62119972800001L) + "'", long43 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        timeSeries3.setRangeDescription("");
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=4]");
        timeSeries3.removeAgedItems(0L, true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries7.getKey();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener13);
        int int15 = day3.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) -1, seriesChangeInfo17);
        int int19 = day3.compareTo((java.lang.Object) seriesChangeEvent18);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day3);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getFirstMillisecond(calendar10);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) day5);
//        java.lang.Number number7 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, number7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
//        java.lang.String str10 = day5.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        java.lang.String str38 = timeSeries3.getDomainDescription();
        int int39 = timeSeries3.getItemCount();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(9, 4);
        long long43 = month42.getFirstMillisecond();
        int int44 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month42);
        boolean boolean46 = month42.equals((java.lang.Object) 1560184995077L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-62020051200000L) + "'", long43 == (-62020051200000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("31-December-1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        java.lang.String str7 = month6.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185055130L + "'", long1 == 1560185055130L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185055130L + "'", long2 == 1560185055130L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185055130L + "'", long4 == 1560185055130L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0);
        timeSeries1.setNotify(true);
        timeSeries1.removeAgedItems(9223372036854775807L, true);
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
        long long14 = timeSeries11.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        long long23 = timeSeries20.getMaximumItemAge();
        java.lang.Comparable comparable24 = timeSeries20.getKey();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year26, seriesChangeInfo32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        boolean boolean42 = year26.equals((java.lang.Object) timeSeries37);
        java.lang.Number number43 = null;
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year26, number43, false);
        java.lang.String str46 = timeSeries11.getDomainDescription();
        java.util.Collection collection47 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = null;
        try {
            timeSeries1.delete(regularTimePeriod48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100.0d + "'", comparable24.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertNotNull(collection47);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
//        boolean boolean9 = timeSeries3.getNotify();
//        timeSeries3.clear();
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
//        java.util.Calendar calendar16 = null;
//        fixedMillisecond12.peg(calendar16);
//        long long18 = fixedMillisecond12.getLastMillisecond();
//        int int19 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries3.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185055185L + "'", long13 == 1560185055185L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185055185L + "'", long14 == 1560185055185L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560185055185L + "'", long18 == 1560185055185L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.next();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        long long34 = month33.getLastMillisecond();
        long long35 = month33.getLastMillisecond();
        long long36 = month33.getFirstMillisecond();
        org.jfree.data.time.Year year37 = month33.getYear();
        int int38 = month33.getMonth();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62104204800001L) + "'", long34 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62104204800001L) + "'", long35 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-62106883200000L) + "'", long36 == (-62106883200000L));
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo54 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year48, seriesChangeInfo54);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries59.addPropertyChangeListener(propertyChangeListener60);
        long long62 = timeSeries59.getMaximumItemAge();
        java.lang.Comparable comparable63 = timeSeries59.getKey();
        boolean boolean64 = year48.equals((java.lang.Object) timeSeries59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year48.next();
        boolean boolean67 = year48.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (byte) 0);
        timeSeries3.setDomainDescription("hi!");
        timeSeries3.clear();
        java.util.List list73 = timeSeries3.getItems();
        boolean boolean74 = timeSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable63 + "' != '" + 100.0d + "'", comparable63.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertNotNull(list73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.Year year34 = month33.getYear();
        int int35 = month33.getMonth();
        java.util.Calendar calendar36 = null;
        try {
            long long37 = month33.getLastMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 12 + "'", int35 == 12);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.clear();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Date date7 = fixedMillisecond1.getTime();
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getLastMillisecond(calendar4);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560185055450L + "'", long5 == 1560185055450L);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        long long26 = timeSeries23.getMaximumItemAge();
        java.lang.Comparable comparable27 = timeSeries23.getKey();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year29, seriesChangeInfo35);
        int int37 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj42 = timeSeries41.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries46.addPropertyChangeListener(propertyChangeListener47);
        long long49 = timeSeries46.getMaximumItemAge();
        java.lang.Comparable comparable50 = timeSeries46.getKey();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) 7, false);
        long long56 = year52.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year52, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year52.previous();
        int int60 = timeSeries3.getIndex(regularTimePeriod59);
        java.util.Date date61 = regularTimePeriod59.getStart();
        java.util.TimeZone timeZone62 = null;
        try {
            org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date61, timeZone62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100.0d + "'", comparable27.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + 100.0d + "'", comparable50.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62119972800001L) + "'", long56 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(date61);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185055496L + "'", long1 == 1560185055496L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185055496L + "'", long2 == 1560185055496L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185055496L + "'", long4 == 1560185055496L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        long long16 = timeSeries13.getMaximumItemAge();
        java.lang.Comparable comparable17 = timeSeries13.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 7, false);
        long long38 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year34.previous();
        boolean boolean40 = year19.equals((java.lang.Object) regularTimePeriod39);
        int int41 = year19.getYear();
        java.util.Date date42 = year19.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date42, timeZone44);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date48 = fixedMillisecond47.getTime();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date48, timeZone49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(date48);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date48);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date48);
        int int54 = year53.getYear();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100.0d + "'", comparable17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62119972800001L) + "'", long38 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Date date7 = fixedMillisecond1.getTime();
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getFirstMillisecond(calendar9);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj13 = timeSeries12.clone();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 7, false);
        long long27 = year23.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year23.previous();
        java.lang.Number number31 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.String str32 = timeSeries3.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries3.addOrUpdate(regularTimePeriod33, (java.lang.Number) 1560184988682L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100.0d + "'", comparable21.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62119972800001L) + "'", long27 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo54 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year48, seriesChangeInfo54);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries59.addPropertyChangeListener(propertyChangeListener60);
        long long62 = timeSeries59.getMaximumItemAge();
        java.lang.Comparable comparable63 = timeSeries59.getKey();
        boolean boolean64 = year48.equals((java.lang.Object) timeSeries59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year48.next();
        boolean boolean67 = year48.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timeSeries73.addPropertyChangeListener(propertyChangeListener74);
        long long76 = timeSeries73.getMaximumItemAge();
        java.lang.Comparable comparable77 = timeSeries73.getKey();
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries73.add((org.jfree.data.time.RegularTimePeriod) year79, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year79, (java.lang.Number) (short) 10);
        java.lang.Object obj85 = timeSeriesDataItem84.clone();
        timeSeriesDataItem84.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries90 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem84, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries3.addAndOrUpdate(timeSeries90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = timeSeries3.getNextTimePeriod();
        double double93 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener94 = null;
        timeSeries3.removeChangeListener(seriesChangeListener94);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable63 + "' != '" + 100.0d + "'", comparable63.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 9223372036854775807L + "'", long76 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable77 + "' != '" + 100.0d + "'", comparable77.equals(100.0d));
        org.junit.Assert.assertNotNull(obj85);
        org.junit.Assert.assertNotNull(timeSeries91);
        org.junit.Assert.assertNotNull(regularTimePeriod92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9, seriesChangeInfo15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        long long23 = timeSeries20.getMaximumItemAge();
        java.lang.Comparable comparable24 = timeSeries20.getKey();
        boolean boolean25 = year9.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod26, (java.lang.Number) 10L);
        java.lang.Object obj29 = null;
        boolean boolean30 = timeSeriesDataItem28.equals(obj29);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
        long long41 = timeSeries38.getMaximumItemAge();
        java.lang.Comparable comparable42 = timeSeries38.getKey();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries34.addOrUpdate(timeSeriesDataItem49);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries54.addPropertyChangeListener(propertyChangeListener55);
        long long57 = timeSeries54.getMaximumItemAge();
        java.lang.Comparable comparable58 = timeSeries54.getKey();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries54.add((org.jfree.data.time.RegularTimePeriod) year60, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year60, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo66 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year60, seriesChangeInfo66);
        int int68 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) year60);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj73 = timeSeries72.clone();
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener78 = null;
        timeSeries77.addPropertyChangeListener(propertyChangeListener78);
        long long80 = timeSeries77.getMaximumItemAge();
        java.lang.Comparable comparable81 = timeSeries77.getKey();
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries77.add((org.jfree.data.time.RegularTimePeriod) year83, (java.lang.Number) 7, false);
        long long87 = year83.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries72.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year83, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = year83.previous();
        int int91 = timeSeries34.getIndex(regularTimePeriod90);
        java.lang.String str92 = regularTimePeriod90.toString();
        boolean boolean93 = timeSeriesDataItem28.equals((java.lang.Object) regularTimePeriod90);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem95 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod90, (double) 1560150000000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100.0d + "'", comparable24.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 100.0d + "'", comparable42.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775807L + "'", long57 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable58 + "' != '" + 100.0d + "'", comparable58.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(obj73);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 9223372036854775807L + "'", long80 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable81 + "' != '" + 100.0d + "'", comparable81.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + (-62119972800001L) + "'", long87 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem89);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-1) + "'", int91 == (-1));
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "0" + "'", str92.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj13 = timeSeries12.clone();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 7, false);
        long long27 = year23.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year23.previous();
        java.lang.Number number31 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.String str32 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj37 = timeSeries36.clone();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener46);
        long long48 = timeSeries45.getMaximumItemAge();
        java.lang.Comparable comparable49 = timeSeries45.getKey();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo57 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent58 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year51, seriesChangeInfo57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year51, (double) '#');
        int int61 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year51);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries65.addPropertyChangeListener(propertyChangeListener66);
        long long68 = timeSeries65.getMaximumItemAge();
        java.lang.Comparable comparable69 = timeSeries65.getKey();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo77 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent78 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year71, seriesChangeInfo77);
        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener83 = null;
        timeSeries82.addPropertyChangeListener(propertyChangeListener83);
        long long85 = timeSeries82.getMaximumItemAge();
        java.lang.Comparable comparable86 = timeSeries82.getKey();
        boolean boolean87 = year71.equals((java.lang.Object) timeSeries82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = year71.next();
        java.lang.String str89 = year71.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year71);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100.0d + "'", comparable21.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62119972800001L) + "'", long27 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + 100.0d + "'", comparable49.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + 100.0d + "'", comparable69.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 9223372036854775807L + "'", long85 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable86 + "' != '" + 100.0d + "'", comparable86.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "1" + "'", str89.equals("1"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) (short) 10);
        boolean boolean49 = month33.equals((java.lang.Object) year43);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        boolean boolean54 = month33.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month33.previous();
        org.jfree.data.time.Year year56 = month33.getYear();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(year56);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        java.lang.String str38 = timeSeries3.getDomainDescription();
        int int39 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener44);
        long long46 = timeSeries43.getMaximumItemAge();
        java.lang.Comparable comparable47 = timeSeries43.getKey();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timeSeries58.addPropertyChangeListener(propertyChangeListener59);
        long long61 = timeSeries58.getMaximumItemAge();
        java.lang.Comparable comparable62 = timeSeries58.getKey();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) year64, (java.lang.Number) 7, false);
        long long68 = year64.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year64.previous();
        boolean boolean70 = year49.equals((java.lang.Object) regularTimePeriod69);
        int int71 = year49.getYear();
        java.util.Date date72 = year49.getEnd();
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date72);
        org.jfree.data.time.Year year74 = month73.getYear();
        org.jfree.data.time.Year year75 = month73.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year75.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries3.getDataItem(regularTimePeriod76);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + 100.0d + "'", comparable47.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 9223372036854775807L + "'", long61 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable62 + "' != '" + 100.0d + "'", comparable62.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-62119972800001L) + "'", long68 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(year74);
        org.junit.Assert.assertNotNull(year75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.clear();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
        timeSeries3.add(regularTimePeriod9, (java.lang.Number) 1546329600000L, false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-62017459200001L));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        long long11 = year9.getFirstMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        java.util.Date date13 = year9.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185056885L + "'", long2 == 1560185056885L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
        java.util.List list28 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
        long long35 = timeSeries32.getMaximumItemAge();
        java.lang.Comparable comparable36 = timeSeries32.getKey();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries47.addPropertyChangeListener(propertyChangeListener48);
        long long50 = timeSeries47.getMaximumItemAge();
        java.lang.Comparable comparable51 = timeSeries47.getKey();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 7, false);
        long long57 = year53.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year53.previous();
        boolean boolean59 = year38.equals((java.lang.Object) regularTimePeriod58);
        int int60 = year38.getYear();
        java.util.Date date61 = year38.getEnd();
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date61);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener67 = null;
        timeSeries66.addPropertyChangeListener(propertyChangeListener67);
        long long69 = timeSeries66.getMaximumItemAge();
        java.lang.Comparable comparable70 = timeSeries66.getKey();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries66.add((org.jfree.data.time.RegularTimePeriod) year72, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year72, (java.lang.Number) (short) 10);
        boolean boolean78 = month62.equals((java.lang.Object) year72);
        long long79 = year72.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date82 = fixedMillisecond81.getTime();
        org.jfree.data.time.Month month83 = new org.jfree.data.time.Month(date82);
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date82);
        org.jfree.data.time.TimeSeries timeSeries88 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener89 = null;
        timeSeries88.addPropertyChangeListener(propertyChangeListener89);
        java.beans.PropertyChangeListener propertyChangeListener91 = null;
        timeSeries88.addPropertyChangeListener(propertyChangeListener91);
        java.lang.Comparable comparable93 = timeSeries88.getKey();
        java.beans.PropertyChangeListener propertyChangeListener94 = null;
        timeSeries88.addPropertyChangeListener(propertyChangeListener94);
        int int96 = day84.compareTo((java.lang.Object) timeSeries88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = day84.next();
        int int98 = timeSeries3.getIndex(regularTimePeriod97);
        double double99 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 9223372036854775807L + "'", long50 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable51 + "' != '" + 100.0d + "'", comparable51.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-62119972800001L) + "'", long57 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 9223372036854775807L + "'", long69 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable70 + "' != '" + 100.0d + "'", comparable70.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-62104204800001L) + "'", long79 == (-62104204800001L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem80);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + comparable93 + "' != '" + 100.0d + "'", comparable93.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod97);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 35.0d + "'", double99 == 35.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj15 = timeSeries14.clone();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        long long26 = timeSeries23.getMaximumItemAge();
        timeSeries23.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass29 = timeSeries23.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries48.addPropertyChangeListener(propertyChangeListener49);
        long long51 = timeSeries48.getMaximumItemAge();
        java.lang.Comparable comparable52 = timeSeries48.getKey();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) 7, false);
        long long58 = year54.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year54.previous();
        boolean boolean60 = year39.equals((java.lang.Object) regularTimePeriod59);
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries65.addPropertyChangeListener(propertyChangeListener66);
        long long68 = timeSeries65.getMaximumItemAge();
        java.lang.Comparable comparable69 = timeSeries65.getKey();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 7, false);
        long long75 = year71.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year71.previous();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year71);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year71);
        java.util.Date date79 = year71.getStart();
        java.util.Calendar calendar80 = null;
        try {
            long long81 = year71.getLastMillisecond(calendar80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 100.0d + "'", comparable52.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62119972800001L) + "'", long58 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + 100.0d + "'", comparable69.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62119972800001L) + "'", long75 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertNotNull(date79);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=10]");
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener16);
        java.lang.Comparable comparable18 = timeSeries13.getKey();
        timeSeries13.removeAgedItems(false);
        java.lang.String str21 = timeSeries13.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries13.addChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean25 = timeSeries13.getNotify();
        timeSeries13.removeAgedItems(1560184987727L, true);
        boolean boolean30 = timeSeries13.equals((java.lang.Object) '4');
        int int31 = timeSeries13.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeries13.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str7 = timeSeries3.getDomainDescription();
        int int8 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) day5);
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        java.lang.Class<?> wildcardClass9 = serialDate8.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
//        java.lang.String str11 = day10.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        timeSeries3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str11 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) -1, 7, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        java.lang.String str38 = timeSeries3.getDomainDescription();
        int int39 = timeSeries3.getItemCount();
        try {
            java.lang.Number number41 = timeSeries3.getValue(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 4);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener17);
        long long19 = timeSeries16.getMaximumItemAge();
        java.lang.Comparable comparable20 = timeSeries16.getKey();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year22, seriesChangeInfo28);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        boolean boolean38 = year22.equals((java.lang.Object) timeSeries33);
        java.lang.Number number39 = null;
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year22, number39, false);
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries46.addPropertyChangeListener(propertyChangeListener47);
        long long49 = timeSeries46.getMaximumItemAge();
        java.lang.Comparable comparable50 = timeSeries46.getKey();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo58 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent59 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year52, seriesChangeInfo58);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timeSeries63.addPropertyChangeListener(propertyChangeListener64);
        long long66 = timeSeries63.getMaximumItemAge();
        java.lang.Comparable comparable67 = timeSeries63.getKey();
        boolean boolean68 = year52.equals((java.lang.Object) timeSeries63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year52.next();
        boolean boolean71 = year52.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) (byte) 0);
        timeSeries7.setDomainDescription("hi!");
        int int76 = timeSeries7.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener81 = null;
        timeSeries80.addPropertyChangeListener(propertyChangeListener81);
        java.beans.PropertyChangeListener propertyChangeListener83 = null;
        timeSeries80.addPropertyChangeListener(propertyChangeListener83);
        boolean boolean85 = timeSeries80.isEmpty();
        timeSeries80.fireSeriesChanged();
        java.util.Collection collection87 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries80);
        int int88 = month2.compareTo((java.lang.Object) timeSeries80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 100.0d + "'", comparable20.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + 100.0d + "'", comparable50.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 9223372036854775807L + "'", long66 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + 100.0d + "'", comparable67.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(collection87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        timeSeriesDataItem14.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        long long27 = timeSeries24.getMaximumItemAge();
        java.lang.Comparable comparable28 = timeSeries24.getKey();
        java.util.Collection collection29 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        timeSeries20.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 100.0d + "'", comparable28.equals(100.0d));
        org.junit.Assert.assertNotNull(collection29);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 4);
        long long3 = month2.getLastMillisecond();
        java.lang.String str4 = month2.toString();
        long long5 = month2.getFirstMillisecond();
        java.util.Date date6 = month2.getEnd();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62017459200001L) + "'", long3 == (-62017459200001L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "September 4" + "'", str4.equals("September 4"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62020051200000L) + "'", long5 == (-62020051200000L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Date date4 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day5.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        try {
            java.lang.Number number9 = timeSeries3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560184993793L, seriesChangeInfo1);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) day5);
//        java.lang.String str7 = day5.toString();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        int int9 = day5.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        long long7 = timeSeries4.getMaximumItemAge();
//        java.lang.Comparable comparable8 = timeSeries4.getKey();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries19.addPropertyChangeListener(propertyChangeListener20);
//        long long22 = timeSeries19.getMaximumItemAge();
//        java.lang.Comparable comparable23 = timeSeries19.getKey();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 7, false);
//        long long29 = year25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year25.previous();
//        boolean boolean31 = year10.equals((java.lang.Object) regularTimePeriod30);
//        int int32 = year10.getYear();
//        java.util.Date date33 = year10.getEnd();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date33);
//        int int36 = day0.compareTo((java.lang.Object) date33);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timeSeries40.addPropertyChangeListener(propertyChangeListener41);
//        long long43 = timeSeries40.getMaximumItemAge();
//        timeSeries40.setKey((java.lang.Comparable) (byte) 100);
//        java.lang.Class<?> wildcardClass46 = timeSeries40.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        long long48 = fixedMillisecond47.getLastMillisecond();
//        long long49 = fixedMillisecond47.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond47.next();
//        java.util.Calendar calendar51 = null;
//        fixedMillisecond47.peg(calendar51);
//        timeSeries40.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener58 = null;
//        timeSeries57.addPropertyChangeListener(propertyChangeListener58);
//        long long60 = timeSeries57.getMaximumItemAge();
//        java.lang.Comparable comparable61 = timeSeries57.getKey();
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries57.add((org.jfree.data.time.RegularTimePeriod) year63, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year63, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo69 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent70 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year63, seriesChangeInfo69);
//        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener75 = null;
//        timeSeries74.addPropertyChangeListener(propertyChangeListener75);
//        long long77 = timeSeries74.getMaximumItemAge();
//        java.lang.Comparable comparable78 = timeSeries74.getKey();
//        boolean boolean79 = year63.equals((java.lang.Object) timeSeries74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = year63.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year63, (java.lang.Number) 2019);
//        timeSeries40.add(timeSeriesDataItem82);
//        boolean boolean84 = day0.equals((java.lang.Object) timeSeriesDataItem82);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 100.0d + "'", comparable23.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-62119972800001L) + "'", long29 == (-62119972800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560185057801L + "'", long48 == 1560185057801L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560185057801L + "'", long49 == 1560185057801L);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 9223372036854775807L + "'", long60 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable61 + "' != '" + 100.0d + "'", comparable61.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 9223372036854775807L + "'", long77 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable78 + "' != '" + 100.0d + "'", comparable78.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        long long17 = timeSeries14.getMaximumItemAge();
        java.lang.Comparable comparable18 = timeSeries14.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) (short) 10);
        java.lang.Object obj26 = timeSeriesDataItem25.clone();
        java.lang.Object obj27 = timeSeriesDataItem25.clone();
        timeSeries3.add(timeSeriesDataItem25, true);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries48.addPropertyChangeListener(propertyChangeListener49);
        long long51 = timeSeries48.getMaximumItemAge();
        java.lang.Comparable comparable52 = timeSeries48.getKey();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) 7, false);
        long long58 = year54.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year54.previous();
        boolean boolean60 = year39.equals((java.lang.Object) regularTimePeriod59);
        int int61 = year39.getYear();
        java.util.Date date62 = year39.getEnd();
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(date62);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month63, (java.lang.Number) 1561964399999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 100.0d + "'", comparable52.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62119972800001L) + "'", long58 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(date62);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.next();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        long long6 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getLastMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185058103L + "'", long1 == 1560185058103L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185058103L + "'", long2 == 1560185058103L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185058103L + "'", long6 == 1560185058103L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560185058103L + "'", long8 == 1560185058103L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9, seriesChangeInfo15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year9.previous();
        java.lang.Object obj18 = null;
        boolean boolean19 = year9.equals(obj18);
        java.util.Date date20 = year9.getStart();
        java.util.TimeZone timeZone21 = null;
        java.util.Locale locale22 = null;
        try {
            org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date20, timeZone21, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 9999);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo5);
        org.junit.Assert.assertNull(seriesChangeInfo2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(5);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year22);
        java.lang.String str24 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener31);
        java.lang.Comparable comparable33 = timeSeries28.getKey();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj38 = timeSeries37.clone();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
        long long52 = year48.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year48.previous();
        java.lang.Number number56 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) year48);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year48);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-62119972800001L) + "'", long52 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(number56);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, 0.0d);
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries4.getMaximumItemAge();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year10, seriesChangeInfo16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.addPropertyChangeListener(propertyChangeListener22);
        long long24 = timeSeries21.getMaximumItemAge();
        java.lang.Comparable comparable25 = timeSeries21.getKey();
        boolean boolean26 = year10.equals((java.lang.Object) timeSeries21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year10.next();
        boolean boolean29 = year10.equals((java.lang.Object) 8);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 1, year10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 100.0d + "'", comparable25.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        long long16 = timeSeries13.getMaximumItemAge();
        java.lang.Comparable comparable17 = timeSeries13.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 7, false);
        long long38 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year34.previous();
        boolean boolean40 = year19.equals((java.lang.Object) regularTimePeriod39);
        int int41 = year19.getYear();
        java.util.Date date42 = year19.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date42, timeZone44);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date48 = fixedMillisecond47.getTime();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date48, timeZone49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(date48);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date48);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date48);
        java.util.TimeZone timeZone54 = null;
        try {
            org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date48, timeZone54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100.0d + "'", comparable17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62119972800001L) + "'", long38 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod50);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        long long17 = timeSeries14.getMaximumItemAge();
        java.lang.Comparable comparable18 = timeSeries14.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) (short) 10);
        java.lang.Object obj26 = timeSeriesDataItem25.clone();
        java.lang.Object obj27 = timeSeriesDataItem25.clone();
        timeSeries3.add(timeSeriesDataItem25, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem25.getPeriod();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        long long34 = month33.getLastMillisecond();
        long long35 = month33.getLastMillisecond();
        long long36 = month33.getFirstMillisecond();
        org.jfree.data.time.Year year37 = month33.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month33.next();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62104204800001L) + "'", long34 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62104204800001L) + "'", long35 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-62106883200000L) + "'", long36 == (-62106883200000L));
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        long long16 = timeSeries13.getMaximumItemAge();
        java.lang.Comparable comparable17 = timeSeries13.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 7, false);
        long long38 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year34.previous();
        boolean boolean40 = year19.equals((java.lang.Object) regularTimePeriod39);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year19);
        timeSeries3.setDomainDescription("0");
        double double44 = timeSeries3.getMaxY();
        double double45 = timeSeries3.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 10);
        int int48 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        try {
            org.jfree.data.time.TimeSeries timeSeries51 = timeSeries3.createCopy((int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100.0d + "'", comparable17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62119972800001L) + "'", long38 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) day5);
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
//        long long17 = timeSeries14.getMaximumItemAge();
//        java.lang.Comparable comparable18 = timeSeries14.getKey();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        long long25 = timeSeries22.getMaximumItemAge();
//        java.lang.Comparable comparable26 = timeSeries22.getKey();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo34 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year28, seriesChangeInfo34);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries39.addPropertyChangeListener(propertyChangeListener40);
//        long long42 = timeSeries39.getMaximumItemAge();
//        java.lang.Comparable comparable43 = timeSeries39.getKey();
//        boolean boolean44 = year28.equals((java.lang.Object) timeSeries39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year28.next();
//        int int46 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(7, year28);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month47);
//        java.util.Date date49 = month47.getStart();
//        int int50 = day5.compareTo((java.lang.Object) month47);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 100.0d + "'", comparable26.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 100.0d + "'", comparable43.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0);
        timeSeries1.setNotify(true);
        timeSeries1.removeAgedItems(9223372036854775807L, true);
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean7, seriesChangeInfo8);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        java.lang.Object obj12 = seriesChangeEvent9.getSource();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + true + "'", obj12.equals(true));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day3.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9, seriesChangeInfo15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        long long23 = timeSeries20.getMaximumItemAge();
        java.lang.Comparable comparable24 = timeSeries20.getKey();
        boolean boolean25 = year9.equals((java.lang.Object) timeSeries20);
        timeSeries20.setDomainDescription("");
        timeSeries20.fireSeriesChanged();
        timeSeries20.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100.0d + "'", comparable24.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.Year year34 = month33.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.next();
        java.util.Calendar calendar36 = null;
        try {
            long long37 = year34.getFirstMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj15 = timeSeries14.clone();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        long long26 = timeSeries23.getMaximumItemAge();
        timeSeries23.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass29 = timeSeries23.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries48.addPropertyChangeListener(propertyChangeListener49);
        long long51 = timeSeries48.getMaximumItemAge();
        java.lang.Comparable comparable52 = timeSeries48.getKey();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) 7, false);
        long long58 = year54.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year54.previous();
        boolean boolean60 = year39.equals((java.lang.Object) regularTimePeriod59);
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries65.addPropertyChangeListener(propertyChangeListener66);
        long long68 = timeSeries65.getMaximumItemAge();
        java.lang.Comparable comparable69 = timeSeries65.getKey();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 7, false);
        long long75 = year71.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year71.previous();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year71);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year71);
        int int79 = year71.getYear();
        int int80 = year71.getYear();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 100.0d + "'", comparable52.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62119972800001L) + "'", long58 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + 100.0d + "'", comparable69.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62119972800001L) + "'", long75 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(false);
        java.lang.String str11 = timeSeries3.getDomainDescription();
        java.lang.String str12 = timeSeries3.getDomainDescription();
        java.lang.String str13 = timeSeries3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Date date4 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getFirstMillisecond();
        int int7 = day5.getYear();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
        long long14 = timeSeries11.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        long long23 = timeSeries20.getMaximumItemAge();
        java.lang.Comparable comparable24 = timeSeries20.getKey();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year26, seriesChangeInfo32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        boolean boolean42 = year26.equals((java.lang.Object) timeSeries37);
        java.lang.Number number43 = null;
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year26, number43, false);
        java.lang.String str46 = timeSeries11.getDomainDescription();
        java.lang.Comparable comparable47 = timeSeries11.getKey();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) 'a');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year49, (double) (-62119972800001L));
        int int52 = day5.compareTo((java.lang.Object) timeSeriesDataItem51);
        int int53 = day5.getDayOfMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100.0d + "'", comparable24.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + 100.0d + "'", comparable47.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 31 + "'", int53 == 31);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(5);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year22);
        double double24 = timeSeries3.getMaxY();
        try {
            timeSeries3.delete(0, 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.setNotify(true);
        java.lang.Comparable comparable12 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener17);
        long long19 = timeSeries16.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener26);
        long long28 = timeSeries25.getMaximumItemAge();
        java.lang.Comparable comparable29 = timeSeries25.getKey();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo37 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year31, seriesChangeInfo37);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        boolean boolean47 = year31.equals((java.lang.Object) timeSeries42);
        java.lang.Number number48 = null;
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year31, number48, false);
        timeSeries16.clear();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timeSeries55.addPropertyChangeListener(propertyChangeListener56);
        long long58 = timeSeries55.getMaximumItemAge();
        java.lang.Comparable comparable59 = timeSeries55.getKey();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries55.add((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo67 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent68 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year61, seriesChangeInfo67);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener73 = null;
        timeSeries72.addPropertyChangeListener(propertyChangeListener73);
        long long75 = timeSeries72.getMaximumItemAge();
        java.lang.Comparable comparable76 = timeSeries72.getKey();
        boolean boolean77 = year61.equals((java.lang.Object) timeSeries72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = year61.next();
        boolean boolean80 = year61.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) (byte) 0);
        java.util.Collection collection83 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        long long84 = timeSeries16.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener85 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener85);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 100.0d + "'", comparable29.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 9223372036854775807L + "'", long58 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + 100.0d + "'", comparable59.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 9223372036854775807L + "'", long75 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable76 + "' != '" + 100.0d + "'", comparable76.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem82);
        org.junit.Assert.assertNotNull(collection83);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 9223372036854775807L + "'", long84 == 9223372036854775807L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("September 4");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
        java.util.List list28 = timeSeries3.getItems();
        java.lang.Class<?> wildcardClass29 = list28.getClass();
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(class30);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
//        long long16 = timeSeries13.getMaximumItemAge();
//        java.lang.Comparable comparable17 = timeSeries13.getKey();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries9.addOrUpdate(timeSeriesDataItem24);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
//        long long32 = timeSeries29.getMaximumItemAge();
//        java.lang.Comparable comparable33 = timeSeries29.getKey();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo41 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent42 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year35, seriesChangeInfo41);
//        int int43 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) (byte) 10);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date48 = fixedMillisecond47.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getTime();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50);
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) day52);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        java.lang.String str55 = fixedMillisecond47.toString();
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100.0d + "'", comparable17.equals(100.0d));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Mon Jun 10 09:44:19 PDT 2019" + "'", str55.equals("Mon Jun 10 09:44:19 PDT 2019"));
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
        timeSeries3.clear();
        timeSeries3.setRangeDescription("December 1");
        double double31 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj13 = timeSeries12.clone();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 7, false);
        long long27 = year23.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year23.previous();
        java.lang.Number number31 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.String str32 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj37 = timeSeries36.clone();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener46);
        long long48 = timeSeries45.getMaximumItemAge();
        java.lang.Comparable comparable49 = timeSeries45.getKey();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo57 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent58 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year51, seriesChangeInfo57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year51, (double) '#');
        int int61 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year51);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries65.addPropertyChangeListener(propertyChangeListener66);
        long long68 = timeSeries65.getMaximumItemAge();
        boolean boolean70 = timeSeries65.equals((java.lang.Object) 5);
        boolean boolean71 = timeSeries65.getNotify();
        timeSeries65.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener78 = null;
        timeSeries77.addPropertyChangeListener(propertyChangeListener78);
        long long80 = timeSeries77.getMaximumItemAge();
        java.lang.Comparable comparable81 = timeSeries77.getKey();
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries77.add((org.jfree.data.time.RegularTimePeriod) year83, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year83, (java.lang.Number) (short) 10);
        java.lang.Object obj89 = timeSeriesDataItem88.clone();
        timeSeriesDataItem88.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem92 = timeSeries65.addOrUpdate(timeSeriesDataItem88);
        timeSeries3.add(timeSeriesDataItem88);
        timeSeries3.removeAgedItems(true);
        timeSeries3.clear();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100.0d + "'", comparable21.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62119972800001L) + "'", long27 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + 100.0d + "'", comparable49.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 9223372036854775807L + "'", long80 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable81 + "' != '" + 100.0d + "'", comparable81.equals(100.0d));
        org.junit.Assert.assertNotNull(obj89);
        org.junit.Assert.assertNull(timeSeriesDataItem92);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener15);
        java.lang.String str17 = timeSeries12.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries12.removeChangeListener(seriesChangeListener18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(9, 4);
        long long23 = month22.getLastMillisecond();
        java.lang.String str24 = month22.toString();
        long long25 = month22.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
        int int27 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month22);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62017459200001L) + "'", long23 == (-62017459200001L));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "September 4" + "'", str24.equals("September 4"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62020051200000L) + "'", long25 == (-62020051200000L));
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        timeSeriesDataItem14.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        long long27 = timeSeries24.getMaximumItemAge();
        java.lang.Comparable comparable28 = timeSeries24.getKey();
        java.util.Collection collection29 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        long long43 = timeSeries33.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries33.getNextTimePeriod();
        timeSeries24.setKey((java.lang.Comparable) regularTimePeriod44);
        java.lang.Object obj46 = timeSeries24.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj52 = timeSeries51.clone();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timeSeries56.addPropertyChangeListener(propertyChangeListener57);
        long long59 = timeSeries56.getMaximumItemAge();
        java.lang.Comparable comparable60 = timeSeries56.getKey();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries56.add((org.jfree.data.time.RegularTimePeriod) year62, (java.lang.Number) 7, false);
        long long66 = year62.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year62, (double) 10L);
        int int69 = year62.getYear();
        int int70 = fixedMillisecond47.compareTo((java.lang.Object) year62);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 'a');
        java.lang.Class<?> wildcardClass73 = fixedMillisecond47.getClass();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 100.0d + "'", comparable28.equals(100.0d));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 9223372036854775807L + "'", long59 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable60 + "' != '" + 100.0d + "'", comparable60.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-62119972800001L) + "'", long66 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(wildcardClass73);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
        long long18 = timeSeries15.getMaximumItemAge();
        java.lang.Comparable comparable19 = timeSeries15.getKey();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) (short) 10);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        timeSeriesDataItem26.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.addOrUpdate(timeSeriesDataItem26);
        java.lang.Class class31 = timeSeries3.getTimePeriodClass();
        timeSeries3.setRangeDescription("0");
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo49 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year43, seriesChangeInfo49);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries54.addPropertyChangeListener(propertyChangeListener55);
        long long57 = timeSeries54.getMaximumItemAge();
        java.lang.Comparable comparable58 = timeSeries54.getKey();
        boolean boolean59 = year43.equals((java.lang.Object) timeSeries54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year43.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 2019);
        int int63 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year43);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 100.0d + "'", comparable19.equals(100.0d));
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775807L + "'", long57 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable58 + "' != '" + 100.0d + "'", comparable58.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries4.getMaximumItemAge();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year18.next();
        int int36 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(7, year18);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37);
        java.util.Date date39 = month37.getStart();
        java.util.Calendar calendar40 = null;
        try {
            long long41 = month37.getLastMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries4.getMaximumItemAge();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 7, false);
        long long14 = year10.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.previous();
        java.util.Date date16 = year10.getEnd();
        int int17 = month0.compareTo((java.lang.Object) year10);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year10, "", "1");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries24.addOrUpdate(timeSeriesDataItem39);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
        long long47 = timeSeries44.getMaximumItemAge();
        java.lang.Comparable comparable48 = timeSeries44.getKey();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) year50, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year50, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo56 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year50, seriesChangeInfo56);
        int int58 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) year50);
        boolean boolean59 = timeSeries24.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timeSeries63.addPropertyChangeListener(propertyChangeListener64);
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries63.addPropertyChangeListener(propertyChangeListener66);
        java.lang.Comparable comparable68 = timeSeries63.getKey();
        java.beans.PropertyChangeListener propertyChangeListener69 = null;
        timeSeries63.addPropertyChangeListener(propertyChangeListener69);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener75 = null;
        timeSeries74.addPropertyChangeListener(propertyChangeListener75);
        long long77 = timeSeries74.getMaximumItemAge();
        java.lang.Comparable comparable78 = timeSeries74.getKey();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries74.add((org.jfree.data.time.RegularTimePeriod) year80, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year80, (java.lang.Number) (short) 10);
        java.lang.Object obj86 = timeSeriesDataItem85.clone();
        java.lang.Object obj87 = timeSeriesDataItem85.clone();
        timeSeries63.add(timeSeriesDataItem85, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries24.addOrUpdate(timeSeriesDataItem85);
        java.util.Collection collection91 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62119972800001L) + "'", long14 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 9223372036854775807L + "'", long47 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + 100.0d + "'", comparable48.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + comparable68 + "' != '" + 100.0d + "'", comparable68.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 9223372036854775807L + "'", long77 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable78 + "' != '" + 100.0d + "'", comparable78.equals(100.0d));
        org.junit.Assert.assertNotNull(obj86);
        org.junit.Assert.assertNotNull(obj87);
        org.junit.Assert.assertNotNull(timeSeriesDataItem90);
        org.junit.Assert.assertNotNull(collection91);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) day5);
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
//        java.lang.Comparable comparable12 = timeSeries7.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener13);
//        int int15 = day3.compareTo((java.lang.Object) timeSeries7);
//        int int16 = day3.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        long long11 = timeSeries8.getMaximumItemAge();
        java.lang.Comparable comparable12 = timeSeries8.getKey();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 7, false);
        long long18 = year14.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year14, (double) 10L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener26);
        long long28 = timeSeries25.getMaximumItemAge();
        java.lang.Comparable comparable29 = timeSeries25.getKey();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo45 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year39, seriesChangeInfo45);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener51);
        long long53 = timeSeries50.getMaximumItemAge();
        java.lang.Comparable comparable54 = timeSeries50.getKey();
        boolean boolean55 = year39.equals((java.lang.Object) timeSeries50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year39.next();
        int int57 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(7, year39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
        java.lang.String str60 = timeSeries3.getDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62119972800001L) + "'", long18 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 100.0d + "'", comparable29.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 9223372036854775807L + "'", long53 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + 100.0d + "'", comparable54.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem59);
        org.junit.Assert.assertNull(str60);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(5);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year22);
        double double24 = timeSeries3.getMaxY();
        timeSeries3.setMaximumItemAge(0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo54 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year48, seriesChangeInfo54);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries59.addPropertyChangeListener(propertyChangeListener60);
        long long62 = timeSeries59.getMaximumItemAge();
        java.lang.Comparable comparable63 = timeSeries59.getKey();
        boolean boolean64 = year48.equals((java.lang.Object) timeSeries59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year48.next();
        boolean boolean67 = year48.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (byte) 0);
        timeSeries3.setDomainDescription("hi!");
        int int72 = timeSeries3.getItemCount();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year74, (java.lang.Number) 2019L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = fixedMillisecond78.previous();
        java.util.Calendar calendar80 = null;
        long long81 = fixedMillisecond78.getMiddleMillisecond(calendar80);
        java.util.Date date82 = fixedMillisecond78.getStart();
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date82);
        int int84 = timeSeriesDataItem76.compareTo((java.lang.Object) day83);
        org.jfree.data.time.SerialDate serialDate85 = day83.getSerialDate();
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(serialDate85);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable63 + "' != '" + 100.0d + "'", comparable63.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem76);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 10L + "'", long81 == 10L);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(serialDate85);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 4);
        int int3 = month2.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        int int7 = month2.compareTo((java.lang.Object) regularTimePeriod6);
        org.jfree.data.time.Year year8 = month2.getYear();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener17);
        long long19 = timeSeries16.getMaximumItemAge();
        java.lang.Comparable comparable20 = timeSeries16.getKey();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries12.addOrUpdate(timeSeriesDataItem27);
        timeSeries12.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo45 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year39, seriesChangeInfo45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year39.previous();
        timeSeries12.setKey((java.lang.Comparable) regularTimePeriod47);
        int int49 = month2.compareTo((java.lang.Object) timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timeSeries53.addPropertyChangeListener(propertyChangeListener54);
        long long56 = timeSeries53.getMaximumItemAge();
        java.lang.Comparable comparable57 = timeSeries53.getKey();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries53.add((org.jfree.data.time.RegularTimePeriod) year59, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (java.lang.Number) (short) 10);
        timeSeriesDataItem64.setValue((java.lang.Number) 100);
        try {
            timeSeries12.add(timeSeriesDataItem64);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 1 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 100.0d + "'", comparable20.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 9223372036854775807L + "'", long56 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + 100.0d + "'", comparable57.equals(100.0d));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185062469L + "'", long1 == 1560185062469L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        timeSeriesDataItem18.setValue((java.lang.Number) 100);
        timeSeriesDataItem18.setSelected(false);
        boolean boolean24 = timeSeriesDataItem18.isSelected();
        timeSeriesDataItem18.setSelected(false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        java.lang.String str38 = timeSeries3.getDomainDescription();
        int int39 = timeSeries3.getItemCount();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(9, 4);
        long long43 = month42.getFirstMillisecond();
        int int44 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month42);
        int int46 = month42.compareTo((java.lang.Object) (-62117424000001L));
        int int47 = month42.getMonth();
        int int48 = month42.getYearValue();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-62020051200000L) + "'", long43 == (-62020051200000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 9 + "'", int47 == 9);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(false);
        int int11 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
        long long18 = timeSeries15.getMaximumItemAge();
        java.lang.Comparable comparable19 = timeSeries15.getKey();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo27 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year21, seriesChangeInfo27);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
        long long35 = timeSeries32.getMaximumItemAge();
        java.lang.Comparable comparable36 = timeSeries32.getKey();
        boolean boolean37 = year21.equals((java.lang.Object) timeSeries32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year21.next();
        boolean boolean40 = year21.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year21.previous();
        timeSeries3.delete(regularTimePeriod41);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (double) (short) 100);
        timeSeriesDataItem46.setValue((java.lang.Number) 1560185033206L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries3.addOrUpdate(timeSeriesDataItem46);
        java.lang.String str50 = timeSeries3.getDescription();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 100.0d + "'", comparable19.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNull(str50);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        timeSeriesDataItem14.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        boolean boolean21 = timeSeriesDataItem14.isSelected();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("September 4");
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date32);
        java.util.Calendar calendar34 = null;
        fixedMillisecond33.peg(calendar34);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.clear();
        timeSeries3.removeAgedItems((-62135784000001L), false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        try {
            timeSeries3.update(5, (java.lang.Number) 1560185049301L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.clear();
        java.util.Collection collection6 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        long long16 = timeSeries13.getMaximumItemAge();
        java.lang.Comparable comparable17 = timeSeries13.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 7, false);
        long long38 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year34.previous();
        boolean boolean40 = year19.equals((java.lang.Object) regularTimePeriod39);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener46);
        long long48 = timeSeries45.getMaximumItemAge();
        java.lang.Comparable comparable49 = timeSeries45.getKey();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 7, false);
        long long55 = year51.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year51.previous();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year51.previous();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1L));
        boolean boolean61 = year51.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100.0d + "'", comparable17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62119972800001L) + "'", long38 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + 100.0d + "'", comparable49.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62119972800001L) + "'", long55 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        long long11 = timeSeries8.getMaximumItemAge();
        java.lang.Comparable comparable12 = timeSeries8.getKey();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 7, false);
        long long18 = year14.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year14, (double) 10L);
        long long21 = year14.getSerialIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62119972800001L) + "'", long18 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(5);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year22);
        double double24 = timeSeries3.getMaxY();
        double double25 = timeSeries3.getMinY();
        timeSeries3.setNotify(true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        java.lang.String str38 = timeSeries3.getDomainDescription();
        java.lang.Comparable comparable39 = timeSeries3.getKey();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
        long long47 = timeSeries44.getMaximumItemAge();
        java.lang.Comparable comparable48 = timeSeries44.getKey();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) year50, (java.lang.Number) 7, false);
        long long54 = year50.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year50.previous();
        java.util.Date date56 = year50.getEnd();
        int int57 = month40.compareTo((java.lang.Object) year50);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year50, "", "1");
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year50, (double) 9223372036854775807L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 1 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + 100.0d + "'", comparable39.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 9223372036854775807L + "'", long47 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + 100.0d + "'", comparable48.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-62119972800001L) + "'", long54 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.removeChangeListener(seriesChangeListener9);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.junit.Assert.assertNotNull(obj4);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        java.lang.Comparable comparable7 = timeSeries3.getKey();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9, seriesChangeInfo15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
//        long long23 = timeSeries20.getMaximumItemAge();
//        java.lang.Comparable comparable24 = timeSeries20.getKey();
//        boolean boolean25 = year9.equals((java.lang.Object) timeSeries20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod26, (java.lang.Number) 10L);
//        java.lang.Number number29 = timeSeriesDataItem28.getValue();
//        java.lang.Object obj30 = timeSeriesDataItem28.clone();
//        timeSeriesDataItem28.setValue((java.lang.Number) 1);
//        java.lang.Object obj33 = null;
//        boolean boolean34 = timeSeriesDataItem28.equals(obj33);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener41);
//        java.lang.Comparable comparable43 = timeSeries38.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener44);
//        java.util.Collection collection46 = timeSeries38.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.lang.Object obj51 = timeSeries50.clone();
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (byte) -1);
//        long long56 = year53.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 1560184988903L);
//        int int59 = timeSeriesDataItem28.compareTo((java.lang.Object) year53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        long long61 = fixedMillisecond60.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond60.next();
//        java.util.Date date63 = fixedMillisecond60.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond60.previous();
//        boolean boolean65 = timeSeriesDataItem28.equals((java.lang.Object) fixedMillisecond60);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100.0d + "'", comparable24.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 10L + "'", number29.equals(10L));
//        org.junit.Assert.assertNotNull(obj30);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 100.0d + "'", comparable43.equals(100.0d));
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertNotNull(obj51);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62119972800001L) + "'", long56 == (-62119972800001L));
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560185064349L + "'", long61 == 1560185064349L);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) (short) 10);
        boolean boolean49 = month33.equals((java.lang.Object) year43);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        boolean boolean54 = month33.equals((java.lang.Object) 100.0d);
        int int55 = month33.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month33.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod56, (double) 1560185021060L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timeSeries41.addPropertyChangeListener(propertyChangeListener42);
        long long44 = timeSeries41.getMaximumItemAge();
        java.lang.Comparable comparable45 = timeSeries41.getKey();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timeSeries56.addPropertyChangeListener(propertyChangeListener57);
        long long59 = timeSeries56.getMaximumItemAge();
        java.lang.Comparable comparable60 = timeSeries56.getKey();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries56.add((org.jfree.data.time.RegularTimePeriod) year62, (java.lang.Number) 7, false);
        long long66 = year62.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year62.previous();
        boolean boolean68 = year47.equals((java.lang.Object) regularTimePeriod67);
        int int69 = year47.getYear();
        java.util.Date date70 = year47.getEnd();
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date70);
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timeSeries75.addPropertyChangeListener(propertyChangeListener76);
        long long78 = timeSeries75.getMaximumItemAge();
        java.lang.Comparable comparable79 = timeSeries75.getKey();
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries75.add((org.jfree.data.time.RegularTimePeriod) year81, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year81, (java.lang.Number) (short) 10);
        boolean boolean87 = month71.equals((java.lang.Object) year81);
        org.jfree.data.time.TimeSeries timeSeries91 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        boolean boolean92 = month71.equals((java.lang.Object) 100.0d);
        int int93 = month71.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = month71.next();
        try {
            timeSeries3.add(regularTimePeriod94, (java.lang.Number) 1560185004149L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + 100.0d + "'", comparable45.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 9223372036854775807L + "'", long59 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable60 + "' != '" + 100.0d + "'", comparable60.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-62119972800001L) + "'", long66 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 9223372036854775807L + "'", long78 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable79 + "' != '" + 100.0d + "'", comparable79.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod94);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
        timeSeries3.clear();
        timeSeries3.setRangeDescription("December 1");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries7.getKey();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener13);
        int int15 = day3.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day3.next();
        int int17 = day3.getYear();
        int int18 = day3.getYear();
        java.util.Date date19 = day3.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        long long16 = timeSeries13.getMaximumItemAge();
        java.lang.Comparable comparable17 = timeSeries13.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 7, false);
        long long38 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year34.previous();
        boolean boolean40 = year19.equals((java.lang.Object) regularTimePeriod39);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year19);
        java.util.Date date42 = year19.getEnd();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100.0d + "'", comparable17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62119972800001L) + "'", long38 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo54 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year48, seriesChangeInfo54);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries59.addPropertyChangeListener(propertyChangeListener60);
        long long62 = timeSeries59.getMaximumItemAge();
        java.lang.Comparable comparable63 = timeSeries59.getKey();
        boolean boolean64 = year48.equals((java.lang.Object) timeSeries59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year48.next();
        boolean boolean67 = year48.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (byte) 0);
        timeSeries3.setDomainDescription("hi!");
        int int72 = timeSeries3.getItemCount();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year74, (java.lang.Number) 2019L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = fixedMillisecond78.previous();
        java.util.Calendar calendar80 = null;
        long long81 = fixedMillisecond78.getMiddleMillisecond(calendar80);
        java.util.Date date82 = fixedMillisecond78.getStart();
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date82);
        int int84 = timeSeriesDataItem76.compareTo((java.lang.Object) day83);
        org.jfree.data.time.SerialDate serialDate85 = day83.getSerialDate();
        long long86 = day83.getSerialIndex();
        org.jfree.data.time.Month month87 = new org.jfree.data.time.Month();
        long long88 = month87.getSerialIndex();
        long long89 = month87.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = month87.next();
        int int91 = day83.compareTo((java.lang.Object) month87);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable63 + "' != '" + 100.0d + "'", comparable63.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem76);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 10L + "'", long81 == 10L);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 25568L + "'", long86 == 25568L);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 24234L + "'", long88 == 24234L);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 24234L + "'", long89 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        long long8 = timeSeries5.getMaximumItemAge();
        timeSeries5.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass11 = timeSeries5.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener18);
        java.lang.Comparable comparable20 = timeSeries15.getKey();
        timeSeries15.removeAgedItems(false);
        java.lang.String str23 = timeSeries15.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries15.addChangeListener(seriesChangeListener24);
        java.util.Collection collection26 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        boolean boolean27 = timeSeries15.getNotify();
        int int28 = timeSeries15.getMaximumItemCount();
        int int29 = year1.compareTo((java.lang.Object) timeSeries15);
        java.util.Calendar calendar30 = null;
        try {
            year1.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 100.0d + "'", comparable20.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        java.lang.String str38 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timeSeries57.addPropertyChangeListener(propertyChangeListener58);
        long long60 = timeSeries57.getMaximumItemAge();
        java.lang.Comparable comparable61 = timeSeries57.getKey();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries57.add((org.jfree.data.time.RegularTimePeriod) year63, (java.lang.Number) 7, false);
        long long67 = year63.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year63.previous();
        boolean boolean69 = year48.equals((java.lang.Object) regularTimePeriod68);
        int int70 = year48.getYear();
        java.util.Date date71 = year48.getEnd();
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month(date71);
        org.jfree.data.time.Year year73 = month72.getYear();
        org.jfree.data.time.Year year74 = month72.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year74.previous();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year74);
        java.lang.String str77 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 9223372036854775807L + "'", long60 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable61 + "' != '" + 100.0d + "'", comparable61.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-62119972800001L) + "'", long67 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(year73);
        org.junit.Assert.assertNotNull(year74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "hi!" + "'", str77.equals("hi!"));
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
//        boolean boolean9 = timeSeries3.getNotify();
//        timeSeries3.clear();
//        timeSeries3.removeAgedItems((-62135784000001L), false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 0.0d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560185065898L + "'", long15 == 1560185065898L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = fixedMillisecond0.equals(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
//        long long14 = timeSeries11.getMaximumItemAge();
//        java.lang.Comparable comparable15 = timeSeries11.getKey();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (short) 10);
//        java.lang.Object obj23 = timeSeriesDataItem22.clone();
//        timeSeriesDataItem22.setSelected(true);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem22, "0", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
//        long long35 = timeSeries32.getMaximumItemAge();
//        java.lang.Comparable comparable36 = timeSeries32.getKey();
//        java.util.Collection collection37 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries32);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timeSeries41.addPropertyChangeListener(propertyChangeListener42);
//        long long44 = timeSeries41.getMaximumItemAge();
//        java.lang.Comparable comparable45 = timeSeries41.getKey();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 7, false);
//        long long51 = timeSeries41.getMaximumItemAge();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeries41.getNextTimePeriod();
//        timeSeries32.setKey((java.lang.Comparable) regularTimePeriod52);
//        java.lang.Object obj54 = timeSeries32.clone();
//        boolean boolean55 = day6.equals((java.lang.Object) timeSeries32);
//        long long56 = day6.getSerialIndex();
//        boolean boolean57 = fixedMillisecond0.equals((java.lang.Object) long56);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185066029L + "'", long1 == 1560185066029L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 100.0d + "'", comparable15.equals(100.0d));
//        org.junit.Assert.assertNotNull(obj23);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
//        org.junit.Assert.assertNotNull(collection37);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + 100.0d + "'", comparable45.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(obj54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 43626L + "'", long56 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        long long10 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        long long17 = timeSeries14.getMaximumItemAge();
        java.lang.Comparable comparable18 = timeSeries14.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 7, false);
        long long24 = year20.getFirstMillisecond();
        int int25 = fixedMillisecond1.compareTo((java.lang.Object) year20);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year20.getLastMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62135740800000L) + "'", long24 == (-62135740800000L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(false);
        java.lang.String str11 = timeSeries3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
        timeSeries3.removeAgedItems((-62106883200000L), true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        long long23 = timeSeries20.getMaximumItemAge();
        java.lang.Comparable comparable24 = timeSeries20.getKey();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year26, seriesChangeInfo32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        boolean boolean42 = year26.equals((java.lang.Object) timeSeries37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year26.next();
        boolean boolean45 = year26.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries49.addPropertyChangeListener(propertyChangeListener50);
        long long52 = timeSeries49.getMaximumItemAge();
        java.lang.Comparable comparable53 = timeSeries49.getKey();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) (short) 10);
        java.lang.Object obj61 = timeSeriesDataItem60.clone();
        timeSeriesDataItem60.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem60, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener71 = null;
        timeSeries70.addPropertyChangeListener(propertyChangeListener71);
        long long73 = timeSeries70.getMaximumItemAge();
        java.lang.Comparable comparable74 = timeSeries70.getKey();
        java.util.Collection collection75 = timeSeries66.getTimePeriodsUniqueToOtherSeries(timeSeries70);
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener80 = null;
        timeSeries79.addPropertyChangeListener(propertyChangeListener80);
        long long82 = timeSeries79.getMaximumItemAge();
        java.lang.Comparable comparable83 = timeSeries79.getKey();
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries79.add((org.jfree.data.time.RegularTimePeriod) year85, (java.lang.Number) 7, false);
        long long89 = year85.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = year85.previous();
        int int91 = timeSeries66.getIndex((org.jfree.data.time.RegularTimePeriod) year85);
        int int92 = year26.compareTo((java.lang.Object) int91);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem93 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
        long long94 = year26.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100.0d + "'", comparable24.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 9223372036854775807L + "'", long52 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + 100.0d + "'", comparable53.equals(100.0d));
        org.junit.Assert.assertNotNull(obj61);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 9223372036854775807L + "'", long73 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable74 + "' != '" + 100.0d + "'", comparable74.equals(100.0d));
        org.junit.Assert.assertNotNull(collection75);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 9223372036854775807L + "'", long82 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable83 + "' != '" + 100.0d + "'", comparable83.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-62119972800001L) + "'", long89 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-1) + "'", int91 == (-1));
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem93);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + (-62104204800001L) + "'", long94 == (-62104204800001L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo54 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year48, seriesChangeInfo54);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries59.addPropertyChangeListener(propertyChangeListener60);
        long long62 = timeSeries59.getMaximumItemAge();
        java.lang.Comparable comparable63 = timeSeries59.getKey();
        boolean boolean64 = year48.equals((java.lang.Object) timeSeries59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year48.next();
        boolean boolean67 = year48.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (byte) 0);
        timeSeries3.setDomainDescription("hi!");
        int int72 = timeSeries3.getItemCount();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year74, (java.lang.Number) 2019L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = fixedMillisecond78.previous();
        java.util.Calendar calendar80 = null;
        long long81 = fixedMillisecond78.getMiddleMillisecond(calendar80);
        java.util.Date date82 = fixedMillisecond78.getStart();
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date82);
        int int84 = timeSeriesDataItem76.compareTo((java.lang.Object) day83);
        org.jfree.data.time.SerialDate serialDate85 = day83.getSerialDate();
        long long86 = day83.getSerialIndex();
        java.util.Calendar calendar87 = null;
        try {
            day83.peg(calendar87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable63 + "' != '" + 100.0d + "'", comparable63.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem76);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 10L + "'", long81 == 10L);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 25568L + "'", long86 == 25568L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        long long16 = timeSeries13.getMaximumItemAge();
        java.lang.Comparable comparable17 = timeSeries13.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 7, false);
        long long38 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year34.previous();
        boolean boolean40 = year19.equals((java.lang.Object) regularTimePeriod39);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year19);
        timeSeries3.setDomainDescription("0");
        double double44 = timeSeries3.getMaxY();
        java.lang.Comparable comparable45 = timeSeries3.getKey();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100.0d + "'", comparable17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62119972800001L) + "'", long38 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + (byte) 100 + "'", comparable45.equals((byte) 100));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
        long long18 = timeSeries15.getMaximumItemAge();
        java.lang.Comparable comparable19 = timeSeries15.getKey();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) (short) 10);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        timeSeriesDataItem26.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.addOrUpdate(timeSeriesDataItem26);
        java.lang.Class class31 = timeSeries3.getTimePeriodClass();
        java.lang.String str32 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries3.addChangeListener(seriesChangeListener33);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener41);
        java.lang.Comparable comparable43 = timeSeries38.getKey();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj48 = timeSeries47.clone();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries52.addPropertyChangeListener(propertyChangeListener53);
        long long55 = timeSeries52.getMaximumItemAge();
        java.lang.Comparable comparable56 = timeSeries52.getKey();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries52.add((org.jfree.data.time.RegularTimePeriod) year58, (java.lang.Number) 7, false);
        long long62 = year58.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year58, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year58.previous();
        java.lang.Number number66 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) year58);
        java.lang.String str67 = timeSeries38.getDescription();
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj72 = timeSeries71.clone();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries71.add((org.jfree.data.time.RegularTimePeriod) year74, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener81 = null;
        timeSeries80.addPropertyChangeListener(propertyChangeListener81);
        long long83 = timeSeries80.getMaximumItemAge();
        java.lang.Comparable comparable84 = timeSeries80.getKey();
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries80.add((org.jfree.data.time.RegularTimePeriod) year86, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year86, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo92 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent93 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year86, seriesChangeInfo92);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem95 = timeSeries71.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year86, (double) '#');
        int int96 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) year86);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem98 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year86, (java.lang.Number) 1560184988903L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 100.0d + "'", comparable19.equals(100.0d));
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 100.0d + "'", comparable43.equals(100.0d));
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 9223372036854775807L + "'", long55 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable56 + "' != '" + 100.0d + "'", comparable56.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-62119972800001L) + "'", long62 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNull(number66);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 9223372036854775807L + "'", long83 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable84 + "' != '" + 100.0d + "'", comparable84.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + (-1) + "'", int96 == (-1));
        org.junit.Assert.assertNotNull(timeSeriesDataItem98);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond0.compareTo(obj3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560184988508L);
//        long long7 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185066893L + "'", long1 == 1560185066893L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185066893L + "'", long7 == 1560185066893L);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date32);
        long long35 = fixedMillisecond34.getFirstMillisecond();
        long long36 = fixedMillisecond34.getMiddleMillisecond();
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond34.getFirstMillisecond(calendar37);
        long long39 = fixedMillisecond34.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62104204800001L) + "'", long35 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-62104204800001L) + "'", long36 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62104204800001L) + "'", long38 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62104204800001L) + "'", long39 == (-62104204800001L));
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
//        java.lang.Comparable comparable12 = timeSeries7.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener13);
//        int int15 = day3.compareTo((java.lang.Object) timeSeries7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day3.next();
//        int int17 = day3.getDayOfMonth();
//        long long18 = day3.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560150000000L + "'", long18 == 1560150000000L);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        timeSeries4.removeAgedItems(1560185003850L, false);
//        timeSeries4.setRangeDescription("");
//        timeSeries4.setDescription("December 1");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185066995L + "'", long1 == 1560185066995L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        timeSeries3.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond10.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.Comparable comparable25 = timeSeries20.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = day16.compareTo((java.lang.Object) timeSeries20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day16.next();
//        int int30 = day16.getDayOfMonth();
//        java.lang.Class<?> wildcardClass31 = day16.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day16.previous();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy(regularTimePeriod12, (org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod12, (double) 1560185066995L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 100.0d + "'", comparable25.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(timeSeries33);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener16);
        java.lang.Comparable comparable18 = timeSeries13.getKey();
        timeSeries13.removeAgedItems(false);
        java.lang.String str21 = timeSeries13.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries13.addChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean25 = timeSeries13.getNotify();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo41 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent42 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year35, seriesChangeInfo41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year35.previous();
        java.lang.Object obj44 = null;
        boolean boolean45 = year35.equals(obj44);
        java.util.Date date46 = year35.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year35);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        timeSeries3.setMaximumItemCount((int) (byte) 100);
        timeSeries3.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=-1]");
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=10]");
        java.util.List list30 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, number3);
        java.lang.String str5 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener10);
        long long12 = timeSeries9.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo30 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year24, seriesChangeInfo30);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener36);
        long long38 = timeSeries35.getMaximumItemAge();
        java.lang.Comparable comparable39 = timeSeries35.getKey();
        boolean boolean40 = year24.equals((java.lang.Object) timeSeries35);
        java.lang.Number number41 = null;
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year24, number41, false);
        int int44 = year24.getYear();
        long long45 = year24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year24.previous();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 1560185041322L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 9223372036854775807L + "'", long38 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + 100.0d + "'", comparable39.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62104204800001L) + "'", long45 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj13 = timeSeries12.clone();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 7, false);
        long long27 = year23.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year23.previous();
        java.lang.Number number31 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year23);
        java.lang.String str33 = timeSeries32.getRangeDescription();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100.0d + "'", comparable21.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62119972800001L) + "'", long27 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-December-1969");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185067454L + "'", long1 == 1560185067454L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560185067454L + "'", long6 == 1560185067454L);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
        try {
            java.lang.Number number29 = timeSeries3.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        double double7 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
        long long14 = timeSeries11.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        long long23 = timeSeries20.getMaximumItemAge();
        java.lang.Comparable comparable24 = timeSeries20.getKey();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year26, seriesChangeInfo32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        boolean boolean42 = year26.equals((java.lang.Object) timeSeries37);
        java.lang.Number number43 = null;
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year26, number43, false);
        java.lang.String str46 = timeSeries11.getDomainDescription();
        double double47 = timeSeries11.getMinY();
        java.util.Collection collection48 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond50.previous();
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond50.getMiddleMillisecond(calendar52);
        java.util.Date date54 = fixedMillisecond50.getStart();
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond50.getLastMillisecond(calendar55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (double) 1560184990994L);
        java.lang.Comparable comparable59 = timeSeries3.getKey();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100.0d + "'", comparable24.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + 100.0d + "'", comparable59.equals(100.0d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0);
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        timeSeries7.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass13 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
        long long35 = timeSeries32.getMaximumItemAge();
        java.lang.Comparable comparable36 = timeSeries32.getKey();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 7, false);
        long long42 = year38.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year38.previous();
        boolean boolean44 = year23.equals((java.lang.Object) regularTimePeriod43);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year23);
        long long46 = timeSeries7.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries54.addPropertyChangeListener(propertyChangeListener55);
        long long57 = timeSeries54.getMaximumItemAge();
        java.lang.Comparable comparable58 = timeSeries54.getKey();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries54.add((org.jfree.data.time.RegularTimePeriod) year60, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year60, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries50.addOrUpdate(timeSeriesDataItem65);
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener71 = null;
        timeSeries70.addPropertyChangeListener(propertyChangeListener71);
        long long73 = timeSeries70.getMaximumItemAge();
        java.lang.Comparable comparable74 = timeSeries70.getKey();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries70.add((org.jfree.data.time.RegularTimePeriod) year76, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year76, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo82 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent83 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year76, seriesChangeInfo82);
        int int84 = timeSeries50.getIndex((org.jfree.data.time.RegularTimePeriod) year76);
        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries7.addAndOrUpdate(timeSeries50);
        org.jfree.data.time.TimeSeries timeSeries86 = timeSeries1.addAndOrUpdate(timeSeries85);
        try {
            timeSeries86.delete(8, 9999, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100.0d + "'", comparable21.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62119972800001L) + "'", long42 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775807L + "'", long57 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable58 + "' != '" + 100.0d + "'", comparable58.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 9223372036854775807L + "'", long73 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable74 + "' != '" + 100.0d + "'", comparable74.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(timeSeries85);
        org.junit.Assert.assertNotNull(timeSeries86);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        java.lang.String str38 = timeSeries3.getDomainDescription();
        int int39 = timeSeries3.getItemCount();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(9, 4);
        long long43 = month42.getFirstMillisecond();
        int int44 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month42);
        int int46 = month42.compareTo((java.lang.Object) (-62117424000001L));
        org.jfree.data.time.Year year47 = month42.getYear();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-62020051200000L) + "'", long43 == (-62020051200000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(year47);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.clear();
        double double6 = timeSeries3.getMaxY();
        java.util.List list7 = timeSeries3.getItems();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Comparable comparable9 = timeSeries4.getKey();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener10);
        java.util.Collection collection12 = timeSeries4.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj17 = timeSeries16.clone();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (byte) -1);
        long long22 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 1560184988903L);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(6, year19);
        java.lang.Class<?> wildcardClass26 = year19.getClass();
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100.0d + "'", comparable9.equals(100.0d));
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62119972800001L) + "'", long22 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9, seriesChangeInfo15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        long long23 = timeSeries20.getMaximumItemAge();
        java.lang.Comparable comparable24 = timeSeries20.getKey();
        boolean boolean25 = year9.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year9.next();
        boolean boolean28 = year9.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
        long long35 = timeSeries32.getMaximumItemAge();
        java.lang.Comparable comparable36 = timeSeries32.getKey();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) (short) 10);
        java.lang.Object obj44 = timeSeriesDataItem43.clone();
        timeSeriesDataItem43.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem43, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timeSeries53.addPropertyChangeListener(propertyChangeListener54);
        long long56 = timeSeries53.getMaximumItemAge();
        java.lang.Comparable comparable57 = timeSeries53.getKey();
        java.util.Collection collection58 = timeSeries49.getTimePeriodsUniqueToOtherSeries(timeSeries53);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timeSeries62.addPropertyChangeListener(propertyChangeListener63);
        long long65 = timeSeries62.getMaximumItemAge();
        java.lang.Comparable comparable66 = timeSeries62.getKey();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries62.add((org.jfree.data.time.RegularTimePeriod) year68, (java.lang.Number) 7, false);
        long long72 = year68.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year68.previous();
        int int74 = timeSeries49.getIndex((org.jfree.data.time.RegularTimePeriod) year68);
        int int75 = year9.compareTo((java.lang.Object) int74);
        long long76 = year9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100.0d + "'", comparable24.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 9223372036854775807L + "'", long56 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + 100.0d + "'", comparable57.equals(100.0d));
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 9223372036854775807L + "'", long65 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable66 + "' != '" + 100.0d + "'", comparable66.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-62119972800001L) + "'", long72 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-62104204800001L) + "'", long76 == (-62104204800001L));
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185068193L + "'", long2 == 1560185068193L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185068193L + "'", long3 == 1560185068193L);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = month6.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185068207L + "'", long1 == 1560185068207L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185068207L + "'", long2 == 1560185068207L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185068207L + "'", long4 == 1560185068207L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date5, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timeSeries41.addPropertyChangeListener(propertyChangeListener42);
        long long44 = timeSeries41.getMaximumItemAge();
        java.lang.Comparable comparable45 = timeSeries41.getKey();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo53 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent54 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year47, seriesChangeInfo53);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timeSeries58.addPropertyChangeListener(propertyChangeListener59);
        long long61 = timeSeries58.getMaximumItemAge();
        java.lang.Comparable comparable62 = timeSeries58.getKey();
        boolean boolean63 = year47.equals((java.lang.Object) timeSeries58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year47.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod64, (java.lang.Number) 10L);
        java.lang.Object obj67 = null;
        boolean boolean68 = timeSeriesDataItem66.equals(obj67);
        java.lang.Number number69 = timeSeriesDataItem66.getValue();
        boolean boolean70 = timeSeriesDataItem66.isSelected();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener75 = null;
        timeSeries74.addPropertyChangeListener(propertyChangeListener75);
        long long77 = timeSeries74.getMaximumItemAge();
        java.lang.Comparable comparable78 = timeSeries74.getKey();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries74.add((org.jfree.data.time.RegularTimePeriod) year80, (java.lang.Number) 7, false);
        long long84 = timeSeries74.getMaximumItemAge();
        boolean boolean85 = timeSeriesDataItem66.equals((java.lang.Object) long84);
        timeSeriesDataItem66.setValue((java.lang.Number) (short) 100);
        timeSeries3.add(timeSeriesDataItem66, false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + 100.0d + "'", comparable45.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 9223372036854775807L + "'", long61 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable62 + "' != '" + 100.0d + "'", comparable62.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 10L + "'", number69.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 9223372036854775807L + "'", long77 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable78 + "' != '" + 100.0d + "'", comparable78.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 9223372036854775807L + "'", long84 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) (short) 10);
        boolean boolean49 = month33.equals((java.lang.Object) year43);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        boolean boolean54 = month33.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month33.previous();
        long long56 = month33.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 24L + "'", long56 == 24L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.clear();
        timeSeries3.removeAgedItems((-62135784000001L), false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.lang.Object obj16 = timeSeries3.clone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61977974400001L) + "'", long3 == (-61977974400001L));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.clear();
        double double11 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
        long long18 = timeSeries15.getMaximumItemAge();
        java.lang.Comparable comparable19 = timeSeries15.getKey();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo27 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year21, seriesChangeInfo27);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
        long long35 = timeSeries32.getMaximumItemAge();
        java.lang.Comparable comparable36 = timeSeries32.getKey();
        boolean boolean37 = year21.equals((java.lang.Object) timeSeries32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year21.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod38, (java.lang.Number) 10L);
        java.lang.Object obj41 = null;
        boolean boolean42 = timeSeriesDataItem40.equals(obj41);
        timeSeries3.add(timeSeriesDataItem40);
        boolean boolean44 = timeSeriesDataItem40.isSelected();
        boolean boolean45 = timeSeriesDataItem40.isSelected();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 100.0d + "'", comparable19.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        timeSeriesDataItem18.setValue((java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem18.getPeriod();
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        long long15 = timeSeries12.getMaximumItemAge();
//        java.lang.Comparable comparable16 = timeSeries12.getKey();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
//        long long32 = timeSeries29.getMaximumItemAge();
//        java.lang.Comparable comparable33 = timeSeries29.getKey();
//        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
//        java.lang.Number number35 = null;
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
//        timeSeries3.clear();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
//        long long45 = timeSeries42.getMaximumItemAge();
//        java.lang.Comparable comparable46 = timeSeries42.getKey();
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo54 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year48, seriesChangeInfo54);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener60 = null;
//        timeSeries59.addPropertyChangeListener(propertyChangeListener60);
//        long long62 = timeSeries59.getMaximumItemAge();
//        java.lang.Comparable comparable63 = timeSeries59.getKey();
//        boolean boolean64 = year48.equals((java.lang.Object) timeSeries59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year48.next();
//        boolean boolean67 = year48.equals((java.lang.Object) 8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (byte) 0);
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener74 = null;
//        timeSeries73.addPropertyChangeListener(propertyChangeListener74);
//        long long76 = timeSeries73.getMaximumItemAge();
//        java.lang.Comparable comparable77 = timeSeries73.getKey();
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries73.add((org.jfree.data.time.RegularTimePeriod) year79, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year79, (java.lang.Number) (short) 10);
//        java.lang.Object obj85 = timeSeriesDataItem84.clone();
//        timeSeriesDataItem84.setSelected(true);
//        org.jfree.data.time.TimeSeries timeSeries90 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem84, "0", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries3.addAndOrUpdate(timeSeries90);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond92 = new org.jfree.data.time.FixedMillisecond();
//        long long93 = fixedMillisecond92.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = fixedMillisecond92.next();
//        java.util.Date date95 = fixedMillisecond92.getTime();
//        org.jfree.data.time.Year year96 = new org.jfree.data.time.Year(date95);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = year96.next();
//        timeSeries90.add(regularTimePeriod97, (double) 1560185015497L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable63 + "' != '" + 100.0d + "'", comparable63.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem69);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 9223372036854775807L + "'", long76 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable77 + "' != '" + 100.0d + "'", comparable77.equals(100.0d));
//        org.junit.Assert.assertNotNull(obj85);
//        org.junit.Assert.assertNotNull(timeSeries91);
//        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 1560185068880L + "'", long93 == 1560185068880L);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//        org.junit.Assert.assertNotNull(date95);
//        org.junit.Assert.assertNotNull(regularTimePeriod97);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
        long long14 = timeSeries11.getMaximumItemAge();
        java.lang.Comparable comparable15 = timeSeries11.getKey();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo23 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year17, seriesChangeInfo23);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        boolean boolean33 = year17.equals((java.lang.Object) timeSeries28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year17.next();
        int int35 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timeSeries39.addPropertyChangeListener(propertyChangeListener40);
        long long42 = timeSeries39.getMaximumItemAge();
        java.lang.Comparable comparable43 = timeSeries39.getKey();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo51 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent52 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year45, seriesChangeInfo51);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timeSeries56.addPropertyChangeListener(propertyChangeListener57);
        long long59 = timeSeries56.getMaximumItemAge();
        java.lang.Comparable comparable60 = timeSeries56.getKey();
        boolean boolean61 = year45.equals((java.lang.Object) timeSeries56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year45.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod62, (java.lang.Number) 10L);
        java.lang.Number number65 = timeSeriesDataItem64.getValue();
        int int66 = year17.compareTo((java.lang.Object) timeSeriesDataItem64);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) 1560185035168L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 100.0d + "'", comparable15.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 100.0d + "'", comparable43.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 9223372036854775807L + "'", long59 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable60 + "' != '" + 100.0d + "'", comparable60.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 10L + "'", number65.equals(10L));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year18.next();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj13 = timeSeries12.clone();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 7, false);
        long long27 = year23.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year23.previous();
        java.lang.Number number31 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.String str32 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj37 = timeSeries36.clone();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener46);
        long long48 = timeSeries45.getMaximumItemAge();
        java.lang.Comparable comparable49 = timeSeries45.getKey();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo57 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent58 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year51, seriesChangeInfo57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year51, (double) '#');
        int int61 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj67 = timeSeries66.clone();
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener72 = null;
        timeSeries71.addPropertyChangeListener(propertyChangeListener72);
        long long74 = timeSeries71.getMaximumItemAge();
        java.lang.Comparable comparable75 = timeSeries71.getKey();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries71.add((org.jfree.data.time.RegularTimePeriod) year77, (java.lang.Number) 7, false);
        long long81 = year77.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year77, (double) 10L);
        int int84 = year77.getYear();
        int int85 = fixedMillisecond62.compareTo((java.lang.Object) year77);
        boolean boolean86 = year51.equals((java.lang.Object) fixedMillisecond62);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100.0d + "'", comparable21.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62119972800001L) + "'", long27 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + 100.0d + "'", comparable49.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 9223372036854775807L + "'", long74 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable75 + "' != '" + 100.0d + "'", comparable75.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-62119972800001L) + "'", long81 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        long long13 = year9.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9, seriesChangeInfo14);
        java.lang.Object obj16 = seriesChangeEvent15.getSource();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62119972800001L) + "'", long13 == (-62119972800001L));
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10);
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
        long long18 = timeSeries15.getMaximumItemAge();
        java.lang.Comparable comparable19 = timeSeries15.getKey();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo27 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year21, seriesChangeInfo27);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
        long long35 = timeSeries32.getMaximumItemAge();
        java.lang.Comparable comparable36 = timeSeries32.getKey();
        boolean boolean37 = year21.equals((java.lang.Object) timeSeries32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year21.next();
        int int39 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener44);
        long long46 = timeSeries43.getMaximumItemAge();
        java.lang.Comparable comparable47 = timeSeries43.getKey();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo55 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year49, seriesChangeInfo55);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener61 = null;
        timeSeries60.addPropertyChangeListener(propertyChangeListener61);
        long long63 = timeSeries60.getMaximumItemAge();
        java.lang.Comparable comparable64 = timeSeries60.getKey();
        boolean boolean65 = year49.equals((java.lang.Object) timeSeries60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year49.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod66, (java.lang.Number) 10L);
        java.lang.Number number69 = timeSeriesDataItem68.getValue();
        int int70 = year21.compareTo((java.lang.Object) timeSeriesDataItem68);
        java.lang.Number number71 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year21, number71);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 100.0d + "'", comparable19.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + 100.0d + "'", comparable47.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 9223372036854775807L + "'", long63 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable64 + "' != '" + 100.0d + "'", comparable64.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 10L + "'", number69.equals(10L));
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        long long17 = timeSeries14.getMaximumItemAge();
        java.lang.Comparable comparable18 = timeSeries14.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) (short) 10);
        java.lang.Object obj26 = timeSeriesDataItem25.clone();
        java.lang.Object obj27 = timeSeriesDataItem25.clone();
        timeSeries3.add(timeSeriesDataItem25, true);
        java.lang.String str30 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 4);
        int int3 = month2.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        int int7 = month2.compareTo((java.lang.Object) regularTimePeriod6);
        org.jfree.data.time.Year year8 = month2.getYear();
        java.util.Calendar calendar9 = null;
        try {
            month2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(year8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
        boolean boolean28 = timeSeries3.getNotify();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeries3.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
//        java.lang.Comparable comparable12 = timeSeries7.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener13);
//        int int15 = day3.compareTo((java.lang.Object) timeSeries7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day3.next();
//        int int17 = day3.getDayOfMonth();
//        java.lang.Class<?> wildcardClass18 = day3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries26.addPropertyChangeListener(propertyChangeListener27);
//        long long29 = timeSeries26.getMaximumItemAge();
//        java.lang.Comparable comparable30 = timeSeries26.getKey();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries22.addOrUpdate(timeSeriesDataItem37);
//        timeSeries22.fireSeriesChanged();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(5);
//        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) year41);
//        java.lang.Class class43 = timeSeries22.getTimePeriodClass();
//        boolean boolean44 = day3.equals((java.lang.Object) timeSeries22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(0L);
//        boolean boolean47 = day3.equals((java.lang.Object) fixedMillisecond46);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + 100.0d + "'", comparable30.equals(100.0d));
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        timeSeries3.clear();
        timeSeries3.setNotify(false);
        timeSeries3.removeAgedItems(0L, true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10]");
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        long long16 = timeSeries13.getMaximumItemAge();
        java.lang.Comparable comparable17 = timeSeries13.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 7, false);
        long long38 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year34.previous();
        boolean boolean40 = year19.equals((java.lang.Object) regularTimePeriod39);
        int int41 = year19.getYear();
        java.util.Date date42 = year19.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date42, timeZone44);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date48 = fixedMillisecond47.getTime();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date48, timeZone49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(date48);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date48);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date48);
        long long54 = year53.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100.0d + "'", comparable17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62119972800001L) + "'", long38 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1546329600000L + "'", long54 == 1546329600000L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        long long9 = year6.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        long long16 = timeSeries13.getMaximumItemAge();
        timeSeries13.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass19 = timeSeries13.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        long long26 = timeSeries23.getMaximumItemAge();
        java.lang.Comparable comparable27 = timeSeries23.getKey();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
        long long41 = timeSeries38.getMaximumItemAge();
        java.lang.Comparable comparable42 = timeSeries38.getKey();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 7, false);
        long long48 = year44.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year44.previous();
        boolean boolean50 = year29.equals((java.lang.Object) regularTimePeriod49);
        int int51 = year29.getYear();
        java.util.Date date52 = year29.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
        java.util.TimeZone timeZone54 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date52, timeZone54);
        boolean boolean56 = year6.equals((java.lang.Object) wildcardClass19);
        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62119972800001L) + "'", long9 == (-62119972800001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100.0d + "'", comparable27.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 100.0d + "'", comparable42.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62119972800001L) + "'", long48 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(class57);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("October 4");
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener16);
        java.lang.Comparable comparable18 = timeSeries13.getKey();
        timeSeries13.removeAgedItems(false);
        java.lang.String str21 = timeSeries13.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries13.addChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
        long long35 = timeSeries32.getMaximumItemAge();
        java.lang.Comparable comparable36 = timeSeries32.getKey();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries28.addOrUpdate(timeSeriesDataItem43);
        timeSeriesDataItem43.setValue((java.lang.Number) 100);
        timeSeries13.add(timeSeriesDataItem43);
        try {
            timeSeries13.delete(5, (int) (byte) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem44);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        timeSeries3.setMaximumItemAge((long) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        double double12 = timeSeries3.getMaxY();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener16);
        java.lang.Comparable comparable18 = timeSeries13.getKey();
        timeSeries13.removeAgedItems(false);
        java.lang.String str21 = timeSeries13.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries13.addChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        double double29 = timeSeries28.getMaxY();
        timeSeries28.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        double double32 = timeSeries28.getMaxY();
        java.util.Collection collection33 = timeSeries28.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo49 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year43, seriesChangeInfo49);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries54.addPropertyChangeListener(propertyChangeListener55);
        long long57 = timeSeries54.getMaximumItemAge();
        java.lang.Comparable comparable58 = timeSeries54.getKey();
        boolean boolean59 = year43.equals((java.lang.Object) timeSeries54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year43.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod60, (java.lang.Number) 10L);
        java.lang.Object obj63 = null;
        boolean boolean64 = timeSeriesDataItem62.equals(obj63);
        java.lang.Number number65 = timeSeriesDataItem62.getValue();
        boolean boolean66 = timeSeriesDataItem62.isSelected();
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener71 = null;
        timeSeries70.addPropertyChangeListener(propertyChangeListener71);
        long long73 = timeSeries70.getMaximumItemAge();
        java.lang.Comparable comparable74 = timeSeries70.getKey();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries70.add((org.jfree.data.time.RegularTimePeriod) year76, (java.lang.Number) 7, false);
        long long80 = timeSeries70.getMaximumItemAge();
        boolean boolean81 = timeSeriesDataItem62.equals((java.lang.Object) long80);
        timeSeriesDataItem62.setValue((java.lang.Number) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries28.addOrUpdate(timeSeriesDataItem62);
        boolean boolean85 = timeSeriesDataItem62.isSelected();
        timeSeries13.add(timeSeriesDataItem62);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775807L + "'", long57 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable58 + "' != '" + 100.0d + "'", comparable58.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 10L + "'", number65.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 9223372036854775807L + "'", long73 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable74 + "' != '" + 100.0d + "'", comparable74.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 9223372036854775807L + "'", long80 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) (short) 10);
        boolean boolean49 = month33.equals((java.lang.Object) year43);
        long long50 = month33.getFirstMillisecond();
        long long51 = month33.getLastMillisecond();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent52 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) long51);
        java.lang.Object obj53 = seriesChangeEvent52.getSource();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-62106883200000L) + "'", long50 == (-62106883200000L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-62104204800001L) + "'", long51 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + obj53 + "' != '" + (-62104204800001L) + "'", obj53.equals((-62104204800001L)));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        java.lang.Comparable comparable13 = timeSeries3.getKey();
        boolean boolean14 = timeSeries3.isEmpty();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100.0d + "'", comparable13.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        long long10 = fixedMillisecond1.getLastMillisecond();
        long long11 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
//        long long11 = timeSeries8.getMaximumItemAge();
//        java.lang.Comparable comparable12 = timeSeries8.getKey();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 7, false);
//        long long18 = year14.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year14, (double) 10L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date22 = fixedMillisecond21.getTime();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries28.addPropertyChangeListener(propertyChangeListener31);
//        java.lang.Comparable comparable33 = timeSeries28.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries28.addPropertyChangeListener(propertyChangeListener34);
//        int int36 = day24.compareTo((java.lang.Object) timeSeries28);
//        int int37 = day24.getMonth();
//        int int38 = day24.getMonth();
//        boolean boolean39 = year14.equals((java.lang.Object) day24);
//        int int40 = day24.getDayOfMonth();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62119972800001L) + "'", long18 == (-62119972800001L));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185071562L + "'", long1 == 1560185071562L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560185071562L + "'", long3 == 1560185071562L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185071562L + "'", long4 == 1560185071562L);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        seriesException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        seriesException7.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        long long26 = timeSeries23.getMaximumItemAge();
        java.lang.Comparable comparable27 = timeSeries23.getKey();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year29, seriesChangeInfo35);
        int int37 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj42 = timeSeries41.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries46.addPropertyChangeListener(propertyChangeListener47);
        long long49 = timeSeries46.getMaximumItemAge();
        java.lang.Comparable comparable50 = timeSeries46.getKey();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) 7, false);
        long long56 = year52.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year52, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year52.previous();
        int int60 = timeSeries3.getIndex(regularTimePeriod59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year61, (double) 4);
        java.lang.String str64 = timeSeries3.getDomainDescription();
        timeSeries3.setDescription("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100.0d + "'", comparable27.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + 100.0d + "'", comparable50.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62119972800001L) + "'", long56 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) day5);
//        long long7 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560185071715L + "'", long7 == 1560185071715L);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getSerialIndex();
        long long6 = month4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        long long16 = timeSeries13.getMaximumItemAge();
        java.lang.Comparable comparable17 = timeSeries13.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 7, false);
        long long38 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year34.previous();
        boolean boolean40 = year19.equals((java.lang.Object) regularTimePeriod39);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year19);
        long long42 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener43);
        timeSeries3.setRangeDescription("1");
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100.0d + "'", comparable17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62119972800001L) + "'", long38 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10L, seriesChangeInfo4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = seriesChangeEvent5.getSummary();
//        java.lang.String str7 = seriesChangeEvent5.toString();
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) seriesChangeEvent5);
//        long long9 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond0.peg(calendar10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185071816L + "'", long1 == 1560185071816L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNull(seriesChangeInfo6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str7.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560185071816L + "'", long9 == 1560185071816L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 3);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Date date4 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        int int8 = day5.getMonth();
        java.lang.String str9 = day5.toString();
        long long10 = day5.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        timeSeriesDataItem14.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        long long27 = timeSeries24.getMaximumItemAge();
        java.lang.Comparable comparable28 = timeSeries24.getKey();
        java.util.Collection collection29 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        java.lang.String str30 = timeSeries20.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj35 = timeSeries34.clone();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) year37, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener44);
        long long46 = timeSeries43.getMaximumItemAge();
        java.lang.Comparable comparable47 = timeSeries43.getKey();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo55 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year49, seriesChangeInfo55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year49, (double) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries20.addOrUpdate(timeSeriesDataItem58);
        timeSeries20.setDescription("1");
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries65.addPropertyChangeListener(propertyChangeListener66);
        long long68 = timeSeries65.getMaximumItemAge();
        java.lang.Comparable comparable69 = timeSeries65.getKey();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo77 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent78 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year71, seriesChangeInfo77);
        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener83 = null;
        timeSeries82.addPropertyChangeListener(propertyChangeListener83);
        long long85 = timeSeries82.getMaximumItemAge();
        java.lang.Comparable comparable86 = timeSeries82.getKey();
        boolean boolean87 = year71.equals((java.lang.Object) timeSeries82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = year71.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond92 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = fixedMillisecond92.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = fixedMillisecond92.previous();
        java.util.Date date95 = fixedMillisecond92.getEnd();
        int int96 = timeSeriesDataItem90.compareTo((java.lang.Object) date95);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem97 = timeSeries20.addOrUpdate(timeSeriesDataItem90);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 100.0d + "'", comparable28.equals(100.0d));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + 100.0d + "'", comparable47.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem58);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + 100.0d + "'", comparable69.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 9223372036854775807L + "'", long85 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable86 + "' != '" + 100.0d + "'", comparable86.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(regularTimePeriod93);
        org.junit.Assert.assertNotNull(regularTimePeriod94);
        org.junit.Assert.assertNotNull(date95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem97);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getSerialIndex();
        long long3 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        int int3 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        int int5 = day3.getDayOfMonth();
//        int int6 = day3.getMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 10L, seriesChangeInfo4);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = seriesChangeEvent5.getSummary();
//        java.lang.String str7 = seriesChangeEvent5.toString();
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) seriesChangeEvent5);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        long long15 = timeSeries12.getMaximumItemAge();
//        java.lang.Comparable comparable16 = timeSeries12.getKey();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
//        java.lang.Object obj24 = timeSeriesDataItem23.clone();
//        timeSeriesDataItem23.setSelected(true);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem23, "0", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
//        long long36 = timeSeries33.getMaximumItemAge();
//        java.lang.Comparable comparable37 = timeSeries33.getKey();
//        java.util.Collection collection38 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries33);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
//        long long45 = timeSeries42.getMaximumItemAge();
//        java.lang.Comparable comparable46 = timeSeries42.getKey();
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
//        long long52 = timeSeries42.getMaximumItemAge();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = timeSeries42.getNextTimePeriod();
//        timeSeries33.setKey((java.lang.Comparable) regularTimePeriod53);
//        java.lang.Object obj55 = timeSeries33.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.lang.Object obj61 = timeSeries60.clone();
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener66 = null;
//        timeSeries65.addPropertyChangeListener(propertyChangeListener66);
//        long long68 = timeSeries65.getMaximumItemAge();
//        java.lang.Comparable comparable69 = timeSeries65.getKey();
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 7, false);
//        long long75 = year71.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year71, (double) 10L);
//        int int78 = year71.getYear();
//        int int79 = fixedMillisecond56.compareTo((java.lang.Object) year71);
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, (double) 'a');
//        int int82 = fixedMillisecond0.compareTo((java.lang.Object) 'a');
//        long long83 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185072966L + "'", long1 == 1560185072966L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNull(seriesChangeInfo6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str7.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 9223372036854775807L + "'", long52 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(obj55);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + 100.0d + "'", comparable69.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62119972800001L) + "'", long75 == (-62119972800001L));
//        org.junit.Assert.assertNull(timeSeriesDataItem77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1560185072966L + "'", long83 == 1560185072966L);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        timeSeries3.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond10.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.Comparable comparable25 = timeSeries20.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = day16.compareTo((java.lang.Object) timeSeries20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day16.next();
//        int int30 = day16.getDayOfMonth();
//        java.lang.Class<?> wildcardClass31 = day16.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day16.previous();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy(regularTimePeriod12, (org.jfree.data.time.RegularTimePeriod) day16);
//        try {
//            timeSeries33.update(9999, (java.lang.Number) 1560185008050L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 100.0d + "'", comparable25.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(timeSeries33);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj15 = timeSeries14.clone();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        long long26 = timeSeries23.getMaximumItemAge();
        timeSeries23.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass29 = timeSeries23.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries48.addPropertyChangeListener(propertyChangeListener49);
        long long51 = timeSeries48.getMaximumItemAge();
        java.lang.Comparable comparable52 = timeSeries48.getKey();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) 7, false);
        long long58 = year54.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year54.previous();
        boolean boolean60 = year39.equals((java.lang.Object) regularTimePeriod59);
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries65.addPropertyChangeListener(propertyChangeListener66);
        long long68 = timeSeries65.getMaximumItemAge();
        java.lang.Comparable comparable69 = timeSeries65.getKey();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 7, false);
        long long75 = year71.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year71.previous();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year71);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year71);
        int int79 = year71.getYear();
        java.util.Date date80 = year71.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = year71.previous();
        java.util.Date date82 = year71.getStart();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 100.0d + "'", comparable52.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62119972800001L) + "'", long58 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + 100.0d + "'", comparable69.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62119972800001L) + "'", long75 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(date82);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        long long10 = fixedMillisecond1.getLastMillisecond();
        long long11 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date12 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) class11);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
//        java.lang.Comparable comparable12 = timeSeries7.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener13);
//        int int15 = day3.compareTo((java.lang.Object) timeSeries7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day3.next();
//        int int17 = day3.getDayOfMonth();
//        java.lang.Class<?> wildcardClass18 = day3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries26.addPropertyChangeListener(propertyChangeListener27);
//        long long29 = timeSeries26.getMaximumItemAge();
//        java.lang.Comparable comparable30 = timeSeries26.getKey();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries22.addOrUpdate(timeSeriesDataItem37);
//        timeSeries22.fireSeriesChanged();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(5);
//        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) year41);
//        java.lang.Class class43 = timeSeries22.getTimePeriodClass();
//        boolean boolean44 = day3.equals((java.lang.Object) timeSeries22);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timeSeries48.addPropertyChangeListener(propertyChangeListener49);
//        long long51 = timeSeries48.getMaximumItemAge();
//        boolean boolean53 = timeSeries48.equals((java.lang.Object) 5);
//        boolean boolean54 = timeSeries48.getNotify();
//        timeSeries48.clear();
//        double double56 = timeSeries48.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener61 = null;
//        timeSeries60.addPropertyChangeListener(propertyChangeListener61);
//        long long63 = timeSeries60.getMaximumItemAge();
//        java.lang.Comparable comparable64 = timeSeries60.getKey();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries60.add((org.jfree.data.time.RegularTimePeriod) year66, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year66, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo72 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent73 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year66, seriesChangeInfo72);
//        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener78 = null;
//        timeSeries77.addPropertyChangeListener(propertyChangeListener78);
//        long long80 = timeSeries77.getMaximumItemAge();
//        java.lang.Comparable comparable81 = timeSeries77.getKey();
//        boolean boolean82 = year66.equals((java.lang.Object) timeSeries77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = year66.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod83, (java.lang.Number) 10L);
//        java.lang.Object obj86 = null;
//        boolean boolean87 = timeSeriesDataItem85.equals(obj86);
//        timeSeries48.add(timeSeriesDataItem85);
//        boolean boolean89 = timeSeriesDataItem85.isSelected();
//        boolean boolean90 = day3.equals((java.lang.Object) timeSeriesDataItem85);
//        java.lang.String str91 = day3.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + 100.0d + "'", comparable30.equals(100.0d));
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 9223372036854775807L + "'", long63 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable64 + "' != '" + 100.0d + "'", comparable64.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 9223372036854775807L + "'", long80 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable81 + "' != '" + 100.0d + "'", comparable81.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "10-June-2019" + "'", str91.equals("10-June-2019"));
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0);
        timeSeries1.setNotify(true);
        timeSeries1.removeAgedItems(9223372036854775807L, true);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener11);
        long long13 = timeSeries10.getMaximumItemAge();
        java.lang.Comparable comparable14 = timeSeries10.getKey();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) (short) 10);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        timeSeriesDataItem21.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
        long long34 = timeSeries31.getMaximumItemAge();
        java.lang.Comparable comparable35 = timeSeries31.getKey();
        java.util.Collection collection36 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries40.addPropertyChangeListener(propertyChangeListener41);
        long long43 = timeSeries40.getMaximumItemAge();
        java.lang.Comparable comparable44 = timeSeries40.getKey();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year46, (java.lang.Number) 7, false);
        long long50 = year46.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year46.previous();
        int int52 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timeSeries56.addPropertyChangeListener(propertyChangeListener57);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timeSeries56.addPropertyChangeListener(propertyChangeListener59);
        java.lang.Comparable comparable61 = timeSeries56.getKey();
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timeSeries56.addPropertyChangeListener(propertyChangeListener62);
        java.util.Collection collection64 = timeSeries56.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries27.addAndOrUpdate(timeSeries56);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 9999);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo68 = seriesChangeEvent67.getSummary();
        java.lang.Object obj69 = seriesChangeEvent67.getSource();
        boolean boolean70 = timeSeries56.equals(obj69);
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries1.addAndOrUpdate(timeSeries56);
        java.lang.Comparable comparable72 = timeSeries56.getKey();
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100.0d + "'", comparable14.equals(100.0d));
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 9223372036854775807L + "'", long34 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + 100.0d + "'", comparable35.equals(100.0d));
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + 100.0d + "'", comparable44.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-62119972800001L) + "'", long50 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + comparable61 + "' != '" + 100.0d + "'", comparable61.equals(100.0d));
        org.junit.Assert.assertNotNull(collection64);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertNull(seriesChangeInfo68);
        org.junit.Assert.assertTrue("'" + obj69 + "' != '" + 9999 + "'", obj69.equals(9999));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertTrue("'" + comparable72 + "' != '" + 100.0d + "'", comparable72.equals(100.0d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9, seriesChangeInfo15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        long long23 = timeSeries20.getMaximumItemAge();
        java.lang.Comparable comparable24 = timeSeries20.getKey();
        boolean boolean25 = year9.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod26, (java.lang.Number) 10L);
        java.lang.Number number29 = timeSeriesDataItem28.getValue();
        java.lang.Object obj30 = timeSeriesDataItem28.clone();
        timeSeriesDataItem28.setValue((java.lang.Number) 1);
        java.lang.Object obj33 = null;
        boolean boolean34 = timeSeriesDataItem28.equals(obj33);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener41);
        java.lang.Comparable comparable43 = timeSeries38.getKey();
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener44);
        java.util.Collection collection46 = timeSeries38.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj51 = timeSeries50.clone();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (byte) -1);
        long long56 = year53.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 1560184988903L);
        int int59 = timeSeriesDataItem28.compareTo((java.lang.Object) year53);
        timeSeriesDataItem28.setValue((java.lang.Number) (-62062300800001L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = timeSeriesDataItem28.getPeriod();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100.0d + "'", comparable24.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 10L + "'", number29.equals(10L));
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 100.0d + "'", comparable43.equals(100.0d));
        org.junit.Assert.assertNotNull(collection46);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62119972800001L) + "'", long56 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
//        long long10 = timeSeries7.getMaximumItemAge();
//        java.lang.Comparable comparable11 = timeSeries7.getKey();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
//        long long26 = timeSeries23.getMaximumItemAge();
//        java.lang.Comparable comparable27 = timeSeries23.getKey();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year29, seriesChangeInfo35);
//        int int37 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
//        boolean boolean38 = timeSeries3.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
//        long long45 = timeSeries42.getMaximumItemAge();
//        timeSeries42.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond49.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond49.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date53 = fixedMillisecond52.getTime();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date53);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener60 = null;
//        timeSeries59.addPropertyChangeListener(propertyChangeListener60);
//        java.beans.PropertyChangeListener propertyChangeListener62 = null;
//        timeSeries59.addPropertyChangeListener(propertyChangeListener62);
//        java.lang.Comparable comparable64 = timeSeries59.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener65 = null;
//        timeSeries59.addPropertyChangeListener(propertyChangeListener65);
//        int int67 = day55.compareTo((java.lang.Object) timeSeries59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day55.next();
//        int int69 = day55.getDayOfMonth();
//        java.lang.Class<?> wildcardClass70 = day55.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = day55.previous();
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries42.createCopy(regularTimePeriod51, (org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries3.getDataItem(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100.0d + "'", comparable27.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + comparable64 + "' != '" + 100.0d + "'", comparable64.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem73);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
        timeSeries3.clear();
        timeSeries3.setNotify(true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener16);
        java.lang.Comparable comparable18 = timeSeries13.getKey();
        timeSeries13.removeAgedItems(false);
        java.lang.String str21 = timeSeries13.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries13.addChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean25 = timeSeries13.getNotify();
        timeSeries13.removeAgedItems(1560184987727L, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.previous();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond30.getMiddleMillisecond(calendar32);
        java.util.Date date34 = fixedMillisecond30.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) day35);
        java.util.Calendar calendar37 = null;
        try {
            long long38 = day35.getFirstMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1560184993793L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) day5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) 1560185032911L);
        java.util.Calendar calendar10 = null;
        try {
            day5.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, number3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.lang.Number number7 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, number7);
        timeSeries1.add(timeSeriesDataItem8);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0);
        timeSeries1.setNotify(true);
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries1.equals(obj4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.jfree.data.time.Year year3 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        timeSeriesDataItem14.setSelected(true);
        java.lang.Object obj18 = timeSeriesDataItem14.clone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(obj18);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        java.lang.Comparable comparable7 = timeSeries3.getKey();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
//        long long21 = timeSeries18.getMaximumItemAge();
//        java.lang.Comparable comparable22 = timeSeries18.getKey();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
//        long long28 = year24.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
//        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
//        int int31 = year9.getYear();
//        java.util.Date date32 = year9.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date32);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        long long37 = fixedMillisecond36.getLastMillisecond();
//        boolean boolean38 = fixedMillisecond33.equals((java.lang.Object) fixedMillisecond36);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond33.getLastMillisecond(calendar39);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62104204800001L) + "'", long35 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560185075291L + "'", long37 == 1560185075291L);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62104204800001L) + "'", long40 == (-62104204800001L));
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getLastMillisecond();
//        int int5 = day3.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        long long10 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date11 = fixedMillisecond1.getTime();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond1.getMiddleMillisecond(calendar12);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
//        long long11 = timeSeries8.getMaximumItemAge();
//        java.lang.Comparable comparable12 = timeSeries8.getKey();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 7, false);
//        long long18 = year14.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year14, (double) 10L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date22 = fixedMillisecond21.getTime();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries28.addPropertyChangeListener(propertyChangeListener31);
//        java.lang.Comparable comparable33 = timeSeries28.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries28.addPropertyChangeListener(propertyChangeListener34);
//        int int36 = day24.compareTo((java.lang.Object) timeSeries28);
//        int int37 = day24.getMonth();
//        int int38 = day24.getMonth();
//        boolean boolean39 = year14.equals((java.lang.Object) day24);
//        long long40 = day24.getSerialIndex();
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62119972800001L) + "'", long18 == (-62119972800001L));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 43626L + "'", long40 == 43626L);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        timeSeries3.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond10.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.Comparable comparable25 = timeSeries20.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener26);
//        int int28 = day16.compareTo((java.lang.Object) timeSeries20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day16.next();
//        int int30 = day16.getDayOfMonth();
//        java.lang.Class<?> wildcardClass31 = day16.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day16.previous();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy(regularTimePeriod12, (org.jfree.data.time.RegularTimePeriod) day16);
//        int int34 = day16.getMonth();
//        int int35 = day16.getDayOfMonth();
//        long long36 = day16.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 100.0d + "'", comparable25.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43626L + "'", long36 == 43626L);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries7.getKey();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener13);
        int int15 = day3.compareTo((java.lang.Object) timeSeries7);
        java.lang.String str16 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
//        java.lang.Comparable comparable12 = timeSeries7.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener13);
//        int int15 = day3.compareTo((java.lang.Object) timeSeries7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day3.next();
//        int int17 = day3.getYear();
//        int int18 = day3.getYear();
//        int int19 = day3.getDayOfMonth();
//        long long20 = day3.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "June 2019", "June 2019");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185075715L + "'", long1 == 1560185075715L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185075715L + "'", long2 == 1560185075715L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560185075715L + "'", long4 == 1560185075715L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(false);
        int int11 = timeSeries3.getMaximumItemCount();
        timeSeries3.setNotify(true);
        try {
            timeSeries3.delete(2019, 2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        seriesException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        seriesException8.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.String str25 = timePeriodFormatException18.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.Year year34 = month33.getYear();
        int int35 = month33.getMonth();
        long long36 = month33.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 12 + "'", int35 == 12);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-62106883200000L) + "'", long36 == (-62106883200000L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        long long26 = timeSeries23.getMaximumItemAge();
        java.lang.Comparable comparable27 = timeSeries23.getKey();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year29, seriesChangeInfo35);
        int int37 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj42 = timeSeries41.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries46.addPropertyChangeListener(propertyChangeListener47);
        long long49 = timeSeries46.getMaximumItemAge();
        java.lang.Comparable comparable50 = timeSeries46.getKey();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) 7, false);
        long long56 = year52.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year52, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year52.previous();
        int int60 = timeSeries3.getIndex(regularTimePeriod59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year61, (double) 4);
        int int64 = year61.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year61.previous();
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100.0d + "'", comparable27.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + 100.0d + "'", comparable50.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62119972800001L) + "'", long56 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        timeSeries3.setRangeDescription("");
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=4]");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.String str8 = seriesException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        seriesException13.addSuppressed((java.lang.Throwable) seriesException15);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) seriesException15);
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str17 = timePeriodFormatException7.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        long long34 = month33.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month33.next();
        java.util.Calendar calendar36 = null;
        try {
            long long37 = month33.getLastMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62104204800001L) + "'", long34 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        java.lang.String str38 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timeSeries57.addPropertyChangeListener(propertyChangeListener58);
        long long60 = timeSeries57.getMaximumItemAge();
        java.lang.Comparable comparable61 = timeSeries57.getKey();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries57.add((org.jfree.data.time.RegularTimePeriod) year63, (java.lang.Number) 7, false);
        long long67 = year63.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year63.previous();
        boolean boolean69 = year48.equals((java.lang.Object) regularTimePeriod68);
        int int70 = year48.getYear();
        java.util.Date date71 = year48.getEnd();
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month(date71);
        org.jfree.data.time.Year year73 = month72.getYear();
        org.jfree.data.time.Year year74 = month72.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year74.previous();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year74);
        long long77 = year74.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 9223372036854775807L + "'", long60 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable61 + "' != '" + 100.0d + "'", comparable61.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-62119972800001L) + "'", long67 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(year73);
        org.junit.Assert.assertNotNull(year74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-62135740800000L) + "'", long77 == (-62135740800000L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries4.getMaximumItemAge();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries19.addPropertyChangeListener(propertyChangeListener20);
        long long22 = timeSeries19.getMaximumItemAge();
        java.lang.Comparable comparable23 = timeSeries19.getKey();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 7, false);
        long long29 = year25.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year25.previous();
        boolean boolean31 = year10.equals((java.lang.Object) regularTimePeriod30);
        int int32 = year10.getYear();
        java.util.Date date33 = year10.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date33);
        int int36 = day0.compareTo((java.lang.Object) date33);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date33);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 100.0d + "'", comparable23.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-62119972800001L) + "'", long29 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
//        long long11 = timeSeries8.getMaximumItemAge();
//        boolean boolean13 = timeSeries8.equals((java.lang.Object) 5);
//        boolean boolean14 = timeSeries8.getNotify();
//        timeSeries8.clear();
//        timeSeries8.removeAgedItems(true);
//        int int18 = day3.compareTo((java.lang.Object) true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day3.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.Year year34 = month33.getYear();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
        long long41 = timeSeries38.getMaximumItemAge();
        boolean boolean43 = timeSeries38.equals((java.lang.Object) 5);
        boolean boolean44 = timeSeries38.getNotify();
        timeSeries38.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener51);
        long long53 = timeSeries50.getMaximumItemAge();
        java.lang.Comparable comparable54 = timeSeries50.getKey();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) (short) 10);
        java.lang.Object obj62 = timeSeriesDataItem61.clone();
        timeSeriesDataItem61.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries38.addOrUpdate(timeSeriesDataItem61);
        java.lang.Class class66 = timeSeries38.getTimePeriodClass();
        int int67 = month33.compareTo((java.lang.Object) timeSeries38);
        try {
            timeSeries38.setMaximumItemAge((long) (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 9223372036854775807L + "'", long53 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + 100.0d + "'", comparable54.equals(100.0d));
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(class66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(false);
        int int11 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
        long long18 = timeSeries15.getMaximumItemAge();
        java.lang.Comparable comparable19 = timeSeries15.getKey();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo27 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year21, seriesChangeInfo27);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
        long long35 = timeSeries32.getMaximumItemAge();
        java.lang.Comparable comparable36 = timeSeries32.getKey();
        boolean boolean37 = year21.equals((java.lang.Object) timeSeries32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year21.next();
        boolean boolean40 = year21.equals((java.lang.Object) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year21.previous();
        timeSeries3.delete(regularTimePeriod41);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries46.addPropertyChangeListener(propertyChangeListener47);
        long long49 = timeSeries46.getMaximumItemAge();
        java.lang.Comparable comparable50 = timeSeries46.getKey();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timeSeries61.addPropertyChangeListener(propertyChangeListener62);
        long long64 = timeSeries61.getMaximumItemAge();
        java.lang.Comparable comparable65 = timeSeries61.getKey();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) year67, (java.lang.Number) 7, false);
        long long71 = year67.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year67.previous();
        boolean boolean73 = year52.equals((java.lang.Object) regularTimePeriod72);
        int int74 = year52.getYear();
        java.util.Date date75 = year52.getEnd();
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date75);
        int int77 = month76.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = month76.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = month76.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month76);
        long long81 = month76.getFirstMillisecond();
        java.util.Calendar calendar82 = null;
        try {
            long long83 = month76.getMiddleMillisecond(calendar82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 100.0d + "'", comparable19.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + 100.0d + "'", comparable50.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 9223372036854775807L + "'", long64 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable65 + "' != '" + 100.0d + "'", comparable65.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-62119972800001L) + "'", long71 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNull(timeSeriesDataItem80);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-62106883200000L) + "'", long81 == (-62106883200000L));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener12);
        java.lang.Comparable comparable14 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener28);
        long long30 = timeSeries27.getMaximumItemAge();
        java.lang.Comparable comparable31 = timeSeries27.getKey();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo39 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year33, seriesChangeInfo39);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
        long long47 = timeSeries44.getMaximumItemAge();
        java.lang.Comparable comparable48 = timeSeries44.getKey();
        boolean boolean49 = year33.equals((java.lang.Object) timeSeries44);
        java.lang.Number number50 = null;
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year33, number50, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year33);
        int int54 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) (short) 100);
        java.lang.Number number57 = timeSeriesDataItem56.getValue();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100.0d + "'", comparable14.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 100.0d + "'", comparable31.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 9223372036854775807L + "'", long47 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + 100.0d + "'", comparable48.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (short) 100 + "'", number57.equals((short) 100));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        long long26 = timeSeries23.getMaximumItemAge();
        java.lang.Comparable comparable27 = timeSeries23.getKey();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year29, seriesChangeInfo35);
        int int37 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj42 = timeSeries41.clone();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries46.addPropertyChangeListener(propertyChangeListener47);
        long long49 = timeSeries46.getMaximumItemAge();
        java.lang.Comparable comparable50 = timeSeries46.getKey();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) 7, false);
        long long56 = year52.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year52, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year52.previous();
        int int60 = timeSeries3.getIndex(regularTimePeriod59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year61, (double) 4);
        java.lang.String str64 = timeSeries3.getDomainDescription();
        timeSeries3.fireSeriesChanged();
        double double66 = timeSeries3.getMaxY();
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100.0d + "'", comparable27.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + 100.0d + "'", comparable50.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62119972800001L) + "'", long56 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 10.0d + "'", double66 == 10.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        timeSeries3.clear();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
        long long35 = timeSeries32.getMaximumItemAge();
        java.lang.Comparable comparable36 = timeSeries32.getKey();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 7, false);
        long long42 = year38.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year38.previous();
        boolean boolean44 = year23.equals((java.lang.Object) regularTimePeriod43);
        int int45 = year23.getYear();
        java.util.Date date46 = year23.getEnd();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date46);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener52);
        long long54 = timeSeries51.getMaximumItemAge();
        java.lang.Comparable comparable55 = timeSeries51.getKey();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) year57, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year57, (java.lang.Number) (short) 10);
        boolean boolean63 = month47.equals((java.lang.Object) year57);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        boolean boolean68 = month47.equals((java.lang.Object) 100.0d);
        int int69 = month47.getYearValue();
        boolean boolean70 = timeSeries3.equals((java.lang.Object) month47);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener71 = null;
        timeSeries3.removeChangeListener(seriesChangeListener71);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100.0d + "'", comparable21.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62119972800001L) + "'", long42 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 9223372036854775807L + "'", long54 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + 100.0d + "'", comparable55.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(5);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year22);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year22.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo54 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year48, seriesChangeInfo54);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries59.addPropertyChangeListener(propertyChangeListener60);
        long long62 = timeSeries59.getMaximumItemAge();
        java.lang.Comparable comparable63 = timeSeries59.getKey();
        boolean boolean64 = year48.equals((java.lang.Object) timeSeries59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year48.next();
        boolean boolean67 = year48.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (byte) 0);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo70 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent71 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year48, seriesChangeInfo70);
        java.lang.String str72 = seriesChangeEvent71.toString();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable63 + "' != '" + 100.0d + "'", comparable63.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str72.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        long long34 = month33.getLastMillisecond();
        long long35 = month33.getSerialIndex();
        java.util.Calendar calendar36 = null;
        try {
            long long37 = month33.getLastMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62104204800001L) + "'", long34 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24L + "'", long35 == 24L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        timeSeriesDataItem14.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        long long27 = timeSeries24.getMaximumItemAge();
        java.lang.Comparable comparable28 = timeSeries24.getKey();
        java.util.Collection collection29 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        java.lang.String str30 = timeSeries20.getDomainDescription();
        timeSeries20.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 100.0d + "'", comparable28.equals(100.0d));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj15 = timeSeries14.clone();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        long long26 = timeSeries23.getMaximumItemAge();
        timeSeries23.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass29 = timeSeries23.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries48.addPropertyChangeListener(propertyChangeListener49);
        long long51 = timeSeries48.getMaximumItemAge();
        java.lang.Comparable comparable52 = timeSeries48.getKey();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) 7, false);
        long long58 = year54.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year54.previous();
        boolean boolean60 = year39.equals((java.lang.Object) regularTimePeriod59);
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries65.addPropertyChangeListener(propertyChangeListener66);
        long long68 = timeSeries65.getMaximumItemAge();
        java.lang.Comparable comparable69 = timeSeries65.getKey();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 7, false);
        long long75 = year71.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year71.previous();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year71);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year71);
        int int79 = year71.getYear();
        java.util.Date date80 = year71.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = year71.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod81, (double) 1560185030458L);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 100.0d + "'", comparable52.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62119972800001L) + "'", long58 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + 100.0d + "'", comparable69.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62119972800001L) + "'", long75 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        double double9 = timeSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj14 = timeSeries13.clone();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
        long long25 = timeSeries22.getMaximumItemAge();
        java.lang.Comparable comparable26 = timeSeries22.getKey();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo34 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year28, seriesChangeInfo34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year28, (double) '#');
        timeSeries13.clear();
        double double39 = timeSeries13.getMinY();
        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        int int41 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 100.0d + "'", comparable26.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2147483647 + "'", int41 == 2147483647);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0);
        timeSeries1.setNotify(true);
        timeSeries1.removeAgedItems(9223372036854775807L, true);
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
        long long14 = timeSeries11.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        long long23 = timeSeries20.getMaximumItemAge();
        java.lang.Comparable comparable24 = timeSeries20.getKey();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year26, seriesChangeInfo32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        long long40 = timeSeries37.getMaximumItemAge();
        java.lang.Comparable comparable41 = timeSeries37.getKey();
        boolean boolean42 = year26.equals((java.lang.Object) timeSeries37);
        java.lang.Number number43 = null;
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year26, number43, false);
        java.lang.String str46 = timeSeries11.getDomainDescription();
        java.util.Collection collection47 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date49 = fixedMillisecond48.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date51 = fixedMillisecond50.getTime();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51);
        boolean boolean54 = fixedMillisecond48.equals((java.lang.Object) day53);
        java.lang.Number number55 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day53, number55);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener61 = null;
        timeSeries60.addPropertyChangeListener(propertyChangeListener61);
        long long63 = timeSeries60.getMaximumItemAge();
        java.lang.Comparable comparable64 = timeSeries60.getKey();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries60.add((org.jfree.data.time.RegularTimePeriod) year66, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year66, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo72 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent73 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year66, seriesChangeInfo72);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo74 = seriesChangeEvent73.getSummary();
        int int75 = timeSeriesDataItem56.compareTo((java.lang.Object) seriesChangeInfo74);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries11.addOrUpdate(timeSeriesDataItem56);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100.0d + "'", comparable24.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 100.0d + "'", comparable41.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 9223372036854775807L + "'", long63 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable64 + "' != '" + 100.0d + "'", comparable64.equals(100.0d));
        org.junit.Assert.assertNull(seriesChangeInfo74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        java.util.Collection collection11 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj16 = timeSeries15.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (byte) -1);
        long long21 = year18.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 1560184988903L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
        try {
            timeSeries3.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62119972800001L) + "'", long21 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem23);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        timeSeries3.removeAgedItems(1560184988062L, true);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj17 = timeSeries16.clone();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener26);
        long long28 = timeSeries25.getMaximumItemAge();
        java.lang.Comparable comparable29 = timeSeries25.getKey();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo37 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year31, seriesChangeInfo37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (double) '#');
        double double41 = timeSeries16.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener46);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener48);
        java.lang.Comparable comparable50 = timeSeries45.getKey();
        timeSeries45.removeAgedItems(false);
        java.lang.String str53 = timeSeries45.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries45.addChangeListener(seriesChangeListener54);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries16.addAndOrUpdate(timeSeries45);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries3.addAndOrUpdate(timeSeries56);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 100.0d + "'", comparable29.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 35.0d + "'", double41 == 35.0d);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + 100.0d + "'", comparable50.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("December 1");
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "", "org.jfree.data.event.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("0");
        boolean boolean3 = year1.equals((java.lang.Object) 1560185020252L);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1561964399999L);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries4.getMaximumItemAge();
        boolean boolean9 = timeSeries4.equals((java.lang.Object) 5);
        boolean boolean10 = timeSeries4.getNotify();
        timeSeries4.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener17);
        long long19 = timeSeries16.getMaximumItemAge();
        java.lang.Comparable comparable20 = timeSeries16.getKey();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) (short) 10);
        java.lang.Object obj28 = timeSeriesDataItem27.clone();
        timeSeriesDataItem27.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries4.addOrUpdate(timeSeriesDataItem27);
        java.lang.Class class32 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries36.addPropertyChangeListener(propertyChangeListener37);
        long long39 = timeSeries36.getMaximumItemAge();
        java.lang.Comparable comparable40 = timeSeries36.getKey();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) year42, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener52);
        long long54 = timeSeries51.getMaximumItemAge();
        java.lang.Comparable comparable55 = timeSeries51.getKey();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) year57, (java.lang.Number) 7, false);
        long long61 = year57.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year57.previous();
        boolean boolean63 = year42.equals((java.lang.Object) regularTimePeriod62);
        int int64 = year42.getYear();
        java.util.Date date65 = year42.getEnd();
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(date65);
        java.util.TimeZone timeZone67 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date65, timeZone67);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date65);
        java.util.TimeZone timeZone70 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date65, timeZone70);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 100.0d + "'", comparable20.equals(100.0d));
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable40 + "' != '" + 100.0d + "'", comparable40.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 9223372036854775807L + "'", long54 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + 100.0d + "'", comparable55.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-62119972800001L) + "'", long61 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNull(regularTimePeriod71);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        long long10 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        long long17 = timeSeries14.getMaximumItemAge();
        java.lang.Comparable comparable18 = timeSeries14.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 7, false);
        long long24 = year20.getFirstMillisecond();
        int int25 = fixedMillisecond1.compareTo((java.lang.Object) year20);
        java.util.Date date26 = fixedMillisecond1.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62135740800000L) + "'", long24 == (-62135740800000L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=true]");
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 12, "10-June-2019", "0");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries4.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
        long long45 = timeSeries42.getMaximumItemAge();
        java.lang.Comparable comparable46 = timeSeries42.getKey();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo54 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year48, seriesChangeInfo54);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries59.addPropertyChangeListener(propertyChangeListener60);
        long long62 = timeSeries59.getMaximumItemAge();
        java.lang.Comparable comparable63 = timeSeries59.getKey();
        boolean boolean64 = year48.equals((java.lang.Object) timeSeries59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year48.next();
        boolean boolean67 = year48.equals((java.lang.Object) 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (byte) 0);
        timeSeries3.setDomainDescription("hi!");
        int int72 = timeSeries3.getItemCount();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year74, (java.lang.Number) 2019L);
        boolean boolean77 = timeSeriesDataItem76.isSelected();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 100.0d + "'", comparable46.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable63 + "' != '" + 100.0d + "'", comparable63.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) day5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) 1560185032911L);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        long long17 = timeSeries14.getMaximumItemAge();
        java.lang.Comparable comparable18 = timeSeries14.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 7, false);
        long long24 = year20.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year20.previous();
        java.util.Date date26 = year20.getEnd();
        int int27 = month10.compareTo((java.lang.Object) year20);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year20, "", "1");
        int int31 = timeSeriesDataItem9.compareTo((java.lang.Object) "");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62119972800001L) + "'", long24 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
        timeSeries3.clear();
        double double29 = timeSeries3.getMinY();
        timeSeries3.setNotify(false);
        try {
            timeSeries3.delete((int) (short) 100, 8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Date date4 = fixedMillisecond1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9, seriesChangeInfo15);
        java.lang.String str17 = seriesChangeEvent16.toString();
        java.lang.Object obj18 = seriesChangeEvent16.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
        seriesChangeEvent16.setSummary(seriesChangeInfo19);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str17.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        timeSeries3.removeAgedItems(1560184988062L, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond14.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond14.getStart();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 1560185016911L);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day19.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        timeSeries3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 9999);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertNull(seriesChangeInfo2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=9999]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=9999]"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 4);
        long long3 = month2.getLastMillisecond();
        java.lang.String str4 = month2.toString();
        long long5 = month2.getFirstMillisecond();
        java.util.Date date6 = month2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.next();
        long long8 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62017459200001L) + "'", long3 == (-62017459200001L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "September 4" + "'", str4.equals("September 4"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62020051200000L) + "'", long5 == (-62020051200000L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62017459200001L) + "'", long8 == (-62017459200001L));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener9);
        long long11 = timeSeries8.getMaximumItemAge();
        java.lang.Comparable comparable12 = timeSeries8.getKey();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 7, false);
        long long18 = year14.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year14, (double) 10L);
        java.util.List list21 = timeSeries3.getItems();
        java.util.Collection collection22 = timeSeries3.getTimePeriods();
        java.lang.String str23 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0d + "'", comparable12.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62119972800001L) + "'", long18 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
//        boolean boolean9 = timeSeries3.getNotify();
//        timeSeries3.clear();
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
//        java.util.Calendar calendar16 = null;
//        fixedMillisecond12.peg(calendar16);
//        long long18 = fixedMillisecond12.getLastMillisecond();
//        int int19 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
//        long long26 = timeSeries23.getMaximumItemAge();
//        java.lang.Comparable comparable27 = timeSeries23.getKey();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year29, seriesChangeInfo35);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo37 = null;
//        seriesChangeEvent36.setSummary(seriesChangeInfo37);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesChangeEvent36);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo40 = null;
//        seriesChangeEvent36.setSummary(seriesChangeInfo40);
//        boolean boolean42 = fixedMillisecond12.equals((java.lang.Object) seriesChangeEvent36);
//        java.lang.String str43 = seriesChangeEvent36.toString();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185078157L + "'", long13 == 1560185078157L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185078157L + "'", long14 == 1560185078157L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560185078157L + "'", long18 == 1560185078157L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100.0d + "'", comparable27.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str43.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Date date4 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185078220L + "'", long1 == 1560185078220L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
//        long long8 = timeSeries5.getMaximumItemAge();
//        java.lang.Comparable comparable9 = timeSeries5.getKey();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (short) 10);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        timeSeriesDataItem16.setSelected(true);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "0", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries26.addPropertyChangeListener(propertyChangeListener27);
//        long long29 = timeSeries26.getMaximumItemAge();
//        java.lang.Comparable comparable30 = timeSeries26.getKey();
//        java.util.Collection collection31 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries26);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timeSeries35.addPropertyChangeListener(propertyChangeListener36);
//        long long38 = timeSeries35.getMaximumItemAge();
//        java.lang.Comparable comparable39 = timeSeries35.getKey();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) year41, (java.lang.Number) 7, false);
//        long long45 = timeSeries35.getMaximumItemAge();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries35.getNextTimePeriod();
//        timeSeries26.setKey((java.lang.Comparable) regularTimePeriod46);
//        java.lang.Object obj48 = timeSeries26.clone();
//        boolean boolean49 = day0.equals((java.lang.Object) timeSeries26);
//        long long50 = day0.getSerialIndex();
//        int int51 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100.0d + "'", comparable9.equals(100.0d));
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + 100.0d + "'", comparable30.equals(100.0d));
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 9223372036854775807L + "'", long38 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + 100.0d + "'", comparable39.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(obj48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 43626L + "'", long50 == 43626L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, (int) ' ');
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries4.getMaximumItemAge();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 7, false);
        long long14 = year10.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.previous();
        java.util.Date date16 = year10.getEnd();
        int int17 = month0.compareTo((java.lang.Object) year10);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year10, "", "1");
        long long21 = year10.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62119972800001L) + "'", long14 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62104204800001L) + "'", long21 == (-62104204800001L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        java.lang.Number number35 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, number35, false);
        java.lang.String str38 = timeSeries3.getDomainDescription();
        int int39 = timeSeries3.getItemCount();
        timeSeries3.removeAgedItems(1560185043753L, true);
        try {
            timeSeries3.delete(100, 7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries3.isEmpty();
        timeSeries3.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        timeSeriesDataItem14.setValue((java.lang.Number) 100);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100, "org.jfree.data.time.TimePeriodFormatException: ", "0");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries19.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
//        timeSeries3.clear();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries3.addChangeListener(seriesChangeListener12);
//        timeSeries3.setDomainDescription("September 4");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        long long17 = fixedMillisecond16.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond16.next();
//        java.util.Date date19 = fixedMillisecond16.getTime();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
//        long long22 = year20.getSerialIndex();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 1560184998477L);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560185078383L + "'", long17 == 1560185078383L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9, seriesChangeInfo15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year9.previous();
        java.lang.Object obj18 = null;
        boolean boolean19 = year9.equals(obj18);
        java.util.Date date20 = year9.getStart();
        int int21 = year9.getYear();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries13.addPropertyChangeListener(propertyChangeListener16);
//        java.lang.Comparable comparable18 = timeSeries13.getKey();
//        timeSeries13.removeAgedItems(false);
//        java.lang.String str21 = timeSeries13.getDomainDescription();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries13.addChangeListener(seriesChangeListener22);
//        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.lang.String str25 = timeSeries13.getDescription();
//        boolean boolean26 = timeSeries13.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        long long28 = fixedMillisecond27.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond27.next();
//        java.util.Date date30 = fixedMillisecond27.getTime();
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond27.peg(calendar31);
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560185078443L + "'", long28 == 1560185078443L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        boolean boolean8 = timeSeries3.equals((java.lang.Object) 5);
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.clear();
        timeSeries3.removeAgedItems((-62135784000001L), false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        java.util.List list16 = timeSeries3.getItems();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent(obj4);
        java.lang.Object obj6 = seriesChangeEvent5.getSource();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        long long13 = year9.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9, seriesChangeInfo14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year9.next();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62119972800001L) + "'", long13 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.Year year34 = month33.getYear();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
        long long41 = timeSeries38.getMaximumItemAge();
        boolean boolean43 = timeSeries38.equals((java.lang.Object) 5);
        boolean boolean44 = timeSeries38.getNotify();
        timeSeries38.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener51);
        long long53 = timeSeries50.getMaximumItemAge();
        java.lang.Comparable comparable54 = timeSeries50.getKey();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) (short) 10);
        java.lang.Object obj62 = timeSeriesDataItem61.clone();
        timeSeriesDataItem61.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries38.addOrUpdate(timeSeriesDataItem61);
        java.lang.Class class66 = timeSeries38.getTimePeriodClass();
        int int67 = month33.compareTo((java.lang.Object) timeSeries38);
        java.lang.Comparable comparable68 = timeSeries38.getKey();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener69 = null;
        timeSeries38.removeChangeListener(seriesChangeListener69);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 9223372036854775807L + "'", long53 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + 100.0d + "'", comparable54.equals(100.0d));
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(class66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + comparable68 + "' != '" + 100.0d + "'", comparable68.equals(100.0d));
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.next();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560185078656L + "'", long1 == 1560185078656L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185078656L + "'", long2 == 1560185078656L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        timeSeries3.clear();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
        long long35 = timeSeries32.getMaximumItemAge();
        java.lang.Comparable comparable36 = timeSeries32.getKey();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 7, false);
        long long42 = year38.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year38.previous();
        boolean boolean44 = year23.equals((java.lang.Object) regularTimePeriod43);
        int int45 = year23.getYear();
        java.util.Date date46 = year23.getEnd();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date46);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener52);
        long long54 = timeSeries51.getMaximumItemAge();
        java.lang.Comparable comparable55 = timeSeries51.getKey();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) year57, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year57, (java.lang.Number) (short) 10);
        boolean boolean63 = month47.equals((java.lang.Object) year57);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        boolean boolean68 = month47.equals((java.lang.Object) 100.0d);
        int int69 = month47.getYearValue();
        boolean boolean70 = timeSeries3.equals((java.lang.Object) month47);
        java.beans.PropertyChangeListener propertyChangeListener71 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener71);
        java.beans.PropertyChangeListener propertyChangeListener73 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener73);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100.0d + "'", comparable21.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 100.0d + "'", comparable36.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62119972800001L) + "'", long42 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 9223372036854775807L + "'", long54 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + 100.0d + "'", comparable55.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries4.getMaximumItemAge();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year18.next();
        int int36 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(7, year18);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37);
        org.jfree.data.time.Year year39 = month37.getYear();
        long long40 = month37.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62117424000001L) + "'", long40 == (-62117424000001L));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        long long10 = timeSeries7.getMaximumItemAge();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(5);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year22);
        double double24 = timeSeries3.getMaxY();
        double double25 = timeSeries3.getMinY();
        timeSeries3.setDescription("1");
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100.0d + "'", comparable11.equals(100.0d));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        long long17 = timeSeries14.getMaximumItemAge();
        timeSeries14.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass20 = timeSeries14.getClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener27);
        java.lang.Comparable comparable29 = timeSeries24.getKey();
        timeSeries24.removeAgedItems(false);
        java.lang.String str32 = timeSeries24.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries24.addChangeListener(seriesChangeListener33);
        java.util.Collection collection35 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        boolean boolean36 = timeSeries24.getNotify();
        int int37 = timeSeries24.getMaximumItemCount();
        int int38 = year10.compareTo((java.lang.Object) timeSeries24);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1560185013075L);
        java.lang.String str41 = timeSeries3.getDescription();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 100.0d + "'", comparable29.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries4.getMaximumItemAge();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year10, seriesChangeInfo16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.addPropertyChangeListener(propertyChangeListener22);
        long long24 = timeSeries21.getMaximumItemAge();
        java.lang.Comparable comparable25 = timeSeries21.getKey();
        boolean boolean26 = year10.equals((java.lang.Object) timeSeries21);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(8, year10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 100.0d + "'", comparable25.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getDayOfMonth();
//        int int6 = day3.getMonth();
//        java.lang.String str7 = day3.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        long long16 = timeSeries13.getMaximumItemAge();
        java.lang.Comparable comparable17 = timeSeries13.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
        long long31 = timeSeries28.getMaximumItemAge();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 7, false);
        long long38 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year34.previous();
        boolean boolean40 = year19.equals((java.lang.Object) regularTimePeriod39);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year19);
        long long42 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener43);
        java.lang.String str45 = timeSeries3.getDescription();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 100.0d + "'", comparable17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100.0d + "'", comparable32.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62119972800001L) + "'", long38 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
        org.junit.Assert.assertNull(str45);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.lang.Object obj4 = timeSeries3.clone();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) -1);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        long long15 = timeSeries12.getMaximumItemAge();
//        java.lang.Comparable comparable16 = timeSeries12.getKey();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) '#');
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.lang.Object obj32 = timeSeries31.clone();
//        timeSeries31.clear();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries37.addPropertyChangeListener(propertyChangeListener40);
//        java.lang.Comparable comparable42 = timeSeries37.getKey();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timeSeries46.addPropertyChangeListener(propertyChangeListener47);
//        long long49 = timeSeries46.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timeSeries46.addPropertyChangeListener(propertyChangeListener50);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timeSeries55.addPropertyChangeListener(propertyChangeListener56);
//        long long58 = timeSeries55.getMaximumItemAge();
//        java.lang.Comparable comparable59 = timeSeries55.getKey();
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries55.add((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) (short) 10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo67 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent68 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year61, seriesChangeInfo67);
//        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener73 = null;
//        timeSeries72.addPropertyChangeListener(propertyChangeListener73);
//        long long75 = timeSeries72.getMaximumItemAge();
//        java.lang.Comparable comparable76 = timeSeries72.getKey();
//        boolean boolean77 = year61.equals((java.lang.Object) timeSeries72);
//        java.lang.Number number78 = null;
//        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) year61, number78, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year61);
//        int int82 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) year61);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date84 = fixedMillisecond83.getTime();
//        long long85 = fixedMillisecond83.getSerialIndex();
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = fixedMillisecond83.next();
//        timeSeries3.delete(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 100.0d + "'", comparable42.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 9223372036854775807L + "'", long58 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + 100.0d + "'", comparable59.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 9223372036854775807L + "'", long75 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable76 + "' != '" + 100.0d + "'", comparable76.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560185078991L + "'", long85 == 1560185078991L);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond3.getFirstMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond3.next();
        java.util.Date date9 = fixedMillisecond3.getTime();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond3.getFirstMillisecond(calendar10);
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) long11);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        double double7 = timeSeries3.getMaxY();
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Comparable comparable16 = timeSeries12.getKey();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18, seriesChangeInfo24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
        long long32 = timeSeries29.getMaximumItemAge();
        java.lang.Comparable comparable33 = timeSeries29.getKey();
        boolean boolean34 = year18.equals((java.lang.Object) timeSeries29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod35, (java.lang.Number) 10L);
        java.lang.Object obj38 = null;
        boolean boolean39 = timeSeriesDataItem37.equals(obj38);
        java.lang.Number number40 = timeSeriesDataItem37.getValue();
        boolean boolean41 = timeSeriesDataItem37.isSelected();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener46);
        long long48 = timeSeries45.getMaximumItemAge();
        java.lang.Comparable comparable49 = timeSeries45.getKey();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 7, false);
        long long55 = timeSeries45.getMaximumItemAge();
        boolean boolean56 = timeSeriesDataItem37.equals((java.lang.Object) long55);
        timeSeriesDataItem37.setValue((java.lang.Number) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate(timeSeriesDataItem37);
        java.lang.Number number60 = timeSeriesDataItem37.getValue();
        java.lang.Number number61 = timeSeriesDataItem37.getValue();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0d + "'", comparable16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 10L + "'", number40.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + 100.0d + "'", comparable49.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 9223372036854775807L + "'", long55 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + (short) 100 + "'", number60.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (short) 100 + "'", number61.equals((short) 100));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.lang.String str5 = fixedMillisecond1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str5.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        long long11 = year9.getFirstMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.String str13 = timeSeries3.getDescription();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj15 = timeSeries14.clone();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        long long26 = timeSeries23.getMaximumItemAge();
        timeSeries23.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass29 = timeSeries23.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries48.addPropertyChangeListener(propertyChangeListener49);
        long long51 = timeSeries48.getMaximumItemAge();
        java.lang.Comparable comparable52 = timeSeries48.getKey();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) 7, false);
        long long58 = year54.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year54.previous();
        boolean boolean60 = year39.equals((java.lang.Object) regularTimePeriod59);
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries65.addPropertyChangeListener(propertyChangeListener66);
        long long68 = timeSeries65.getMaximumItemAge();
        java.lang.Comparable comparable69 = timeSeries65.getKey();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 7, false);
        long long75 = year71.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year71.previous();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year71);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year71);
        timeSeries78.setRangeDescription("");
        double double81 = timeSeries78.getMinY();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 100.0d + "'", comparable52.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62119972800001L) + "'", long58 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 9223372036854775807L + "'", long68 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable69 + "' != '" + 100.0d + "'", comparable69.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62119972800001L) + "'", long75 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertEquals((double) double81, Double.NaN, 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj4 = timeSeries3.clone();
        timeSeries3.clear();
        double double6 = timeSeries3.getMaxY();
        timeSeries3.setMaximumItemAge(1560185000668L);
        java.util.Collection collection9 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.lang.Object obj13 = timeSeries12.clone();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 7, false);
        long long27 = year23.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year23.previous();
        java.lang.Number number31 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year23);
        long long32 = year23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) 1560184998477L);
        java.lang.Object obj35 = timeSeriesDataItem34.clone();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0d + "'", comparable8.equals(100.0d));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100.0d + "'", comparable21.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62119972800001L) + "'", long27 == (-62119972800001L));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(obj35);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
//        long long6 = timeSeries3.getMaximumItemAge();
//        java.lang.Comparable comparable7 = timeSeries3.getKey();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
//        long long21 = timeSeries18.getMaximumItemAge();
//        java.lang.Comparable comparable22 = timeSeries18.getKey();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
//        long long28 = year24.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
//        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
//        int int31 = year9.getYear();
//        java.util.Date date32 = year9.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
//        long long41 = timeSeries38.getMaximumItemAge();
//        timeSeries38.setKey((java.lang.Comparable) (byte) 100);
//        java.lang.Class<?> wildcardClass44 = timeSeries38.getClass();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timeSeries48.addPropertyChangeListener(propertyChangeListener49);
//        long long51 = timeSeries48.getMaximumItemAge();
//        java.lang.Comparable comparable52 = timeSeries48.getKey();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) 7, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener64 = null;
//        timeSeries63.addPropertyChangeListener(propertyChangeListener64);
//        long long66 = timeSeries63.getMaximumItemAge();
//        java.lang.Comparable comparable67 = timeSeries63.getKey();
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year((int) (short) 1);
//        timeSeries63.add((org.jfree.data.time.RegularTimePeriod) year69, (java.lang.Number) 7, false);
//        long long73 = year69.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year69.previous();
//        boolean boolean75 = year54.equals((java.lang.Object) regularTimePeriod74);
//        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) year54);
//        long long77 = timeSeries38.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener78 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener78);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond();
//        long long81 = fixedMillisecond80.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = fixedMillisecond80.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries38.addOrUpdate(regularTimePeriod82, (java.lang.Number) 1.0d);
//        boolean boolean85 = year34.equals((java.lang.Object) regularTimePeriod82);
//        long long86 = year34.getFirstMillisecond();
//        long long87 = year34.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 100.0d + "'", comparable52.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 9223372036854775807L + "'", long66 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + 100.0d + "'", comparable67.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-62119972800001L) + "'", long73 == (-62119972800001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 9223372036854775807L + "'", long77 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560185079654L + "'", long81 == 1560185079654L);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNull(timeSeriesDataItem84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + (-62135740800000L) + "'", long86 == (-62135740800000L));
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + (-62119972800001L) + "'", long87 == (-62119972800001L));
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) (byte) 100);
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener16);
        java.lang.Comparable comparable18 = timeSeries13.getKey();
        timeSeries13.removeAgedItems(false);
        java.lang.String str21 = timeSeries13.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries13.addChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.lang.String str25 = timeSeries13.getDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries13.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560185030114L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        long long21 = timeSeries18.getMaximumItemAge();
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 7, false);
        long long28 = year24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean30 = year9.equals((java.lang.Object) regularTimePeriod29);
        int int31 = year9.getYear();
        java.util.Date date32 = year9.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date32);
        long long35 = fixedMillisecond34.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date37 = fixedMillisecond36.getTime();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener44);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener46);
        java.lang.Comparable comparable48 = timeSeries43.getKey();
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener49);
        int int51 = day39.compareTo((java.lang.Object) timeSeries43);
        int int52 = fixedMillisecond34.compareTo((java.lang.Object) day39);
        long long53 = fixedMillisecond34.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100.0d + "'", comparable22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62119972800001L) + "'", long28 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62104204800001L) + "'", long35 == (-62104204800001L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + 100.0d + "'", comparable48.equals(100.0d));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-62104204800001L) + "'", long53 == (-62104204800001L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries3.getMaximumItemAge();
        java.lang.Comparable comparable7 = timeSeries3.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 7, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (short) 10);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        timeSeriesDataItem14.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "0", "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        long long27 = timeSeries24.getMaximumItemAge();
        java.lang.Comparable comparable28 = timeSeries24.getKey();
        java.util.Collection collection29 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
        long long36 = timeSeries33.getMaximumItemAge();
        java.lang.Comparable comparable37 = timeSeries33.getKey();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (short) 1);
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 7, false);
        long long43 = year39.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year39.previous();
        int int45 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries49.addPropertyChangeListener(propertyChangeListener50);
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries49.addPropertyChangeListener(propertyChangeListener52);
        java.lang.Comparable comparable54 = timeSeries49.getKey();
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries49.addPropertyChangeListener(propertyChangeListener55);
        java.util.Collection collection57 = timeSeries49.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries20.addAndOrUpdate(timeSeries49);
        java.lang.String str59 = timeSeries20.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 100.0d + "'", comparable7.equals(100.0d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 100.0d + "'", comparable28.equals(100.0d));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100.0d + "'", comparable37.equals(100.0d));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-62119972800001L) + "'", long43 == (-62119972800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + 100.0d + "'", comparable54.equals(100.0d));
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0" + "'", str59.equals("0"));
    }
}

