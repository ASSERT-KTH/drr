import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker12.getLabelAnchor();
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle5.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle5.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Paint paint20 = piePlot19.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator21 = piePlot19.getLabelGenerator();
        java.awt.Paint paint22 = piePlot19.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot19);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = legendTitle23.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle23.setLegendItemGraphicAnchor(rectangleAnchor25);
        legendTitle23.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = valueMarker30.getLabelAnchor();
        legendTitle23.setLegendItemGraphicAnchor(rectangleAnchor31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean34 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge33);
        legendTitle23.setLegendItemGraphicEdge(rectangleEdge33);
        java.awt.geom.Rectangle2D rectangle2D36 = legendTitle23.getBounds();
        try {
            legendTitle5.draw(graphics2D17, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Paint paint5 = piePlot4.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot4.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart7.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle8.getMargin();
        double double10 = rectangleInsets9.getBottom();
        xYPlot0.setAxisOffset(rectangleInsets9);
        java.awt.Paint paint12 = null;
        xYPlot0.setOutlinePaint(paint12);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        double double7 = categoryAxis6.getFixedDimension();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        categoryAxis6.setPlot((org.jfree.chart.plot.Plot) piePlot9);
        java.lang.String str11 = categoryAxis6.getLabelToolTip();
        categoryPlot0.setDomainAxis(categoryAxis6);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis6.getLabelInsets();
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        int int9 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setFixedDimension((double) (short) 100);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.lang.Object obj1 = null;
        boolean boolean2 = piePlot3D0.equals(obj1);
        piePlot3D0.setNoDataMessage("VerticalAlignment.CENTER");
        piePlot3D0.setDepthFactor((double) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getText();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getShadowXOffset();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot4);
        java.awt.Paint paint7 = piePlot4.getLabelBackgroundPaint();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        java.awt.Paint paint13 = ringPlot12.getSeparatorPaint();
        valueMarker10.setLabelPaint(paint13);
        java.awt.Stroke stroke15 = valueMarker10.getStroke();
        piePlot4.setSectionOutlineStroke((java.lang.Comparable) "HorizontalAlignment.LEFT", stroke15);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke4);
        xYPlot0.setRangeCrosshairValue((double) 10, true);
        java.awt.Font font9 = xYPlot0.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot0.getDomainAxisEdge((int) (byte) 100);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        boolean boolean5 = xYPlot0.isDomainZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getRangeAxisForDataset(0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) -1);
        pieLabelDistributor1.sort();
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Paint paint4 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3.getLabelGenerator();
        java.awt.Paint paint6 = piePlot3.getBackgroundPaint();
        ringPlot1.setLabelShadowPaint(paint6);
        double double8 = ringPlot1.getOuterSeparatorExtension();
        java.awt.Stroke stroke10 = ringPlot1.getSectionOutlineStroke((java.lang.Comparable) ' ');
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNull(stroke10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        categoryPlot0.setRangeCrosshairValue(45.0d);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            xYPlot0.addRangeMarker(4, marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = valueMarker3.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        java.awt.Paint paint10 = ringPlot9.getSeparatorPaint();
        valueMarker7.setLabelPaint(paint10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker7.getLabelOffsetType();
        valueMarker3.setLabelOffsetType(lengthAdjustmentType12);
        boolean boolean14 = columnArrangement0.equals((java.lang.Object) lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        boolean boolean10 = jFreeChart8.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis1, jFreeChart8);
        java.lang.Object obj12 = chartChangeEvent11.getSource();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.lang.Object obj1 = null;
        boolean boolean2 = piePlot3D0.equals(obj1);
        piePlot3D0.setCircular(false, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis7.setLowerMargin(0.0d);
        java.awt.Shape shape10 = dateAxis7.getLeftArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis7.getTickUnit();
        dateAxis1.setTickUnit(dateTickUnit11);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(dateTickUnit11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        xYPlot0.setDomainCrosshairValue(0.4d);
        int int8 = xYPlot0.getSeriesCount();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            boolean boolean11 = xYPlot0.removeRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D17 = blockContainer12.arrange(graphics2D13, rectangleConstraint16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 0.025d, 0.05d, rectangleAnchor20);
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) 0L, 10.0d, rectangleAnchor20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis25.setLowerMargin(0.0d);
        java.awt.Shape shape28 = dateAxis25.getLeftArrow();
        boolean boolean30 = dateAxis25.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, polarItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot35.getDomainAxisEdge((int) (short) 10);
        xYPlot35.clearRangeMarkers();
        xYPlot35.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot35.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        xYPlot45.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis48 = xYPlot45.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D49 = xYPlot45.getQuadrantOrigin();
        xYPlot35.zoomDomainAxes((double) (short) 0, plotRenderingInfo44, point2D49, false);
        polarPlot32.zoomDomainAxes((double) (-1), plotRenderingInfo34, point2D49, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = null;
        try {
            jFreeChart5.draw(graphics2D7, rectangle2D22, point2D49, chartRenderingInfo54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNull(valueAxis48);
        org.junit.Assert.assertNotNull(point2D49);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        boolean boolean6 = xYPlot5.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot5.getDomainAxis((int) (byte) 1);
        xYPlot5.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        java.awt.Paint paint14 = ringPlot13.getSeparatorPaint();
        valueMarker11.setLabelPaint(paint14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker11.setOutlineStroke(stroke16);
        xYPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker11);
        java.awt.Font font19 = valueMarker11.getLabelFont();
        try {
            boolean boolean20 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Object obj1 = null;
        boolean boolean2 = strokeMap0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 15);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset3, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        double double4 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis6.setLowerMargin(0.0d);
        java.awt.Shape shape9 = dateAxis6.getLeftArrow();
        org.jfree.data.Range range10 = dateAxis6.getRange();
        dateAxis1.setDefaultAutoRange(range10);
        double double12 = dateAxis1.getLabelAngle();
        dateAxis1.setInverted(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) 2.0f, true);
        double double5 = range0.constrain((double) (short) 0);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range0, (-35.57979797979798d));
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getTotal();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        boolean boolean4 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setLabel("ThreadContext");
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 2.0d, font8);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        xYPlot0.setDomainCrosshairValue(0.4d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer9, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getShadowXOffset();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        piePlot4.setDataset(pieDataset6);
        boolean boolean8 = categoryAxis1.hasListener((java.util.EventListener) piePlot4);
        float float9 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot6 = categoryAxis5.getPlot();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        double double9 = piePlot8.getShadowXOffset();
        categoryAxis5.setPlot((org.jfree.chart.plot.Plot) piePlot8);
        int int11 = categoryPlot3.getDomainAxisIndex(categoryAxis5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot3.setRenderer(categoryItemRenderer12);
        double double14 = categoryPlot3.getAnchorValue();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot3.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("TextBlockAnchor.TOP_RIGHT", "Pie Plot", "PlotOrientation.HORIZONTAL", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getLabelGap();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        ringPlot1.setLabelLinksVisible(false);
        ringPlot1.setCircular(true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = ringPlot1.getLegendItems();
        ringPlot1.setSeparatorsVisible(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle6.getMargin();
        textTitle6.setWidth(90.0d);
        textTitle6.setNotify(false);
        java.awt.Paint paint12 = textTitle6.getPaint();
        java.awt.Paint paint13 = textTitle6.getPaint();
        java.lang.String str14 = textTitle6.getToolTipText();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        boolean boolean5 = xYPlot4.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getDomainAxis((int) (byte) 1);
        xYPlot4.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        java.awt.Paint paint13 = ringPlot12.getSeparatorPaint();
        valueMarker10.setLabelPaint(paint13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker10.setOutlineStroke(stroke15);
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Font font18 = valueMarker10.getLabelFont();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker10);
        java.awt.Paint paint20 = valueMarker10.getLabelPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setLicenceText("");
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo7.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        double double11 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxis(4);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.clearRangeMarkers();
        java.lang.String str17 = xYPlot15.getPlotType();
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot15.getDomainMarkers((int) (short) -1, layer19);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot15.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation21, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            categoryPlot0.handleClick((int) 'a', 4, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "XY Plot" + "'", str17.equals("XY Plot"));
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, range2);
        boolean boolean5 = range2.contains((double) (short) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        java.lang.String str14 = rectangleConstraint13.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((-35.57979797979798d), range2, lengthConstraintType6, (double) 100L, range9, lengthConstraintType15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.RendererState rendererState18 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo17);
        org.jfree.chart.entity.EntityCollection entityCollection19 = rendererState18.getEntityCollection();
        boolean boolean20 = lengthConstraintType15.equals((java.lang.Object) rendererState18);
        java.lang.Object obj21 = null;
        boolean boolean22 = lengthConstraintType15.equals(obj21);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str14.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNull(entityCollection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot1.setURLGenerator(pieURLGenerator3);
        java.awt.Paint paint6 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) "TextBlockAnchor.TOP_LEFT");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint4 = ringPlot3.getSeparatorPaint();
        valueMarker1.setLabelPaint(paint4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker1.setOutlineStroke(stroke6);
        float float8 = valueMarker1.getAlpha();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.8f + "'", float8 == 0.8f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.025d, 4.0d, (-1.0f), 2.0d, (-4.0d), (-1) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.025d, 4.0d, (-1.0f), 2.0d, (-4.0d), (-1) };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.025d, 4.0d, (-1.0f), 2.0d, (-4.0d), (-1) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 0.025d, 4.0d, (-1.0f), 2.0d, (-4.0d), (-1) };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "Size2D[width=-1.0, height=205.0]", numberArray30);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        boolean boolean7 = dateAxis2.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot12.getDomainAxisEdge((int) (short) 10);
        xYPlot12.clearRangeMarkers();
        xYPlot12.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot12.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        xYPlot22.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot22.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D26 = xYPlot22.getQuadrantOrigin();
        xYPlot12.zoomDomainAxes((double) (short) 0, plotRenderingInfo21, point2D26, false);
        polarPlot9.zoomDomainAxes((double) (-1), plotRenderingInfo11, point2D26, true);
        java.lang.String str31 = polarPlot9.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis33.setLowerMargin(0.0d);
        java.awt.Shape shape36 = dateAxis33.getLeftArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = dateAxis33.getTickUnit();
        polarPlot9.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit37);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = polarPlot9.getLegendItems();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Polar Plot" + "'", str31.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertNotNull(legendItemCollection39);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis2.setRange(range5);
        boolean boolean7 = dateAxis2.isTickMarksVisible();
        double double8 = dateAxis2.getAutoRangeMinimumSize();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke10 = xYPlot9.getRangeCrosshairStroke();
        boolean boolean11 = xYPlot9.isDomainGridlinesVisible();
        java.awt.Paint paint12 = xYPlot9.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis14.setLowerMargin(0.0d);
        int int17 = xYPlot9.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
        boolean boolean20 = dateAxis2.isAxisLineVisible();
        dateAxis2.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 0);
        categoryAxis1.setLabelURL("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        categoryAxis1.setCategoryLabelPositionOffset(100);
        categoryAxis1.setLowerMargin(2.0d);
        java.awt.Font font12 = categoryAxis1.getLabelFont();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.Object obj1 = new java.lang.Object();
        boolean boolean2 = verticalAlignment0.equals(obj1);
        java.lang.String str3 = verticalAlignment0.toString();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Paint paint7 = piePlot6.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Font font10 = piePlot6.getLabelFont();
        java.awt.Paint paint12 = piePlot6.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Paint paint15 = piePlot14.getShadowPaint();
        double double16 = piePlot14.getShadowXOffset();
        org.jfree.chart.plot.Plot plot17 = piePlot14.getParent();
        java.awt.Paint paint18 = piePlot14.getBaseSectionOutlinePaint();
        piePlot6.setLabelBackgroundPaint(paint18);
        boolean boolean20 = verticalAlignment0.equals((java.lang.Object) piePlot6);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke22 = defaultDrawingSupplier21.getNextStroke();
        piePlot6.setOutlineStroke(stroke22);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.CENTER" + "'", str3.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((int) (byte) 1);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getSeparatorPaint();
        valueMarker6.setLabelPaint(paint9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker6.setOutlineStroke(stroke11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        int int16 = xYPlot0.getDatasetCount();
        int int17 = xYPlot0.getSeriesCount();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot18.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot24 = categoryAxis23.getPlot();
        java.awt.Paint paint25 = categoryAxis23.getTickMarkPaint();
        xYPlot18.setRangeTickBandPaint(paint25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = xYPlot18.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        xYPlot0.setDomainCrosshairValue(0.4d);
        int int8 = xYPlot0.getSeriesCount();
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = piePlot7.getLabelOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) (byte) 0, (double) (short) -1, (double) 1.0f, paint10);
        double[][] doubleArray14 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray14);
        boolean boolean16 = blockBorder11.equals((java.lang.Object) categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, (double) 10);
        categoryPlot0.setDataset(categoryDataset15);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        org.jfree.data.Range range5 = dateAxis1.getRange();
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range5, (double) '4', false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray1 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot0.setRangeAxes(valueAxisArray1);
        org.junit.Assert.assertNotNull(valueAxisArray1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        xYPlot0.clearRangeMarkers();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        java.util.List list7 = textBlock6.getLines();
        xYPlot0.drawRangeTickBands(graphics2D4, rectangle2D5, list7);
        java.awt.Paint paint9 = null;
        try {
            xYPlot0.setRangeCrosshairPaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        boolean boolean10 = jFreeChart8.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis1, jFreeChart8);
        java.lang.Object obj12 = jFreeChart8.getTextAntiAlias();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis5.setLowerMargin(0.0d);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range8);
        org.jfree.data.Range range10 = dateAxis5.getDefaultAutoRange();
        java.awt.Shape shape11 = dateAxis5.getRightArrow();
        dateAxis5.setInverted(false);
        int int14 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace15);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace4, true);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        java.awt.Paint paint11 = ringPlot10.getSeparatorPaint();
        valueMarker8.setLabelPaint(paint11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker8.setOutlineStroke(stroke13);
        xYPlot0.setDomainCrosshairStroke(stroke13);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        jFreeChart5.setBorderPaint((java.awt.Paint) color7);
        boolean boolean9 = jFreeChart5.isNotify();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieWRadius((double) 10.0f);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Paint paint7 = piePlot6.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        jFreeChart9.setBorderPaint((java.awt.Paint) color11);
        int int13 = jFreeChart9.getBackgroundImageAlignment();
        boolean boolean14 = jFreeChart9.getAntiAlias();
        java.awt.Paint paint15 = jFreeChart9.getBorderPaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0f, jFreeChart9);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart9.getLegend();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(legendTitle17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot1.setURLGenerator(pieURLGenerator3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot5.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine();
        boolean boolean9 = rectangleEdge7.equals((java.lang.Object) textLine8);
        java.awt.Color color10 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getStartAngle();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot12.setBaseSectionOutlineStroke(stroke14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.awt.Paint paint18 = piePlot17.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = piePlot17.getLabelGenerator();
        java.awt.Paint paint20 = piePlot17.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot17.getLabelPadding();
        org.jfree.chart.util.UnitType unitType22 = rectangleInsets21.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color10, stroke14, rectangleInsets21);
        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer25 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D30 = blockContainer25.arrange(graphics2D26, rectangleConstraint29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, 0.025d, 0.05d, rectangleAnchor33);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D34);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets21.createOutsetRectangle(rectangle2D34, false, false);
        boolean boolean39 = textLine8.equals((java.lang.Object) rectangle2D34);
        boolean boolean40 = piePlot1.equals((java.lang.Object) rectangle2D34);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 90.0d + "'", double13 == 90.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(unitType22);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        xYPlot0.setDomainCrosshairValue(0.4d);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot8.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis13.setLowerMargin(0.0d);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range16);
        org.jfree.data.Range range18 = dateAxis13.getDefaultAutoRange();
        java.awt.Shape shape19 = dateAxis13.getRightArrow();
        dateAxis13.setInverted(false);
        int int22 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot0.getDomainMarkers(0, layer25);
        java.lang.Object obj27 = xYPlot0.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 205);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset3, true);
        boolean boolean8 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset3);
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis3.setLowerMargin(0.0d);
        java.awt.Shape shape6 = dateAxis3.getLeftArrow();
        boolean boolean8 = dateAxis3.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.PiePlotState piePlotState13 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo12);
        piePlotState13.setPieWRadius((double) 10.0f);
        double double16 = piePlotState13.getPieCenterY();
        piePlotState13.setPieWRadius((-4.0d));
        java.awt.Color color19 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        double double22 = piePlot21.getStartAngle();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot21.setBaseSectionOutlineStroke(stroke23);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        java.awt.Paint paint27 = piePlot26.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = piePlot26.getLabelGenerator();
        java.awt.Paint paint29 = piePlot26.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = piePlot26.getLabelPadding();
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets30.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color19, stroke23, rectangleInsets30);
        org.jfree.chart.block.ColumnArrangement columnArrangement33 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D39 = blockContainer34.arrange(graphics2D35, rectangleConstraint38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D43 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, 0.025d, 0.05d, rectangleAnchor42);
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets30.createOutsetRectangle(rectangle2D43, false, false);
        piePlotState13.setLinkArea(rectangle2D43);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis51.setLowerMargin(0.0d);
        java.awt.Shape shape54 = dateAxis51.getLeftArrow();
        boolean boolean56 = dateAxis51.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer57 = null;
        org.jfree.chart.plot.PolarPlot polarPlot58 = new org.jfree.chart.plot.PolarPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis51, polarItemRenderer57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = xYPlot61.getDomainAxisEdge((int) (short) 10);
        xYPlot61.clearRangeMarkers();
        xYPlot61.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot61.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot();
        xYPlot71.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis74 = xYPlot71.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D75 = xYPlot71.getQuadrantOrigin();
        xYPlot61.zoomDomainAxes((double) (short) 0, plotRenderingInfo70, point2D75, false);
        polarPlot58.zoomDomainAxes((double) (-1), plotRenderingInfo60, point2D75, true);
        org.jfree.chart.plot.PlotState plotState80 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        polarPlot10.draw(graphics2D11, rectangle2D43, point2D75, plotState80, plotRenderingInfo81);
        org.jfree.chart.axis.DateAxis dateAxis84 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis84.setLowerMargin(0.0d);
        java.awt.Shape shape87 = dateAxis84.getLeftArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit88 = dateAxis84.getTickUnit();
        polarPlot10.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit88);
        try {
            org.jfree.data.general.PieDataset pieDataset90 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) dateTickUnit88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 90.0d + "'", double22 == 90.0d);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(unitType31);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertNull(valueAxis74);
        org.junit.Assert.assertNotNull(point2D75);
        org.junit.Assert.assertNotNull(shape87);
        org.junit.Assert.assertNotNull(dateTickUnit88);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.configureRangeAxes();
        int int4 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = xYPlot0.getAxisOffset();
        double double6 = rectangleInsets5.getBottom();
        double double8 = rectangleInsets5.calculateTopInset(4.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        boolean boolean9 = projectInfo7.equals((java.lang.Object) true);
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image13, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo7.getLicenceText();
        java.lang.String str20 = projectInfo7.toString();
        org.jfree.chart.ui.Library[] libraryArray21 = projectInfo7.getLibraries();
        java.lang.String str22 = projectInfo7.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray23 = projectInfo7.getLibraries();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str19.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str20.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertNotNull(libraryArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(libraryArray23);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textBlock0.setLineAlignment(horizontalAlignment2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke5 = xYPlot4.getRangeCrosshairStroke();
        boolean boolean6 = xYPlot4.isDomainGridlinesVisible();
        xYPlot4.configureRangeAxes();
        int int8 = xYPlot4.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        xYPlot4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis11, true);
        boolean boolean14 = textBlock0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("XY Plot", "0,-49,1,51", "Pie 3D Plot", "Other");
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        java.awt.Paint paint9 = piePlot5.getNoDataMessagePaint();
        boolean boolean10 = piePlot1.equals((java.lang.Object) piePlot5);
        java.awt.Paint paint11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot1.setOutlinePaint(paint11);
        java.awt.Stroke stroke14 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(2.0d, (double) 100L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        double double4 = rectangleConstraint3.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace4, true);
        java.awt.Stroke stroke7 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setRangeCrosshairValue((double) '#', false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        valueMarker1.setValue((double) (short) 10);
        valueMarker1.setAlpha((float) (byte) 1);
        java.awt.Font font6 = valueMarker1.getLabelFont();
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("VerticalAlignment.CENTER", font8, (java.awt.Paint) color9);
        valueMarker1.setPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.025d, 0.05d, rectangleAnchor9);
        size2D6.height = (byte) 10;
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart5.getLegend();
        java.awt.Paint paint8 = jFreeChart5.getBorderPaint();
        jFreeChart5.removeLegend();
        try {
            org.jfree.chart.title.Title title11 = jFreeChart5.getSubtitle((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.plot.PiePlotState piePlotState3 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo2);
        piePlotState3.setPassesRequired(0);
        java.lang.Class<?> wildcardClass6 = piePlotState3.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("XY Plot", (java.lang.Class) wildcardClass6);
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResource("Polar Plot", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(inputStream7);
        org.junit.Assert.assertNull(uRL8);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        java.awt.Font font5 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 15);
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("VerticalAlignment.CENTER", font1, (java.awt.Paint) color2);
        int int4 = color2.getBlue();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.025d, 0.05d, rectangleAnchor9);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10, "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "TextBlockAnchor.TOP_RIGHT");
        java.lang.String str15 = chartEntity14.getToolTipText();
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str15.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis2.setRange(range5);
        boolean boolean7 = dateAxis2.isTickMarksVisible();
        double double8 = dateAxis2.getAutoRangeMinimumSize();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke10 = xYPlot9.getRangeCrosshairStroke();
        boolean boolean11 = xYPlot9.isDomainGridlinesVisible();
        java.awt.Paint paint12 = xYPlot9.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis14.setLowerMargin(0.0d);
        int int17 = xYPlot9.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
        java.awt.Paint paint20 = dateAxis14.getAxisLinePaint();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        multiplePiePlot1.setNoDataMessageFont(font2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot6 = categoryAxis5.getPlot();
        java.awt.Paint paint7 = categoryAxis5.getTickMarkPaint();
        java.awt.Font font9 = categoryAxis5.getTickLabelFont((java.lang.Comparable) 15);
        multiplePiePlot1.setNoDataMessageFont(font9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Paint paint15 = piePlot12.getLabelOutlinePaint();
        java.awt.Paint paint16 = piePlot12.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer20 = new org.jfree.chart.text.G2TextMeasurer(graphics2D19);
        try {
            org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font9, paint16, (float) 100, 1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (java.lang.Comparable) 0.4d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(pieDataset6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("ClassContext", "", "ClassContext", "Other");
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = categoryPlot0.getDataset();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(categoryDataset5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("HorizontalAlignment.LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name HorizontalAlignment.LEFT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setLicenceText("");
        java.lang.String str10 = projectInfo7.toString();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n" + "'", str10.equals(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        java.awt.Paint paint6 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D13 = blockContainer8.arrange(graphics2D9, rectangleConstraint12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 0.025d, 0.05d, rectangleAnchor16);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D17);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D17, "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setRightArrow((java.awt.Shape) rectangle2D17);
        java.text.DateFormat dateFormat23 = dateAxis1.getDateFormatOverride();
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range24);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNull(dateFormat23);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint4 = ringPlot3.getSeparatorPaint();
        valueMarker1.setLabelPaint(paint4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker1.setOutlineStroke(stroke6);
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        java.lang.Object obj9 = null;
        boolean boolean10 = piePlot3D8.equals(obj9);
        java.awt.Paint paint11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot3D8.setBaseSectionPaint(paint11);
        valueMarker1.setLabelPaint(paint11);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "Pie Plot");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis5.setLowerMargin(0.0d);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range8);
        org.jfree.data.Range range10 = dateAxis5.getDefaultAutoRange();
        java.awt.Shape shape11 = dateAxis5.getRightArrow();
        dateAxis5.setInverted(false);
        int int14 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        dateAxis5.setAutoRange(true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMaximumCategoryLabelWidthRatio(10.0f);
        categoryAxis1.setMaximumCategoryLabelWidthRatio(1.0f);
        java.awt.Font font9 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 2, font9);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Paint paint7 = piePlot6.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Font font10 = piePlot6.getLabelFont();
        java.awt.Paint paint12 = piePlot6.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Paint paint15 = piePlot14.getShadowPaint();
        double double16 = piePlot14.getShadowXOffset();
        org.jfree.chart.plot.Plot plot17 = piePlot14.getParent();
        java.awt.Paint paint18 = piePlot14.getBaseSectionOutlinePaint();
        piePlot6.setLabelBackgroundPaint(paint18);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) piePlot6);
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        ringPlot1.setLabelLinksVisible(false);
        ringPlot1.setSeparatorsVisible(true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "HorizontalAlignment.LEFT", "TextBlockAnchor.TOP_LEFT", "hi!");
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        java.awt.Paint paint8 = piePlot5.getBackgroundPaint();
        xYPlot0.setOutlinePaint(paint8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot0.getDomainMarkers((int) (byte) 0, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        xYPlot0.setDomainAxisLocation(4, axisLocation14);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.025d, 0.05d, rectangleAnchor9);
        java.lang.String str11 = rectangleAnchor9.toString();
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        java.util.List list13 = textBlock12.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textBlock12.setLineAlignment(horizontalAlignment14);
        java.awt.Font font17 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color18 = java.awt.Color.yellow;
        textBlock12.addLine("TextBlockAnchor.TOP_RIGHT", font17, (java.awt.Paint) color18);
        boolean boolean20 = rectangleAnchor9.equals((java.lang.Object) "TextBlockAnchor.TOP_RIGHT");
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleAnchor.RIGHT" + "'", str11.equals("RectangleAnchor.RIGHT"));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        java.awt.Paint paint5 = piePlot2.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot9 = categoryAxis8.getPlot();
        java.awt.Paint paint10 = categoryAxis8.getLabelPaint();
        legendTitle6.setItemPaint(paint10);
        boolean boolean12 = legendTitle6.getNotify();
        java.awt.Font font13 = legendTitle6.getItemFont();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot14.getFixedDomainAxisSpace();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font13, (org.jfree.chart.plot.Plot) xYPlot14, false);
        java.awt.Image image19 = null;
        jFreeChart18.setBackgroundImage(image19);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(axisSpace16);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        java.awt.Paint paint5 = piePlot2.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot9 = categoryAxis8.getPlot();
        java.awt.Paint paint10 = categoryAxis8.getLabelPaint();
        legendTitle6.setItemPaint(paint10);
        boolean boolean12 = legendTitle6.getNotify();
        java.awt.Font font13 = legendTitle6.getItemFont();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot14.getFixedDomainAxisSpace();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font13, (org.jfree.chart.plot.Plot) xYPlot14, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        try {
            jFreeChart18.handleClick(2, (int) ' ', chartRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        xYPlot0.clearRangeMarkers();
        xYPlot0.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot10.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D14 = xYPlot10.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) (short) 0, plotRenderingInfo9, point2D14, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        xYPlot0.setRenderer(xYItemRenderer17);
        boolean boolean19 = xYPlot0.isDomainZoomable();
        xYPlot0.clearDomainMarkers();
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        xYPlot0.setDomainTickBandPaint(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset();
        boolean boolean3 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj1 = blockContainer0.clone();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        xYPlot2.setRenderer((int) '#', xYItemRenderer4);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot2.setDomainGridlineStroke(stroke6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot2.getRangeAxis((int) 'a');
        boolean boolean10 = blockContainer0.equals((java.lang.Object) xYPlot2);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.lang.Object obj1 = null;
        boolean boolean2 = piePlot3D0.equals(obj1);
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot3D0.setBaseSectionPaint(paint3);
        java.awt.Paint paint5 = piePlot3D0.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot8.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D12 = xYPlot8.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo7, point2D12);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(point2D12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDepthFactor((-1.0d));
        piePlot3D0.setCircular(false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(100);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.String str8 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "XY Plot" + "'", str8.equals("XY Plot"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        java.awt.Shape shape7 = dateAxis1.getRightArrow();
        dateAxis1.setInverted(false);
        dateAxis1.centerRange((double) 100L);
        java.text.DateFormat dateFormat12 = null;
        dateAxis1.setDateFormatOverride(dateFormat12);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        boolean boolean7 = dateAxis2.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo11);
        piePlotState12.setPieWRadius((double) 10.0f);
        double double15 = piePlotState12.getPieCenterY();
        piePlotState12.setPieWRadius((-4.0d));
        java.awt.Color color18 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        double double21 = piePlot20.getStartAngle();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot20.setBaseSectionOutlineStroke(stroke22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        java.awt.Paint paint26 = piePlot25.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator27 = piePlot25.getLabelGenerator();
        java.awt.Paint paint28 = piePlot25.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot25.getLabelPadding();
        org.jfree.chart.util.UnitType unitType30 = rectangleInsets29.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke22, rectangleInsets29);
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D38 = blockContainer33.arrange(graphics2D34, rectangleConstraint37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D38, 0.025d, 0.05d, rectangleAnchor41);
        org.jfree.chart.entity.ChartEntity chartEntity43 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets29.createOutsetRectangle(rectangle2D42, false, false);
        piePlotState12.setLinkArea(rectangle2D42);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis50.setLowerMargin(0.0d);
        java.awt.Shape shape53 = dateAxis50.getLeftArrow();
        boolean boolean55 = dateAxis50.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) dateAxis50, polarItemRenderer56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = xYPlot60.getDomainAxisEdge((int) (short) 10);
        xYPlot60.clearRangeMarkers();
        xYPlot60.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot60.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot();
        xYPlot70.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis73 = xYPlot70.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D74 = xYPlot70.getQuadrantOrigin();
        xYPlot60.zoomDomainAxes((double) (short) 0, plotRenderingInfo69, point2D74, false);
        polarPlot57.zoomDomainAxes((double) (-1), plotRenderingInfo59, point2D74, true);
        org.jfree.chart.plot.PlotState plotState79 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        polarPlot9.draw(graphics2D10, rectangle2D42, point2D74, plotState79, plotRenderingInfo80);
        java.lang.String str82 = polarPlot9.getPlotType();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(point2D74);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "Polar Plot" + "'", str82.equals("Polar Plot"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        double double11 = categoryPlot0.getAnchorValue();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot0.getLegendItems();
        categoryPlot0.clearDomainMarkers(1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot0.setRenderer(categoryItemRenderer15, true);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot0.getDomainMarkers(15, layer19);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNull(collection20);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        int int6 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis9.setLowerMargin(0.0d);
        try {
            xYPlot0.setDomainAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) dateAxis9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.Object obj2 = new java.lang.Object();
        boolean boolean3 = verticalAlignment1.equals(obj2);
        java.lang.String str4 = verticalAlignment1.toString();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot7);
        java.awt.Font font11 = piePlot7.getLabelFont();
        java.awt.Paint paint13 = piePlot7.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Paint paint16 = piePlot15.getShadowPaint();
        double double17 = piePlot15.getShadowXOffset();
        org.jfree.chart.plot.Plot plot18 = piePlot15.getParent();
        java.awt.Paint paint19 = piePlot15.getBaseSectionOutlinePaint();
        piePlot7.setLabelBackgroundPaint(paint19);
        boolean boolean21 = verticalAlignment1.equals((java.lang.Object) piePlot7);
        java.lang.String str22 = verticalAlignment1.toString();
        boolean boolean23 = multiplePiePlot0.equals((java.lang.Object) verticalAlignment1);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D27 = new org.jfree.chart.util.Size2D(0.0d, 0.0d);
        double double28 = size2D27.getWidth();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        java.awt.Paint paint33 = piePlot32.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator34 = piePlot32.getLabelGenerator();
        java.awt.Paint paint35 = piePlot32.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot32);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = legendTitle36.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle36.setLegendItemGraphicAnchor(rectangleAnchor38);
        java.awt.geom.Rectangle2D rectangle2D40 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, 0.14d, (double) (-1L), rectangleAnchor38);
        java.awt.geom.Point2D point2D41 = null;
        org.jfree.chart.plot.PlotState plotState42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        try {
            multiplePiePlot0.draw(graphics2D24, rectangle2D40, point2D41, plotState42, plotRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.CENTER" + "'", str4.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "VerticalAlignment.CENTER" + "'", str22.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine();
        boolean boolean4 = rectangleEdge2.equals((java.lang.Object) textLine3);
        java.awt.Color color5 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        double double8 = piePlot7.getStartAngle();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot7.setBaseSectionOutlineStroke(stroke9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        java.awt.Paint paint13 = piePlot12.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot12.getLabelGenerator();
        java.awt.Paint paint15 = piePlot12.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = piePlot12.getLabelPadding();
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets16.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke9, rectangleInsets16);
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D25 = blockContainer20.arrange(graphics2D21, rectangleConstraint24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, 0.025d, 0.05d, rectangleAnchor28);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D29);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets16.createOutsetRectangle(rectangle2D29, false, false);
        boolean boolean34 = textLine3.equals((java.lang.Object) rectangle2D29);
        java.awt.Image image38 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo42 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image38, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo42.setLicenceName("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        boolean boolean45 = textLine3.equals((java.lang.Object) projectInfo42);
        org.jfree.chart.text.TextFragment textFragment47 = new org.jfree.chart.text.TextFragment("HorizontalAlignment.LEFT");
        textLine3.removeFragment(textFragment47);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        boolean boolean4 = categoryAxis1.isTickLabelsVisible();
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 10.0d);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("Other", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(true);
        org.jfree.data.RangeType rangeType3 = numberAxis0.getRangeType();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.text.TextBlock textBlock9 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = textBlock9.calculateDimensions(graphics2D10);
        boolean boolean12 = rectangleEdge8.equals((java.lang.Object) size2D11);
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D21 = blockContainer16.arrange(graphics2D17, rectangleConstraint20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, 0.025d, 0.05d, rectangleAnchor24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color27 = java.awt.Color.WHITE;
        float[] floatArray33 = new float[] { (-1.0f), (short) 0, 0.0f, (-1L), (-1) };
        float[] floatArray34 = color27.getRGBColorComponents(floatArray33);
        float[] floatArray35 = color26.getRGBComponents(floatArray34);
        boolean boolean36 = rectangleAnchor24.equals((java.lang.Object) color26);
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) 1.0f, (double) (byte) -1, rectangleAnchor24);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        boolean boolean39 = xYPlot38.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot38.getDomainAxis((int) (byte) 1);
        xYPlot38.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.RingPlot ringPlot46 = new org.jfree.chart.plot.RingPlot(pieDataset45);
        java.awt.Paint paint47 = ringPlot46.getSeparatorPaint();
        valueMarker44.setLabelPaint(paint47);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker44.setOutlineStroke(stroke49);
        xYPlot38.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker44);
        xYPlot38.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.Layer layer54 = null;
        java.util.Collection collection55 = xYPlot38.getDomainMarkers(layer54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot57.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot57.getRangeAxisLocation();
        xYPlot38.setDomainAxisLocation((int) (short) 10, axisLocation59, false);
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis64.setLowerMargin(0.0d);
        java.awt.Shape shape67 = dateAxis64.getLeftArrow();
        boolean boolean69 = dateAxis64.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer70 = null;
        org.jfree.chart.plot.PolarPlot polarPlot71 = new org.jfree.chart.plot.PolarPlot(xYDataset62, (org.jfree.chart.axis.ValueAxis) dateAxis64, polarItemRenderer70);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = xYPlot74.getDomainAxisEdge((int) (short) 10);
        xYPlot74.clearRangeMarkers();
        xYPlot74.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot74.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        org.jfree.chart.plot.XYPlot xYPlot84 = new org.jfree.chart.plot.XYPlot();
        xYPlot84.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis87 = xYPlot84.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D88 = xYPlot84.getQuadrantOrigin();
        xYPlot74.zoomDomainAxes((double) (short) 0, plotRenderingInfo83, point2D88, false);
        polarPlot71.zoomDomainAxes((double) (-1), plotRenderingInfo73, point2D88, true);
        java.lang.String str93 = polarPlot71.getPlotType();
        org.jfree.chart.plot.PlotOrientation plotOrientation94 = polarPlot71.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge95 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation59, plotOrientation94);
        try {
            java.util.List list96 = numberAxis0.refreshTicks(graphics2D4, axisState5, rectangle2D37, rectangleEdge95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNull(valueAxis87);
        org.junit.Assert.assertNotNull(point2D88);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "Polar Plot" + "'", str93.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(plotOrientation94);
        org.junit.Assert.assertNotNull(rectangleEdge95);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textBlock0.setLineAlignment(horizontalAlignment2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        java.lang.String str8 = textBlockAnchor7.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement9);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Paint paint14 = piePlot13.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot13.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart16.getTitle();
        textTitle17.setPadding((double) (short) 0, (double) 100, (-1.0d), 0.4d);
        java.lang.Object obj23 = null;
        blockContainer10.add((org.jfree.chart.block.Block) textTitle17, obj23);
        boolean boolean25 = textBlockAnchor7.equals((java.lang.Object) blockContainer10);
        textBlock0.draw(graphics2D4, (float) 205, (float) (short) -1, textBlockAnchor7);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str8.equals("TextBlockAnchor.TOP_RIGHT"));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Font font6 = piePlot2.getLabelFont();
        java.awt.Paint paint8 = piePlot2.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        java.awt.Paint paint10 = piePlot2.getSectionPaint((java.lang.Comparable) (-1L));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        java.awt.Paint paint6 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D13 = blockContainer8.arrange(graphics2D9, rectangleConstraint12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 0.025d, 0.05d, rectangleAnchor16);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D17);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D17, "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setRightArrow((java.awt.Shape) rectangle2D17);
        boolean boolean23 = dateAxis1.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis25.setLowerMargin(0.0d);
        org.jfree.data.Range range28 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis25.setRange(range28);
        org.jfree.data.Range range30 = dateAxis25.getDefaultAutoRange();
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint(range31, range32);
        org.jfree.data.Range range34 = org.jfree.data.Range.combine(range30, range32);
        dateAxis1.setRangeWithMargins(range32);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 100.0f, jFreeChart1, 205, (int) 'a');
        chartProgressEvent4.setPercent(10);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Paint paint10 = piePlot9.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot9.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot9);
        org.jfree.chart.title.TextTitle textTitle13 = jFreeChart12.getTitle();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        jFreeChart12.setBorderPaint((java.awt.Paint) color14);
        int int16 = jFreeChart12.getBackgroundImageAlignment();
        boolean boolean17 = jFreeChart12.getAntiAlias();
        java.awt.Paint paint18 = jFreeChart12.getBorderPaint();
        chartProgressEvent4.setChart(jFreeChart12);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(textTitle13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = legendTitle5.getHorizontalAlignment();
        org.jfree.chart.block.BlockContainer blockContainer12 = legendTitle5.getItemContainer();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray13 = legendTitle5.getSources();
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle5.getItemContainer();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(blockContainer12);
        org.junit.Assert.assertNotNull(legendItemSourceArray13);
        org.junit.Assert.assertNotNull(blockContainer14);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        ringPlot1.setSeparatorPaint(paint2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        double double9 = piePlot7.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        piePlot7.markerChanged(markerChangeEvent10);
        java.awt.Shape shape12 = piePlot7.getLegendItemShape();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.PiePlotState piePlotState15 = ringPlot1.initialise(graphics2D4, rectangle2D5, piePlot7, (java.lang.Integer) 255, plotRenderingInfo14);
        ringPlot1.setSectionDepth(1.0E-5d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(piePlotState15);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font2, (java.awt.Paint) color3);
        boolean boolean5 = objectList0.equals((java.lang.Object) color3);
        java.lang.Object obj6 = objectList0.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker12.getLabelAnchor();
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis16.setLowerMargin(0.0d);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRange(range19);
        boolean boolean21 = rectangleAnchor13.equals((java.lang.Object) dateAxis16);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint4 = ringPlot3.getSeparatorPaint();
        valueMarker1.setLabelPaint(paint4);
        java.awt.Stroke stroke6 = valueMarker1.getStroke();
        boolean boolean8 = valueMarker1.equals((java.lang.Object) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = valueMarker1.getLabelOffset();
        double double10 = rectangleInsets9.getLeft();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.lang.Object obj1 = null;
        boolean boolean2 = piePlot3D0.equals(obj1);
        piePlot3D0.setNoDataMessage("VerticalAlignment.CENTER");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor6 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        piePlot3D0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        valueMarker1.setValue((double) (short) 10);
        valueMarker1.setAlpha((float) (byte) 1);
        java.awt.Font font6 = valueMarker1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.ORANGE;
        boolean boolean8 = valueMarker1.equals((java.lang.Object) color7);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = legendTitle5.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(2.0d, (double) 100L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint15.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint16.toFixedHeight((double) 2.0f);
        org.jfree.chart.util.Size2D size2D19 = legendTitle5.arrange(graphics2D12, rectangleConstraint18);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(size2D19);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 100.0f, jFreeChart1, 205, (int) 'a');
        chartProgressEvent4.setPercent(10);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Paint paint10 = piePlot9.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot9.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot9);
        java.lang.Object obj13 = jFreeChart12.clone();
        java.awt.RenderingHints renderingHints14 = jFreeChart12.getRenderingHints();
        chartProgressEvent4.setChart(jFreeChart12);
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart12.removeChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(renderingHints14);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setFixedDimension(0.0d);
        double double9 = dateAxis1.getAutoRangeMinimumSize();
        dateAxis1.setAutoRangeMinimumSize((double) 10L);
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMaximumDate(date12);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPassesRequired(0);
        double double4 = piePlotState1.getPieCenterY();
        piePlotState1.setPieCenterY(0.2d);
        piePlotState1.setPieCenterY(1.0E-5d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis2.setRange(range5);
        org.jfree.data.Range range7 = dateAxis2.getDefaultAutoRange();
        java.awt.Shape shape8 = dateAxis2.getRightArrow();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer9);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Paint paint10 = piePlot9.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot9.getLabelGenerator();
        java.awt.Paint paint12 = piePlot9.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle13.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle13.setLegendItemGraphicAnchor(rectangleAnchor15);
        legendTitle13.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = valueMarker20.getLabelAnchor();
        legendTitle13.setLegendItemGraphicAnchor(rectangleAnchor21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean24 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge23);
        legendTitle13.setLegendItemGraphicEdge(rectangleEdge23);
        legendTitle6.setLegendItemGraphicEdge(rectangleEdge23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = legendTitle6.getPosition();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.025d, 0.05d, rectangleAnchor9);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10);
        chartEntity11.setToolTipText("");
        java.lang.String str14 = chartEntity11.getURLText();
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset5 = piePlot1.getDataset();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.Plot plot7 = plotChangeEvent6.getPlot();
        org.jfree.chart.plot.Plot plot8 = plotChangeEvent6.getPlot();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = plotChangeEvent6.getType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) (byte) 1, 0.0d, (double) (byte) 100);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset5 = piePlot1.getDataset();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.Plot plot7 = plotChangeEvent6.getPlot();
        org.jfree.chart.plot.Plot plot8 = plotChangeEvent6.getPlot();
        java.lang.Object obj9 = plotChangeEvent6.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str11 = chartChangeEventType10.toString();
        plotChangeEvent6.setType(chartChangeEventType10);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str11.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis0.setMarkerBand(markerAxisBand5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis2.setRange(range5);
        boolean boolean7 = dateAxis2.isTickMarksVisible();
        double double8 = dateAxis2.getAutoRangeMinimumSize();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke10 = xYPlot9.getRangeCrosshairStroke();
        boolean boolean11 = xYPlot9.isDomainGridlinesVisible();
        java.awt.Paint paint12 = xYPlot9.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis14.setLowerMargin(0.0d);
        int int17 = xYPlot9.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
        boolean boolean20 = dateAxis2.isAxisLineVisible();
        dateAxis2.setUpperBound(0.05d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        boolean boolean6 = piePlot1.getIgnoreNullValues();
        java.awt.Paint paint7 = piePlot1.getLabelBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Font font6 = piePlot2.getLabelFont();
        piePlot2.setCircular(false, false);
        java.awt.Paint paint10 = piePlot2.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.lang.Object obj7 = textTitle6.clone();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        textTitle6.draw(graphics2D8, rectangle2D9);
        textTitle6.setToolTipText("");
        org.jfree.chart.block.BlockFrame blockFrame13 = textTitle6.getFrame();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(blockFrame13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke4);
        xYPlot0.setRangeCrosshairValue((double) 10, true);
        java.awt.Font font9 = xYPlot0.getNoDataMessageFont();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot10.getRangeAxisEdge((int) 'a');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = xYPlot10.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.util.List list4 = blockContainer0.getBlocks();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Paint paint12 = piePlot11.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot11.getLabelGenerator();
        java.awt.Paint paint14 = piePlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle15.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle15.setLegendItemGraphicAnchor(rectangleAnchor17);
        legendTitle15.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker22.getLabelAnchor();
        legendTitle15.setLegendItemGraphicAnchor(rectangleAnchor23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean26 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge25);
        legendTitle15.setLegendItemGraphicEdge(rectangleEdge25);
        java.awt.geom.Rectangle2D rectangle2D28 = legendTitle15.getBounds();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets9.createOutsetRectangle(rectangle2D28, false, false);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot32.getDomainAxisEdge((int) (short) 10);
        xYPlot32.clearRangeMarkers();
        xYPlot32.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot32.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        xYPlot42.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis45 = xYPlot42.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D46 = xYPlot42.getQuadrantOrigin();
        xYPlot32.zoomDomainAxes((double) (short) 0, plotRenderingInfo41, point2D46, false);
        org.jfree.chart.plot.PlotState plotState49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        waferMapPlot7.draw(graphics2D8, rectangle2D31, point2D46, plotState49, plotRenderingInfo50);
        org.jfree.data.general.PieDataset pieDataset52 = null;
        org.jfree.chart.plot.PiePlot piePlot53 = new org.jfree.chart.plot.PiePlot(pieDataset52);
        java.awt.Paint paint54 = piePlot53.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator55 = piePlot53.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset56 = null;
        org.jfree.chart.plot.PiePlot piePlot57 = new org.jfree.chart.plot.PiePlot(pieDataset56);
        org.jfree.chart.event.PlotChangeListener plotChangeListener58 = null;
        piePlot57.addChangeListener(plotChangeListener58);
        java.awt.Paint paint60 = piePlot57.getLabelOutlinePaint();
        java.awt.Paint paint61 = piePlot57.getNoDataMessagePaint();
        boolean boolean62 = piePlot53.equals((java.lang.Object) piePlot57);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator63 = null;
        piePlot53.setLegendLabelToolTipGenerator(pieSectionLabelGenerator63);
        piePlot53.setCircular(true, true);
        java.awt.Paint paint68 = piePlot53.getLabelLinkPaint();
        try {
            java.lang.Object obj69 = blockContainer0.draw(graphics2D5, rectangle2D31, (java.lang.Object) piePlot53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator55);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(paint68);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        java.awt.Paint paint6 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D13 = blockContainer8.arrange(graphics2D9, rectangleConstraint12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 0.025d, 0.05d, rectangleAnchor16);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D17);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D17, "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setRightArrow((java.awt.Shape) rectangle2D17);
        dateAxis1.setRangeAboutValue(3.0d, 4.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        int int6 = xYPlot0.indexOf(xYDataset5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 15);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        java.awt.Shape shape5 = dateAxis1.getLeftArrow();
        dateAxis1.centerRange(45.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 15);
        double double6 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        double double11 = categoryPlot0.getAnchorValue();
        java.awt.Paint paint12 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Paint paint15 = valueMarker14.getPaint();
        categoryPlot0.setDomainGridlinePaint(paint15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        xYPlot0.clearRangeMarkers();
        java.awt.Stroke stroke4 = xYPlot0.getOutlineStroke();
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) (byte) 0, (double) (short) -1, (double) 1.0f, paint8);
        double[][] doubleArray12 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray12);
        boolean boolean14 = blockBorder9.equals((java.lang.Object) categoryDataset13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset13, (double) 10);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset13);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot7);
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle11.getMargin();
        textTitle11.setWidth(90.0d);
        textTitle11.setNotify(false);
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle11.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        boolean boolean20 = categoryPlot0.render(graphics2D4, rectangle2D17, (int) (byte) -1, plotRenderingInfo19);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 100);
        valueMarker22.setValue((double) (short) 10);
        valueMarker22.setAlpha((float) (byte) 1);
        org.jfree.chart.util.Layer layer27 = null;
        try {
            boolean boolean28 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker22, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        java.awt.Color color6 = java.awt.Color.YELLOW;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "ClassContext", (java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.WHITE;
        float[] floatArray14 = new float[] { (-1.0f), (short) 0, 0.0f, (-1L), (-1) };
        float[] floatArray15 = color8.getRGBColorComponents(floatArray14);
        java.awt.Color color16 = java.awt.Color.WHITE;
        float[] floatArray22 = new float[] { (-1.0f), (short) 0, 0.0f, (-1L), (-1) };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color8.getRGBComponents(floatArray22);
        float[] floatArray25 = color6.getComponents(floatArray24);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(15);
        pieLabelDistributor1.distributeLabels((double) (-1), 10.0d);
        pieLabelDistributor1.distributeLabels(0.4d, (double) 0.5f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = valueMarker1.getLabelOffsetType();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker1.setStroke(stroke4);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) '#');
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        int int7 = categoryPlot0.getIndexOf(categoryItemRenderer6);
        java.awt.Paint paint8 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        categoryPlot0.setRangeCrosshairVisible(true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) (byte) 0, (double) (short) -1, (double) 1.0f, paint8);
        double[][] doubleArray12 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray12);
        boolean boolean14 = blockBorder9.equals((java.lang.Object) categoryDataset13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset13, (double) 10);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset13, false);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset13);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.025d, 0.05d, rectangleAnchor9);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10);
        java.lang.Object obj12 = chartEntity11.clone();
        java.lang.String str13 = chartEntity11.getURLText();
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        valueMarker1.setValue((double) (short) 10);
        valueMarker1.setAlpha((float) (byte) 1);
        java.awt.Font font6 = valueMarker1.getLabelFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot9 = categoryAxis8.getPlot();
        java.awt.Paint paint10 = categoryAxis8.getLabelPaint();
        java.awt.Stroke stroke11 = categoryAxis8.getTickMarkStroke();
        valueMarker1.setStroke(stroke11);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6, true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = new org.jfree.chart.text.TextBlock();
        java.util.List list12 = textBlock11.getLines();
        xYPlot0.drawRangeTickBands(graphics2D9, rectangle2D10, list12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker12.getLabelAnchor();
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean16 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge15);
        legendTitle5.setLegendItemGraphicEdge(rectangleEdge15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle5);
        org.jfree.chart.title.Title title19 = titleChangeEvent18.getTitle();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(title19);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setLicenceName("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        java.util.List list10 = projectInfo7.getContributors();
        org.jfree.chart.ui.Library[] libraryArray11 = projectInfo7.getOptionalLibraries();
        projectInfo7.addOptionalLibrary("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertNotNull(libraryArray11);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Paint paint5 = piePlot4.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot4.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart7.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle8.getMargin();
        double double10 = rectangleInsets9.getBottom();
        xYPlot0.setAxisOffset(rectangleInsets9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot12.setRenderer((int) '#', xYItemRenderer14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        xYPlot12.axisChanged(axisChangeEvent16);
        int int18 = xYPlot12.getDomainAxisCount();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis21.setLowerMargin(0.0d);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis21.setRange(range24);
        org.jfree.data.Range range26 = dateAxis21.getDefaultAutoRange();
        java.awt.Shape shape27 = dateAxis21.getRightArrow();
        dateAxis21.setRangeWithMargins(0.4d, (double) 'a');
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis32.setLowerMargin(0.0d);
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis32.setRange(range35);
        java.awt.Paint paint37 = dateAxis32.getTickMarkPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement38 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer39 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement38);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D44 = blockContainer39.arrange(graphics2D40, rectangleConstraint43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D48 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D44, 0.025d, 0.05d, rectangleAnchor47);
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D48);
        org.jfree.chart.entity.ChartEntity chartEntity52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D48, "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "TextBlockAnchor.TOP_RIGHT");
        dateAxis32.setRightArrow((java.awt.Shape) rectangle2D48);
        dateAxis21.setLeftArrow((java.awt.Shape) rectangle2D48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        xYPlot12.drawAnnotations(graphics2D19, rectangle2D48, plotRenderingInfo55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets9.createOutsetRectangle(rectangle2D48);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D57);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot0.getLegendItems();
        org.jfree.chart.StrokeMap strokeMap8 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot11 = categoryAxis10.getPlot();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Paint paint15 = piePlot14.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot14.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart17.getTitle();
        boolean boolean19 = jFreeChart17.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis10, jFreeChart17);
        boolean boolean21 = strokeMap8.equals((java.lang.Object) jFreeChart17);
        boolean boolean22 = jFreeChart17.isNotify();
        xYPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        ringPlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot7);
        jFreeChart10.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart10.getLegend();
        jFreeChart10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = jFreeChart10.getPadding();
        ringPlot1.setSimpleLabelOffset(rectangleInsets15);
        double double18 = rectangleInsets15.calculateBottomInset((double) 0.0f);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNull(legendTitle12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis5.setLowerMargin(0.0d);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range8);
        org.jfree.data.Range range10 = dateAxis5.getDefaultAutoRange();
        java.awt.Shape shape11 = dateAxis5.getRightArrow();
        dateAxis5.setInverted(false);
        int int14 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range15, (double) 2.0f, true);
        dateAxis5.setRange(range18);
        dateAxis5.resizeRange(1.0d, (double) 255);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(100);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot0.getRendererForDataset(xYDataset8);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMaximumCategoryLabelWidthRatio(10.0f);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Paint paint9 = piePlot8.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot8.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot8);
        org.jfree.chart.title.TextTitle textTitle12 = jFreeChart11.getTitle();
        java.lang.Object obj13 = textTitle12.clone();
        java.awt.Color color14 = java.awt.Color.black;
        textTitle12.setPaint((java.awt.Paint) color14);
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(textTitle12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        java.awt.Color color6 = java.awt.Color.YELLOW;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "ClassContext", (java.awt.Paint) color6);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        categoryPlot0.setAnchorValue((double) 4, false);
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        boolean boolean12 = categoryPlot0.render(graphics2D8, rectangle2D9, 128, plotRenderingInfo11);
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint4 = ringPlot3.getSeparatorPaint();
        valueMarker1.setLabelPaint(paint4);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double6 = legendTitle5.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle5.getItemLabelPadding();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Font font6 = piePlot2.getLabelFont();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        java.lang.String str9 = horizontalAlignment8.toString();
        legendTitle7.setHorizontalAlignment(horizontalAlignment8);
        boolean boolean11 = legendTitle7.getNotify();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "HorizontalAlignment.LEFT" + "'", str9.equals("HorizontalAlignment.LEFT"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint4 = ringPlot3.getSeparatorPaint();
        valueMarker1.setLabelPaint(paint4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker1.setOutlineStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = valueMarker1.getLabelOffset();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        java.awt.Paint paint8 = piePlot5.getBackgroundPaint();
        xYPlot0.setOutlinePaint(paint8);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        org.jfree.chart.util.Layer layer8 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker6, layer8);
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.configureRangeAxes();
        int int4 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis7, true);
        xYPlot0.setDomainCrosshairValue(0.0d, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        xYPlot0.setDomainCrosshairValue(0.4d);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot8.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis13.setLowerMargin(0.0d);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range16);
        org.jfree.data.Range range18 = dateAxis13.getDefaultAutoRange();
        java.awt.Shape shape19 = dateAxis13.getRightArrow();
        dateAxis13.setInverted(false);
        int int22 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot0.getDomainMarkers(0, layer25);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = xYPlot0.getDomainMarkers(205, layer28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNull(collection29);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        double double4 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis6.setLowerMargin(0.0d);
        java.awt.Shape shape9 = dateAxis6.getLeftArrow();
        org.jfree.data.Range range10 = dateAxis6.getRange();
        dateAxis1.setDefaultAutoRange(range10);
        double double12 = dateAxis1.getLabelAngle();
        dateAxis1.setLabelURL("");
        java.util.Date date15 = null;
        try {
            dateAxis1.setMaximumDate(date15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("", (int) (byte) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace2 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis7.setLowerMargin(0.0d);
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range10);
        org.jfree.data.Range range12 = dateAxis7.getDefaultAutoRange();
        dateAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range15 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis7);
        dateAxis7.setUpperMargin((double) ' ');
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        textTitle6.setPadding((double) (short) 0, (double) 100, (-1.0d), 0.4d);
        java.awt.Graphics2D graphics2D12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = textTitle6.arrange(graphics2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot8 = categoryAxis7.getPlot();
        java.awt.Paint paint9 = categoryAxis7.getLabelPaint();
        legendTitle5.setItemPaint(paint9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle5.getMargin();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle5.arrange(graphics2D12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D21 = blockContainer16.arrange(graphics2D17, rectangleConstraint20);
        org.jfree.chart.util.Size2D size2D22 = legendTitle5.arrange(graphics2D14, rectangleConstraint20);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(size2D22);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        double double4 = piePlot1.getLabelLinkMargin();
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.Object obj2 = new java.lang.Object();
        boolean boolean3 = verticalAlignment1.equals(obj2);
        java.lang.String str4 = verticalAlignment1.toString();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot7);
        java.awt.Font font11 = piePlot7.getLabelFont();
        java.awt.Paint paint13 = piePlot7.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Paint paint16 = piePlot15.getShadowPaint();
        double double17 = piePlot15.getShadowXOffset();
        org.jfree.chart.plot.Plot plot18 = piePlot15.getParent();
        java.awt.Paint paint19 = piePlot15.getBaseSectionOutlinePaint();
        piePlot7.setLabelBackgroundPaint(paint19);
        boolean boolean21 = verticalAlignment1.equals((java.lang.Object) piePlot7);
        java.lang.String str22 = verticalAlignment1.toString();
        boolean boolean23 = multiplePiePlot0.equals((java.lang.Object) verticalAlignment1);
        java.lang.String str24 = multiplePiePlot0.getPlotType();
        java.lang.Comparable comparable25 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot26.getDomainAxisEdge((int) (short) 10);
        boolean boolean29 = multiplePiePlot0.equals((java.lang.Object) rectangleEdge28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = multiplePiePlot0.getDataset();
        java.lang.Comparable comparable31 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.CENTER" + "'", str4.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "VerticalAlignment.CENTER" + "'", str22.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Multiple Pie Plot" + "'", str24.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + "Other" + "'", comparable25.equals("Other"));
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + "Other" + "'", comparable31.equals("Other"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        xYPlot0.clearRangeMarkers();
        java.awt.Stroke stroke4 = xYPlot0.getOutlineStroke();
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        java.util.List list2 = textBlock0.getLines();
        java.util.List list3 = textBlock0.getLines();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.awt.Shape shape11 = textBlock0.calculateBounds(graphics2D4, 0.0f, 0.0f, textBlockAnchor7, (float) 'a', (float) 100, 1.0E-5d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = textBlock0.calculateDimensions(graphics2D12);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(size2D13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Font font6 = piePlot2.getLabelFont();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2);
        legendTitle7.setMargin((double) 1, 10.0d, (double) (short) 0, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle7.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setFixedDimension(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = null;
        dateAxis1.setTickUnit(dateTickUnit9, false, true);
        dateAxis1.resizeRange(0.2d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis5.setLowerMargin(0.0d);
        int int8 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getRangeMarkers(layer9);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot0.getRangeMarkers(0, layer13);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        java.awt.Paint paint19 = piePlot16.getLabelOutlinePaint();
        org.jfree.chart.plot.Plot plot20 = piePlot16.getParent();
        java.awt.Stroke stroke21 = piePlot16.getLabelOutlineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke21);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getFixedDimension();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        java.awt.Shape shape7 = dateAxis1.getRightArrow();
        dateAxis1.setRangeWithMargins(0.4d, (double) 'a');
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range11, range12);
        org.jfree.data.Range range16 = org.jfree.data.Range.expand(range11, 0.0d, (double) 15);
        dateAxis1.setRange(range16, true, true);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.Object obj0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        java.awt.Paint paint4 = categoryAxis2.getLabelPaint();
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 0);
        categoryAxis2.setLabelURL("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        categoryAxis2.setCategoryLabelPositionOffset(100);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.clearRangeMarkers();
        java.lang.String str13 = xYPlot11.getPlotType();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot11.getDomainMarkers((int) (short) -1, layer15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot11);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle17.getItemLabelPadding();
        categoryAxis2.setTickLabelInsets(rectangleInsets18);
        org.jfree.chart.StrokeMap strokeMap20 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot23 = categoryAxis22.getPlot();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        java.awt.Paint paint27 = piePlot26.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = piePlot26.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot26);
        org.jfree.chart.title.TextTitle textTitle30 = jFreeChart29.getTitle();
        boolean boolean31 = jFreeChart29.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis22, jFreeChart29);
        boolean boolean33 = strokeMap20.equals((java.lang.Object) jFreeChart29);
        boolean boolean34 = categoryAxis2.hasListener((java.util.EventListener) jFreeChart29);
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent37 = new org.jfree.chart.event.ChartProgressEvent(obj0, jFreeChart29, 128, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "XY Plot" + "'", str13.equals("XY Plot"));
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator28);
        org.junit.Assert.assertNotNull(textTitle30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = null;
        org.jfree.chart.plot.PiePlotState piePlotState2 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo1);
        piePlotState2.setPassesRequired(0);
        java.lang.Class<?> wildcardClass5 = piePlotState2.getClass();
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("Pie 3D Plot", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(uRL6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        boolean boolean2 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getRangeAxis();
        java.awt.Paint paint6 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot7.getRangeAxis((int) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot7.getLegendItems();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Paint paint14 = piePlot13.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot13.getLabelGenerator();
        java.awt.Paint paint16 = piePlot13.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = piePlot13.getLabelPadding();
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        boolean boolean20 = unitType18.equals((java.lang.Object) 4.0d);
        boolean boolean21 = legendItemCollection11.equals((java.lang.Object) unitType18);
        xYPlot0.setFixedLegendItems(legendItemCollection11);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 100.0f, jFreeChart1, 205, (int) 'a');
        org.jfree.chart.JFreeChart jFreeChart5 = chartProgressEvent4.getChart();
        int int6 = chartProgressEvent4.getPercent();
        org.junit.Assert.assertNull(jFreeChart5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setFixedDimension(0.0d);
        double double9 = dateAxis1.getAutoRangeMinimumSize();
        java.awt.Paint paint10 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        xYPlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis8.setLowerMargin(0.0d);
        double double11 = dateAxis8.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis13.setLowerMargin(0.0d);
        java.awt.Shape shape16 = dateAxis13.getLeftArrow();
        org.jfree.data.Range range17 = dateAxis13.getRange();
        dateAxis8.setDefaultAutoRange(range17);
        boolean boolean19 = dateAxis8.isAutoRange();
        java.lang.String str20 = dateAxis8.getLabelURL();
        int int21 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(255);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Paint paint4 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        jFreeChart6.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = jFreeChart6.getPadding();
        multiplePiePlot0.setPieChart(jFreeChart6);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        boolean boolean9 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot13.getDomainAxisEdge((int) (short) 10);
        xYPlot13.clearRangeMarkers();
        xYPlot13.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot23.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D27 = xYPlot23.getQuadrantOrigin();
        xYPlot13.zoomDomainAxes((double) (short) 0, plotRenderingInfo22, point2D27, false);
        categoryPlot0.zoomDomainAxes((double) (short) 10, 0.0d, plotRenderingInfo12, point2D27);
        org.jfree.chart.plot.Marker marker31 = null;
        try {
            boolean boolean32 = categoryPlot0.removeRangeMarker(marker31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        java.lang.String str4 = rectangleConstraint3.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint3.getHeightConstraintType();
        boolean boolean6 = chartChangeEventType0.equals((java.lang.Object) rectangleConstraint3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint3.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.lang.Object obj3 = categoryAxis1.clone();
        categoryAxis1.setLabelURL("hi!");
        java.awt.Paint paint7 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 2.0f);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType6 = numberAxis5.getRangeType();
        numberAxis0.setRangeType(rangeType6);
        org.junit.Assert.assertNotNull(rangeType6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        jFreeChart5.setBorderVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart5.getPadding();
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10);
        blockContainer11.setMargin(0.025d, 4.0d, 3.0d, 0.025d);
        java.util.List list17 = blockContainer11.getBlocks();
        jFreeChart5.setSubtitles(list17);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.util.List list2 = textBlock1.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textBlock1.setLineAlignment(horizontalAlignment3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment5, (double) (short) 1, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment5, (double) (short) -1, (double) (short) -1);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Font font5 = categoryAxis1.getLabelFont();
        categoryAxis1.setTickMarkInsideLength((float) 205);
        categoryAxis1.setUpperMargin((double) 'a');
        boolean boolean10 = categoryAxis1.isVisible();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((int) (byte) 1);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getSeparatorPaint();
        valueMarker6.setLabelPaint(paint9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker6.setOutlineStroke(stroke11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot0.getDomainMarkers(layer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        double double4 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis6.setLowerMargin(0.0d);
        java.awt.Shape shape9 = dateAxis6.getLeftArrow();
        org.jfree.data.Range range10 = dateAxis6.getRange();
        dateAxis1.setDefaultAutoRange(range10);
        boolean boolean12 = dateAxis1.isAutoRange();
        java.lang.String str13 = dateAxis1.getLabelURL();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.awt.Paint paint18 = piePlot17.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = piePlot17.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.title.TextTitle textTitle21 = jFreeChart20.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle21.getMargin();
        textTitle21.setWidth(90.0d);
        textTitle21.setNotify(false);
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle21.getBounds();
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement28);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D34 = blockContainer29.arrange(graphics2D30, rectangleConstraint33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, 0.025d, 0.05d, rectangleAnchor37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean40 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge39);
        double double42 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D38, rectangleEdge39);
        double double43 = dateAxis1.valueToJava2D(0.4d, rectangle2D27, rectangleEdge39);
        boolean boolean44 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertNotNull(textTitle21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(size2D34);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.025d + "'", double42 == 0.025d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.calculateRightInset((double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str1.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke3);
        java.awt.Paint paint5 = piePlot1.getLabelOutlinePaint();
        try {
            piePlot1.setBackgroundImageAlpha((float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke3);
        double double5 = piePlot1.getMinimumArcAngleToDraw();
        piePlot1.setShadowXOffset((double) 'a');
        java.awt.Stroke stroke8 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint9 = piePlot1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis5.setLowerMargin(0.0d);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range8);
        org.jfree.data.Range range10 = dateAxis5.getDefaultAutoRange();
        java.awt.Shape shape11 = dateAxis5.getRightArrow();
        dateAxis5.setInverted(false);
        int int14 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range15, (double) 2.0f, true);
        dateAxis5.setRange(range18);
        org.jfree.data.Range range20 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.combine(range18, range20);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker12.getLabelAnchor();
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        org.jfree.data.Range range5 = dateAxis1.getRange();
        dateAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        double double4 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis6.setLowerMargin(0.0d);
        java.awt.Shape shape9 = dateAxis6.getLeftArrow();
        org.jfree.data.Range range10 = dateAxis6.getRange();
        dateAxis1.setDefaultAutoRange(range10);
        dateAxis1.zoomRange((double) (-1L), (double) (byte) 10);
        dateAxis1.resizeRange((double) '4');
        boolean boolean17 = dateAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        piePlot3D0.setStartAngle(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis1.getTickUnit();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Paint paint10 = piePlot9.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot9.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot9);
        org.jfree.chart.title.TextTitle textTitle13 = jFreeChart12.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle13.getMargin();
        textTitle13.setWidth(90.0d);
        textTitle13.setNotify(false);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle13.getBounds();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot20.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine();
        boolean boolean24 = rectangleEdge22.equals((java.lang.Object) textLine23);
        double double25 = dateAxis1.lengthToJava2D(10.0d, rectangle2D19, rectangleEdge22);
        dateAxis1.setLabelAngle((double) 3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(textTitle13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((int) (byte) 1);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getSeparatorPaint();
        valueMarker6.setLabelPaint(paint9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker6.setOutlineStroke(stroke11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        boolean boolean16 = xYPlot0.isDomainZeroBaselineVisible();
        java.lang.Object obj17 = null;
        boolean boolean18 = xYPlot0.equals(obj17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        double double4 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis6.setLowerMargin(0.0d);
        java.awt.Shape shape9 = dateAxis6.getLeftArrow();
        org.jfree.data.Range range10 = dateAxis6.getRange();
        dateAxis1.setDefaultAutoRange(range10);
        double double12 = dateAxis1.getLabelAngle();
        dateAxis1.setLabelURL("");
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis16.setLowerMargin(0.0d);
        double double19 = dateAxis16.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis21.setLowerMargin(0.0d);
        java.awt.Shape shape24 = dateAxis21.getLeftArrow();
        org.jfree.data.Range range25 = dateAxis21.getRange();
        dateAxis16.setDefaultAutoRange(range25);
        boolean boolean27 = dateAxis16.isAutoRange();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition28 = dateAxis16.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition28);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition28);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textBlock0.setLineAlignment(horizontalAlignment2);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color6 = java.awt.Color.yellow;
        textBlock0.addLine("TextBlockAnchor.TOP_RIGHT", font5, (java.awt.Paint) color6);
        boolean boolean9 = textBlock0.equals((java.lang.Object) 2.0d);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        java.awt.Font font5 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 15);
        java.awt.Paint paint6 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieWRadius((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = piePlotState1.getInfo();
        piePlotState1.setPieWRadius(0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo4);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart5.getLegend();
        java.awt.Paint paint8 = jFreeChart5.getBorderPaint();
        jFreeChart5.removeLegend();
        java.awt.Image image10 = jFreeChart5.getBackgroundImage();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(image10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.configureDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot2.getDomainAxisEdge((int) '#');
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot2.getFixedRangeAxisSpace();
        boolean boolean8 = categoryPlot0.equals((java.lang.Object) categoryPlot2);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        double double4 = piePlot2.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        piePlot2.markerChanged(markerChangeEvent5);
        java.lang.Object obj7 = piePlot2.clone();
        java.awt.Paint paint8 = piePlot2.getLabelShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("RectangleAnchor.RIGHT", (org.jfree.chart.plot.Plot) piePlot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle6.getMargin();
        textTitle6.setWidth(90.0d);
        textTitle6.setNotify(false);
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        java.util.List list13 = textBlock12.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textBlock12.setLineAlignment(horizontalAlignment14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment14, verticalAlignment16, (double) (short) 1, 0.0d);
        textTitle6.setTextAlignment(horizontalAlignment14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle6.getTextAlignment();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        boolean boolean6 = piePlot1.getIgnoreNullValues();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke7);
        piePlot1.setIgnoreZeroValues(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D(0.0d, 0.0d);
        double double15 = size2D14.getWidth();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Paint paint20 = piePlot19.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator21 = piePlot19.getLabelGenerator();
        java.awt.Paint paint22 = piePlot19.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot19);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = legendTitle23.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle23.setLegendItemGraphicAnchor(rectangleAnchor25);
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, 0.14d, (double) (-1L), rectangleAnchor25);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        java.awt.Paint paint31 = piePlot30.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator32 = piePlot30.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot30);
        java.awt.Font font34 = piePlot30.getLabelFont();
        piePlot30.setCircular(false, false);
        java.awt.Paint paint38 = piePlot30.getBaseSectionOutlinePaint();
        try {
            java.lang.Object obj39 = legendTitle5.draw(graphics2D11, rectangle2D27, (java.lang.Object) paint38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        java.lang.String str4 = rectangleConstraint3.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint3.getHeightConstraintType();
        boolean boolean6 = chartChangeEventType0.equals((java.lang.Object) rectangleConstraint3);
        org.jfree.data.Range range7 = rectangleConstraint3.getWidthRange();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        categoryPlot0.setAnchorValue((double) 0, false);
        java.lang.Object obj7 = categoryPlot0.clone();
        java.util.List list8 = categoryPlot0.getCategories();
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        categoryPlot0.setAnchorValue((double) 0, false);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeGridlinePaint(paint7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis(0);
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        double double11 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxis(4);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.clearRangeMarkers();
        java.lang.String str17 = xYPlot15.getPlotType();
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot15.getDomainMarkers((int) (short) -1, layer19);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot15.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation21, false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis26.setLowerMargin(0.0d);
        java.awt.Shape shape29 = dateAxis26.getLeftArrow();
        boolean boolean31 = dateAxis26.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = null;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer32);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = polarPlot33.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation34);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "XY Plot" + "'", str17.equals("XY Plot"));
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("Size2D[width=0.0, height=205.0]", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double6 = legendTitle5.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            legendTitle5.setLegendItemGraphicPadding(rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis5.setLowerMargin(0.0d);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range8);
        org.jfree.data.Range range10 = dateAxis5.getDefaultAutoRange();
        java.awt.Shape shape11 = dateAxis5.getRightArrow();
        dateAxis5.setInverted(false);
        int int14 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range15, (double) 2.0f, true);
        dateAxis5.setRange(range18);
        double double21 = range18.constrain((double) (-1L));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        categoryPlot0.setAnchorValue((double) 0, false);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        categoryPlot0.setRangeGridlinePaint(paint7);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot12 = categoryAxis11.getPlot();
        java.awt.Paint paint13 = categoryAxis11.getTickMarkPaint();
        boolean boolean14 = categoryAxis11.isTickLabelsVisible();
        categoryAxis11.setLabel("");
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis11, true);
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        xYPlot0.clearRangeMarkers();
        xYPlot0.setNoDataMessage("TextAnchor.TOP_RIGHT");
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        double double4 = piePlot1.getLabelLinkMargin();
        java.lang.String str5 = piePlot1.getNoDataMessage();
        piePlot1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        boolean boolean9 = projectInfo7.equals((java.lang.Object) true);
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image13, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo17.getInfo();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        java.awt.Stroke stroke11 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        java.awt.Paint paint16 = ringPlot15.getSeparatorPaint();
        valueMarker13.setLabelPaint(paint16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker13.setOutlineStroke(stroke18);
        org.jfree.chart.util.Layer layer20 = null;
        try {
            boolean boolean21 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker13, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        double double4 = piePlot1.getLabelLinkMargin();
        double double5 = piePlot1.getLabelGap();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        double double4 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis6.setLowerMargin(0.0d);
        java.awt.Shape shape9 = dateAxis6.getLeftArrow();
        org.jfree.data.Range range10 = dateAxis6.getRange();
        dateAxis1.setDefaultAutoRange(range10);
        double double12 = dateAxis1.getLabelAngle();
        org.jfree.data.Range range13 = dateAxis1.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range5 = org.jfree.data.Range.expand(range0, 0.0d, (double) 15);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) (short) 0);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) -1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Paint paint5 = piePlot4.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot4.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot4);
        jFreeChart7.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart7.getLegend();
        java.awt.Stroke stroke10 = jFreeChart7.getBorderStroke();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        java.lang.String str15 = rectangleConstraint14.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint14.getHeightConstraintType();
        boolean boolean17 = chartChangeEventType11.equals((java.lang.Object) rectangleConstraint14);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) pieLabelDistributor1, jFreeChart7, chartChangeEventType11);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNull(legendTitle9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str15.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        java.lang.Object obj4 = xYPlot0.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke4);
        xYPlot0.setRangeCrosshairValue((double) 10, true);
        java.awt.Font font9 = xYPlot0.getNoDataMessageFont();
        java.awt.Stroke stroke10 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, range2);
        boolean boolean5 = range2.contains((double) (short) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        java.lang.String str14 = rectangleConstraint13.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((-35.57979797979798d), range2, lengthConstraintType6, (double) 100L, range9, lengthConstraintType15);
        double double17 = range2.getLength();
        org.jfree.data.Range range19 = org.jfree.data.Range.shift(range2, (double) (-1.0f));
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str14.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setFixedDimension(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = null;
        dateAxis1.setTickUnit(dateTickUnit9, false, true);
        java.awt.Font font13 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        dateAxis1.setTickLabelFont(font13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        boolean boolean16 = xYPlot15.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot15.getDomainAxis((int) (byte) 1);
        xYPlot15.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot(pieDataset22);
        java.awt.Paint paint24 = ringPlot23.getSeparatorPaint();
        valueMarker21.setLabelPaint(paint24);
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker21.setOutlineStroke(stroke26);
        xYPlot15.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
        java.awt.Font font29 = valueMarker21.getLabelFont();
        dateAxis1.setTickLabelFont(font29);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        double double11 = categoryPlot0.getAnchorValue();
        java.awt.Paint paint12 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Paint paint15 = valueMarker14.getPaint();
        categoryPlot0.setDomainGridlinePaint(paint15);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis18.setLowerMargin(0.0d);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis18.setRange(range21);
        java.awt.Shape shape23 = dateAxis18.getUpArrow();
        double double24 = dateAxis18.getLowerBound();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.awt.Shape shape26 = dateAxis18.getRightArrow();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 3, (double) (byte) -1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        double double9 = piePlot7.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        piePlot7.markerChanged(markerChangeEvent10);
        java.awt.Shape shape12 = piePlot7.getLegendItemShape();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        boolean boolean14 = xYPlot13.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot13.getDomainAxis((int) (byte) 1);
        xYPlot13.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        java.awt.Paint paint22 = ringPlot21.getSeparatorPaint();
        valueMarker19.setLabelPaint(paint22);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker19.setOutlineStroke(stroke24);
        xYPlot13.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = xYPlot13.getInsets();
        piePlot7.setLabelPadding(rectangleInsets27);
        xYPlot0.setAxisOffset(rectangleInsets27);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setRangeAxes(valueAxisArray30);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke33 = defaultDrawingSupplier32.getNextOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke33);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(valueAxisArray30);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        boolean boolean7 = dateAxis2.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo11);
        piePlotState12.setPieWRadius((double) 10.0f);
        double double15 = piePlotState12.getPieCenterY();
        piePlotState12.setPieWRadius((-4.0d));
        java.awt.Color color18 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        double double21 = piePlot20.getStartAngle();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot20.setBaseSectionOutlineStroke(stroke22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        java.awt.Paint paint26 = piePlot25.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator27 = piePlot25.getLabelGenerator();
        java.awt.Paint paint28 = piePlot25.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot25.getLabelPadding();
        org.jfree.chart.util.UnitType unitType30 = rectangleInsets29.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke22, rectangleInsets29);
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D38 = blockContainer33.arrange(graphics2D34, rectangleConstraint37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D38, 0.025d, 0.05d, rectangleAnchor41);
        org.jfree.chart.entity.ChartEntity chartEntity43 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets29.createOutsetRectangle(rectangle2D42, false, false);
        piePlotState12.setLinkArea(rectangle2D42);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis50.setLowerMargin(0.0d);
        java.awt.Shape shape53 = dateAxis50.getLeftArrow();
        boolean boolean55 = dateAxis50.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) dateAxis50, polarItemRenderer56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = xYPlot60.getDomainAxisEdge((int) (short) 10);
        xYPlot60.clearRangeMarkers();
        xYPlot60.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot60.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot();
        xYPlot70.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis73 = xYPlot70.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D74 = xYPlot70.getQuadrantOrigin();
        xYPlot60.zoomDomainAxes((double) (short) 0, plotRenderingInfo69, point2D74, false);
        polarPlot57.zoomDomainAxes((double) (-1), plotRenderingInfo59, point2D74, true);
        org.jfree.chart.plot.PlotState plotState79 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        polarPlot9.draw(graphics2D10, rectangle2D42, point2D74, plotState79, plotRenderingInfo80);
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis83.setLowerMargin(0.0d);
        java.awt.Shape shape86 = dateAxis83.getLeftArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit87 = dateAxis83.getTickUnit();
        polarPlot9.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit87);
        polarPlot9.zoom((double) 0.8f);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(point2D74);
        org.junit.Assert.assertNotNull(shape86);
        org.junit.Assert.assertNotNull(dateTickUnit87);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace4, true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        double double9 = piePlot8.getStartAngle();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot8.setBaseSectionOutlineStroke(stroke10);
        xYPlot0.setDomainCrosshairStroke(stroke10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot0.setRenderer(0, xYItemRenderer14, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 90.0d + "'", double9 == 90.0d);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        java.awt.Paint paint9 = piePlot5.getNoDataMessagePaint();
        boolean boolean10 = piePlot1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = null;
        piePlot1.setLegendLabelToolTipGenerator(pieSectionLabelGenerator11);
        java.awt.Paint paint13 = piePlot1.getLabelPaint();
        double double14 = piePlot1.getInteriorGap();
        java.awt.Stroke stroke16 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0.4d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.08d + "'", double14 == 0.08d);
        org.junit.Assert.assertNull(stroke16);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        java.util.List list2 = textBlock0.getLines();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot3.getRangeAxis((int) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot3.getLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot3.getRangeAxisEdge();
        boolean boolean9 = xYPlot3.isDomainGridlinesVisible();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot3.setDomainGridlineStroke(stroke10);
        xYPlot3.setRangeCrosshairValue((double) 100.0f, true);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke16 = xYPlot15.getRangeCrosshairStroke();
        boolean boolean17 = xYPlot15.isDomainGridlinesVisible();
        java.awt.Paint paint18 = xYPlot15.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis20.setLowerMargin(0.0d);
        int int23 = xYPlot15.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
        int int24 = xYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis26.setLowerMargin(0.0d);
        java.awt.Shape shape29 = dateAxis26.getLeftArrow();
        java.awt.Shape shape30 = dateAxis26.getLeftArrow();
        dateAxis26.centerRange(45.0d);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis34.setLowerMargin(0.0d);
        java.awt.Shape shape37 = dateAxis34.getLeftArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = dateAxis34.getTickUnit();
        java.util.Date date39 = dateAxis26.calculateLowestVisibleTickValue(dateTickUnit38);
        dateAxis20.setMaximumDate(date39);
        boolean boolean41 = textBlock0.equals((java.lang.Object) dateAxis20);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(dateTickUnit38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent3);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets5.getUnitType();
        double double8 = rectangleInsets5.calculateLeftOutset(0.0d);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot9.setRenderer((int) '#', xYItemRenderer11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = null;
        xYPlot9.axisChanged(axisChangeEvent13);
        int int15 = xYPlot9.getDomainAxisCount();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis18.setLowerMargin(0.0d);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis18.setRange(range21);
        org.jfree.data.Range range23 = dateAxis18.getDefaultAutoRange();
        java.awt.Shape shape24 = dateAxis18.getRightArrow();
        dateAxis18.setRangeWithMargins(0.4d, (double) 'a');
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis29.setLowerMargin(0.0d);
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRange(range32);
        java.awt.Paint paint34 = dateAxis29.getTickMarkPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement35 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D41 = blockContainer36.arrange(graphics2D37, rectangleConstraint40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D41, 0.025d, 0.05d, rectangleAnchor44);
        org.jfree.chart.entity.ChartEntity chartEntity46 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D45);
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D45, "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "TextBlockAnchor.TOP_RIGHT");
        dateAxis29.setRightArrow((java.awt.Shape) rectangle2D45);
        dateAxis18.setLeftArrow((java.awt.Shape) rectangle2D45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        xYPlot9.drawAnnotations(graphics2D16, rectangle2D45, plotRenderingInfo52);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets5.createInsetRectangle(rectangle2D45, false, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(size2D41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D56);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(100);
        java.lang.String str2 = pieLabelDistributor1.toString();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleAnchor.RIGHT");
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        xYPlot0.setDomainGridlinesVisible(false);
        boolean boolean4 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace2 = categoryPlot0.getFixedRangeAxisSpace();
        java.util.List list3 = categoryPlot0.getCategories();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke5 = xYPlot4.getRangeCrosshairStroke();
        categoryPlot0.setRangeGridlineStroke(stroke5);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat8 = null;
        numberAxis5.setNumberFormatOverride(numberFormat8);
        boolean boolean10 = numberAxis5.isTickMarksVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis5.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit11, false, false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(numberTickUnit11);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.lang.Comparable comparable5 = multiplePiePlot4.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = valueMarker1.getLabelOffsetType();
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor(0, (int) (byte) 0, 0);
        valueMarker1.setLabelPaint((java.awt.Paint) chartColor7);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator1.getAttributedLabel((int) (byte) -1);
        java.lang.Object obj4 = null;
        boolean boolean5 = standardPieSectionLabelGenerator1.equals(obj4);
        java.lang.Object obj6 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 0, (float) '4', (float) (-1L));
        int int4 = color3.getBlue();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 205 + "'", int4 == 205);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = legendTitle5.getVerticalAlignment();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(verticalAlignment11);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range4, range5);
        boolean boolean8 = range5.contains((double) (short) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range11, range12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        java.lang.String str17 = rectangleConstraint16.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint16.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((-35.57979797979798d), range5, lengthConstraintType9, (double) 100L, range12, lengthConstraintType18);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint2.toRangeHeight(range5);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str17.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        xYPlot0.configureRangeAxes();
        int int4 = xYPlot0.getRangeAxisCount();
        int int5 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setLicenceText("");
        java.lang.String str10 = projectInfo7.getInfo();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Paint paint14 = piePlot13.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot13.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot13);
        jFreeChart16.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart16.getLegend();
        jFreeChart16.setAntiAlias(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart16.createBufferedImage((int) (byte) 10, 100, chartRenderingInfo23);
        projectInfo7.setLogo((java.awt.Image) bufferedImage24);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertNull(legendTitle18);
        org.junit.Assert.assertNotNull(bufferedImage24);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        boolean boolean7 = dateAxis2.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer8);
        polarPlot9.zoom((double) 10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        polarPlot9.datasetChanged(datasetChangeEvent12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis15.setLowerMargin(0.0d);
        java.awt.Shape shape18 = dateAxis15.getLeftArrow();
        boolean boolean20 = dateAxis15.isHiddenValue((long) '4');
        polarPlot9.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        java.awt.Stroke stroke3 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        java.awt.Paint paint7 = ringPlot6.getSeparatorPaint();
        valueMarker4.setLabelPaint(paint7);
        java.lang.Object obj9 = valueMarker4.clone();
        valueMarker4.setLabel("ThreadContext");
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = valueMarker13.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = valueMarker13.getLabelOffsetType();
        valueMarker4.setLabelOffsetType(lengthAdjustmentType15);
        org.jfree.chart.util.Layer layer17 = null;
        try {
            boolean boolean18 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        double double11 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3, true);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot1.getLegendLabelGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot1.getLabelPadding();
        double double4 = rectangleInsets3.getTop();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double7 = piePlot1.getExplodePercent((java.lang.Comparable) 1.0f);
        org.jfree.data.general.DatasetGroup datasetGroup8 = piePlot1.getDatasetGroup();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(datasetGroup8);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator1.getAttributedLabel((int) (byte) -1);
        java.lang.Object obj4 = null;
        boolean boolean5 = standardPieSectionLabelGenerator1.equals(obj4);
        java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator1.getAttributedLabel(15);
        java.text.NumberFormat numberFormat8 = standardPieSectionLabelGenerator1.getPercentFormat();
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(attributedString7);
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        boolean boolean7 = dateAxis2.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo11);
        piePlotState12.setPieWRadius((double) 10.0f);
        double double15 = piePlotState12.getPieCenterY();
        piePlotState12.setPieWRadius((-4.0d));
        java.awt.Color color18 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        double double21 = piePlot20.getStartAngle();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot20.setBaseSectionOutlineStroke(stroke22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        java.awt.Paint paint26 = piePlot25.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator27 = piePlot25.getLabelGenerator();
        java.awt.Paint paint28 = piePlot25.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot25.getLabelPadding();
        org.jfree.chart.util.UnitType unitType30 = rectangleInsets29.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke22, rectangleInsets29);
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D38 = blockContainer33.arrange(graphics2D34, rectangleConstraint37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D42 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D38, 0.025d, 0.05d, rectangleAnchor41);
        org.jfree.chart.entity.ChartEntity chartEntity43 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets29.createOutsetRectangle(rectangle2D42, false, false);
        piePlotState12.setLinkArea(rectangle2D42);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis50.setLowerMargin(0.0d);
        java.awt.Shape shape53 = dateAxis50.getLeftArrow();
        boolean boolean55 = dateAxis50.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) dateAxis50, polarItemRenderer56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = xYPlot60.getDomainAxisEdge((int) (short) 10);
        xYPlot60.clearRangeMarkers();
        xYPlot60.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot60.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot();
        xYPlot70.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis73 = xYPlot70.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D74 = xYPlot70.getQuadrantOrigin();
        xYPlot60.zoomDomainAxes((double) (short) 0, plotRenderingInfo69, point2D74, false);
        polarPlot57.zoomDomainAxes((double) (-1), plotRenderingInfo59, point2D74, true);
        org.jfree.chart.plot.PlotState plotState79 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        polarPlot9.draw(graphics2D10, rectangle2D42, point2D74, plotState79, plotRenderingInfo80);
        org.jfree.data.general.PieDataset pieDataset82 = null;
        org.jfree.chart.plot.RingPlot ringPlot83 = new org.jfree.chart.plot.RingPlot(pieDataset82);
        java.awt.Paint paint84 = ringPlot83.getSeparatorPaint();
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis86.setLowerMargin(0.0d);
        java.awt.Shape shape89 = dateAxis86.getLeftArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit90 = dateAxis86.getTickUnit();
        ringPlot83.setExplodePercent((java.lang.Comparable) dateTickUnit90, 0.0d);
        polarPlot9.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit90);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(point2D74);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(shape89);
        org.junit.Assert.assertNotNull(dateTickUnit90);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot8 = categoryAxis7.getPlot();
        java.awt.Paint paint9 = categoryAxis7.getLabelPaint();
        legendTitle5.setItemPaint(paint9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle5.getMargin();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        legendTitle5.setHorizontalAlignment(horizontalAlignment12);
        java.awt.Color color14 = java.awt.Color.darkGray;
        legendTitle5.setBackgroundPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        xYPlot0.clearRangeMarkers();
        xYPlot0.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot10.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D14 = xYPlot10.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) (short) 0, plotRenderingInfo9, point2D14, false);
        org.jfree.chart.axis.AxisSpace axisSpace17 = xYPlot0.getFixedDomainAxisSpace();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Paint paint20 = piePlot19.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator21 = piePlot19.getLabelGenerator();
        java.awt.Paint paint22 = piePlot19.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot19.getLabelPadding();
        org.jfree.chart.util.UnitType unitType24 = rectangleInsets23.getUnitType();
        double double26 = rectangleInsets23.extendHeight((double) (-1L));
        xYPlot0.setAxisOffset(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(unitType24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis4.setLowerMargin(0.0d);
        java.awt.Shape shape7 = dateAxis4.getLeftArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis4.getTickUnit();
        ringPlot1.setExplodePercent((java.lang.Comparable) dateTickUnit8, 0.0d);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke12 = xYPlot11.getRangeCrosshairStroke();
        boolean boolean13 = xYPlot11.isDomainGridlinesVisible();
        java.awt.Paint paint14 = xYPlot11.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot11.setFixedDomainAxisSpace(axisSpace15, true);
        java.awt.Stroke stroke18 = xYPlot11.getDomainCrosshairStroke();
        ringPlot1.setSeparatorStroke(stroke18);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D13 = blockContainer8.arrange(graphics2D9, rectangleConstraint12);
        legendTitle6.setWrapper(blockContainer8);
        java.awt.Paint paint15 = legendTitle6.getItemPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle6.getLegendItemGraphicLocation();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray8);
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset9, 15);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset9);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot0.getRendererForDataset(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot17 = categoryAxis16.getPlot();
        java.awt.Paint paint18 = categoryAxis16.getTickMarkPaint();
        java.awt.Font font20 = categoryAxis16.getTickLabelFont((java.lang.Comparable) 15);
        categoryAxis16.setMaximumCategoryLabelLines((int) (byte) 0);
        java.util.List list23 = categoryPlot0.getCategoriesForAxis(categoryAxis16);
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(pieDataset11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setLicenceName("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image13, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo17.toString();
        java.lang.String str20 = projectInfo17.toString();
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str19.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str20.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.025d, 0.05d, rectangleAnchor9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean12 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge11);
        double double14 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D10, rectangleEdge11);
        try {
            java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.025d + "'", double14 == 0.025d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis0.setMarkerBand(markerAxisBand3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textBlock0.setLineAlignment(horizontalAlignment2);
        org.jfree.chart.text.TextLine textLine4 = textBlock0.getLastLine();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNull(textLine4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Paint paint7 = piePlot6.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        textTitle10.setPadding((double) (short) 0, (double) 100, (-1.0d), 0.4d);
        java.lang.Object obj16 = null;
        blockContainer3.add((org.jfree.chart.block.Block) textTitle10, obj16);
        boolean boolean18 = textBlockAnchor0.equals((java.lang.Object) blockContainer3);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot20.getDomainAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot20.getDomainAxisLocation();
        java.awt.Paint paint25 = categoryPlot20.getDomainGridlinePaint();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis28.setLowerMargin(0.0d);
        java.awt.Shape shape31 = dateAxis28.getLeftArrow();
        org.jfree.data.Range range32 = dateAxis28.getRange();
        org.jfree.chart.block.ColumnArrangement columnArrangement33 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D39 = blockContainer34.arrange(graphics2D35, rectangleConstraint38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D43 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, 0.025d, 0.05d, rectangleAnchor42);
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D43);
        dateAxis28.setRightArrow((java.awt.Shape) rectangle2D43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        boolean boolean48 = categoryPlot20.render(graphics2D26, rectangle2D43, 205, plotRenderingInfo47);
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot49.getDomainAxisEdge((int) (short) 10);
        xYPlot49.clearRangeMarkers();
        java.awt.Stroke stroke53 = xYPlot49.getRangeZeroBaselineStroke();
        xYPlot49.clearRangeMarkers();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        int int56 = xYPlot49.getIndexOf(xYItemRenderer55);
        try {
            java.lang.Object obj57 = blockContainer3.draw(graphics2D19, rectangle2D43, (java.lang.Object) xYItemRenderer55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str1.equals("TextBlockAnchor.TOP_RIGHT"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        boolean boolean9 = projectInfo7.equals((java.lang.Object) true);
        projectInfo7.setInfo("Pie Plot");
        java.lang.String str12 = projectInfo7.getVersion();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str12.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        xYPlot0.clearRangeMarkers();
        xYPlot0.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot0.setRangeGridlinesVisible(false);
        java.lang.Object obj8 = xYPlot0.clone();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getRangeCrosshairStroke();
        boolean boolean12 = xYPlot10.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot10.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot10.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot10.getRangeAxisLocation(10);
        xYPlot0.setDomainAxisLocation(205, axisLocation17, false);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Paint paint4 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = piePlot7.getLabelOutlinePaint();
        java.awt.Paint paint11 = piePlot7.getNoDataMessagePaint();
        boolean boolean12 = piePlot3.equals((java.lang.Object) piePlot7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot3.getLabelGenerator();
        piePlot3.setMinimumArcAngleToDraw(3.0d);
        java.awt.Shape shape16 = piePlot3.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        boolean boolean18 = paintMap0.equals((java.lang.Object) chartEntity17);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        java.awt.Font font4 = valueMarker1.getLabelFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getShadowXOffset();
        double double4 = piePlot1.getStartAngle();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.PiePlotState piePlotState6 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo5);
        piePlotState6.setPieWRadius((double) 10.0f);
        double double9 = piePlotState6.getPieCenterY();
        piePlotState6.setPieWRadius((-4.0d));
        boolean boolean12 = piePlot1.equals((java.lang.Object) (-4.0d));
        piePlot1.setExplodePercent((java.lang.Comparable) 0.0f, 4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = piePlotState1.getPieArea();
        org.junit.Assert.assertNull(rectangle2D2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.025d, 0.05d, rectangleAnchor9);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10);
        chartEntity11.setToolTipText("");
        java.lang.Object obj14 = chartEntity11.clone();
        java.awt.Shape shape15 = chartEntity11.getArea();
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis5.setLowerMargin(0.0d);
        int int8 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getRangeMarkers(layer9);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot0.getRangeMarkers(0, layer13);
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint15);
        xYPlot0.setRangeCrosshairValue(45.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Font font5 = categoryAxis1.getLabelFont();
        categoryAxis1.setTickMarkInsideLength((float) 205);
        categoryAxis1.setUpperMargin((double) 'a');
        org.jfree.chart.StrokeMap strokeMap10 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot13 = categoryAxis12.getPlot();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.awt.Paint paint17 = piePlot16.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot16.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot16);
        org.jfree.chart.title.TextTitle textTitle20 = jFreeChart19.getTitle();
        boolean boolean21 = jFreeChart19.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis12, jFreeChart19);
        boolean boolean23 = strokeMap10.equals((java.lang.Object) jFreeChart19);
        java.awt.Stroke stroke25 = strokeMap10.getStroke((java.lang.Comparable) 4.0d);
        boolean boolean26 = categoryAxis1.equals((java.lang.Object) stroke25);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(textTitle20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        java.awt.Paint paint6 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D13 = blockContainer8.arrange(graphics2D9, rectangleConstraint12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 0.025d, 0.05d, rectangleAnchor16);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D17);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D17, "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setRightArrow((java.awt.Shape) rectangle2D17);
        org.jfree.chart.text.TextBlock textBlock23 = new org.jfree.chart.text.TextBlock();
        java.util.List list24 = textBlock23.getLines();
        java.util.List list25 = textBlock23.getLines();
        java.util.List list26 = textBlock23.getLines();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor30 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.awt.Shape shape34 = textBlock23.calculateBounds(graphics2D27, 0.0f, 0.0f, textBlockAnchor30, (float) 'a', (float) 100, 1.0E-5d);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity(shape34, "hi!");
        dateAxis1.setLeftArrow(shape34);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(textBlockAnchor30);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItemCollection4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        boolean boolean6 = piePlot1.getIgnoreNullValues();
        java.awt.Paint paint7 = piePlot1.getLabelBackgroundPaint();
        piePlot1.setSimpleLabels(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("XY Plot", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = textBlock3.calculateDimensions(graphics2D4);
        boolean boolean6 = rectangleEdge2.equals((java.lang.Object) size2D5);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D15 = blockContainer10.arrange(graphics2D11, rectangleConstraint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, 0.025d, 0.05d, rectangleAnchor18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color21 = java.awt.Color.WHITE;
        float[] floatArray27 = new float[] { (-1.0f), (short) 0, 0.0f, (-1L), (-1) };
        float[] floatArray28 = color21.getRGBColorComponents(floatArray27);
        float[] floatArray29 = color20.getRGBComponents(floatArray28);
        boolean boolean30 = rectangleAnchor18.equals((java.lang.Object) color20);
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, (double) 1.0f, (double) (byte) -1, rectangleAnchor18);
        double double32 = size2D5.width;
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        categoryPlot0.setAnchorValue((double) 0, false);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace7);
        org.junit.Assert.assertNull(categoryAxis3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 0.5f);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray2, doubleArray3, doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie Plot", "TextBlockAnchor.TOP_RIGHT", doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getFixedDimension();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot4);
        java.lang.String str7 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 205.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.awt.Color color0 = java.awt.Color.RED;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-65536) + "'", int1 == (-65536));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        boolean boolean9 = projectInfo7.equals((java.lang.Object) true);
        projectInfo7.setInfo("Pie Plot");
        projectInfo7.setVersion("PlotOrientation.HORIZONTAL");
        java.lang.String str14 = projectInfo7.getInfo();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pie Plot" + "'", str14.equals("Pie Plot"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getDomainAxisEdge((int) (short) 10);
        xYPlot4.clearRangeMarkers();
        xYPlot4.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D18 = xYPlot14.getQuadrantOrigin();
        xYPlot4.zoomDomainAxes((double) (short) 0, plotRenderingInfo13, point2D18, false);
        xYPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo3, point2D18);
        java.awt.Stroke stroke22 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        java.awt.image.BufferedImage bufferedImage15 = jFreeChart8.createBufferedImage((int) (byte) 10, 15, (double) 2.0f, (double) 100.0f, chartRenderingInfo14);
        org.jfree.chart.ui.ProjectInfo projectInfo19 = new org.jfree.chart.ui.ProjectInfo("ThreadContext", " version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", "TextBlockAnchor.TOP_RIGHT", (java.awt.Image) bufferedImage15, "TextBlockAnchor.TOP_LEFT", "Polar Plot", "ThreadContext");
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertNotNull(bufferedImage15);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        double double4 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis6.setLowerMargin(0.0d);
        double double9 = dateAxis6.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis11.setLowerMargin(0.0d);
        java.awt.Shape shape14 = dateAxis11.getLeftArrow();
        org.jfree.data.Range range15 = dateAxis11.getRange();
        dateAxis6.setDefaultAutoRange(range15);
        dateAxis1.setDefaultAutoRange(range15);
        java.lang.String str18 = range15.toString();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str18.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        boolean boolean7 = dateAxis2.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer8);
        polarPlot9.zoom((double) 10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        polarPlot9.datasetChanged(datasetChangeEvent12);
        polarPlot9.addCornerTextItem("");
        org.jfree.chart.axis.ValueAxis valueAxis16 = polarPlot9.getAxis();
        org.jfree.data.Range range17 = valueAxis16.getRange();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(valueAxis16);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double double3 = range0.getUpperBound();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        piePlot1.setCircular(true);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        piePlot1.setLabelLinkStroke(stroke5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        boolean boolean4 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setLabel("ThreadContext");
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot7.getDomainAxisEdge((int) (short) 10);
        xYPlot7.clearRangeMarkers();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = new org.jfree.chart.text.TextBlock();
        java.util.List list14 = textBlock13.getLines();
        xYPlot7.drawRangeTickBands(graphics2D11, rectangle2D12, list14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot7.setFixedRangeAxisSpace(axisSpace16);
        boolean boolean18 = categoryAxis1.equals((java.lang.Object) axisSpace16);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }
}

