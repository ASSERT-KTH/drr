import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double6 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        double double7 = rectangleInsets4.getRight();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        categoryPlot14.setDomainCrosshairColumnKey((java.lang.Comparable) "hi!", true);
        categoryPlot14.clearDomainMarkers((int) ' ');
        boolean boolean37 = categoryPlot14.isNotify();
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        categoryPlot14.setOrientation(plotOrientation38);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(plotOrientation38);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', (double) 'a', 0.0d, (double) 1.0f);
        double double5 = rectangleInsets4.getBottom();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextPaint();
        java.awt.Paint paint7 = defaultDrawingSupplier5.getNextFillPaint();
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.REVERSE", "ItemLabelAnchor.OUTSIDE8", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "-3,-3,3,3", shape4, paint7);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent19 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent19);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot14.zoomDomainAxes((double) (byte) -1, (double) 10, plotRenderingInfo33, point2D34);
        categoryPlot14.setDomainCrosshairColumnKey((java.lang.Comparable) 89);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot14.getRangeAxis(100);
        java.awt.Paint paint26 = categoryPlot14.getRangeMinorGridlinePaint();
        float float27 = categoryPlot14.getBackgroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot14.getRangeAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot14.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot30 = categoryPlot14.getRootPlot();
        double double31 = categoryPlot14.getAnchorValue();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(plot30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int2 = defaultCategoryDataset0.getRowCount();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) "rect");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (rect) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        java.lang.Object obj29 = categoryPlot14.clone();
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot14.getDomainMarkers(0, layer31);
        categoryPlot14.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNull(collection32);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        categoryPlot14.setRangeMinorGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        try {
            categoryPlot14.setDomainAxisLocation(axisLocation17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        categoryPlot14.setRangeMinorGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot14.panRangeAxes((double) 'a', plotRenderingInfo18, point2D19);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMinorTickMarkOutsideLength((float) (byte) 10);
        java.lang.String str9 = categoryAxis1.getLabelToolTip();
        double double10 = categoryAxis1.getLowerMargin();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        try {
            double double17 = categoryAxis1.getCategoryMiddle(8, (int) '#', rectangle2D13, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        java.lang.String str38 = plotEntity36.getShapeCoords();
        java.lang.String str39 = plotEntity36.getShapeType();
        java.lang.String str40 = plotEntity36.getToolTipText();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-3,-3,3,3" + "'", str38.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "rect" + "'", str39.equals("rect"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str40.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer7.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        boolean boolean16 = categoryPlot15.isRangeGridlinesVisible();
        java.awt.Stroke stroke17 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot15.setRangePannable(false);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot15.getDomainMarkers(0, layer21);
        boolean boolean23 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot15);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot15.getFixedLegendItems();
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(legendItemCollection24);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener1 = null;
        abstractCategoryDataset0.removeChangeListener(datasetChangeListener1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.isRangeGridlinesVisible();
        java.awt.Stroke stroke19 = categoryPlot17.getRangeZeroBaselineStroke();
        boolean boolean20 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot17);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke29 = null;
        lineAndShapeRenderer27.setSeriesStroke(10, stroke29, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = lineAndShapeRenderer27.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint34 = lineAndShapeRenderer27.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis23, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer27);
        boolean boolean36 = categoryPlot35.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double42 = rectangleInsets41.getTop();
        categoryPlot35.setInsets(rectangleInsets41, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        categoryPlot35.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo47, point2D48);
        java.lang.Object obj50 = categoryPlot35.clone();
        boolean boolean51 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot35);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer0.getBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(barPainter2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setLowerMargin((double) 0);
        categoryAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke45 = null;
        lineAndShapeRenderer43.setSeriesStroke(10, stroke45, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = lineAndShapeRenderer43.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint50 = lineAndShapeRenderer43.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis39, valueAxis40, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer43);
        boolean boolean52 = categoryPlot51.isRangeGridlinesVisible();
        java.awt.Stroke stroke53 = categoryPlot51.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis55.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color58 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis55.setTickLabelPaint((java.awt.Paint) color58);
        java.awt.Paint paint60 = categoryAxis55.getTickMarkPaint();
        categoryAxis55.setTickLabelsVisible(false);
        java.awt.Color color66 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis55.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color66);
        categoryPlot51.setDomainCrosshairPaint((java.awt.Paint) color66);
        org.jfree.chart.entity.PlotEntity plotEntity71 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot51, "", "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(color66);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Paint paint21 = lineAndShapeRenderer2.getSeriesOutlinePaint(15);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, true);
        java.awt.Color color11 = java.awt.Color.ORANGE;
        float[] floatArray17 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray18 = color11.getRGBComponents(floatArray17);
        lineAndShapeRenderer0.setSeriesFillPaint(10, (java.awt.Paint) color11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke25 = null;
        lineAndShapeRenderer23.setSeriesStroke(10, stroke25, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = lineAndShapeRenderer23.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font31 = lineAndShapeRenderer23.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke35 = lineAndShapeRenderer23.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        lineAndShapeRenderer0.setSeriesOutlineStroke(0, stroke35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertNull(font31);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        categoryPlot14.setNotify(true);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) 1L, true);
        java.util.List list33 = categoryPlot14.getCategories();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(list33);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        categoryPlot14.setRangeMinorGridlinesVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState21 = null;
        boolean boolean22 = categoryPlot14.render(graphics2D17, rectangle2D18, 15, plotRenderingInfo20, categoryCrosshairState21);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color16, true);
        int int19 = color16.getRed();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 64 + "'", int19 == 64);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Shape shape7 = null;
        lineAndShapeRenderer0.setSeriesShape((int) (short) 100, shape7);
        java.awt.Paint paint12 = lineAndShapeRenderer0.getItemPaint((int) (short) 100, (int) (short) 0, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot14.getRangeAxis(100);
        java.awt.Paint paint26 = categoryPlot14.getRangeMinorGridlinePaint();
        float float27 = categoryPlot14.getBackgroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot14.getRangeAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot14.getDatasetRenderingOrder();
        boolean boolean30 = categoryPlot14.isDomainPannable();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) (-1L));
        selectableValue1.setSelected(true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((-1.0d));
        double double4 = rectangleInsets0.calculateLeftInset(0.0d);
        double double5 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        categoryPlot14.setDomainCrosshairColumnKey((java.lang.Comparable) "hi!", true);
        categoryPlot14.clearDomainMarkers((int) ' ');
        categoryPlot14.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.axis.ValueAxis valueAxis39 = categoryPlot14.getRangeAxis();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        int int31 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot14, jFreeChart32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot14.panDomainAxes(1.0d, plotRenderingInfo35, point2D36);
        java.lang.Comparable comparable38 = categoryPlot14.getDomainCrosshairRowKey();
        int int39 = categoryPlot14.getWeight();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(comparable38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        int int16 = categoryPlot14.getDatasetCount();
        categoryPlot14.setRangeCrosshairVisible(false);
        java.awt.geom.GeneralPath generalPath19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.RenderingSource renderingSource21 = null;
        categoryPlot14.select(generalPath19, rectangle2D20, renderingSource21);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        java.awt.Shape shape6 = renderAttributes1.getSeriesShape(2);
        java.awt.Shape shape9 = renderAttributes1.getItemShape((int) (byte) 10, 0);
        java.awt.Paint paint10 = renderAttributes1.getDefaultFillPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) '#');
        java.lang.Object obj3 = null;
        boolean boolean4 = itemLabelPosition2.equals(obj3);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = itemLabelPosition2.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer66 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke68 = null;
        lineAndShapeRenderer66.setSeriesStroke(10, stroke68, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator72 = lineAndShapeRenderer66.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font74 = lineAndShapeRenderer66.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke78 = lineAndShapeRenderer66.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        categoryPlot14.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer66);
        lineAndShapeRenderer66.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator85 = lineAndShapeRenderer66.getToolTipGenerator((-123), (int) '#', false);
        int int86 = lineAndShapeRenderer66.getColumnCount();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNull(categoryToolTipGenerator72);
        org.junit.Assert.assertNull(font74);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNull(categoryToolTipGenerator85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Shape shape2 = legendItem1.getLine();
        legendItem1.setShapeVisible(false);
        java.lang.Comparable comparable5 = legendItem1.getSeriesKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(comparable5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        java.awt.Paint paint13 = lineAndShapeRenderer2.getSeriesItemLabelPaint((int) (short) 10);
        java.awt.Font font15 = lineAndShapeRenderer2.lookupLegendTextFont((int) ' ');
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        lineAndShapeRenderer2.setSeriesPaint(0, (java.awt.Paint) color17);
        java.awt.Paint paint20 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.data.general.Dataset dataset10 = legendItem7.getDataset();
        legendItem7.setURLText("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis14.setMaximumCategoryLabelWidthRatio((float) 100);
        double double17 = categoryAxis14.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateLeftInset((-1.0d));
        categoryAxis14.setLabelInsets(rectangleInsets18, false);
        categoryAxis14.addCategoryLabelToolTip((java.lang.Comparable) ' ', "");
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int27 = color26.getAlpha();
        categoryAxis14.setLabelPaint((java.awt.Paint) color26);
        legendItem7.setOutlinePaint((java.awt.Paint) color26);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 255 + "'", int27 == 255);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Color color12 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12);
        int int14 = categoryAxis1.getMaximumCategoryLabelLines();
        boolean boolean15 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis1.setTickMarkOutsideLength(0.0f);
        categoryAxis1.clearCategoryLabelToolTips();
        double double7 = categoryAxis1.getCategoryMargin();
        double double8 = categoryAxis1.getFixedDimension();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        try {
            java.util.List list13 = categoryAxis1.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) '#');
        boolean boolean4 = lineAndShapeRenderer0.isSeriesVisibleInLegend(8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        lineAndShapeRenderer0.setSeriesItemLabelGenerator(255, categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        lineAndShapeRenderer2.setSeriesOutlinePaint(192, (java.awt.Paint) color17);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=10.0]", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D22, categoryPlot23, valueAxis24, marker25, rectangle2D26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = lineAndShapeRenderer2.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Boolean boolean33 = lineAndShapeRenderer2.getSeriesCreateEntities((-123));
        java.awt.Shape shape34 = lineAndShapeRenderer2.getBaseLegendShape();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertNull(shape34);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseFillPaint();
        java.awt.Font font3 = lineAndShapeRenderer0.lookupLegendTextFont((int) ' ');
        java.awt.Shape shape4 = lineAndShapeRenderer0.getBaseLegendShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        double double6 = barRenderer0.getShadowXOffset();
        double double7 = barRenderer0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot14.getRangeAxis(100);
        java.awt.Paint paint26 = categoryPlot14.getRangeMinorGridlinePaint();
        float float27 = categoryPlot14.getBackgroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot14.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis30.setMaximumCategoryLabelWidthRatio((float) 100);
        double double33 = categoryAxis30.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double36 = rectangleInsets34.calculateLeftInset((-1.0d));
        categoryAxis30.setLabelInsets(rectangleInsets34, false);
        double double40 = rectangleInsets34.extendHeight((double) 2.0f);
        double double42 = rectangleInsets34.trimWidth((double) '#');
        categoryPlot14.setInsets(rectangleInsets34, false);
        java.awt.Stroke stroke45 = categoryPlot14.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.0d + "'", double40 == 2.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 35.0d + "'", double42 == 35.0d);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range8 = barRenderer0.findRangeBounds(categoryDataset6, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font14 = lineAndShapeRenderer9.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean15 = lineAndShapeRenderer9.getAutoPopulateSeriesFillPaint();
        java.awt.Font font16 = lineAndShapeRenderer9.getBaseItemLabelFont();
        barRenderer0.setBaseLegendTextFont(font16);
        double double18 = barRenderer0.getMaximumBarWidth();
        boolean boolean19 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        keyedObjects0.sortByKeys(sortOrder1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) color3);
        int int5 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        boolean boolean7 = barRenderer0.isSeriesItemLabelsVisible((int) (short) 100);
        barRenderer0.setItemMargin((double) (byte) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean15 = lineAndShapeRenderer12.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        boolean boolean17 = lineAndShapeRenderer12.removeAnnotation(categoryAnnotation16);
        boolean boolean18 = lineAndShapeRenderer12.getUseOutlinePaint();
        lineAndShapeRenderer12.setBaseSeriesVisible(false, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer22.getBaseCreateEntities();
        java.awt.Paint paint25 = lineAndShapeRenderer22.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator26 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer22.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator26);
        lineAndShapeRenderer12.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator26);
        barRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator26);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke20, false);
        boolean boolean23 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        barRenderer0.setBaseCreateEntities(true, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator10, false);
        java.awt.Paint paint14 = barRenderer0.lookupSeriesOutlinePaint(89);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        try {
            lineAndShapeRenderer2.setItemMargin((double) (-123));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean6 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean16 = lineAndShapeRenderer9.getBaseItemLabelsVisible();
        lineAndShapeRenderer9.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer9.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean25 = lineAndShapeRenderer9.getItemLineVisible(8, (int) (short) 10);
        boolean boolean26 = lineAndShapeRenderer9.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke31 = null;
        lineAndShapeRenderer29.setSeriesStroke(10, stroke31, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = lineAndShapeRenderer29.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean36 = lineAndShapeRenderer29.getBaseItemLabelsVisible();
        lineAndShapeRenderer29.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = lineAndShapeRenderer29.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        lineAndShapeRenderer9.setBaseNegativeItemLabelPosition(itemLabelPosition42, true);
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition42, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer48.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color52 = java.awt.Color.ORANGE;
        lineAndShapeRenderer48.setBaseFillPaint((java.awt.Paint) color52);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean57 = lineAndShapeRenderer54.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation58 = null;
        boolean boolean59 = lineAndShapeRenderer54.removeAnnotation(categoryAnnotation58);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition61 = lineAndShapeRenderer54.getSeriesNegativeItemLabelPosition((int) ' ');
        lineAndShapeRenderer48.setBasePositiveItemLabelPosition(itemLabelPosition61);
        org.jfree.chart.text.TextAnchor textAnchor63 = itemLabelPosition61.getRotationAnchor();
        try {
            lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((-123), itemLabelPosition61, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition61);
        org.junit.Assert.assertNotNull(textAnchor63);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot14.addDomainMarker((int) (byte) 100, categoryMarker20, layer21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color4 = color3.brighter();
        legendItem1.setLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = legendItem1.isLineVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue(number0, false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer7.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        boolean boolean16 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double22 = rectangleInsets21.getTop();
        categoryPlot15.setInsets(rectangleInsets21, true);
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot15.select(generalPath25, rectangle2D26, renderingSource27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        categoryPlot15.setRangeAxes(valueAxisArray30);
        keyedObjects2D0.setObject((java.lang.Object) valueAxisArray30, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) (byte) 10);
        keyedObjects2D0.clear();
        java.lang.Object obj36 = null;
        boolean boolean37 = keyedObjects2D0.equals(obj36);
        try {
            java.lang.Comparable comparable39 = keyedObjects2D0.getColumnKey((-16777024));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -16777024");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem1.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType4 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str5 = gradientPaintTransformType4.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer6 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType4);
        legendItem1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer6);
        legendItem1.setSeriesKey((java.lang.Comparable) 4.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str5.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMinorTickMarkOutsideLength((float) (byte) 10);
        double double9 = categoryAxis1.getUpperMargin();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis12.setTickMarkOutsideLength(0.0f);
        boolean boolean17 = textAnchor10.equals((java.lang.Object) categoryAxis12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = categoryAxis12.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        int int38 = categoryPlot17.getRendererCount();
        java.lang.Comparable comparable39 = categoryPlot17.getDomainCrosshairRowKey();
        categoryPlot17.setAnchorValue((double) 10L);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(comparable39);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot14.getRangeAxis(100);
        java.awt.Paint paint26 = categoryPlot14.getRangeMinorGridlinePaint();
        float float27 = categoryPlot14.getBackgroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot14.getRangeAxis();
        categoryPlot14.clearDomainAxes();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNull(valueAxis28);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color4 = color3.darker();
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", (java.awt.Paint) color4);
        legendItem5.setToolTipText("GradientPaintTransformType.CENTER_VERTICAL");
        legendItemCollection0.add(legendItem5);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean12 = lineAndShapeRenderer0.getItemShapeFilled((int) (byte) 1, 2);
        boolean boolean13 = lineAndShapeRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Paint paint4 = lineAndShapeRenderer2.lookupSeriesOutlinePaint((-1));
        boolean boolean5 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = lineAndShapeRenderer2.getSelectedItemAttributes();
        java.lang.Boolean boolean7 = renderAttributes6.getDefaultCreateEntity();
        java.awt.Shape shape9 = renderAttributes6.getSeriesShape((int) (byte) 100);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(renderAttributes6);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNull(shape9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot14.zoomRangeAxes((double) 100, plotRenderingInfo17, point2D18);
        categoryPlot14.clearAnnotations();
        int int21 = categoryPlot14.getCrosshairDatasetIndex();
        int int22 = categoryPlot14.getDatasetCount();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState27 = null;
        try {
            boolean boolean28 = categoryPlot14.render(graphics2D23, rectangle2D24, (-16777024), plotRenderingInfo26, categoryCrosshairState27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        try {
            keyedObjects0.removeValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot14.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot30.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = categoryPlot30.removeDomainMarker((int) (short) 1, marker33, layer34, true);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot30.setRangeAxisLocation((int) 'a', axisLocation38);
        categoryPlot14.setRangeAxisLocation(axisLocation38, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean46 = lineAndShapeRenderer43.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation47 = null;
        boolean boolean48 = lineAndShapeRenderer43.removeAnnotation(categoryAnnotation47);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator50 = lineAndShapeRenderer43.getSeriesURLGenerator((int) 'a');
        categoryPlot14.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer43);
        org.jfree.chart.plot.Marker marker53 = null;
        org.jfree.chart.util.Layer layer54 = null;
        try {
            categoryPlot14.addRangeMarker(89, marker53, layer54, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryURLGenerator50);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        int int31 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot14, jFreeChart32);
        int int34 = categoryPlot14.getCrosshairDatasetIndex();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot14.getRangeAxisEdge((int) (byte) 100);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        defaultCategoryDataset56.addValue((double) (byte) 100, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) 1.0f);
        try {
            defaultCategoryDataset56.setSelected(8, (-2), false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        categoryPlot14.setNotify(true);
        java.lang.Class<?> wildcardClass30 = categoryPlot14.getClass();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis32.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis32.setTickLabelPaint((java.awt.Paint) color35);
        java.awt.Font font37 = categoryAxis32.getTickLabelFont();
        java.awt.Paint paint39 = categoryAxis32.getTickLabelPaint((java.lang.Comparable) 1.0f);
        java.util.List list40 = categoryPlot14.getCategoriesForAxis(categoryAxis32);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(list40);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        int int19 = categoryPlot14.getBackgroundImageAlignment();
        categoryPlot14.setRangePannable(false);
        categoryPlot14.clearRangeMarkers();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        int int5 = color3.getBlue();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer7.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        boolean boolean16 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double22 = rectangleInsets21.getTop();
        categoryPlot15.setInsets(rectangleInsets21, true);
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot15.select(generalPath25, rectangle2D26, renderingSource27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        categoryPlot15.setRangeAxes(valueAxisArray30);
        keyedObjects2D0.setObject((java.lang.Object) valueAxisArray30, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) (byte) 10);
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 5);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (5) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray30);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) itemLabelAnchor1);
        int int3 = keyedObjects2D0.getRowCount();
        int int4 = keyedObjects2D0.getRowCount();
        keyedObjects2D0.clear();
        int int6 = keyedObjects2D0.getRowCount();
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke((int) (short) 10);
        java.awt.Stroke stroke4 = strokeList0.getStroke(2);
        java.lang.Object obj5 = strokeList0.clone();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Shape shape10 = lineAndShapeRenderer2.getSeriesShape(0);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Shape shape13 = legendItem12.getLine();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color15 = color14.brighter();
        legendItem12.setLabelPaint((java.awt.Paint) color15);
        lineAndShapeRenderer2.setBaseFillPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke21 = null;
        lineAndShapeRenderer19.setSeriesStroke(10, stroke21, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = lineAndShapeRenderer19.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint26 = lineAndShapeRenderer19.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        boolean boolean28 = categoryPlot27.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double34 = rectangleInsets33.getTop();
        categoryPlot27.setInsets(rectangleInsets33, true);
        java.awt.geom.GeneralPath generalPath37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.RenderingSource renderingSource39 = null;
        categoryPlot27.select(generalPath37, rectangle2D38, renderingSource39);
        categoryPlot27.setNotify(true);
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        categoryPlot27.setFixedDomainAxisSpace(axisSpace43, true);
        java.awt.Paint paint46 = categoryPlot27.getDomainGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot27.getDomainAxisEdge(2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            org.jfree.chart.axis.AxisState axisState50 = categoryAxis1.draw(graphics2D9, (double) 3, rectangle2D11, rectangle2D12, rectangleEdge48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Paint paint4 = lineAndShapeRenderer2.lookupSeriesOutlinePaint((-1));
        boolean boolean5 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = lineAndShapeRenderer2.getSelectedItemAttributes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis9.setTickLabelPaint((java.awt.Paint) color12);
        java.awt.Paint paint14 = categoryAxis9.getLabelPaint();
        categoryAxis9.setMinorTickMarkOutsideLength((float) (byte) 10);
        double double17 = categoryAxis9.getUpperMargin();
        categoryAxis9.setCategoryMargin((double) (-1));
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer20.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font25 = lineAndShapeRenderer20.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean26 = lineAndShapeRenderer20.getAutoPopulateSeriesFillPaint();
        java.awt.Font font27 = lineAndShapeRenderer20.getBaseItemLabelFont();
        java.awt.Paint paint31 = lineAndShapeRenderer20.getItemFillPaint((-123), (int) 'a', false);
        lineAndShapeRenderer20.clearSeriesPaints(false);
        boolean boolean35 = lineAndShapeRenderer20.isSeriesItemLabelsVisible(0);
        java.awt.Stroke stroke37 = lineAndShapeRenderer20.lookupSeriesOutlineStroke((int) ' ');
        categoryAxis9.setTickMarkStroke(stroke37);
        lineAndShapeRenderer2.setSeriesOutlineStroke((int) (short) 10, stroke37, true);
        try {
            lineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (short) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(renderAttributes6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double6 = rectangleInsets4.calculateBottomInset((double) (byte) 0);
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets4.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets4.createInsetRectangle(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 0.0f, (double) 0, (double) (-1.0f), (double) (byte) 1);
        java.lang.String str6 = unitType0.toString();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        boolean boolean8 = unitType0.equals((java.lang.Object) stroke7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke17 = null;
        lineAndShapeRenderer15.setSeriesStroke(10, stroke17, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = lineAndShapeRenderer15.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint22 = lineAndShapeRenderer15.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot23.getDomainAxisLocation();
        boolean boolean25 = unitType0.equals((java.lang.Object) categoryPlot23);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isRangeMinorGridlinesVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot14.addDomainMarker(categoryMarker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.util.BooleanList booleanList1 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = java.awt.Color.ORANGE;
        float[] floatArray10 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray11 = color4.getRGBComponents(floatArray10);
        float[] floatArray12 = color3.getRGBColorComponents(floatArray10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER", (java.awt.Paint) color3);
        int int14 = color3.getTransparency();
        boolean boolean15 = booleanList1.equals((java.lang.Object) color3);
        org.jfree.data.KeyedObject keyedObject16 = new org.jfree.data.KeyedObject((java.lang.Comparable) 89, (java.lang.Object) color3);
        java.lang.Object obj17 = keyedObject16.getObject();
        java.lang.Object obj18 = keyedObject16.getObject();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color16, true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        lineAndShapeRenderer2.setBasePaint((java.awt.Paint) color19);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.String str3 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str3.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color6 = color5.darker();
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", (java.awt.Paint) color6);
        legendItem7.setSeriesKey((java.lang.Comparable) 2.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer10.getIncludeBaseInRange();
        java.awt.Shape shape13 = barRenderer10.lookupSeriesShape(0);
        legendItem7.setLine(shape13);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer15.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        lineAndShapeRenderer15.setBaseFillPaint((java.awt.Paint) color19);
        lineAndShapeRenderer15.setItemLabelAnchorOffset((double) (byte) 1);
        boolean boolean23 = lineAndShapeRenderer15.getDrawOutlines();
        java.awt.Stroke stroke27 = lineAndShapeRenderer15.getItemOutlineStroke((-1), (int) ' ', true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke32 = null;
        lineAndShapeRenderer30.setSeriesStroke(10, stroke32, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = lineAndShapeRenderer30.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean37 = lineAndShapeRenderer30.getBaseItemLabelsVisible();
        lineAndShapeRenderer30.setDefaultEntityRadius(8);
        java.awt.Paint paint41 = lineAndShapeRenderer30.getSeriesItemLabelPaint((int) (short) 10);
        java.awt.Font font43 = lineAndShapeRenderer30.lookupLegendTextFont((int) ' ');
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        lineAndShapeRenderer30.setSeriesPaint(0, (java.awt.Paint) color45);
        java.awt.color.ColorSpace colorSpace47 = color45.getColorSpace();
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("rect", "-3,-3,3,3", "GradientPaintTransformType.CENTER_VERTICAL", "", shape13, stroke27, (java.awt.Paint) color45);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categoryToolTipGenerator36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNull(font43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(colorSpace47);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke26 = null;
        lineAndShapeRenderer24.setSeriesStroke(10, stroke26, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = lineAndShapeRenderer24.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint31 = lineAndShapeRenderer24.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        boolean boolean33 = categoryPlot32.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double39 = rectangleInsets38.getTop();
        categoryPlot32.setInsets(rectangleInsets38, true);
        java.awt.geom.GeneralPath generalPath42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.RenderingSource renderingSource44 = null;
        categoryPlot32.select(generalPath42, rectangle2D43, renderingSource44);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray47 = new org.jfree.chart.axis.ValueAxis[] { valueAxis46 };
        categoryPlot32.setRangeAxes(valueAxisArray47);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor49 = categoryPlot32.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis51.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis51.setTickLabelPaint((java.awt.Paint) color54);
        java.awt.Paint paint56 = categoryAxis51.getTickMarkPaint();
        categoryPlot32.setDomainGridlinePaint(paint56);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset58 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset58.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int63 = categoryPlot32.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset58);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = categoryPlot32.getRenderer(15);
        org.jfree.chart.util.SortOrder sortOrder66 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean68 = sortOrder66.equals((java.lang.Object) 1.0d);
        categoryPlot32.setColumnRenderingOrder(sortOrder66);
        categoryPlot14.setColumnRenderingOrder(sortOrder66);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.0d + "'", double39 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray47);
        org.junit.Assert.assertNotNull(categoryAnchor49);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer65);
        org.junit.Assert.assertNotNull(sortOrder66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean12 = lineAndShapeRenderer0.getItemShapeFilled((int) (byte) 1, 2);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = lineAndShapeRenderer0.getToolTipGenerator(0, (int) (byte) -1, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape2, "TextAnchor.HALF_ASCENT_CENTER", "TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj43 = defaultCategoryDataset42.clone();
        int int44 = defaultCategoryDataset42.getRowCount();
        defaultCategoryDataset42.fireSelectionEvent();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity48 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]", "-3,-3,3,3", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0f);
        java.awt.Font font49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boolean boolean50 = categoryItemEntity48.equals((java.lang.Object) font49);
        java.lang.Comparable comparable51 = categoryItemEntity48.getRowKey();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + comparable51 + "' != '" + 100.0f + "'", comparable51.equals(100.0f));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.clear();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer5.setSeriesStroke(10, stroke7, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer5.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean12 = lineAndShapeRenderer5.getBaseItemLabelsVisible();
        lineAndShapeRenderer5.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer5.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean21 = lineAndShapeRenderer5.getItemLineVisible(8, (int) (short) 10);
        boolean boolean22 = lineAndShapeRenderer5.getAutoPopulateSeriesShape();
        keyedObjects0.addObject((java.lang.Comparable) 0, (java.lang.Object) lineAndShapeRenderer5);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Color color12 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12);
        categoryAxis1.setFixedDimension((double) (short) 100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean19 = lineAndShapeRenderer16.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        boolean boolean21 = lineAndShapeRenderer16.removeAnnotation(categoryAnnotation20);
        boolean boolean22 = lineAndShapeRenderer16.getUseOutlinePaint();
        lineAndShapeRenderer16.setBaseSeriesVisible(false, true);
        boolean boolean26 = lineAndShapeRenderer16.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean29 = barRenderer28.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = null;
        barRenderer28.setGradientPaintTransformer(gradientPaintTransformer30);
        barRenderer28.setMinimumBarLength((double) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.data.Range range36 = barRenderer28.findRangeBounds(categoryDataset34, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer37.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font42 = lineAndShapeRenderer37.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean43 = lineAndShapeRenderer37.getAutoPopulateSeriesFillPaint();
        java.awt.Font font44 = lineAndShapeRenderer37.getBaseItemLabelFont();
        barRenderer28.setBaseLegendTextFont(font44);
        lineAndShapeRenderer16.setSeriesItemLabelFont((int) (short) 10, font44);
        categoryAxis1.setLabelFont(font44);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNull(font42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(font44);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8388608) + "'", int1 == (-8388608));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer2.getBaseCreateEntities();
        java.awt.Paint paint5 = lineAndShapeRenderer2.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        boolean boolean8 = textAnchor0.equals((java.lang.Object) lineAndShapeRenderer2);
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem10.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer13.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font18 = lineAndShapeRenderer13.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean19 = lineAndShapeRenderer13.getAutoPopulateSeriesFillPaint();
        java.awt.Font font20 = lineAndShapeRenderer13.getBaseItemLabelFont();
        legendItem10.setLabelFont(font20);
        lineAndShapeRenderer2.setBaseItemLabelFont(font20, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = lineAndShapeRenderer2.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_CENTER" + "'", str1.equals("TextAnchor.HALF_ASCENT_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        java.lang.Object obj29 = categoryPlot14.clone();
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot14.getDomainMarkers(0, layer31);
        boolean boolean33 = categoryPlot14.isDomainCrosshairVisible();
        categoryPlot14.setRangePannable(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        java.awt.Shape shape6 = renderAttributes1.getSeriesShape(2);
        java.awt.Shape shape9 = renderAttributes1.getItemShape((int) (byte) 10, 0);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes1.setDefaultLabelFont(font10);
        java.awt.Paint paint12 = renderAttributes1.getDefaultPaint();
        org.jfree.chart.renderer.RenderAttributes renderAttributes14 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator15 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color16 = defaultShadowGenerator15.getShadowColor();
        renderAttributes14.setDefaultPaint((java.awt.Paint) color16);
        java.awt.Shape shape19 = renderAttributes14.getSeriesShape(2);
        java.awt.Shape shape22 = renderAttributes14.getItemShape((int) (byte) 10, 0);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes14.setDefaultLabelFont(font23);
        renderAttributes1.setDefaultLabelFont(font23);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean27 = lineAndShapeRenderer26.getBaseCreateEntities();
        java.awt.Paint paint29 = lineAndShapeRenderer26.lookupSeriesFillPaint((int) (short) -1);
        renderAttributes1.setDefaultFillPaint(paint29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color33 = color32.darker();
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", (java.awt.Paint) color33);
        renderAttributes1.setDefaultPaint((java.awt.Paint) color33);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesItemLabelsVisible((int) '4');
        boolean boolean8 = lineAndShapeRenderer0.getBaseCreateEntities();
        java.awt.Shape shape10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        try {
            lineAndShapeRenderer0.setLegendShape((int) (short) -1, shape10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        barRenderer0.setBaseCreateEntities(true, true);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        barRenderer0.setShadowYOffset(1.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        categoryPlot30.setNotify(true);
        categoryPlot30.setDomainCrosshairRowKey((java.lang.Comparable) 1L, true);
        java.awt.Stroke stroke49 = categoryPlot30.getRangeCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke49);
        java.awt.Stroke stroke51 = categoryPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double57 = rectangleInsets56.getTop();
        double double58 = rectangleInsets56.getLeft();
        categoryPlot14.setInsets(rectangleInsets56);
        java.awt.Paint paint60 = categoryPlot14.getDomainGridlinePaint();
        java.awt.Color color61 = java.awt.Color.white;
        categoryPlot14.setRangeZeroBaselinePaint((java.awt.Paint) color61);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 100.0d + "'", double57 == 100.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 32.0d + "'", double58 == 32.0d);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(color61);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        categoryPlot14.setNotify(true);
        java.lang.Class<?> wildcardClass30 = categoryPlot14.getClass();
        int int31 = categoryPlot14.getDomainAxisCount();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        java.awt.Paint paint8 = barRenderer0.getItemOutlinePaint((int) (short) -1, (int) (short) 100, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.LegendItem legendItem12 = barRenderer0.getLegendItem(3, (int) (short) 100);
        org.jfree.chart.renderer.category.BarPainter barPainter13 = barRenderer0.getBarPainter();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint15 = defaultDrawingSupplier14.getNextPaint();
        java.awt.Shape shape16 = defaultDrawingSupplier14.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke25 = null;
        lineAndShapeRenderer23.setSeriesStroke(10, stroke25, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = lineAndShapeRenderer23.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint30 = lineAndShapeRenderer23.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer23);
        boolean boolean32 = categoryPlot31.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double38 = rectangleInsets37.getTop();
        categoryPlot31.setInsets(rectangleInsets37, true);
        java.awt.geom.GeneralPath generalPath41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.RenderingSource renderingSource43 = null;
        categoryPlot31.select(generalPath41, rectangle2D42, renderingSource43);
        categoryPlot31.setNotify(true);
        boolean boolean47 = categoryPlot31.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity50 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) categoryPlot31, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str51 = plotEntity50.toString();
        java.lang.String str52 = plotEntity50.getShapeCoords();
        java.lang.String str53 = plotEntity50.getShapeType();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier54 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint55 = defaultDrawingSupplier54.getNextPaint();
        java.awt.Stroke stroke56 = defaultDrawingSupplier54.getNextStroke();
        boolean boolean57 = plotEntity50.equals((java.lang.Object) defaultDrawingSupplier54);
        boolean boolean58 = barRenderer0.equals((java.lang.Object) plotEntity50);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertNull(legendItem12);
        org.junit.Assert.assertNotNull(barPainter13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str51.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "-3,-3,3,3" + "'", str52.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "rect" + "'", str53.equals("rect"));
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape5 = null;
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint7 = null;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape5, stroke6, paint7);
        legendItem8.setSeriesIndex((int) '4');
        org.jfree.data.general.Dataset dataset11 = legendItem8.getDataset();
        legendItemCollection0.add(legendItem8);
        java.util.Iterator iterator13 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(dataset11);
        org.junit.Assert.assertNotNull(iterator13);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        java.awt.Paint paint7 = barRenderer0.lookupSeriesOutlinePaint(15);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke16 = null;
        lineAndShapeRenderer14.setSeriesStroke(10, stroke16, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer14.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint21 = lineAndShapeRenderer14.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        boolean boolean23 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double29 = rectangleInsets28.getTop();
        categoryPlot22.setInsets(rectangleInsets28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot22.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo34, point2D35);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent37 = null;
        categoryPlot22.datasetChanged(datasetChangeEvent37);
        int int39 = categoryPlot22.getDomainAxisCount();
        boolean boolean40 = categoryPlot22.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis42.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color45 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis42.setTickLabelPaint((java.awt.Paint) color45);
        java.awt.Font font47 = categoryAxis42.getTickLabelFont();
        java.awt.Paint paint49 = categoryAxis42.getTickLabelPaint((java.lang.Comparable) 1.0f);
        boolean boolean50 = categoryPlot22.equals((java.lang.Object) categoryAxis42);
        boolean boolean51 = barRenderer0.equals((java.lang.Object) categoryPlot22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer66 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke68 = null;
        lineAndShapeRenderer66.setSeriesStroke(10, stroke68, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator72 = lineAndShapeRenderer66.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font74 = lineAndShapeRenderer66.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke78 = lineAndShapeRenderer66.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        categoryPlot14.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer66);
        lineAndShapeRenderer66.setDefaultEntityRadius(1);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNull(categoryToolTipGenerator72);
        org.junit.Assert.assertNull(font74);
        org.junit.Assert.assertNotNull(stroke78);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean10 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = lineAndShapeRenderer0.getBaseURLGenerator();
        java.lang.Boolean boolean13 = lineAndShapeRenderer0.getSeriesLinesVisible(3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setTickLabelsVisible(true);
        java.awt.Stroke stroke8 = categoryAxis1.getTickMarkStroke();
        float float9 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        java.lang.Object obj29 = categoryPlot14.clone();
        java.awt.Paint paint30 = categoryPlot14.getDomainGridlinePaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean8 = lineAndShapeRenderer5.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = lineAndShapeRenderer5.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = lineAndShapeRenderer5.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer5.setDefaultEntityRadius((int) (byte) -1);
        java.awt.Shape shape15 = null;
        lineAndShapeRenderer5.setBaseLegendShape(shape15);
        java.awt.Stroke stroke20 = lineAndShapeRenderer5.getItemOutlineStroke((-2), 0, false);
        lineAndShapeRenderer0.setSeriesStroke((int) (short) 10, stroke20, true);
        boolean boolean23 = lineAndShapeRenderer0.getDrawOutlines();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        java.lang.String str38 = plotEntity36.getShapeCoords();
        java.lang.Object obj39 = null;
        boolean boolean40 = plotEntity36.equals(obj39);
        java.lang.String str41 = plotEntity36.getToolTipText();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-3,-3,3,3" + "'", str38.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str41.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        java.lang.String str38 = plotEntity36.getShapeCoords();
        java.lang.String str39 = plotEntity36.getShapeType();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier40 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint41 = defaultDrawingSupplier40.getNextPaint();
        java.awt.Stroke stroke42 = defaultDrawingSupplier40.getNextStroke();
        boolean boolean43 = plotEntity36.equals((java.lang.Object) defaultDrawingSupplier40);
        java.awt.Paint paint44 = defaultDrawingSupplier40.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-3,-3,3,3" + "'", str38.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "rect" + "'", str39.equals("rect"));
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100, 0.0d, (double) 0, (double) 1L);
        double double7 = rectangleInsets6.getLeft();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem11.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType14 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str15 = gradientPaintTransformType14.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType14);
        legendItem11.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        legendItem7.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        boolean boolean19 = legendItem7.isShapeOutlineVisible();
        java.awt.Shape shape20 = legendItem7.getShape();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str15.equals("GradientPaintTransformType.CENTER_VERTICAL"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Shape shape3 = barRenderer0.lookupSeriesShape(0);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        barRenderer0.setBasePaint((java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem1.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType4 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str5 = gradientPaintTransformType4.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer6 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType4);
        legendItem1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer6);
        boolean boolean8 = legendItem1.isLineVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke13 = null;
        lineAndShapeRenderer11.setSeriesStroke(10, stroke13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = lineAndShapeRenderer11.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean18 = lineAndShapeRenderer11.getBaseItemLabelsVisible();
        lineAndShapeRenderer11.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer11.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean27 = lineAndShapeRenderer11.getItemLineVisible(8, (int) (short) 10);
        boolean boolean28 = lineAndShapeRenderer11.getAutoPopulateSeriesShape();
        lineAndShapeRenderer11.setUseSeriesOffset(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint33 = lineAndShapeRenderer32.getBaseFillPaint();
        lineAndShapeRenderer11.setLegendTextPaint(0, paint33);
        legendItem1.setLinePaint(paint33);
        org.junit.Assert.assertNotNull(gradientPaintTransformType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str5.equals("GradientPaintTransformType.CENTER_VERTICAL"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) '#', "UnitType.ABSOLUTE");
        float float18 = categoryAxis2.getTickMarkOutsideLength();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer66 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke68 = null;
        lineAndShapeRenderer66.setSeriesStroke(10, stroke68, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator72 = lineAndShapeRenderer66.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font74 = lineAndShapeRenderer66.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke78 = lineAndShapeRenderer66.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        categoryPlot14.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer66);
        java.awt.Paint paint80 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation82 = categoryPlot14.getRangeAxisLocation((int) (byte) 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNull(categoryToolTipGenerator72);
        org.junit.Assert.assertNull(font74);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(axisLocation82);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font10 = lineAndShapeRenderer2.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke14 = lineAndShapeRenderer2.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        boolean boolean15 = lineAndShapeRenderer2.getUseFillPaint();
        java.awt.Paint paint17 = lineAndShapeRenderer2.getSeriesItemLabelPaint(2);
        lineAndShapeRenderer2.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset40.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int45 = categoryPlot14.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot14.getRenderer(15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener48 = null;
        categoryPlot14.addChangeListener(plotChangeListener48);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer47);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer3.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = null;
        barRenderer3.setGradientPaintTransformer(gradientPaintTransformer5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean10 = lineAndShapeRenderer7.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = lineAndShapeRenderer7.removeAnnotation(categoryAnnotation11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer7.getSeriesNegativeItemLabelPosition((int) ' ');
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition14.getTextAnchor();
        barRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition14);
        boolean boolean17 = defaultDrawingSupplier0.equals((java.lang.Object) itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) itemLabelAnchor1);
        int int3 = keyedObjects2D0.getRowCount();
        int int4 = keyedObjects2D0.getRowCount();
        keyedObjects2D0.clear();
        java.util.List list6 = keyedObjects2D0.getColumnKeys();
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (1.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Shape shape3 = barRenderer0.lookupSeriesShape(0);
        double double4 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer6.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font11 = lineAndShapeRenderer6.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean12 = lineAndShapeRenderer6.getAutoPopulateSeriesFillPaint();
        java.awt.Font font13 = lineAndShapeRenderer6.getBaseItemLabelFont();
        barRenderer0.setLegendTextFont(3, font13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset40.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int45 = categoryPlot14.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState46 = defaultCategoryDataset40.getSelectionState();
        try {
            defaultCategoryDataset40.removeColumn((java.lang.Comparable) (-8458323));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (-8458323) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState46);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        java.awt.Shape shape6 = renderAttributes1.getSeriesShape(2);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean11 = lineAndShapeRenderer8.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        boolean boolean13 = lineAndShapeRenderer8.removeAnnotation(categoryAnnotation12);
        java.awt.Shape shape15 = null;
        lineAndShapeRenderer8.setSeriesShape((int) (short) 100, shape15);
        java.awt.Paint paint20 = lineAndShapeRenderer8.getItemPaint((int) (short) 100, (int) (short) 0, true);
        renderAttributes1.setSeriesPaint((int) (short) 10, paint20);
        java.awt.Paint paint23 = renderAttributes1.getSeriesOutlinePaint((int) '#');
        java.awt.Shape shape25 = renderAttributes1.getSeriesShape((-123));
        java.awt.Shape shape26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        renderAttributes1.setDefaultShape(shape26);
        java.awt.Shape shape29 = renderAttributes1.getSeriesShape((int) (short) -1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNull(shape25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(shape29);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint2 = renderAttributes0.getSeriesFillPaint(64);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke12 = null;
        lineAndShapeRenderer10.setSeriesStroke(10, stroke12, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = lineAndShapeRenderer10.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint17 = lineAndShapeRenderer10.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10);
        int int19 = lineAndShapeRenderer10.getPassCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis22.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis22.setTickLabelPaint((java.awt.Paint) color25);
        java.awt.Paint paint27 = categoryAxis22.getLabelPaint();
        categoryAxis22.setTickMarkInsideLength((float) (-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis31.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis31.setTickLabelPaint((java.awt.Paint) color34);
        categoryAxis22.setTickMarkPaint((java.awt.Paint) color34);
        lineAndShapeRenderer10.setSeriesFillPaint((int) '#', (java.awt.Paint) color34, true);
        float[] floatArray44 = new float[] { 8, 64, 10.0f, 64, (byte) 1 };
        float[] floatArray45 = color34.getComponents(floatArray44);
        try {
            renderAttributes0.setSeriesOutlinePaint((-8458323), (java.awt.Paint) color34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        java.awt.Paint paint2 = null;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { paint2 };
        java.awt.Paint paint4 = null;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { paint4 };
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] {};
        java.awt.Stroke stroke7 = null;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke7 };
        java.awt.Stroke stroke9 = null;
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] { stroke9 };
        java.awt.Shape[] shapeArray11 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray5, paintArray6, strokeArray8, strokeArray10, shapeArray11);
        boolean boolean14 = defaultDrawingSupplier12.equals((java.lang.Object) (byte) -1);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset15 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.isRangeGridlinesVisible();
        java.awt.Stroke stroke32 = categoryPlot30.getRangeZeroBaselineStroke();
        categoryPlot30.setRangePannable(false);
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = categoryPlot30.getDomainMarkers(0, layer36);
        boolean boolean38 = abstractCategoryDataset15.hasListener((java.util.EventListener) categoryPlot30);
        org.jfree.data.general.DatasetGroup datasetGroup39 = new org.jfree.data.general.DatasetGroup();
        abstractCategoryDataset15.setGroup(datasetGroup39);
        boolean boolean41 = defaultDrawingSupplier12.equals((java.lang.Object) datasetGroup39);
        boolean boolean42 = strokeList0.equals((java.lang.Object) datasetGroup39);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shapeArray11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke20, false);
        org.jfree.chart.renderer.RenderAttributes renderAttributes25 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator26 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color27 = defaultShadowGenerator26.getShadowColor();
        renderAttributes25.setDefaultPaint((java.awt.Paint) color27);
        java.awt.Shape shape30 = renderAttributes25.getSeriesShape(2);
        java.awt.Shape shape33 = renderAttributes25.getItemShape((int) (byte) 10, 0);
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes25.setDefaultLabelFont(font34);
        java.awt.Paint paint36 = renderAttributes25.getDefaultPaint();
        lineAndShapeRenderer2.setSeriesItemLabelPaint(100, paint36);
        java.awt.Paint paint39 = lineAndShapeRenderer2.lookupLegendTextPaint(10);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(shape30);
        org.junit.Assert.assertNull(shape33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(paint39);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke16 = null;
        lineAndShapeRenderer14.setSeriesStroke(10, stroke16, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer14.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint21 = lineAndShapeRenderer14.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        boolean boolean23 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double29 = rectangleInsets28.getTop();
        categoryPlot22.setInsets(rectangleInsets28, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot22);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryPlot22.setDomainGridlinePaint((java.awt.Paint) color33);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = categoryPlot22.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(drawingSupplier35);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font10 = lineAndShapeRenderer2.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke14 = lineAndShapeRenderer2.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        boolean boolean15 = lineAndShapeRenderer2.getUseFillPaint();
        java.awt.Paint paint17 = lineAndShapeRenderer2.getSeriesItemLabelPaint(2);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke19 = null;
        lineAndShapeRenderer17.setSeriesStroke(10, stroke19, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = lineAndShapeRenderer17.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean24 = lineAndShapeRenderer17.getBaseItemLabelsVisible();
        lineAndShapeRenderer17.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = lineAndShapeRenderer17.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean33 = lineAndShapeRenderer17.getItemLineVisible(8, (int) (short) 10);
        boolean boolean34 = lineAndShapeRenderer17.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer17.setBaseOutlineStroke(stroke35, false);
        categoryPlot14.setRangeGridlineStroke(stroke35);
        categoryPlot14.setWeight(0);
        java.awt.Stroke stroke41 = categoryPlot14.getOutlineStroke();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        barRenderer0.setBaseCreateEntities(true, true);
        boolean boolean10 = barRenderer0.isSeriesVisible((int) (short) 10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean12 = lineAndShapeRenderer11.getBaseCreateEntities();
        java.awt.Paint paint14 = lineAndShapeRenderer11.lookupSeriesFillPaint((int) (short) -1);
        barRenderer0.setBasePaint(paint14);
        barRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) true);
        barRenderer0.setMinimumBarLength((double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke10 = null;
        lineAndShapeRenderer8.setSeriesStroke(10, stroke10, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = lineAndShapeRenderer8.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint15 = lineAndShapeRenderer8.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        boolean boolean17 = categoryPlot16.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double23 = rectangleInsets22.getTop();
        categoryPlot16.setInsets(rectangleInsets22, true);
        java.awt.Stroke stroke26 = categoryPlot16.getRangeMinorGridlineStroke();
        categoryPlot16.setRangeCrosshairValue(4.0d, false);
        java.awt.Stroke stroke30 = categoryPlot16.getOutlineStroke();
        boolean boolean31 = unitType0.equals((java.lang.Object) categoryPlot16);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke36 = null;
        lineAndShapeRenderer34.setSeriesStroke(10, stroke36, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = lineAndShapeRenderer34.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint41 = lineAndShapeRenderer34.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis30, valueAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot42.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker45 = null;
        org.jfree.chart.util.Layer layer46 = null;
        boolean boolean48 = categoryPlot42.removeDomainMarker((int) (short) 1, marker45, layer46, true);
        categoryPlot42.setBackgroundImageAlignment((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot42.setDomainAxisLocation((int) '#', axisLocation52, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        java.awt.geom.Point2D point2D57 = null;
        categoryPlot42.zoomRangeAxes(0.05d, plotRenderingInfo56, point2D57);
        categoryPlot14.setParent((org.jfree.chart.plot.Plot) categoryPlot42);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(axisLocation52);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER");
        java.lang.String str2 = legendItem1.getToolTipText();
        int int3 = legendItem1.getDatasetIndex();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) '#');
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean20 = categoryPlot14.removeDomainMarker((int) (short) 1, marker17, layer18, true);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setRangeAxisLocation((int) 'a', axisLocation22);
        boolean boolean24 = categoryPlot14.isRangePannable();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot14.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        categoryPlot14.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke27 = null;
        lineAndShapeRenderer25.setSeriesStroke(10, stroke27, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = lineAndShapeRenderer25.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint32 = lineAndShapeRenderer25.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot33.getDomainAxisLocation();
        categoryPlot14.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = categoryPlot14.getRangeAxis();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNull(valueAxis36);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Color color12 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12);
        categoryAxis1.setFixedDimension((double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke30 = null;
        lineAndShapeRenderer28.setSeriesStroke(10, stroke30, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = lineAndShapeRenderer28.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint35 = lineAndShapeRenderer28.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis24, valueAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer28);
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double43 = rectangleInsets42.getTop();
        categoryPlot36.setInsets(rectangleInsets42, true);
        java.awt.geom.GeneralPath generalPath46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.RenderingSource renderingSource48 = null;
        categoryPlot36.select(generalPath46, rectangle2D47, renderingSource48);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray51 = new org.jfree.chart.axis.ValueAxis[] { valueAxis50 };
        categoryPlot36.setRangeAxes(valueAxisArray51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot36.getRangeAxisEdge();
        try {
            double double54 = categoryAxis1.getCategorySeriesMiddle((int) '4', 10, 10, (int) '#', (double) 0.5f, rectangle2D21, rectangleEdge53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryToolTipGenerator34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 100.0d + "'", double43 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean10 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke20 = null;
        lineAndShapeRenderer18.setSeriesStroke(10, stroke20, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = lineAndShapeRenderer18.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint25 = lineAndShapeRenderer18.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot26.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean32 = categoryPlot26.removeDomainMarker((int) (short) 1, marker29, layer30, true);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D11, categoryPlot26, valueAxis33, marker34, rectangle2D35);
        java.awt.Shape shape37 = lineAndShapeRenderer0.getBaseShape();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke16 = null;
        lineAndShapeRenderer14.setSeriesStroke(10, stroke16, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer14.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint21 = lineAndShapeRenderer14.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        boolean boolean23 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double29 = rectangleInsets28.getTop();
        categoryPlot22.setInsets(rectangleInsets28, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace33, false);
        org.jfree.chart.plot.Marker marker37 = null;
        org.jfree.chart.util.Layer layer38 = null;
        try {
            categoryPlot22.addRangeMarker(0, marker37, layer38, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        java.lang.Boolean boolean13 = lineAndShapeRenderer0.getSeriesVisibleInLegend((-1));
        java.awt.Paint paint15 = lineAndShapeRenderer0.getSeriesPaint(255);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot14.getRangeAxis(100);
        java.awt.Paint paint26 = categoryPlot14.getRangeMinorGridlinePaint();
        float float27 = categoryPlot14.getBackgroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot14.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis30.setMaximumCategoryLabelWidthRatio((float) 100);
        double double33 = categoryAxis30.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double36 = rectangleInsets34.calculateLeftInset((-1.0d));
        categoryAxis30.setLabelInsets(rectangleInsets34, false);
        double double40 = rectangleInsets34.extendHeight((double) 2.0f);
        double double42 = rectangleInsets34.trimWidth((double) '#');
        categoryPlot14.setInsets(rectangleInsets34, false);
        org.jfree.chart.plot.Marker marker46 = null;
        org.jfree.chart.util.Layer layer47 = null;
        try {
            categoryPlot14.addRangeMarker(1, marker46, layer47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.0d + "'", double40 == 2.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 35.0d + "'", double42 == 35.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = booleanList0.equals((java.lang.Object) (-16777024));
        java.lang.Boolean boolean4 = booleanList0.getBoolean(0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke14 = null;
        lineAndShapeRenderer12.setSeriesStroke(10, stroke14, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = lineAndShapeRenderer12.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint19 = lineAndShapeRenderer12.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        boolean boolean21 = categoryPlot20.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double27 = rectangleInsets26.getTop();
        categoryPlot20.setInsets(rectangleInsets26, true);
        java.awt.Stroke stroke30 = categoryPlot20.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot20.panDomainAxes((double) (-2), plotRenderingInfo32, point2D33);
        boolean boolean35 = categoryAnchor5.equals((java.lang.Object) plotRenderingInfo32);
        boolean boolean36 = booleanList0.equals((java.lang.Object) categoryAnchor5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke19 = null;
        lineAndShapeRenderer17.setSeriesStroke(10, stroke19, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = lineAndShapeRenderer17.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean24 = lineAndShapeRenderer17.getBaseItemLabelsVisible();
        lineAndShapeRenderer17.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = lineAndShapeRenderer17.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean33 = lineAndShapeRenderer17.getItemLineVisible(8, (int) (short) 10);
        boolean boolean34 = lineAndShapeRenderer17.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer17.setBaseOutlineStroke(stroke35, false);
        categoryPlot14.setRangeGridlineStroke(stroke35);
        categoryPlot14.setWeight(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent41);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        try {
            int int44 = categoryPlot14.getRangeAxisIndex(valueAxis43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent2.setChart(jFreeChart3);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        int int19 = categoryPlot14.getBackgroundImageAlignment();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot14.getRenderer(4);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        try {
            int int23 = categoryPlot14.getRangeAxisIndex(valueAxis22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNull(categoryItemRenderer21);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot14.getDomainMarkers(0, layer20);
        categoryPlot14.setForegroundAlpha((float) (short) 1);
        categoryPlot14.setNoDataMessage("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis27.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis27.setTickLabelPaint((java.awt.Paint) color30);
        java.awt.Paint paint32 = categoryAxis27.getTickMarkPaint();
        categoryAxis27.setTickLabelsVisible(false);
        java.awt.Color color38 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis27.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color38);
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color38);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean20 = categoryPlot14.removeDomainMarker((int) (short) 1, marker17, layer18, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot14.zoomDomainAxes((double) (short) 0, plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis26.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis26.setTickLabelPaint((java.awt.Paint) color29);
        java.awt.Paint paint31 = categoryAxis26.getTickMarkPaint();
        categoryAxis26.setTickLabelsVisible(false);
        java.awt.Color color37 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis26.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color37);
        categoryPlot14.setRangeCrosshairPaint((java.awt.Paint) color37);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMinorTickMarkOutsideLength((float) (byte) 10);
        double double9 = categoryAxis1.getUpperMargin();
        categoryAxis1.setCategoryLabelPositionOffset((int) (short) 10);
        java.awt.Shape shape16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint18 = null;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape16, stroke17, paint18);
        legendItem19.setSeriesIndex((int) '4');
        java.awt.Paint paint22 = legendItem19.getLabelPaint();
        java.awt.Paint paint23 = legendItem19.getFillPaint();
        int int24 = legendItem19.getSeriesIndex();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke33 = null;
        lineAndShapeRenderer31.setSeriesStroke(10, stroke33, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = lineAndShapeRenderer31.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint38 = lineAndShapeRenderer31.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis27, valueAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer31);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke49 = null;
        lineAndShapeRenderer47.setSeriesStroke(10, stroke49, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = lineAndShapeRenderer47.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint54 = lineAndShapeRenderer47.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis43, valueAxis44, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer47);
        boolean boolean56 = categoryPlot55.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double62 = rectangleInsets61.getTop();
        categoryPlot55.setInsets(rectangleInsets61, true);
        java.awt.geom.GeneralPath generalPath65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.RenderingSource renderingSource67 = null;
        categoryPlot55.select(generalPath65, rectangle2D66, renderingSource67);
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray70 = new org.jfree.chart.axis.ValueAxis[] { valueAxis69 };
        categoryPlot55.setRangeAxes(valueAxisArray70);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor72 = categoryPlot55.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis74.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color77 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis74.setTickLabelPaint((java.awt.Paint) color77);
        java.awt.Paint paint79 = categoryAxis74.getTickMarkPaint();
        categoryPlot55.setDomainGridlinePaint(paint79);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset81 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset81.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int86 = categoryPlot55.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset81);
        categoryPlot39.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset81);
        defaultCategoryDataset81.addValue((double) (byte) 100, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) 1.0f);
        int int92 = defaultCategoryDataset81.getColumnCount();
        legendItem19.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset81);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo94 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent95 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) categoryAxis1, (org.jfree.data.general.Dataset) defaultCategoryDataset81, datasetChangeInfo94);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(categoryToolTipGenerator53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 100.0d + "'", double62 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray70);
        org.junit.Assert.assertNotNull(categoryAnchor72);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2 + "'", int92 == 2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot14.getDomainMarkers(layer18);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "TextAnchor.HALF_ASCENT_LEFT");
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        defaultCategoryDataset56.addValue((double) (byte) 100, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) 1.0f);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState67 = defaultCategoryDataset56.getSelectionState();
        try {
            defaultCategoryDataset56.removeColumn((java.lang.Comparable) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (3) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState67);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((-1.0d));
        double double4 = rectangleInsets0.calculateRightInset((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            rectangleInsets0.trim(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D22, categoryPlot23, valueAxis24, marker25, rectangle2D26);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = lineAndShapeRenderer2.getToolTipGenerator(64, 0, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font10 = lineAndShapeRenderer2.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke14 = lineAndShapeRenderer2.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        boolean boolean15 = lineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke21 = null;
        lineAndShapeRenderer19.setSeriesStroke(10, stroke21, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = lineAndShapeRenderer19.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean26 = lineAndShapeRenderer19.getBaseItemLabelsVisible();
        lineAndShapeRenderer19.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer19.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean35 = lineAndShapeRenderer19.getItemLineVisible(8, (int) (short) 10);
        java.lang.Boolean boolean37 = lineAndShapeRenderer19.getSeriesVisible((int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis39.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis39.setTickLabelPaint((java.awt.Paint) color42);
        java.awt.Font font44 = categoryAxis39.getTickLabelFont();
        lineAndShapeRenderer19.setBaseItemLabelFont(font44, false);
        lineAndShapeRenderer2.setLegendTextFont((int) '#', font44);
        lineAndShapeRenderer2.removeAnnotations();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(font44);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape2, "TextAnchor.HALF_ASCENT_CENTER", "TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj43 = defaultCategoryDataset42.clone();
        int int44 = defaultCategoryDataset42.getRowCount();
        defaultCategoryDataset42.fireSelectionEvent();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity48 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]", "-3,-3,3,3", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0f);
        java.lang.String str49 = categoryItemEntity48.toString();
        java.lang.Comparable comparable50 = categoryItemEntity48.getRowKey();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + 100.0f + "'", comparable50.equals(100.0f));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Shape shape10 = lineAndShapeRenderer2.getSeriesShape(0);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        java.awt.Stroke stroke14 = lineAndShapeRenderer2.getSeriesOutlineStroke(8);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        categoryPlot14.mapDatasetToRangeAxis((int) (short) 100, 52);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font10 = lineAndShapeRenderer2.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke14 = lineAndShapeRenderer2.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        boolean boolean15 = lineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke21 = null;
        lineAndShapeRenderer19.setSeriesStroke(10, stroke21, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = lineAndShapeRenderer19.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean26 = lineAndShapeRenderer19.getBaseItemLabelsVisible();
        lineAndShapeRenderer19.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer19.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean35 = lineAndShapeRenderer19.getItemLineVisible(8, (int) (short) 10);
        java.lang.Boolean boolean37 = lineAndShapeRenderer19.getSeriesVisible((int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis39.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis39.setTickLabelPaint((java.awt.Paint) color42);
        java.awt.Font font44 = categoryAxis39.getTickLabelFont();
        lineAndShapeRenderer19.setBaseItemLabelFont(font44, false);
        lineAndShapeRenderer2.setLegendTextFont((int) '#', font44);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke57 = null;
        lineAndShapeRenderer55.setSeriesStroke(10, stroke57, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator61 = lineAndShapeRenderer55.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint62 = lineAndShapeRenderer55.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis51, valueAxis52, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer55);
        java.lang.Object obj64 = categoryPlot63.clone();
        int int65 = categoryPlot63.getWeight();
        categoryPlot63.setDrawSharedDomainAxis(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer70 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke72 = null;
        lineAndShapeRenderer70.setSeriesStroke(10, stroke72, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator76 = lineAndShapeRenderer70.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean77 = lineAndShapeRenderer70.getBaseItemLabelsVisible();
        lineAndShapeRenderer70.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition83 = lineAndShapeRenderer70.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean86 = lineAndShapeRenderer70.getItemLineVisible(8, (int) (short) 10);
        lineAndShapeRenderer70.setSeriesShapesFilled((int) ' ', true);
        java.awt.Stroke stroke91 = lineAndShapeRenderer70.lookupSeriesOutlineStroke(0);
        categoryPlot63.setDomainCrosshairStroke(stroke91);
        try {
            lineAndShapeRenderer2.setSeriesOutlineStroke((-16777024), stroke91);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNull(categoryToolTipGenerator61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(stroke91);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot14.zoomRangeAxes((double) 100, plotRenderingInfo17, point2D18);
        boolean boolean20 = categoryPlot14.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot14.getRangeAxisForDataset((int) ' ');
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke26 = null;
        lineAndShapeRenderer24.setSeriesStroke(10, stroke26, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = lineAndShapeRenderer24.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint31 = lineAndShapeRenderer24.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot32.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean38 = categoryPlot32.removeDomainMarker((int) (short) 1, marker35, layer36, true);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot32.setRangeAxisLocation((int) 'a', axisLocation40);
        categoryPlot14.setRangeAxisLocation(axisLocation40, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint47 = categoryAxis45.getTickLabelPaint((java.lang.Comparable) 192);
        org.jfree.chart.plot.Plot plot48 = categoryAxis45.getPlot();
        boolean boolean49 = categoryAxis45.isTickMarksVisible();
        boolean boolean50 = categoryAxis45.isTickMarksVisible();
        categoryPlot14.setDomainAxis((int) (short) 100, categoryAxis45, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(plot48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot14.zoomRangeAxes((double) 100, plotRenderingInfo17, point2D18);
        categoryPlot14.clearAnnotations();
        categoryPlot14.setRangeCrosshairValue((double) (-1.0f), true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke32 = null;
        lineAndShapeRenderer30.setSeriesStroke(10, stroke32, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = lineAndShapeRenderer30.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint37 = lineAndShapeRenderer30.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis26, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer30);
        boolean boolean39 = categoryPlot38.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double45 = rectangleInsets44.getTop();
        categoryPlot38.setInsets(rectangleInsets44, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        categoryPlot38.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo50, point2D51);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent53 = null;
        categoryPlot38.datasetChanged(datasetChangeEvent53);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        java.awt.geom.Point2D point2D58 = null;
        categoryPlot38.zoomDomainAxes((double) (byte) -1, (double) 10, plotRenderingInfo57, point2D58);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator60 = new org.jfree.chart.util.DefaultShadowGenerator();
        int int61 = defaultShadowGenerator60.getShadowSize();
        categoryPlot38.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator60);
        categoryPlot14.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator60);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 5 + "'", int61 == 5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultCategoryDataset0.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D22, categoryPlot23, valueAxis24, marker25, rectangle2D26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = lineAndShapeRenderer2.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Boolean boolean33 = lineAndShapeRenderer2.getSeriesCreateEntities((-123));
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        java.lang.String str39 = categoryAxis37.getCategoryLabelToolTip((java.lang.Comparable) 0.2d);
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        try {
            lineAndShapeRenderer2.drawDomainMarker(graphics2D34, categoryPlot35, categoryAxis37, categoryMarker40, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        int int37 = categoryPlot17.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace38 = categoryPlot17.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNull(axisSpace38);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Stroke stroke2 = legendItem1.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Shape shape10 = lineAndShapeRenderer2.getSeriesShape(0);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint14 = lineAndShapeRenderer2.getSeriesFillPaint((-1));
        java.awt.Font font16 = lineAndShapeRenderer2.getLegendTextFont(5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(font16);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        java.awt.Shape shape7 = renderAttributes1.getItemShape(3, 15);
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Shape shape11 = legendItem10.getLine();
        renderAttributes1.setSeriesShape(100, shape11);
        java.awt.Shape shape14 = renderAttributes1.getSeriesShape((int) (byte) 100);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        java.lang.String str38 = plotEntity36.getShapeCoords();
        java.lang.Object obj39 = null;
        boolean boolean40 = plotEntity36.equals(obj39);
        java.lang.Object obj41 = plotEntity36.clone();
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Shape shape44 = legendItem43.getLine();
        boolean boolean45 = plotEntity36.equals((java.lang.Object) legendItem43);
        java.awt.Stroke stroke46 = legendItem43.getLineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-3,-3,3,3" + "'", str38.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range8 = barRenderer0.findRangeBounds(categoryDataset6, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font14 = lineAndShapeRenderer9.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean15 = lineAndShapeRenderer9.getAutoPopulateSeriesFillPaint();
        java.awt.Font font16 = lineAndShapeRenderer9.getBaseItemLabelFont();
        barRenderer0.setBaseLegendTextFont(font16);
        barRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer21.isDrawBarOutline();
        org.jfree.chart.renderer.category.BarPainter barPainter23 = barRenderer21.getBarPainter();
        barRenderer21.setMinimumBarLength((double) 3);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer27.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font32 = lineAndShapeRenderer27.getSeriesItemLabelFont((int) (byte) 100);
        java.awt.Font font33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer27.setBaseItemLabelFont(font33);
        barRenderer21.setSeriesItemLabelFont((int) (byte) 0, font33);
        barRenderer0.setLegendTextFont((int) ' ', font33);
        barRenderer0.setItemLabelAnchorOffset(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(barPainter23);
        org.junit.Assert.assertNull(font32);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, (double) (short) 1, (double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.setSeriesCreateEntities((int) (byte) 100, (java.lang.Boolean) false);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke13 = null;
        lineAndShapeRenderer11.setSeriesStroke(10, stroke13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = lineAndShapeRenderer11.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint18 = lineAndShapeRenderer11.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        barRenderer0.setPlot(categoryPlot19);
        barRenderer0.setItemMargin((double) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.awt.Stroke stroke37 = categoryPlot17.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        categoryPlot17.setRangeCrosshairStroke(stroke38);
        boolean boolean40 = categoryPlot17.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        defaultCategoryDataset56.addValue((double) (byte) 100, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) 1.0f);
        int int67 = defaultCategoryDataset56.getColumnCount();
        defaultCategoryDataset56.validateObject();
        defaultCategoryDataset56.setValue(32.0d, (java.lang.Comparable) "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", (java.lang.Comparable) "CategoryAnchor.END");
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D22, categoryPlot23, valueAxis24, marker25, rectangle2D26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = lineAndShapeRenderer2.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Boolean boolean33 = lineAndShapeRenderer2.getSeriesCreateEntities((-123));
        boolean boolean34 = lineAndShapeRenderer2.getBaseSeriesVisible();
        java.awt.Stroke stroke35 = null;
        try {
            lineAndShapeRenderer2.setBaseOutlineStroke(stroke35, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.data.general.Dataset dataset10 = legendItem7.getDataset();
        legendItem7.setURLText("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis14.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis14.setTickLabelPaint((java.awt.Paint) color17);
        categoryAxis14.setTickLabelsVisible(false);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color23 = color22.darker();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", (java.awt.Paint) color23);
        categoryAxis14.setAxisLinePaint((java.awt.Paint) color23);
        boolean boolean26 = legendItem7.equals((java.lang.Object) categoryAxis14);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis28.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Font font31 = categoryAxis28.getLabelFont();
        legendItem7.setLabelFont(font31);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke16 = null;
        lineAndShapeRenderer14.setSeriesStroke(10, stroke16, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer14.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint21 = lineAndShapeRenderer14.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        boolean boolean23 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double29 = rectangleInsets28.getTop();
        categoryPlot22.setInsets(rectangleInsets28, true);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot22.getRangeAxis(100);
        java.awt.Paint paint34 = categoryPlot22.getRangeMinorGridlinePaint();
        categoryAxis1.setAxisLinePaint(paint34);
        categoryAxis1.setMaximumCategoryLabelLines(192);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = lineAndShapeRenderer0.getItemLabelGenerator(0, 0, false);
        boolean boolean7 = lineAndShapeRenderer0.isSeriesVisibleInLegend((int) (byte) 1);
        boolean boolean8 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis1.setTickMarkOutsideLength(0.0f);
        categoryAxis1.clearCategoryLabelToolTips();
        double double7 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setTickMarksVisible(false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean10 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke20 = null;
        lineAndShapeRenderer18.setSeriesStroke(10, stroke20, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = lineAndShapeRenderer18.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint25 = lineAndShapeRenderer18.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot26.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean32 = categoryPlot26.removeDomainMarker((int) (short) 1, marker29, layer30, true);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D11, categoryPlot26, valueAxis33, marker34, rectangle2D35);
        java.lang.String str37 = categoryPlot26.getNoDataMessage();
        java.lang.Comparable comparable38 = categoryPlot26.getDomainCrosshairRowKey();
        java.awt.Image image39 = categoryPlot26.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(comparable38);
        org.junit.Assert.assertNull(image39);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape2, "TextAnchor.HALF_ASCENT_CENTER", "TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj43 = defaultCategoryDataset42.clone();
        int int44 = defaultCategoryDataset42.getRowCount();
        defaultCategoryDataset42.fireSelectionEvent();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity48 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]", "-3,-3,3,3", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0f);
        java.lang.Comparable comparable49 = categoryItemEntity48.getColumnKey();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + 1.0f + "'", comparable49.equals(1.0f));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setSeriesStroke((int) 'a', stroke12);
        java.awt.Paint paint15 = lineAndShapeRenderer2.getSeriesPaint((int) (short) 0);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(true);
        boolean boolean9 = categoryAxis1.isAxisLineVisible();
        int int10 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.Plot plot11 = null;
        categoryAxis1.setPlot(plot11);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color10 = color9.darker();
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", (java.awt.Paint) color10);
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color10);
        int int13 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 1);
        categoryAxis1.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.clear();
        keyedObjects0.clear();
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        barRenderer0.setBaseCreateEntities(true, true);
        boolean boolean10 = barRenderer0.isSeriesVisible((int) (short) 10);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint11);
        boolean boolean13 = barRenderer0.getShadowsVisible();
        double double14 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot14.getDatasetRenderingOrder();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextPaint();
        java.awt.Shape shape19 = defaultDrawingSupplier17.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke28 = null;
        lineAndShapeRenderer26.setSeriesStroke(10, stroke28, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator32 = lineAndShapeRenderer26.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint33 = lineAndShapeRenderer26.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer26);
        boolean boolean35 = categoryPlot34.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double41 = rectangleInsets40.getTop();
        categoryPlot34.setInsets(rectangleInsets40, true);
        java.awt.geom.GeneralPath generalPath44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.RenderingSource renderingSource46 = null;
        categoryPlot34.select(generalPath44, rectangle2D45, renderingSource46);
        categoryPlot34.setNotify(true);
        boolean boolean50 = categoryPlot34.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity53 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot34, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.util.List list54 = categoryPlot34.getAnnotations();
        try {
            categoryPlot14.mapDatasetToRangeAxes(10, list54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(categoryToolTipGenerator32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.0d + "'", double41 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(list54);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean39 = barRenderer38.getIncludeBaseInRange();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer38.setBaseFillPaint(paint40, true);
        double double43 = barRenderer38.getShadowYOffset();
        java.awt.Paint paint44 = barRenderer38.getBasePaint();
        java.awt.Paint paint46 = barRenderer38.lookupSeriesOutlinePaint((-1));
        boolean boolean47 = plotEntity36.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Shape shape10 = lineAndShapeRenderer2.getSeriesShape(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator11, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis16.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color19);
        java.awt.Paint paint21 = categoryAxis16.getLabelPaint();
        categoryAxis16.setMinorTickMarkOutsideLength((float) (byte) 10);
        double double24 = categoryAxis16.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke33 = null;
        lineAndShapeRenderer31.setSeriesStroke(10, stroke33, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = lineAndShapeRenderer31.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint38 = lineAndShapeRenderer31.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis27, valueAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer31);
        boolean boolean40 = categoryPlot39.isRangeGridlinesVisible();
        java.awt.Stroke stroke41 = categoryPlot39.getRangeZeroBaselineStroke();
        categoryAxis16.setTickMarkStroke(stroke41);
        lineAndShapeRenderer2.setSeriesOutlineStroke(0, stroke41);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color46 = color45.darker();
        lineAndShapeRenderer2.setSeriesPaint((int) (short) 1, (java.awt.Paint) color46, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        java.lang.String str1 = itemLabelAnchor0.toString();
        java.lang.String str2 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE8" + "'", str1.equals("ItemLabelAnchor.OUTSIDE8"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ItemLabelAnchor.OUTSIDE8" + "'", str2.equals("ItemLabelAnchor.OUTSIDE8"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, (double) (short) 1, (double) (byte) 0);
        java.lang.Object obj5 = null;
        boolean boolean6 = rectangleInsets4.equals(obj5);
        double double7 = rectangleInsets4.getLeft();
        double double9 = rectangleInsets4.calculateTopOutset((double) (-123));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot14.getDomainMarkers(0, layer20);
        categoryPlot14.setForegroundAlpha((float) (short) 1);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = categoryPlot14.getOrientation();
        float float25 = categoryPlot14.getBackgroundAlpha();
        categoryPlot14.configureDomainAxes();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 192);
        java.awt.Color color3 = java.awt.Color.pink;
        categoryAxis0.setLabelPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        int int16 = categoryPlot14.getWeight();
        categoryPlot14.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace19, false);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot14.removeDomainMarker((int) '4', marker23, layer24);
        java.awt.Paint paint26 = categoryPlot14.getOutlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot14.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(axisSpace27);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        defaultCategoryDataset56.addValue((double) (byte) 100, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) 1.0f);
        int int67 = defaultCategoryDataset56.getColumnCount();
        defaultCategoryDataset56.validateObject();
        try {
            defaultCategoryDataset56.removeColumn((java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (100.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke16 = null;
        lineAndShapeRenderer14.setSeriesStroke(10, stroke16, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer14.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint21 = lineAndShapeRenderer14.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        boolean boolean23 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double29 = rectangleInsets28.getTop();
        categoryPlot22.setInsets(rectangleInsets28, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot22);
        java.awt.Paint paint33 = categoryPlot22.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.awt.Paint paint3 = legendItem1.getLabelPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        java.lang.Object obj29 = categoryPlot14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryPlot14.getInsets();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        categoryPlot14.markerChanged(markerChangeEvent31);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = null;
        try {
            categoryPlot14.addDomainMarker(categoryMarker33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color4 = java.awt.Color.ORANGE;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        java.lang.String str6 = color4.toString();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean10 = lineAndShapeRenderer7.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        boolean boolean12 = lineAndShapeRenderer7.removeAnnotation(categoryAnnotation11);
        boolean boolean13 = lineAndShapeRenderer7.getUseOutlinePaint();
        lineAndShapeRenderer7.setBaseSeriesVisible(false, true);
        boolean boolean17 = color4.equals((java.lang.Object) lineAndShapeRenderer7);
        java.awt.Color color18 = java.awt.Color.lightGray;
        boolean boolean19 = color4.equals((java.lang.Object) color18);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str6.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = null;
        boolean boolean2 = shapeList0.equals(obj1);
        java.lang.Object obj3 = shapeList0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot14.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot30.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = categoryPlot30.removeDomainMarker((int) (short) 1, marker33, layer34, true);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot30.setRangeAxisLocation((int) 'a', axisLocation38);
        categoryPlot14.setRangeAxisLocation(axisLocation38, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean46 = lineAndShapeRenderer43.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation47 = null;
        boolean boolean48 = lineAndShapeRenderer43.removeAnnotation(categoryAnnotation47);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator50 = lineAndShapeRenderer43.getSeriesURLGenerator((int) 'a');
        categoryPlot14.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer43);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset52 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset52.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        org.jfree.data.Range range57 = lineAndShapeRenderer43.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset52);
        java.awt.Color color59 = java.awt.Color.GRAY;
        int int60 = color59.getTransparency();
        lineAndShapeRenderer43.setSeriesFillPaint(0, (java.awt.Paint) color59);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryURLGenerator50);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftInset((-1.0d));
        categoryAxis1.setLabelInsets(rectangleInsets5, false);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) ' ', "");
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int14 = color13.getAlpha();
        categoryAxis1.setLabelPaint((java.awt.Paint) color13);
        java.awt.Color color16 = java.awt.Color.black;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer17.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer22.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color26 = java.awt.Color.ORANGE;
        lineAndShapeRenderer22.setBaseFillPaint((java.awt.Paint) color26);
        java.lang.String str28 = color26.toString();
        lineAndShapeRenderer17.setSeriesOutlinePaint(10, (java.awt.Paint) color26);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color31 = java.awt.Color.ORANGE;
        float[] floatArray37 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray38 = color31.getRGBComponents(floatArray37);
        float[] floatArray39 = color30.getRGBColorComponents(floatArray37);
        float[] floatArray40 = color26.getComponents(floatArray39);
        float[] floatArray41 = color16.getRGBColorComponents(floatArray39);
        float[] floatArray42 = color13.getComponents(floatArray41);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str28.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        java.awt.Paint paint8 = barRenderer0.getItemOutlinePaint((int) (short) -1, (int) (short) 100, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = barRenderer0.getSelectedItemAttributes();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertNotNull(renderAttributes10);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        boolean boolean7 = barRenderer0.isSeriesItemLabelsVisible((int) (short) 100);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = barRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryURLGenerator8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) 0L, false);
        java.lang.Number number3 = selectableValue2.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0L + "'", number3.equals(0L));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) 'a', categoryToolTipGenerator6);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        lineAndShapeRenderer2.setSeriesVisible((int) (byte) 10, (java.lang.Boolean) true);
        lineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.util.BooleanList booleanList1 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = java.awt.Color.ORANGE;
        float[] floatArray10 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray11 = color4.getRGBComponents(floatArray10);
        float[] floatArray12 = color3.getRGBColorComponents(floatArray10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER", (java.awt.Paint) color3);
        int int14 = color3.getTransparency();
        boolean boolean15 = booleanList1.equals((java.lang.Object) color3);
        org.jfree.data.KeyedObject keyedObject16 = new org.jfree.data.KeyedObject((java.lang.Comparable) 89, (java.lang.Object) color3);
        java.lang.Object obj17 = keyedObject16.getObject();
        java.lang.Object obj18 = keyedObject16.clone();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double6 = rectangleInsets4.calculateBottomInset((double) (byte) 0);
        double double8 = rectangleInsets4.calculateRightOutset((double) 4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        categoryPlot14.notifyListeners(plotChangeEvent40);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot14.setDomainGridlinePosition(categoryAnchor42);
        java.lang.String str44 = categoryAnchor42.toString();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "CategoryAnchor.START" + "'", str44.equals("CategoryAnchor.START"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        java.awt.Shape shape6 = barRenderer0.lookupSeriesShape((int) (short) 10);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        try {
            barRenderer0.setLegendTextFont((int) (byte) -1, font8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot14.getRangeAxis(100);
        java.awt.Paint paint26 = categoryPlot14.getRangeMinorGridlinePaint();
        float float27 = categoryPlot14.getBackgroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot14.getRangeAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot14.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot30 = categoryPlot14.getRootPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis32.setMaximumCategoryLabelWidthRatio((float) 100);
        double double35 = categoryAxis32.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets36.calculateLeftInset((-1.0d));
        categoryAxis32.setLabelInsets(rectangleInsets36, false);
        plot30.setInsets(rectangleInsets36, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(plot30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.2d + "'", double35 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.data.general.Dataset dataset10 = legendItem7.getDataset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer13.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean17 = lineAndShapeRenderer16.getBaseCreateEntities();
        java.awt.Paint paint19 = lineAndShapeRenderer16.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer13.setBasePaint(paint19);
        legendItem7.setLabelPaint(paint19);
        legendItem7.setDescription("TextAnchor.HALF_ASCENT_LEFT");
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Shape shape10 = lineAndShapeRenderer2.getSeriesShape(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator11, true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke23 = null;
        lineAndShapeRenderer21.setSeriesStroke(10, stroke23, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = lineAndShapeRenderer21.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint28 = lineAndShapeRenderer21.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21);
        boolean boolean30 = categoryPlot29.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double36 = rectangleInsets35.getTop();
        categoryPlot29.setInsets(rectangleInsets35, true);
        java.awt.geom.GeneralPath generalPath39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.RenderingSource renderingSource41 = null;
        categoryPlot29.select(generalPath39, rectangle2D40, renderingSource41);
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        categoryPlot29.addChangeListener(plotChangeListener43);
        org.jfree.chart.plot.Marker marker46 = null;
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = categoryPlot29.removeDomainMarker((int) '#', marker46, layer47);
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        try {
            lineAndShapeRenderer2.drawBackground(graphics2D14, categoryPlot29, rectangle2D49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(categoryToolTipGenerator27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        java.lang.Boolean boolean13 = lineAndShapeRenderer0.getSeriesVisibleInLegend((-1));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = lineAndShapeRenderer0.getToolTipGenerator(192, 0, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Shape shape10 = lineAndShapeRenderer2.getSeriesShape(0);
        java.awt.Stroke stroke12 = lineAndShapeRenderer2.getSeriesStroke((int) ' ');
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(stroke12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        int int31 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot14, jFreeChart32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot14.getLegendItems();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection34);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        categoryAxis2.setLowerMargin((double) 100.0f);
        categoryAxis2.setLowerMargin(0.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint9 = lineAndShapeRenderer2.getBasePaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = lineAndShapeRenderer2.getURLGenerator((int) (byte) 10, (int) 'a', true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesItemLabelsVisible((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        lineAndShapeRenderer0.setUseSeriesOffset(false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer7.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        boolean boolean16 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double22 = rectangleInsets21.getTop();
        categoryPlot15.setInsets(rectangleInsets21, true);
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot15.select(generalPath25, rectangle2D26, renderingSource27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        categoryPlot15.setRangeAxes(valueAxisArray30);
        keyedObjects2D0.setObject((java.lang.Object) valueAxisArray30, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) (byte) 10);
        keyedObjects2D0.clear();
        int int36 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray30);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem11.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType14 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str15 = gradientPaintTransformType14.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType14);
        legendItem11.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        legendItem7.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        boolean boolean19 = legendItem7.isLineVisible();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str15.equals("GradientPaintTransformType.CENTER_VERTICAL"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextPaint();
        java.awt.Shape shape13 = defaultDrawingSupplier11.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke22 = null;
        lineAndShapeRenderer20.setSeriesStroke(10, stroke22, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = lineAndShapeRenderer20.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint27 = lineAndShapeRenderer20.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        boolean boolean29 = categoryPlot28.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double35 = rectangleInsets34.getTop();
        categoryPlot28.setInsets(rectangleInsets34, true);
        java.awt.geom.GeneralPath generalPath38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.RenderingSource renderingSource40 = null;
        categoryPlot28.select(generalPath38, rectangle2D39, renderingSource40);
        categoryPlot28.setNotify(true);
        boolean boolean44 = categoryPlot28.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity47 = new org.jfree.chart.entity.PlotEntity(shape13, (org.jfree.chart.plot.Plot) categoryPlot28, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str48 = plotEntity47.toString();
        java.lang.String str49 = plotEntity47.getToolTipText();
        java.awt.Shape shape50 = plotEntity47.getArea();
        java.awt.Paint paint51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]", "", "ChartChangeEventType.GENERAL", "SortOrder.ASCENDING", shape50, paint51);
        lineAndShapeRenderer0.setSeriesShape((int) (short) 10, shape50, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str48.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str49.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset40.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int45 = categoryPlot14.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState46 = defaultCategoryDataset40.getSelectionState();
        defaultCategoryDataset40.clear();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState46);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Font font6 = categoryAxis1.getTickLabelFont();
        categoryAxis1.setAxisLineVisible(false);
        categoryAxis1.setLabelAngle(0.0d);
        double double11 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesItemLabelsVisible((int) '4');
        boolean boolean8 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = lineAndShapeRenderer0.getItemLabelGenerator(100, (int) (short) -1, true);
        lineAndShapeRenderer0.setBaseShapesFilled(false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        categoryPlot14.setNotify(true);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) 1L, true);
        boolean boolean33 = categoryPlot14.isDomainGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        categoryPlot14.setRangeAxis((int) (short) 10, valueAxis35);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis2.setTickLabelPaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = categoryAxis2.getTickMarkPaint();
        double double8 = categoryAxis2.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis2.getLabelInsets();
        boolean boolean10 = textAnchor0.equals((java.lang.Object) categoryAxis2);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot14.getDomainMarkers(layer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        int int22 = categoryPlot14.getDomainAxisIndex(categoryAxis21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot14.getDataset(255);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(categoryDataset24);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke12 = null;
        lineAndShapeRenderer10.setSeriesStroke(10, stroke12, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = lineAndShapeRenderer10.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Shape shape18 = lineAndShapeRenderer10.getSeriesShape(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        lineAndShapeRenderer10.setBaseURLGenerator(categoryURLGenerator19, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis23.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis23.setTickLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint28 = categoryAxis23.getTickMarkPaint();
        lineAndShapeRenderer10.setBasePaint(paint28, false);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=255,g=200,b=0]", paint28);
        categoryAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertNull(shape18);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range8 = barRenderer0.findRangeBounds(categoryDataset6, false);
        java.awt.Shape shape10 = barRenderer0.getLegendShape((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getSeriesPositiveItemLabelPosition(4);
        boolean boolean14 = barRenderer0.isSeriesVisible((-2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape2, "TextAnchor.HALF_ASCENT_CENTER", "TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj43 = defaultCategoryDataset42.clone();
        int int44 = defaultCategoryDataset42.getRowCount();
        defaultCategoryDataset42.fireSelectionEvent();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity48 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]", "-3,-3,3,3", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0f);
        categoryItemEntity48.setColumnKey((java.lang.Comparable) 5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        java.lang.Boolean boolean13 = lineAndShapeRenderer0.getSeriesVisibleInLegend((-1));
        java.awt.Paint paint17 = lineAndShapeRenderer0.getItemOutlinePaint((int) 'a', 15, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.DESCENDING;
        keyedObjects0.sortByKeys(sortOrder1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) color3);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        keyedObjects0.setObject((java.lang.Comparable) "hi!", (java.lang.Object) itemLabelAnchor6);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((-1.0d));
        double double4 = rectangleInsets0.calculateLeftInset(0.0d);
        double double6 = rectangleInsets0.calculateBottomOutset(0.2d);
        double double7 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint9 = lineAndShapeRenderer2.getBasePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (short) 10);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        float float18 = categoryPlot14.getForegroundAlpha();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        categoryPlot14.setRangeGridlineStroke(stroke19);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke16 = null;
        lineAndShapeRenderer14.setSeriesStroke(10, stroke16, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer14.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint21 = lineAndShapeRenderer14.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        boolean boolean23 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double29 = rectangleInsets28.getTop();
        categoryPlot22.setInsets(rectangleInsets28, true);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot22.getRangeAxis(100);
        java.awt.Paint paint34 = categoryPlot22.getRangeMinorGridlinePaint();
        categoryAxis1.setAxisLinePaint(paint34);
        java.awt.Font font36 = categoryAxis1.getLabelFont();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font36);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesItemLabelsVisible((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        boolean boolean13 = lineAndShapeRenderer0.isItemLabelVisible((int) (short) -1, 89, false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot14.getDomainMarkers(0, layer20);
        categoryPlot14.setRangeCrosshairVisible(true);
        categoryPlot14.clearRangeMarkers();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke20, false);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Shape shape27 = lineAndShapeRenderer2.lookupLegendShape((int) (byte) 1);
        java.awt.Paint paint28 = lineAndShapeRenderer2.getBaseLegendTextPaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(paint28);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        double double2 = barRenderer0.getMinimumBarLength();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", (java.awt.Paint) color2);
        java.awt.Font font4 = legendItem3.getLabelFont();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(font4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.awt.Paint paint3 = legendItem1.getLinePaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.Stroke stroke24 = categoryPlot14.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.panDomainAxes((double) (-2), plotRenderingInfo26, point2D27);
        int int29 = categoryPlot14.getDomainAxisCount();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.RenderingSource renderingSource33 = null;
        categoryPlot14.select((double) 10L, (double) (byte) 10, rectangle2D32, renderingSource33);
        categoryPlot14.setAnchorValue((double) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        int int39 = categoryPlot14.getDomainAxisIndex(categoryAxis38);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = null;
        boolean boolean2 = paintList0.equals(obj1);
        java.awt.Paint paint4 = paintList0.getPaint((int) (short) 1);
        java.awt.Paint paint6 = paintList0.getPaint((int) ' ');
        java.awt.Paint paint8 = paintList0.getPaint((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16744320) + "'", int1 == (-16744320));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean20 = categoryPlot14.removeDomainMarker((int) (short) 1, marker17, layer18, true);
        categoryPlot14.setBackgroundImageAlignment((int) (byte) 10);
        java.awt.Stroke stroke23 = categoryPlot14.getDomainCrosshairStroke();
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot14.getRangeMarkers(10, layer25);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(collection26);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem1.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType4 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str5 = gradientPaintTransformType4.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer6 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType4);
        legendItem1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer6);
        java.awt.Color color8 = java.awt.Color.PINK;
        legendItem1.setFillPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = legendItem1.getFillPaint();
        org.junit.Assert.assertNotNull(gradientPaintTransformType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str5.equals("GradientPaintTransformType.CENTER_VERTICAL"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer1.getIncludeBaseInRange();
        java.awt.Shape shape4 = barRenderer1.lookupSeriesShape(0);
        double double5 = barRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer1.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator7, false);
        org.jfree.data.KeyedObject keyedObject10 = new org.jfree.data.KeyedObject(comparable0, (java.lang.Object) categoryItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        categoryPlot17.setFixedRangeAxisSpace(axisSpace38);
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean44 = categoryPlot17.removeDomainMarker(2, marker41, layer42, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis3.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis3.setTickMarkOutsideLength(0.0f);
        int int8 = categoryAxis3.getCategoryLabelPositionOffset();
        objectList0.set((int) '4', (java.lang.Object) int8);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        categoryPlot14.notifyListeners(plotChangeEvent40);
        categoryPlot14.clearSelection();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(true);
        categoryAxis1.setLabelURL("CategoryAnchor.START");
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        categoryPlot14.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke27 = null;
        lineAndShapeRenderer25.setSeriesStroke(10, stroke27, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = lineAndShapeRenderer25.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint32 = lineAndShapeRenderer25.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot33.getDomainAxisLocation();
        categoryPlot14.setRangeAxisLocation(axisLocation34);
        java.lang.String str36 = axisLocation34.toString();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str36.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        categoryPlot14.setNotify(true);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot14.setFixedDomainAxisSpace(axisSpace30, true);
        java.awt.Paint paint33 = categoryPlot14.getBackgroundPaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer0.getPositiveItemLabelPosition((-2), 8, true);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (short) 0, (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.setShadowXOffset(0.2d);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = barRenderer0.getPlot();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryPlot4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint8 = defaultDrawingSupplier7.getNextPaint();
        java.awt.Shape shape9 = defaultDrawingSupplier7.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke18 = null;
        lineAndShapeRenderer16.setSeriesStroke(10, stroke18, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = lineAndShapeRenderer16.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint23 = lineAndShapeRenderer16.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        boolean boolean25 = categoryPlot24.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double31 = rectangleInsets30.getTop();
        categoryPlot24.setInsets(rectangleInsets30, true);
        java.awt.geom.GeneralPath generalPath34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.RenderingSource renderingSource36 = null;
        categoryPlot24.select(generalPath34, rectangle2D35, renderingSource36);
        categoryPlot24.setNotify(true);
        boolean boolean40 = categoryPlot24.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity43 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot24, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.awt.Stroke stroke44 = categoryPlot24.getRangeZeroBaselineStroke();
        try {
            barRenderer0.setSeriesStroke((-8458323), stroke44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.0d + "'", double31 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        categoryPlot14.notifyListeners(plotChangeEvent40);
        categoryPlot14.mapDatasetToDomainAxis((int) (short) 1, (-123));
        java.lang.Comparable comparable45 = categoryPlot14.getDomainCrosshairRowKey();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(comparable45);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) itemLabelAnchor1);
        int int3 = keyedObjects2D0.getRowCount();
        int int4 = keyedObjects2D0.getRowCount();
        keyedObjects2D0.clear();
        try {
            keyedObjects2D0.removeRow((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem1.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType4 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str5 = gradientPaintTransformType4.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer6 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType4);
        legendItem1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer6);
        boolean boolean8 = legendItem1.isLineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke17 = null;
        lineAndShapeRenderer15.setSeriesStroke(10, stroke17, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = lineAndShapeRenderer15.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint22 = lineAndShapeRenderer15.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15);
        boolean boolean24 = categoryPlot23.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double30 = rectangleInsets29.getTop();
        categoryPlot23.setInsets(rectangleInsets29, true);
        java.awt.Stroke stroke33 = categoryPlot23.getRangeMinorGridlineStroke();
        double double34 = categoryPlot23.getAnchorValue();
        java.awt.Color color37 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryPlot23.setRangeCrosshairPaint((java.awt.Paint) color37);
        legendItem1.setOutlinePaint((java.awt.Paint) color37);
        int int40 = color37.getRed();
        org.junit.Assert.assertNotNull(gradientPaintTransformType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str5.equals("GradientPaintTransformType.CENTER_VERTICAL"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.Stroke stroke24 = categoryPlot14.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.panDomainAxes((double) (-2), plotRenderingInfo26, point2D27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot14.getDataRange(valueAxis29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot14.getDomainAxisLocation();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 100);
        double double5 = categoryAxis2.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.calculateLeftInset((-1.0d));
        categoryAxis2.setLabelInsets(rectangleInsets6, false);
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) ' ', "");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int15 = color14.getAlpha();
        categoryAxis2.setLabelPaint((java.awt.Paint) color14);
        org.jfree.data.KeyedObject keyedObject17 = new org.jfree.data.KeyedObject((java.lang.Comparable) "PlotOrientation.VERTICAL", (java.lang.Object) color14);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        categoryPlot14.notifyListeners(plotChangeEvent40);
        int int42 = categoryPlot14.getDomainAxisCount();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        barRenderer0.setBaseCreateEntities(true, true);
        boolean boolean10 = barRenderer0.isSeriesVisible((int) (short) 10);
        java.awt.Paint paint11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setBaseItemLabelPaint(paint11);
        double double13 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        java.lang.Object obj4 = chartChangeEvent2.getSource();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 10.0d + "'", obj4.equals(10.0d));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        int int16 = categoryPlot14.getWeight();
        categoryPlot14.configureDomainAxes();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            categoryPlot14.addAnnotation(categoryAnnotation18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        int int19 = categoryPlot14.getBackgroundImageAlignment();
        categoryPlot14.setNoDataMessage("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        java.lang.Boolean boolean20 = lineAndShapeRenderer2.getSeriesVisible((int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis22.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis22.setTickLabelPaint((java.awt.Paint) color25);
        java.awt.Font font27 = categoryAxis22.getTickLabelFont();
        lineAndShapeRenderer2.setBaseItemLabelFont(font27, false);
        java.awt.Paint paint30 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        java.awt.Shape shape31 = null;
        lineAndShapeRenderer2.setBaseLegendShape(shape31);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator33, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis1.getLabelInsets();
        java.awt.Color color8 = java.awt.Color.YELLOW;
        int int9 = color8.getRed();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        int int11 = color8.getRGB();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-256) + "'", int11 == (-256));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        categoryPlot14.setNotify(true);
        boolean boolean30 = categoryPlot14.isNotify();
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation31, plotOrientation32);
        categoryPlot14.setOrientation(plotOrientation32);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "");
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = null;
        categoryPlot14.axisChanged(axisChangeEvent37);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        categoryPlot14.setDomainCrosshairColumnKey((java.lang.Comparable) "hi!", true);
        categoryPlot14.clearDomainMarkers((int) ' ');
        boolean boolean37 = categoryPlot14.isNotify();
        java.awt.Paint paint38 = categoryPlot14.getRangeGridlinePaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        double double2 = barRenderer0.getShadowYOffset();
        barRenderer0.setBase((double) (-8458323));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMinorTickMarkOutsideLength((float) (byte) 10);
        double double9 = categoryAxis1.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke18 = null;
        lineAndShapeRenderer16.setSeriesStroke(10, stroke18, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = lineAndShapeRenderer16.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint23 = lineAndShapeRenderer16.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        boolean boolean25 = categoryPlot24.isRangeGridlinesVisible();
        java.awt.Stroke stroke26 = categoryPlot24.getRangeZeroBaselineStroke();
        categoryAxis1.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis1.getLabelInsets();
        double double29 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.2d + "'", double29 == 0.2d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range8 = barRenderer0.findRangeBounds(categoryDataset6, false);
        java.awt.Shape shape10 = barRenderer0.getLegendShape((int) '#');
        java.awt.Color color12 = java.awt.Color.ORANGE;
        float[] floatArray18 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray19 = color12.getRGBComponents(floatArray18);
        barRenderer0.setLegendTextPaint((int) (short) 10, (java.awt.Paint) color12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke25 = null;
        lineAndShapeRenderer23.setSeriesStroke(10, stroke25, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = lineAndShapeRenderer23.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean30 = lineAndShapeRenderer23.getBaseItemLabelsVisible();
        lineAndShapeRenderer23.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = lineAndShapeRenderer23.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean39 = lineAndShapeRenderer23.getItemLineVisible(8, (int) (short) 10);
        boolean boolean40 = lineAndShapeRenderer23.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer23.setBaseOutlineStroke(stroke41, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint45 = lineAndShapeRenderer44.getBaseFillPaint();
        double double46 = lineAndShapeRenderer44.getItemMargin();
        boolean boolean47 = lineAndShapeRenderer44.getBaseSeriesVisible();
        int int48 = lineAndShapeRenderer44.getColumnCount();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean50 = lineAndShapeRenderer49.getBaseCreateEntities();
        java.awt.Paint paint52 = lineAndShapeRenderer49.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer44.setBaseLegendTextPaint(paint52);
        lineAndShapeRenderer23.setBaseOutlinePaint(paint52, false);
        barRenderer0.setBaseOutlinePaint(paint52, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean59 = barRenderer58.getIncludeBaseInRange();
        java.awt.Paint paint60 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer58.setBaseFillPaint(paint60, true);
        double double63 = barRenderer58.getShadowYOffset();
        java.awt.Paint paint64 = barRenderer58.getBasePaint();
        java.awt.Paint paint66 = barRenderer58.lookupSeriesOutlinePaint((-1));
        barRenderer0.setShadowPaint(paint66);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 4.0d + "'", double63 == 4.0d);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(paint66);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        java.awt.Shape shape6 = renderAttributes1.getSeriesShape(2);
        java.awt.Shape shape9 = renderAttributes1.getItemShape((int) (byte) 10, 0);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes1.setDefaultLabelFont(font10);
        java.awt.Paint paint12 = renderAttributes1.getDefaultPaint();
        org.jfree.chart.renderer.RenderAttributes renderAttributes14 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator15 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color16 = defaultShadowGenerator15.getShadowColor();
        renderAttributes14.setDefaultPaint((java.awt.Paint) color16);
        java.awt.Shape shape19 = renderAttributes14.getSeriesShape(2);
        java.awt.Shape shape22 = renderAttributes14.getItemShape((int) (byte) 10, 0);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes14.setDefaultLabelFont(font23);
        renderAttributes1.setDefaultLabelFont(font23);
        java.awt.Paint paint27 = renderAttributes1.getSeriesPaint((int) (byte) 100);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint33 = defaultDrawingSupplier32.getNextPaint();
        java.awt.Shape shape34 = defaultDrawingSupplier32.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke43 = null;
        lineAndShapeRenderer41.setSeriesStroke(10, stroke43, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = lineAndShapeRenderer41.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint48 = lineAndShapeRenderer41.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer41);
        boolean boolean50 = categoryPlot49.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double56 = rectangleInsets55.getTop();
        categoryPlot49.setInsets(rectangleInsets55, true);
        java.awt.geom.GeneralPath generalPath59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.RenderingSource renderingSource61 = null;
        categoryPlot49.select(generalPath59, rectangle2D60, renderingSource61);
        categoryPlot49.setNotify(true);
        boolean boolean65 = categoryPlot49.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity68 = new org.jfree.chart.entity.PlotEntity(shape34, (org.jfree.chart.plot.Plot) categoryPlot49, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str69 = plotEntity68.toString();
        java.lang.String str70 = plotEntity68.getToolTipText();
        java.awt.Shape shape71 = plotEntity68.getArea();
        java.awt.Paint paint72 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]", "", "ChartChangeEventType.GENERAL", "SortOrder.ASCENDING", shape71, paint72);
        renderAttributes1.setDefaultShape(shape71);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(categoryToolTipGenerator47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 100.0d + "'", double56 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str69.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str70.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(paint72);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean20 = categoryPlot14.removeDomainMarker((int) (short) 1, marker17, layer18, true);
        categoryPlot14.setBackgroundImageAlignment((int) (byte) 10);
        boolean boolean23 = categoryPlot14.isOutlineVisible();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset40.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int45 = categoryPlot14.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot14.getRenderer(15);
        org.jfree.chart.util.SortOrder sortOrder48 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean50 = sortOrder48.equals((java.lang.Object) 1.0d);
        categoryPlot14.setColumnRenderingOrder(sortOrder48);
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke60 = null;
        lineAndShapeRenderer58.setSeriesStroke(10, stroke60, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator64 = lineAndShapeRenderer58.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint65 = lineAndShapeRenderer58.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis54, valueAxis55, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer58);
        boolean boolean67 = categoryPlot66.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double73 = rectangleInsets72.getTop();
        categoryPlot66.setInsets(rectangleInsets72, true);
        java.awt.geom.GeneralPath generalPath76 = null;
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        org.jfree.chart.RenderingSource renderingSource78 = null;
        categoryPlot66.select(generalPath76, rectangle2D77, renderingSource78);
        org.jfree.chart.axis.ValueAxis valueAxis80 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray81 = new org.jfree.chart.axis.ValueAxis[] { valueAxis80 };
        categoryPlot66.setRangeAxes(valueAxisArray81);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = categoryPlot66.getRangeAxisEdge();
        boolean boolean84 = sortOrder48.equals((java.lang.Object) categoryPlot66);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer47);
        org.junit.Assert.assertNotNull(sortOrder48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 100.0d + "'", double73 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray81);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) -1);
        java.awt.Shape shape10 = null;
        lineAndShapeRenderer0.setBaseLegendShape(shape10);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemOutlineStroke(1, (-8388608), false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape2, "TextAnchor.HALF_ASCENT_CENTER", "TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj43 = defaultCategoryDataset42.clone();
        int int44 = defaultCategoryDataset42.getRowCount();
        defaultCategoryDataset42.fireSelectionEvent();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity48 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]", "-3,-3,3,3", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0f);
        java.awt.Font font49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boolean boolean50 = categoryItemEntity48.equals((java.lang.Object) font49);
        categoryItemEntity48.setRowKey((java.lang.Comparable) (-256));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range8 = barRenderer0.findRangeBounds(categoryDataset6, false);
        java.awt.Shape shape10 = barRenderer0.getLegendShape((int) '#');
        org.jfree.chart.renderer.category.BarPainter barPainter11 = barRenderer0.getBarPainter();
        barRenderer0.setShadowVisible(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(barPainter11);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setBaseLinesVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer22.getBaseCreateEntities();
        java.awt.Paint paint25 = lineAndShapeRenderer22.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator26 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer22.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator26);
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator26);
        org.jfree.data.SelectableValue selectableValue30 = new org.jfree.data.SelectableValue((java.lang.Number) (-1L));
        boolean boolean31 = standardCategorySeriesLabelGenerator26.equals((java.lang.Object) selectableValue30);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke20, false);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        lineAndShapeRenderer2.setDefaultEntityRadius((int) 'a');
        try {
            lineAndShapeRenderer2.setItemMargin(1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        int int8 = lineAndShapeRenderer0.getRowCount();
        boolean boolean10 = lineAndShapeRenderer0.isSeriesVisible(1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot14.zoomDomainAxes((double) (byte) -1, (double) 10, plotRenderingInfo33, point2D34);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator36 = new org.jfree.chart.util.DefaultShadowGenerator();
        int int37 = defaultShadowGenerator36.getShadowSize();
        categoryPlot14.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator36);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation40, plotOrientation41);
        categoryPlot14.setRangeAxisLocation((int) (byte) 0, axisLocation40);
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot14.setDomainAxisLocation(axisLocation44, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(axisLocation44);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int int3 = java.awt.Color.HSBtoRGB((float) 255, (float) 5, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-763) + "'", int3 == (-763));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke13 = null;
        lineAndShapeRenderer11.setSeriesStroke(10, stroke13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = lineAndShapeRenderer11.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint18 = lineAndShapeRenderer11.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        boolean boolean20 = categoryPlot19.isRangeGridlinesVisible();
        categoryPlot19.setBackgroundAlpha((float) 2);
        java.util.List list23 = categoryPlot19.getCategories();
        boolean boolean24 = categoryPlot19.isRangeMinorGridlinesVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer25.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        lineAndShapeRenderer25.setDefaultEntityRadius((int) ' ');
        java.awt.Stroke stroke32 = lineAndShapeRenderer25.lookupSeriesOutlineStroke(0);
        categoryPlot19.setOutlineStroke(stroke32);
        java.awt.Stroke stroke34 = categoryPlot19.getDomainCrosshairStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes36 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator37 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color38 = defaultShadowGenerator37.getShadowColor();
        renderAttributes36.setDefaultPaint((java.awt.Paint) color38);
        try {
            org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem(attributedString0, "ItemLabelAnchor.OUTSIDE8", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "CategoryAnchor.END", shape4, stroke34, (java.awt.Paint) color38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(list23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lineAndShapeRenderer2.getItemVisible(0, 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer8.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean12 = lineAndShapeRenderer11.getBaseCreateEntities();
        java.awt.Paint paint14 = lineAndShapeRenderer11.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer8.setBasePaint(paint14);
        java.awt.Shape shape19 = lineAndShapeRenderer8.getItemShape((int) (short) 1, 192, false);
        lineAndShapeRenderer2.setBaseLegendShape(shape19);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape19);
        boolean boolean22 = shapeList0.equals((java.lang.Object) chartEntity21);
        java.lang.Object obj23 = chartEntity21.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        java.awt.Font font8 = lineAndShapeRenderer0.lookupLegendTextFont(52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(font8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        boolean boolean14 = lineAndShapeRenderer2.getItemShapeVisible((-16744320), (int) (byte) -1);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis2.setTickMarkOutsideLength(0.0f);
        boolean boolean7 = textAnchor0.equals((java.lang.Object) categoryAxis2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis2.getCategoryLabelPositions();
        categoryAxis2.setUpperMargin(0.2d);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        categoryPlot14.setNotify(true);
        boolean boolean30 = categoryPlot14.canSelectByPoint();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        try {
            int int32 = categoryPlot14.getRangeAxisIndex(valueAxis31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setSeriesStroke((int) 'a', stroke12);
        java.awt.Paint paint15 = lineAndShapeRenderer2.getSeriesPaint((int) (short) 0);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        boolean boolean11 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = lineAndShapeRenderer2.getBaseURLGenerator();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryURLGenerator12);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        org.jfree.chart.plot.Plot plot9 = categoryAxis1.getPlot();
        double double10 = categoryAxis1.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        categoryAxis1.addChangeListener(axisChangeListener11);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot14.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.panDomainAxes(0.0d, plotRenderingInfo19, point2D20);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer0.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getSeriesItemLabelGenerator(0);
        org.jfree.chart.renderer.category.BarPainter barPainter5 = barRenderer0.getBarPainter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(barPainter5);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseFillPaint();
        double double2 = lineAndShapeRenderer0.getItemMargin();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke7 = null;
        lineAndShapeRenderer5.setSeriesStroke(10, stroke7, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer5.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font13 = lineAndShapeRenderer5.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke17 = lineAndShapeRenderer5.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke17);
        boolean boolean21 = lineAndShapeRenderer0.getItemShapeFilled((int) (byte) 0, 0);
        java.awt.Paint paint25 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 100, (int) (short) 1, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNull(font13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        int int31 = categoryPlot14.getDomainAxisCount();
        boolean boolean32 = categoryPlot14.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot14.zoomRangeAxes((double) (-1.0f), plotRenderingInfo35, point2D36, false);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace39, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot14.getDomainMarkers(0, layer20);
        categoryPlot14.setForegroundAlpha((float) (short) 1);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = categoryPlot14.getOrientation();
        java.lang.Object obj25 = categoryPlot14.clone();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer4.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer4.setBaseCreateEntities(false, true);
        lineAndShapeRenderer4.setAutoPopulateSeriesPaint(false);
        boolean boolean12 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) lineAndShapeRenderer4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseCreateEntities();
        java.awt.Paint paint3 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(false, true);
        java.awt.Paint paint7 = null;
        try {
            lineAndShapeRenderer0.setBaseOutlinePaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        java.awt.Shape shape7 = renderAttributes1.getItemShape(3, 15);
        java.awt.Paint paint8 = renderAttributes1.getDefaultFillPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        int int38 = categoryPlot17.getRendererCount();
        java.lang.Comparable comparable39 = categoryPlot17.getDomainCrosshairRowKey();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot17.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(comparable39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getDomainMarkers((-8458323), layer2);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        renderAttributes1.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint9 = renderAttributes1.getItemFillPaint(4, 3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.data.general.Dataset dataset10 = legendItem7.getDataset();
        java.awt.Paint paint11 = legendItem7.getFillPaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = legendItem7.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        java.util.List list18 = categoryPlot14.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot14.addDomainMarker((int) (short) -1, categoryMarker20, layer21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(list18);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 10.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Font font6 = categoryAxis1.getTickLabelFont();
        java.awt.Paint paint8 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 1.0f);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer15.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        lineAndShapeRenderer15.setBaseFillPaint((java.awt.Paint) color19);
        java.lang.String str21 = color19.toString();
        lineAndShapeRenderer10.setSeriesOutlinePaint(10, (java.awt.Paint) color19);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color24 = java.awt.Color.ORANGE;
        float[] floatArray30 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray31 = color24.getRGBComponents(floatArray30);
        float[] floatArray32 = color23.getRGBColorComponents(floatArray30);
        float[] floatArray33 = color19.getComponents(floatArray32);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (short) 10, (java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str21.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        categoryPlot17.setFixedRangeAxisSpace(axisSpace38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot17.zoomDomainAxes(100.0d, (double) 3, plotRenderingInfo42, point2D43);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke53 = null;
        lineAndShapeRenderer51.setSeriesStroke(10, stroke53, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator57 = lineAndShapeRenderer51.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint58 = lineAndShapeRenderer51.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis47, valueAxis48, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer51);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder60 = categoryPlot59.getDatasetRenderingOrder();
        categoryPlot17.setDatasetRenderingOrder(datasetRenderingOrder60);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(categoryToolTipGenerator57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(datasetRenderingOrder60);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Shape shape3 = barRenderer0.lookupSeriesShape(0);
        double double4 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator6, false);
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color2 = java.awt.Color.ORANGE;
        float[] floatArray8 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray9 = color2.getRGBComponents(floatArray8);
        float[] floatArray10 = color1.getRGBColorComponents(floatArray8);
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER", (java.awt.Paint) color1);
        legendItem11.setDescription("rect");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        int int17 = lineAndShapeRenderer16.getPassCount();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer19.isDrawBarOutline();
        org.jfree.chart.renderer.category.BarPainter barPainter21 = barRenderer19.getBarPainter();
        barRenderer19.setMinimumBarLength((double) 3);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer25.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font30 = lineAndShapeRenderer25.getSeriesItemLabelFont((int) (byte) 100);
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer25.setBaseItemLabelFont(font31);
        barRenderer19.setSeriesItemLabelFont((int) (byte) 0, font31);
        lineAndShapeRenderer16.setLegendTextFont(100, font31);
        legendItem11.setLabelFont(font31);
        java.awt.Shape shape40 = null;
        java.awt.Stroke stroke41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint42 = null;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape40, stroke41, paint42);
        legendItem43.setShapeVisible(false);
        java.awt.Paint paint46 = legendItem43.getFillPaint();
        legendItem11.setLabelPaint(paint46);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(barPainter21);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        renderAttributes1.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint8 = renderAttributes1.getSeriesOutlinePaint(5);
        java.awt.Paint paint10 = null;
        renderAttributes1.setSeriesFillPaint(15, paint10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        categoryPlot14.setNotify(true);
        double double30 = categoryPlot14.getAnchorValue();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Shape shape10 = lineAndShapeRenderer2.getSeriesShape(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator11, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis15.setTickLabelPaint((java.awt.Paint) color18);
        java.awt.Paint paint20 = categoryAxis15.getTickMarkPaint();
        lineAndShapeRenderer2.setBasePaint(paint20, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextPaint();
        java.awt.Shape shape26 = defaultDrawingSupplier24.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke35 = null;
        lineAndShapeRenderer33.setSeriesStroke(10, stroke35, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = lineAndShapeRenderer33.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint40 = lineAndShapeRenderer33.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        boolean boolean42 = categoryPlot41.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double48 = rectangleInsets47.getTop();
        categoryPlot41.setInsets(rectangleInsets47, true);
        java.awt.geom.GeneralPath generalPath51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.RenderingSource renderingSource53 = null;
        categoryPlot41.select(generalPath51, rectangle2D52, renderingSource53);
        categoryPlot41.setNotify(true);
        boolean boolean57 = categoryPlot41.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity60 = new org.jfree.chart.entity.PlotEntity(shape26, (org.jfree.chart.plot.Plot) categoryPlot41, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        lineAndShapeRenderer2.setSeriesShape((int) (byte) 0, shape26, false);
        lineAndShapeRenderer2.removeAnnotations();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(categoryToolTipGenerator39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.0d + "'", double48 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }
}

