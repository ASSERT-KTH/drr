import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        try {
            lineAndShapeRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis5, valueAxis6, categoryDataset7, (int) (byte) 100, (int) '#', true, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = lineAndShapeRenderer2.createHotSpotBounds(graphics2D5, rectangle2D6, categoryPlot7, categoryAxis8, valueAxis9, categoryDataset10, (int) (short) 100, (-1), false, categoryItemRendererState14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        float[] floatArray4 = new float[] { (short) 1 };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB((int) (byte) 10, (int) (short) 0, 0, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener5 = null;
        try {
            lineAndShapeRenderer2.removeChangeListener(rendererChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        try {
            lineAndShapeRenderer0.setSeriesVisible((int) (byte) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = null;
        try {
            lineAndShapeRenderer0.setBaseOutlinePaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseCreateEntities();
        try {
            lineAndShapeRenderer0.setSeriesVisible((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = null;
        try {
            boolean boolean19 = lineAndShapeRenderer2.hitTest((double) (short) -1, (double) 0L, graphics2D9, rectangle2D10, categoryPlot11, categoryAxis12, valueAxis13, categoryDataset14, (int) (byte) -1, (int) (short) 100, false, categoryItemRendererState18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) -1, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.ORANGE;
        float[] floatArray11 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray12 = color5.getRGBComponents(floatArray11);
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer14.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color18 = java.awt.Color.ORANGE;
        lineAndShapeRenderer14.setBaseFillPaint((java.awt.Paint) color18);
        java.lang.String str20 = color18.toString();
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color18.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        try {
            org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "hi!", shape4, (java.awt.Paint) color5, stroke13, (java.awt.Paint) color18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str20.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertNotNull(paintContext26);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = lineAndShapeRenderer0.createHotSpotBounds(graphics2D1, rectangle2D2, categoryPlot3, categoryAxis4, valueAxis5, categoryDataset6, (int) ' ', (int) (short) 10, true, categoryItemRendererState10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 100, 10.0f, (float) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-123) + "'", int3 == (-123));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer6.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color10 = java.awt.Color.ORANGE;
        lineAndShapeRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        try {
            org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "hi!", "", "java.awt.Color[r=255,g=200,b=0]", shape4, stroke5, (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        try {
            lineAndShapeRenderer0.setSeriesVisible((-123), (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean6 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        lineAndShapeRenderer0.setBaseCreateEntities(false, true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean17 = itemLabelPosition15.equals((java.lang.Object) 8);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) ' ');
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke13 = null;
        lineAndShapeRenderer11.setSeriesStroke(10, stroke13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = lineAndShapeRenderer11.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean18 = lineAndShapeRenderer11.getBaseItemLabelsVisible();
        lineAndShapeRenderer11.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer11.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        try {
            lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) -1, itemLabelPosition24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity4 = new org.jfree.chart.entity.PlotEntity(shape0, plot1, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke14 = null;
        lineAndShapeRenderer12.setSeriesStroke(10, stroke14, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = lineAndShapeRenderer12.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        lineAndShapeRenderer12.setBaseURLGenerator(categoryURLGenerator19);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer12.setSeriesStroke((int) 'a', stroke22);
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke22);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = lineAndShapeRenderer2.getSeriesItemLabelGenerator((int) (short) 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = lineAndShapeRenderer2.getSeriesItemLabelGenerator((int) (short) 1);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset12 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo13 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) categoryItemLabelGenerator11, (org.jfree.data.general.Dataset) abstractCategoryDataset12, datasetChangeInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        java.awt.Color color22 = java.awt.Color.ORANGE;
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color22);
        lineAndShapeRenderer2.setSeriesShapesVisible(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) "java.awt.Color[r=255,g=200,b=0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (java.awt.Color[r=255,g=200,b=0]) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.Color color12 = java.awt.Color.ORANGE;
        float[] floatArray18 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray19 = color12.getRGBComponents(floatArray18);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = null;
        lineAndShapeRenderer22.setBaseURLGenerator(categoryURLGenerator29);
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer22.setSeriesStroke((int) 'a', stroke32);
        try {
            lineAndShapeRenderer0.drawDomainLine(graphics2D8, categoryPlot9, rectangle2D10, (double) 100.0f, (java.awt.Paint) color12, stroke32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.GREEN;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "hi!", "", shape4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) -1);
        java.awt.Shape shape11 = null;
        try {
            lineAndShapeRenderer0.setLegendShape((-123), shape11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color4 = java.awt.Color.ORANGE;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) (byte) 1);
        boolean boolean8 = lineAndShapeRenderer0.getDrawOutlines();
        try {
            lineAndShapeRenderer0.setSeriesShapesFilled((-1), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100, (double) (short) 1, (double) '4', (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        legendItem7.setToolTipText("hi!");
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        try {
            barRenderer0.setMinimumBarLength((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'min' >= 0.0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.clear();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (1.0) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState1 = null;
        abstractCategoryDataset0.setSelectionState(categoryDatasetSelectionState1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener1 = null;
        abstractCategoryDataset0.removeChangeListener(datasetChangeListener1);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState3 = abstractCategoryDataset0.getSelectionState();
        org.junit.Assert.assertNull(categoryDatasetSelectionState3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.data.general.Dataset dataset10 = legendItem7.getDataset();
        java.awt.Shape shape11 = legendItem7.getLine();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertNull(shape11);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = null;
        try {
            abstractCategoryDataset0.setGroup(datasetGroup1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str1.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis11.setTickLabelPaint((java.awt.Paint) color14);
        java.awt.Paint paint16 = categoryAxis11.getTickMarkPaint();
        categoryAxis11.setTickLabelsVisible(false);
        org.jfree.chart.plot.Plot plot19 = categoryAxis11.getPlot();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            lineAndShapeRenderer0.drawAnnotations(graphics2D8, rectangle2D9, categoryAxis11, valueAxis20, layer21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer7.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color11 = java.awt.Color.ORANGE;
        lineAndShapeRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke19 = null;
        lineAndShapeRenderer17.setSeriesStroke(10, stroke19, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = lineAndShapeRenderer17.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean24 = lineAndShapeRenderer17.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke29 = null;
        lineAndShapeRenderer27.setSeriesStroke(10, stroke29, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = lineAndShapeRenderer27.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = null;
        lineAndShapeRenderer27.setBaseURLGenerator(categoryURLGenerator34);
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer27.setSeriesStroke((int) 'a', stroke37);
        lineAndShapeRenderer17.setBaseOutlineStroke(stroke37);
        java.awt.Shape shape41 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke46 = null;
        lineAndShapeRenderer44.setSeriesStroke(10, stroke46, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = lineAndShapeRenderer44.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator51 = null;
        lineAndShapeRenderer44.setBaseURLGenerator(categoryURLGenerator51);
        java.awt.Stroke stroke54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer44.setSeriesStroke((int) 'a', stroke54);
        java.awt.Color color56 = java.awt.Color.black;
        try {
            org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem(attributedString0, "", "java.awt.Color[r=255,g=200,b=0]", "hi!", false, shape5, false, (java.awt.Paint) color11, false, (java.awt.Paint) color14, stroke37, false, shape41, stroke54, (java.awt.Paint) color56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(categoryToolTipGenerator50);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color56);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean6 = lineAndShapeRenderer5.getBaseCreateEntities();
        java.awt.Paint paint8 = lineAndShapeRenderer5.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer2.setBasePaint(paint8);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            boolean boolean17 = categoryPlot14.removeAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, true);
        try {
            lineAndShapeRenderer0.setSeriesLinesVisible((int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 'a', (double) 'a', 0.0d, (double) 1.0f);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.lang.String str6 = categoryAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        float float9 = categoryAxis1.getMinorTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            org.jfree.chart.axis.AxisState axisState18 = categoryAxis1.draw(graphics2D10, (double) 100L, rectangle2D12, rectangle2D13, rectangleEdge16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        try {
            keyedObjects0.insertValue((int) 'a', (java.lang.Comparable) 10.0f, (java.lang.Object) paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesItemLabelsVisible((int) '4');
        boolean boolean8 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        try {
            lineAndShapeRenderer0.setSeriesToolTipGenerator((-1), categoryToolTipGenerator10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        try {
            categoryPlot14.zoom((double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.chart.util.Layer layer31 = null;
        try {
            categoryPlot14.addRangeMarker((-2), marker30, layer31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation13);
        try {
            double double15 = categoryAxis1.getCategoryEnd(10, 100, rectangle2D11, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.clear();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (hi!) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        keyedObjects0.insertValue(0, (java.lang.Comparable) (short) 1, (java.lang.Object) 0.0f);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (-2));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (-2) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        int int1 = defaultShadowGenerator0.calculateOffsetX();
        java.awt.image.BufferedImage bufferedImage2 = null;
        try {
            java.awt.image.BufferedImage bufferedImage3 = defaultShadowGenerator0.createDropShadow(bufferedImage2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.util.Layer layer30 = null;
        try {
            boolean boolean31 = categoryPlot14.removeRangeMarker(marker29, layer30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer5.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        lineAndShapeRenderer5.setBaseFillPaint((java.awt.Paint) color9);
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color9);
        float[] floatArray13 = new float[] { 100.0f };
        try {
            float[] floatArray14 = color9.getRGBComponents(floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftInset((-1.0d));
        categoryAxis1.setLabelInsets(rectangleInsets5, false);
        java.awt.Stroke stroke10 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        try {
            double double17 = categoryAxis1.getCategoryMiddle((-123), (-1), rectangle2D13, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -123");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        try {
            booleanList0.setBoolean((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getLabelPaint();
        categoryAxis1.setTickMarkInsideLength((float) (-1));
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation16);
        try {
            double double18 = categoryAxis1.getCategorySeriesMiddle(0, 10, (int) 'a', (int) (short) 0, (double) (byte) 0, rectangle2D14, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = lineAndShapeRenderer2.getSeriesURLGenerator((int) '4');
        java.awt.Paint paint15 = lineAndShapeRenderer2.getItemLabelPaint((int) (byte) -1, (int) '4', false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState35 = null;
        boolean boolean36 = categoryPlot14.render(graphics2D31, rectangle2D32, (int) '4', plotRenderingInfo34, categoryCrosshairState35);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = null;
        org.jfree.chart.util.Layer layer38 = null;
        try {
            categoryPlot14.addDomainMarker(categoryMarker37, layer38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftInset((-1.0d));
        categoryAxis1.setLabelInsets(rectangleInsets5, false);
        java.awt.Stroke stroke10 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        try {
            double double17 = categoryAxis1.getCategoryEnd((int) ' ', (int) '#', rectangle2D13, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        int int6 = color4.getRGB();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-16777024) + "'", int6 == (-16777024));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        try {
            int int18 = categoryPlot14.getRangeAxisIndex(valueAxis17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.data.KeyedObjects keyedObjects32 = new org.jfree.data.KeyedObjects();
        java.util.List list33 = keyedObjects32.getKeys();
        try {
            categoryPlot14.mapDatasetToDomainAxes((int) (short) 100, list33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity8 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "TextAnchor.HALF_ASCENT_CENTER", "", categoryDataset5, (java.lang.Comparable) (short) 0, (java.lang.Comparable) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        int int16 = categoryPlot14.getWeight();
        categoryPlot14.setDrawSharedDomainAxis(false);
        categoryPlot14.clearDomainMarkers();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot14.getDatasetRenderingOrder();
        categoryPlot14.clearRangeAxes();
        java.awt.Paint paint17 = null;
        try {
            categoryPlot14.setDomainGridlinePaint(paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint5 = defaultDrawingSupplier4.getNextPaint();
        java.awt.Shape shape6 = defaultDrawingSupplier4.getNextShape();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis9.setTickLabelPaint((java.awt.Paint) color12);
        java.awt.Paint paint14 = categoryAxis9.getLabelPaint();
        categoryAxis9.setMinorTickMarkOutsideLength((float) (byte) 10);
        double double17 = categoryAxis9.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke26 = null;
        lineAndShapeRenderer24.setSeriesStroke(10, stroke26, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = lineAndShapeRenderer24.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint31 = lineAndShapeRenderer24.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        boolean boolean33 = categoryPlot32.isRangeGridlinesVisible();
        java.awt.Stroke stroke34 = categoryPlot32.getRangeZeroBaselineStroke();
        categoryAxis9.setTickMarkStroke(stroke34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis37.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis37.setTickLabelPaint((java.awt.Paint) color40);
        java.awt.Paint paint42 = categoryAxis37.getTickMarkPaint();
        categoryAxis37.setTickLabelsVisible(false);
        java.awt.Color color48 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis37.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color48);
        try {
            org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem(attributedString0, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "TextAnchor.HALF_ASCENT_CENTER", "", shape6, (java.awt.Paint) color7, stroke34, (java.awt.Paint) color48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setTickLabelsVisible(true);
        java.awt.Stroke stroke8 = categoryAxis1.getTickMarkStroke();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation13);
        try {
            java.util.List list15 = categoryAxis1.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot14.getDatasetRenderingOrder();
        categoryPlot14.clearRangeAxes();
        boolean boolean17 = categoryPlot14.isDomainZoomable();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        boolean boolean3 = unitType0.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot14.getRangeAxis(100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            categoryPlot14.handleClick((int) (short) -1, (int) (byte) 10, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(valueAxis25);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, true);
        java.awt.Color color11 = java.awt.Color.ORANGE;
        float[] floatArray17 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray18 = color11.getRGBComponents(floatArray17);
        lineAndShapeRenderer0.setSeriesFillPaint(10, (java.awt.Paint) color11);
        java.lang.Boolean boolean21 = lineAndShapeRenderer0.getSeriesShapesFilled((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNull(boolean21);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint7 = null;
        try {
            categoryAxis1.setTickMarkPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer5.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        lineAndShapeRenderer5.setBaseFillPaint((java.awt.Paint) color9);
        java.lang.String str11 = color9.toString();
        lineAndShapeRenderer0.setSeriesOutlinePaint(10, (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer13.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = null;
        barRenderer13.setGradientPaintTransformer(gradientPaintTransformer15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean20 = lineAndShapeRenderer17.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = lineAndShapeRenderer17.removeAnnotation(categoryAnnotation21);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer17.getSeriesNegativeItemLabelPosition((int) ' ');
        org.jfree.chart.text.TextAnchor textAnchor25 = itemLabelPosition24.getTextAnchor();
        barRenderer13.setBaseNegativeItemLabelPosition(itemLabelPosition24);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition24, true);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis32.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis32.setTickLabelPaint((java.awt.Paint) color35);
        java.awt.Paint paint37 = categoryAxis32.getTickMarkPaint();
        categoryAxis32.setTickLabelsVisible(false);
        float float40 = categoryAxis32.getMinorTickMarkOutsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.util.Layer layer42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        try {
            lineAndShapeRenderer0.drawAnnotations(graphics2D29, rectangle2D30, categoryAxis32, valueAxis41, layer42, plotRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str11.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 2.0f + "'", float40 == 2.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            boolean boolean18 = categoryPlot14.removeAnnotation(categoryAnnotation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator37 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator38 = null;
        try {
            java.lang.String str39 = plotEntity36.getImageMapAreaTag(toolTipTagFragmentGenerator37, uRLTagFragmentGenerator38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("GradientPaintTransformType.CENTER_VERTICAL");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name GradientPaintTransformType.CENTER_VERTICAL, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setSeriesStroke((int) 'a', stroke12);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) '#', categoryItemLabelGenerator15, false);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis21.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color24);
        categoryAxis21.setTickLabelsVisible(true);
        java.awt.Stroke stroke28 = categoryAxis21.getTickMarkStroke();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.util.Layer layer30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            lineAndShapeRenderer2.drawAnnotations(graphics2D18, rectangle2D19, categoryAxis21, valueAxis29, layer30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        java.lang.Comparable comparable3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        try {
            keyedObjects0.insertValue((int) (byte) -1, comparable3, (java.lang.Object) stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font10 = lineAndShapeRenderer2.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke14 = lineAndShapeRenderer2.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        boolean boolean15 = lineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator16);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color4 = java.awt.Color.ORANGE;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) (byte) 1);
        boolean boolean8 = lineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        try {
            lineAndShapeRenderer0.setSeriesItemLabelGenerator((-123), categoryItemLabelGenerator10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("TextAnchor.HALF_ASCENT_CENTER");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Paint paint4 = lineAndShapeRenderer2.lookupSeriesOutlinePaint((-1));
        java.lang.Object obj5 = lineAndShapeRenderer2.clone();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer11.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        boolean boolean15 = lineAndShapeRenderer11.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer16.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color20 = java.awt.Color.ORANGE;
        lineAndShapeRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        lineAndShapeRenderer11.setBaseFillPaint((java.awt.Paint) color20);
        try {
            lineAndShapeRenderer2.setSeriesFillPaint((int) (short) -1, (java.awt.Paint) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        java.awt.Color color22 = java.awt.Color.ORANGE;
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color22);
        boolean boolean24 = lineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        lineAndShapeRenderer2.clearSeriesPaints(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot14.getDatasetRenderingOrder();
        java.lang.String str16 = datasetRenderingOrder15.toString();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str16.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) -1);
        java.awt.Shape shape10 = null;
        lineAndShapeRenderer0.setBaseLegendShape(shape10);
        java.awt.Stroke stroke15 = lineAndShapeRenderer0.getItemOutlineStroke((-2), 0, false);
        java.awt.Paint paint19 = lineAndShapeRenderer0.getItemOutlinePaint(0, (int) (byte) 1, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects keyedObjects33 = new org.jfree.data.KeyedObjects();
        java.util.List list34 = keyedObjects33.getKeys();
        try {
            categoryPlot14.mapDatasetToRangeAxes(100, list34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            categoryPlot14.drawBackground(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color4 = java.awt.Color.ORANGE;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) (byte) 1);
        boolean boolean8 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        int int31 = categoryPlot14.getDomainAxisCount();
        org.jfree.data.KeyedObjects keyedObjects33 = new org.jfree.data.KeyedObjects();
        java.util.List list34 = keyedObjects33.getKeys();
        java.util.List list35 = keyedObjects33.getKeys();
        try {
            categoryPlot14.mapDatasetToDomainAxes((-123), list35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Shape shape10 = lineAndShapeRenderer2.getSeriesShape(0);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(shape10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke14 = null;
        lineAndShapeRenderer12.setSeriesStroke(10, stroke14, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = lineAndShapeRenderer12.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        lineAndShapeRenderer12.setBaseURLGenerator(categoryURLGenerator19);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer12.setSeriesStroke((int) 'a', stroke22);
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke22);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean27 = barRenderer26.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer28 = null;
        barRenderer26.setGradientPaintTransformer(gradientPaintTransformer28);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean33 = lineAndShapeRenderer30.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation34 = null;
        boolean boolean35 = lineAndShapeRenderer30.removeAnnotation(categoryAnnotation34);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = lineAndShapeRenderer30.getSeriesNegativeItemLabelPosition((int) ' ');
        org.jfree.chart.text.TextAnchor textAnchor38 = itemLabelPosition37.getTextAnchor();
        barRenderer26.setBaseNegativeItemLabelPosition(itemLabelPosition37);
        try {
            lineAndShapeRenderer2.setSeriesNegativeItemLabelPosition((-16777024), itemLabelPosition37, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(textAnchor38);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryAxis2.isAxisLineVisible();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 0, (-16777024), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke20, false);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke34 = null;
        lineAndShapeRenderer32.setSeriesStroke(10, stroke34, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator38 = lineAndShapeRenderer32.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint39 = lineAndShapeRenderer32.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis28, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer32);
        boolean boolean41 = categoryPlot40.isRangeGridlinesVisible();
        java.awt.Stroke stroke42 = categoryPlot40.getRangeZeroBaselineStroke();
        categoryPlot40.setRangePannable(false);
        int int45 = categoryPlot40.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis47.setMaximumCategoryLabelWidthRatio((float) 100);
        double double50 = categoryAxis47.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double53 = rectangleInsets51.calculateLeftInset((-1.0d));
        categoryAxis47.setLabelInsets(rectangleInsets51, false);
        java.awt.Stroke stroke56 = categoryAxis47.getTickMarkStroke();
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset58 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            lineAndShapeRenderer2.drawItem(graphics2D23, categoryItemRendererState24, rectangle2D25, categoryPlot40, categoryAxis47, valueAxis57, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset58, (int) (short) 1, 192, true, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(categoryToolTipGenerator38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.2d + "'", double50 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        renderAttributes1.setDefaultCreateEntity((java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer8.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        barRenderer8.setGradientPaintTransformer(gradientPaintTransformer10);
        barRenderer8.setMinimumBarLength((double) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.data.Range range16 = barRenderer8.findRangeBounds(categoryDataset14, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer17.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font22 = lineAndShapeRenderer17.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean23 = lineAndShapeRenderer17.getAutoPopulateSeriesFillPaint();
        java.awt.Font font24 = lineAndShapeRenderer17.getBaseItemLabelFont();
        barRenderer8.setBaseLegendTextFont(font24);
        try {
            renderAttributes1.setSeriesLabelFont((-2), font24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer7.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color11 = java.awt.Color.ORANGE;
        lineAndShapeRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        boolean boolean13 = barRenderer0.equals((java.lang.Object) color11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        java.awt.Stroke stroke15 = lineAndShapeRenderer2.getItemOutlineStroke(3, 0, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        int int37 = categoryPlot17.getRangeAxisCount();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setDefaultEntityRadius((int) ' ');
        java.awt.Stroke stroke7 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(0);
        boolean boolean8 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent2.setChart(jFreeChart3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent2.getType();
        java.lang.String str6 = chartChangeEvent2.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str6.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) (-1L));
        selectableValue1.setSelected(false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        java.awt.Color color22 = java.awt.Color.ORANGE;
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color22);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer24.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        lineAndShapeRenderer24.setBaseFillPaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean33 = lineAndShapeRenderer30.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation34 = null;
        boolean boolean35 = lineAndShapeRenderer30.removeAnnotation(categoryAnnotation34);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = lineAndShapeRenderer30.getSeriesNegativeItemLabelPosition((int) ' ');
        lineAndShapeRenderer24.setBasePositiveItemLabelPosition(itemLabelPosition37);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition37);
        double double40 = itemLabelPosition37.getAngle();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setDefaultEntityRadius((int) ' ');
        java.awt.Stroke stroke7 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(0);
        lineAndShapeRenderer0.setBaseLinesVisible(false);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.Marker marker17 = null;
        try {
            categoryPlot14.addRangeMarker(marker17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        try {
            categoryPlot14.mapDatasetToDomainAxis((int) (byte) -1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.Stroke stroke24 = categoryPlot14.getRangeMinorGridlineStroke();
        double double25 = categoryPlot14.getAnchorValue();
        try {
            org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot14.getDomainAxisForDataset((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = lineAndShapeRenderer0.getSeriesPositiveItemLabelPosition((int) '#');
        boolean boolean4 = lineAndShapeRenderer0.isSeriesVisibleInLegend(8);
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        java.lang.String str3 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.2d);
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation10);
        try {
            double double12 = categoryAxis1.getCategoryEnd((int) '#', (int) (short) 1, rectangle2D8, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        try {
            categoryPlot17.addAnnotation(categoryAnnotation38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("java.awt.Color[r=255,g=200,b=0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot14.getDataset();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryDataset18);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer0.getBarPainter();
        barRenderer0.setBase(1.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertNull(itemLabelPosition5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer5.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        lineAndShapeRenderer5.setBaseFillPaint((java.awt.Paint) color9);
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke21 = null;
        lineAndShapeRenderer19.setSeriesStroke(10, stroke21, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = lineAndShapeRenderer19.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint26 = lineAndShapeRenderer19.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        boolean boolean28 = categoryPlot27.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double34 = rectangleInsets33.getTop();
        categoryPlot27.setInsets(rectangleInsets33, true);
        java.awt.geom.GeneralPath generalPath37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.RenderingSource renderingSource39 = null;
        categoryPlot27.select(generalPath37, rectangle2D38, renderingSource39);
        categoryPlot27.setNotify(true);
        boolean boolean43 = categoryPlot27.isNotify();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis48.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis48.setTickLabelPaint((java.awt.Paint) color51);
        java.awt.Paint paint53 = categoryAxis48.getTickMarkPaint();
        categoryAxis48.setTickLabelsVisible(false);
        java.awt.Color color59 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis48.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color59);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke65 = null;
        lineAndShapeRenderer63.setSeriesStroke(10, stroke65, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator69 = lineAndShapeRenderer63.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator70 = null;
        lineAndShapeRenderer63.setBaseURLGenerator(categoryURLGenerator70);
        java.awt.Stroke stroke73 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer63.setSeriesStroke((int) 'a', stroke73);
        try {
            lineAndShapeRenderer0.drawRangeLine(graphics2D12, categoryPlot27, valueAxis44, rectangle2D45, (-1.0d), (java.awt.Paint) color59, stroke73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryToolTipGenerator25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNull(categoryToolTipGenerator69);
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.clear();
        java.lang.Comparable comparable2 = null;
        try {
            java.lang.Object obj3 = keyedObjects0.getObject(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Paint paint0 = null;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { paint0 };
        java.awt.Paint paint2 = null;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { paint2 };
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] {};
        java.awt.Stroke stroke5 = null;
        java.awt.Stroke[] strokeArray6 = new java.awt.Stroke[] { stroke5 };
        java.awt.Stroke stroke7 = null;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke7 };
        java.awt.Shape[] shapeArray9 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray3, paintArray4, strokeArray6, strokeArray8, shapeArray9);
        java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(shapeArray9);
        org.junit.Assert.assertNull(stroke11);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Color color12 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12);
        int int14 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setLabel("GradientPaintTransformType.CENTER_VERTICAL");
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean20 = categoryPlot14.removeDomainMarker((int) (short) 1, marker17, layer18, true);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setRangeAxisLocation((int) 'a', axisLocation22);
        org.jfree.data.KeyedObjects keyedObjects25 = new org.jfree.data.KeyedObjects();
        java.util.List list26 = keyedObjects25.getKeys();
        java.util.List list27 = keyedObjects25.getKeys();
        try {
            categoryPlot14.mapDatasetToDomainAxes(3, list27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 192);
        org.jfree.chart.plot.Plot plot3 = categoryAxis0.getPlot();
        categoryAxis0.setTickMarkInsideLength((float) 255);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("TextAnchor.HALF_ASCENT_CENTER");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        java.lang.Throwable throwable3 = null;
        try {
            unknownKeyException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        java.awt.Shape shape6 = renderAttributes1.getSeriesShape(2);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer8.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font13 = lineAndShapeRenderer8.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean14 = lineAndShapeRenderer8.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean16 = lineAndShapeRenderer15.getBaseCreateEntities();
        java.awt.Paint paint18 = lineAndShapeRenderer15.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer8.setBaseFillPaint(paint18, false);
        try {
            renderAttributes1.setSeriesFillPaint((-1), paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis1.setTickMarkOutsideLength(0.0f);
        java.lang.String str6 = categoryAxis1.getLabelURL();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 100L);
        float float9 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((-1.0d));
        double double4 = rectangleInsets0.calculateRightInset((double) 100L);
        double double6 = rectangleInsets0.calculateRightOutset((double) 192);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot14.zoomDomainAxes((double) (byte) -1, (double) 10, plotRenderingInfo33, point2D34);
        float float36 = categoryPlot14.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.5f + "'", float36 == 0.5f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem1.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        java.awt.Font font4 = legendItem1.getLabelFont();
        boolean boolean5 = legendItem1.isShapeOutlineVisible();
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) (-1L));
        boolean boolean2 = selectableValue1.isSelected();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        boolean boolean31 = categoryPlot14.isRangeCrosshairVisible();
        java.util.List list32 = categoryPlot14.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot14.getAxisOffset();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(list32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font10 = lineAndShapeRenderer2.getLegendTextFont((int) 'a');
        java.awt.Stroke stroke14 = lineAndShapeRenderer2.getItemOutlineStroke((int) ' ', (int) (short) 1, true);
        boolean boolean15 = lineAndShapeRenderer2.getUseFillPaint();
        lineAndShapeRenderer2.setBaseSeriesVisible(false, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot14.getRangeAxis(100);
        java.awt.Paint paint26 = categoryPlot14.getRangeMinorGridlinePaint();
        float float27 = categoryPlot14.getBackgroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot14.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace29 = categoryPlot14.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNull(axisSpace29);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint5 = defaultDrawingSupplier4.getNextPaint();
        java.awt.Shape shape6 = defaultDrawingSupplier4.getNextShape();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int8 = color7.getGreen();
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem(attributedString0, "UnitType.ABSOLUTE", "UnitType.ABSOLUTE", "DatasetRenderingOrder.REVERSE", shape6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d, jFreeChart3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent4.setChart(jFreeChart5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = chartChangeEvent4.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) strokeArray0, jFreeChart1, chartChangeEventType7);
        java.lang.String str9 = chartChangeEventType7.toString();
        org.junit.Assert.assertNotNull(strokeArray0);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str9.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setDefaultEntityRadius((int) ' ');
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis1.setTickMarkOutsideLength(0.0f);
        java.lang.String str6 = categoryAxis1.getLabelURL();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 100L);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis10.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis10.setTickLabelPaint((java.awt.Paint) color13);
        java.awt.Font font15 = categoryAxis10.getTickLabelFont();
        categoryAxis1.setLabelFont(font15);
        int int17 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState35 = null;
        boolean boolean36 = categoryPlot14.render(graphics2D31, rectangle2D32, (int) '4', plotRenderingInfo34, categoryCrosshairState35);
        java.awt.Stroke stroke37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        categoryPlot14.setDomainGridlineStroke(stroke37);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Shape shape3 = barRenderer0.lookupSeriesShape(0);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis8.setTickLabelPaint((java.awt.Paint) color11);
        java.awt.Paint paint13 = categoryAxis8.getLabelPaint();
        categoryAxis8.setMinorTickMarkOutsideLength((float) (byte) 10);
        double double16 = categoryAxis8.getUpperMargin();
        categoryAxis8.setCategoryMargin((double) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke28 = null;
        lineAndShapeRenderer26.setSeriesStroke(10, stroke28, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator32 = lineAndShapeRenderer26.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint33 = lineAndShapeRenderer26.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer26);
        boolean boolean35 = categoryPlot34.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double41 = rectangleInsets40.getTop();
        categoryPlot34.setInsets(rectangleInsets40, true);
        java.awt.geom.GeneralPath generalPath44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.RenderingSource renderingSource46 = null;
        categoryPlot34.select(generalPath44, rectangle2D45, renderingSource46);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { valueAxis48 };
        categoryPlot34.setRangeAxes(valueAxisArray49);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor51 = categoryPlot34.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis53.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis53.setTickLabelPaint((java.awt.Paint) color56);
        java.awt.Paint paint58 = categoryAxis53.getTickMarkPaint();
        categoryPlot34.setDomainGridlinePaint(paint58);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset60 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset60.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int65 = categoryPlot34.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset60);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState66 = defaultCategoryDataset60.getSelectionState();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState70 = null;
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D72 = barRenderer0.createHotSpotBounds(graphics2D4, rectangle2D5, categoryPlot6, categoryAxis8, valueAxis19, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset60, (int) (byte) 100, 0, false, categoryItemRendererState70, rectangle2D71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNull(categoryToolTipGenerator32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.0d + "'", double41 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(categoryAnchor51);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState66);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            boolean boolean18 = categoryPlot14.removeAnnotation(categoryAnnotation16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot14.zoomRangeAxes((double) 100, plotRenderingInfo17, point2D18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot14.zoomRangeAxes((double) 5, plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        try {
            categoryPlot14.setDomainAxisLocation(0, axisLocation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.Stroke stroke24 = categoryPlot14.getRangeMinorGridlineStroke();
        double double25 = categoryPlot14.getAnchorValue();
        java.awt.geom.GeneralPath generalPath26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.RenderingSource renderingSource28 = null;
        categoryPlot14.select(generalPath26, rectangle2D27, renderingSource28);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean6 = lineAndShapeRenderer5.getBaseCreateEntities();
        java.awt.Paint paint8 = lineAndShapeRenderer5.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer2.setBasePaint(paint8);
        java.awt.Shape shape13 = lineAndShapeRenderer2.getItemShape((int) (short) 1, 192, false);
        java.awt.Paint paint15 = lineAndShapeRenderer2.lookupSeriesPaint(15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer7.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        boolean boolean16 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double22 = rectangleInsets21.getTop();
        categoryPlot15.setInsets(rectangleInsets21, true);
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot15.select(generalPath25, rectangle2D26, renderingSource27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        categoryPlot15.setRangeAxes(valueAxisArray30);
        keyedObjects2D0.setObject((java.lang.Object) valueAxisArray30, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) (byte) 10);
        java.lang.Comparable comparable35 = null;
        try {
            java.lang.Object obj37 = keyedObjects2D0.getObject(comparable35, (java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray30);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        java.awt.Shape shape10 = null;
        try {
            legendItem7.setLine(shape10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'line' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        int int1 = defaultShadowGenerator0.calculateOffsetX();
        float float2 = defaultShadowGenerator0.getShadowOpacity();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke20, false);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = lineAndShapeRenderer2.getSeriesURLGenerator(255);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(categoryURLGenerator27);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean6 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getBaseItemLabelFont();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean11 = lineAndShapeRenderer8.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        boolean boolean13 = lineAndShapeRenderer8.removeAnnotation(categoryAnnotation12);
        boolean boolean14 = lineAndShapeRenderer8.getUseOutlinePaint();
        lineAndShapeRenderer8.setBaseSeriesVisible(false, true);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        float[] floatArray25 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray26 = color19.getRGBComponents(floatArray25);
        lineAndShapeRenderer8.setSeriesFillPaint(10, (java.awt.Paint) color19);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color19, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        keyedObjects0.insertValue(0, (java.lang.Comparable) (short) 1, (java.lang.Object) 0.0f);
        java.lang.Object obj6 = keyedObjects0.clone();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset40.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int45 = categoryPlot14.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        java.lang.Comparable comparable47 = null;
        java.lang.Comparable comparable48 = null;
        try {
            defaultCategoryDataset40.setValue((double) 0L, comparable47, comparable48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMinorTickMarkOutsideLength((float) (byte) 10);
        java.lang.String str9 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setCategoryMargin((double) 100.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem11.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType14 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str15 = gradientPaintTransformType14.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType14);
        legendItem11.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        legendItem7.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        legendItem7.setDescription("");
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str15.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean6 = lineAndShapeRenderer5.getBaseCreateEntities();
        java.awt.Paint paint8 = lineAndShapeRenderer5.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer2.setBasePaint(paint8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = lineAndShapeRenderer2.getLegendItems();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = lineAndShapeRenderer2.getSeriesItemLabelGenerator((int) (short) 1);
        java.awt.Shape shape13 = lineAndShapeRenderer2.getLegendShape((int) '4');
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(shape13);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        try {
            categoryPlot14.zoom((double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset40.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int45 = categoryPlot14.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot14.getRenderer(15);
        org.jfree.chart.util.SortOrder sortOrder48 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean50 = sortOrder48.equals((java.lang.Object) 1.0d);
        categoryPlot14.setColumnRenderingOrder(sortOrder48);
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace52);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer47);
        org.junit.Assert.assertNotNull(sortOrder48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem11.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType14 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str15 = gradientPaintTransformType14.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType14);
        legendItem11.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        legendItem7.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean22 = lineAndShapeRenderer19.getItemVisible(0, 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer25.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean29 = lineAndShapeRenderer28.getBaseCreateEntities();
        java.awt.Paint paint31 = lineAndShapeRenderer28.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer25.setBasePaint(paint31);
        java.awt.Shape shape36 = lineAndShapeRenderer25.getItemShape((int) (short) 1, 192, false);
        lineAndShapeRenderer19.setBaseLegendShape(shape36);
        legendItem7.setShape(shape36);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str15.equals("GradientPaintTransformType.CENTER_VERTICAL"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer7.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        boolean boolean16 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double22 = rectangleInsets21.getTop();
        categoryPlot15.setInsets(rectangleInsets21, true);
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot15.select(generalPath25, rectangle2D26, renderingSource27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        categoryPlot15.setRangeAxes(valueAxisArray30);
        keyedObjects2D0.setObject((java.lang.Object) valueAxisArray30, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) (byte) 10);
        try {
            keyedObjects2D0.removeRow((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray30);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseFillPaint();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot17.getRangeAxis(100);
        java.awt.Paint paint29 = categoryPlot17.getRangeMinorGridlinePaint();
        float float30 = categoryPlot17.getBackgroundAlpha();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D2, categoryPlot17, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke20, false);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke36 = null;
        lineAndShapeRenderer34.setSeriesStroke(10, stroke36, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = lineAndShapeRenderer34.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint41 = lineAndShapeRenderer34.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis30, valueAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        boolean boolean43 = categoryPlot42.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double49 = rectangleInsets48.getTop();
        categoryPlot42.setInsets(rectangleInsets48, true);
        java.awt.geom.GeneralPath generalPath52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.RenderingSource renderingSource54 = null;
        categoryPlot42.select(generalPath52, rectangle2D53, renderingSource54);
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray57 = new org.jfree.chart.axis.ValueAxis[] { valueAxis56 };
        categoryPlot42.setRangeAxes(valueAxisArray57);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor59 = categoryPlot42.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis61.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color64 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis61.setTickLabelPaint((java.awt.Paint) color64);
        java.awt.Paint paint66 = categoryAxis61.getTickMarkPaint();
        categoryPlot42.setDomainGridlinePaint(paint66);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset68 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset68.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int73 = categoryPlot42.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset68);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState74 = defaultCategoryDataset68.getSelectionState();
        org.jfree.data.Range range75 = lineAndShapeRenderer2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset68);
        try {
            java.lang.Comparable comparable77 = defaultCategoryDataset68.getRowKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(categoryToolTipGenerator40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.0d + "'", double49 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray57);
        org.junit.Assert.assertNotNull(categoryAnchor59);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState74);
        org.junit.Assert.assertNotNull(range75);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        java.awt.Stroke stroke32 = categoryPlot14.getRangeGridlineStroke();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke20, false);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent26);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseLegendTextFont();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(font28);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent2.setChart(jFreeChart3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent2.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = chartChangeEvent2.getType();
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.trimHeight((double) (byte) 0);
        boolean boolean5 = gradientPaintTransformType0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke14 = null;
        lineAndShapeRenderer12.setSeriesStroke(10, stroke14, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = lineAndShapeRenderer12.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        lineAndShapeRenderer12.setBaseURLGenerator(categoryURLGenerator19);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer12.setSeriesStroke((int) 'a', stroke22);
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke22);
        java.awt.Paint paint26 = lineAndShapeRenderer2.getSeriesOutlinePaint((int) (byte) 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        int int38 = categoryPlot17.getRendererCount();
        java.lang.Comparable comparable39 = categoryPlot17.getDomainCrosshairRowKey();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        try {
            int int41 = categoryPlot17.getRangeAxisIndex(valueAxis40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(comparable39);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setDefaultEntityRadius((int) ' ');
        java.awt.Font font7 = null;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (short) 100, font7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke18 = null;
        lineAndShapeRenderer16.setSeriesStroke(10, stroke18, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = lineAndShapeRenderer16.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint23 = lineAndShapeRenderer16.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        boolean boolean25 = categoryPlot24.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double31 = rectangleInsets30.getTop();
        categoryPlot24.setInsets(rectangleInsets30, true);
        java.awt.geom.GeneralPath generalPath34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.RenderingSource renderingSource36 = null;
        categoryPlot24.select(generalPath34, rectangle2D35, renderingSource36);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray39 = new org.jfree.chart.axis.ValueAxis[] { valueAxis38 };
        categoryPlot24.setRangeAxes(valueAxisArray39);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor41 = categoryPlot24.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis43.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color46 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis43.setTickLabelPaint((java.awt.Paint) color46);
        java.awt.Paint paint48 = categoryAxis43.getTickMarkPaint();
        categoryPlot24.setDomainGridlinePaint(paint48);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset50.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int55 = categoryPlot24.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset50);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = categoryPlot24.getRenderer(15);
        org.jfree.chart.util.SortOrder sortOrder58 = categoryPlot24.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis60.setMaximumCategoryLabelWidthRatio((float) 100);
        double double63 = categoryAxis60.getCategoryMargin();
        categoryAxis60.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = categoryAxis60.getLabelInsets();
        org.jfree.chart.plot.CategoryMarker categoryMarker67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D9, categoryPlot24, categoryAxis60, categoryMarker67, rectangle2D68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.0d + "'", double31 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray39);
        org.junit.Assert.assertNotNull(categoryAnchor41);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer57);
        org.junit.Assert.assertNotNull(sortOrder58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.2d + "'", double63 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets66);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        java.lang.Boolean boolean12 = lineAndShapeRenderer2.getSeriesVisible(15);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 192);
        float float3 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str2 = legendItem1.getLabel();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = null;
        boolean boolean2 = paintList0.equals(obj1);
        java.awt.Paint paint4 = paintList0.getPaint((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke13 = null;
        lineAndShapeRenderer11.setSeriesStroke(10, stroke13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = lineAndShapeRenderer11.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint18 = lineAndShapeRenderer11.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        boolean boolean20 = categoryPlot19.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double26 = rectangleInsets25.getTop();
        categoryPlot19.setInsets(rectangleInsets25, true);
        java.awt.Stroke stroke29 = categoryPlot19.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot19.panDomainAxes((double) (-2), plotRenderingInfo31, point2D32);
        boolean boolean34 = paintList0.equals((java.lang.Object) point2D32);
        org.jfree.chart.renderer.RenderAttributes renderAttributes37 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator38 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color39 = defaultShadowGenerator38.getShadowColor();
        renderAttributes37.setDefaultPaint((java.awt.Paint) color39);
        java.awt.Shape shape42 = renderAttributes37.getSeriesShape(2);
        java.awt.Shape shape45 = renderAttributes37.getItemShape((int) (byte) 10, 0);
        java.awt.Font font46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes37.setDefaultLabelFont(font46);
        java.awt.Paint paint48 = renderAttributes37.getDefaultPaint();
        paintList0.setPaint((int) (short) 10, paint48);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(shape42);
        org.junit.Assert.assertNull(shape45);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean10 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke20 = null;
        lineAndShapeRenderer18.setSeriesStroke(10, stroke20, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = lineAndShapeRenderer18.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint25 = lineAndShapeRenderer18.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot26.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean32 = categoryPlot26.removeDomainMarker((int) (short) 1, marker29, layer30, true);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D11, categoryPlot26, valueAxis33, marker34, rectangle2D35);
        java.awt.Paint paint38 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(paint38);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextPaint();
        java.awt.Shape shape7 = defaultDrawingSupplier5.getNextShape();
        java.awt.Paint paint9 = null;
        org.jfree.chart.renderer.RenderAttributes renderAttributes12 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator13 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color14 = defaultShadowGenerator13.getShadowColor();
        renderAttributes12.setDefaultPaint((java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot30.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo42, point2D43);
        java.lang.Object obj45 = categoryPlot30.clone();
        org.jfree.chart.util.Layer layer47 = null;
        java.util.Collection collection48 = categoryPlot30.getDomainMarkers(0, layer47);
        java.awt.Stroke stroke49 = categoryPlot30.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean54 = lineAndShapeRenderer51.getItemVisible(0, 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer57.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer60 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean61 = lineAndShapeRenderer60.getBaseCreateEntities();
        java.awt.Paint paint63 = lineAndShapeRenderer60.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer57.setBasePaint(paint63);
        java.awt.Shape shape68 = lineAndShapeRenderer57.getItemShape((int) (short) 1, 192, false);
        lineAndShapeRenderer51.setBaseLegendShape(shape68);
        java.awt.Stroke stroke70 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Paint paint71 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem(attributedString0, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "UnitType.ABSOLUTE", "GradientPaintTransformType.CENTER_VERTICAL", true, shape7, false, paint9, true, (java.awt.Paint) color14, stroke49, false, shape68, stroke70, paint71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer8.getIncludeBaseInRange();
        java.awt.Shape shape11 = barRenderer8.lookupSeriesShape(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor12, textAnchor13);
        double double15 = itemLabelPosition14.getAngle();
        barRenderer8.setBaseNegativeItemLabelPosition(itemLabelPosition14, false);
        try {
            lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) -1, itemLabelPosition14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        try {
            boolean boolean65 = defaultCategoryDataset56.isSelected(100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Color color12 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12);
        categoryAxis1.setMaximumCategoryLabelLines((int) '#');
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation19, plotOrientation20);
        try {
            double double22 = categoryAxis1.getCategoryMiddle(89, (int) ' ', rectangle2D18, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 89");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseFillPaint();
        double double2 = lineAndShapeRenderer0.getItemMargin();
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisible();
        int int4 = lineAndShapeRenderer0.getColumnCount();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean6 = lineAndShapeRenderer5.getBaseCreateEntities();
        java.awt.Paint paint8 = lineAndShapeRenderer5.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer0.setBaseLegendTextPaint(paint8);
        java.awt.Font font11 = lineAndShapeRenderer0.getSeriesItemLabelFont(15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(font11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Color color12 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12);
        int int14 = categoryAxis1.getMaximumCategoryLabelLines();
        double double15 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        int int1 = defaultShadowGenerator0.calculateOffsetX();
        java.awt.Color color2 = defaultShadowGenerator0.getShadowColor();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        java.lang.String str16 = axisLocation15.toString();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str16.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        boolean boolean6 = barRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.lookupSeriesOutlinePaint((-123));
        boolean boolean12 = lineAndShapeRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesShapesFilled(3);
        double double8 = lineAndShapeRenderer0.getItemMargin();
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setTickLabelsVisible(false);
        float float8 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setFixedDimension(0.0d);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis13.setTickMarkOutsideLength(0.0f);
        boolean boolean18 = textAnchor11.equals((java.lang.Object) categoryAxis13);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = categoryAxis13.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset40.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int45 = categoryPlot14.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot14.getRenderer(15);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation48 = null;
        try {
            categoryPlot14.addAnnotation(categoryAnnotation48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer47);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis1.setTickMarkOutsideLength(0.0f);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setMaximumCategoryLabelLines(2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        org.jfree.data.general.DatasetGroup datasetGroup63 = defaultCategoryDataset56.getGroup();
        try {
            java.lang.Number number66 = defaultCategoryDataset56.getValue(0, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(datasetGroup63);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_LEFT" + "'", str1.equals("TextAnchor.HALF_ASCENT_LEFT"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseFillPaint();
        java.awt.Shape shape3 = lineAndShapeRenderer0.getLegendShape(0);
        lineAndShapeRenderer0.setBaseCreateEntities(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(shape3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setTickLabelsVisible(false);
        float float8 = categoryAxis1.getTickMarkInsideLength();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Paint paint10 = null;
        try {
            categoryAxis1.setLabelPaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer9.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean13 = lineAndShapeRenderer12.getBaseCreateEntities();
        java.awt.Paint paint15 = lineAndShapeRenderer12.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer9.setBasePaint(paint15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer17.getIncludeBaseInRange();
        java.awt.Shape shape20 = barRenderer17.lookupSeriesShape(0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor21 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor21, textAnchor22);
        double double24 = itemLabelPosition23.getAngle();
        barRenderer17.setBaseNegativeItemLabelPosition(itemLabelPosition23, false);
        lineAndShapeRenderer9.setBasePositiveItemLabelPosition(itemLabelPosition23);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition23);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(itemLabelAnchor21);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range8 = barRenderer0.findRangeBounds(categoryDataset6, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font14 = lineAndShapeRenderer9.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean15 = lineAndShapeRenderer9.getAutoPopulateSeriesFillPaint();
        java.awt.Font font16 = lineAndShapeRenderer9.getBaseItemLabelFont();
        barRenderer0.setBaseLegendTextFont(font16);
        java.awt.Shape shape19 = barRenderer0.getSeriesShape((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(shape19);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Paint paint4 = lineAndShapeRenderer2.lookupSeriesOutlinePaint((-1));
        boolean boolean5 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        boolean boolean8 = lineAndShapeRenderer2.getItemLineVisible((-123), 1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Paint paint4 = lineAndShapeRenderer2.lookupSeriesOutlinePaint((-1));
        boolean boolean5 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = lineAndShapeRenderer2.getSelectedItemAttributes();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean11 = lineAndShapeRenderer8.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        boolean boolean13 = lineAndShapeRenderer8.removeAnnotation(categoryAnnotation12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = lineAndShapeRenderer8.getSeriesURLGenerator((int) 'a');
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator16 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer8.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator16);
        java.awt.Paint paint19 = lineAndShapeRenderer8.lookupSeriesOutlinePaint((-123));
        lineAndShapeRenderer2.setSeriesOutlinePaint(192, paint19, true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(renderAttributes6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMinorTickMarkOutsideLength((float) (byte) 10);
        double double9 = categoryAxis1.getUpperMargin();
        float float10 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        categoryAxis1.removeChangeListener(axisChangeListener11);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.data.general.Dataset dataset10 = legendItem7.getDataset();
        boolean boolean11 = legendItem7.isShapeVisible();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = lineAndShapeRenderer0.getItemLabelGenerator(0, 0, false);
        boolean boolean7 = lineAndShapeRenderer0.isSeriesVisibleInLegend((int) (byte) 1);
        double double8 = lineAndShapeRenderer0.getItemMargin();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) -1);
        java.awt.Shape shape10 = null;
        lineAndShapeRenderer0.setBaseLegendShape(shape10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke20 = null;
        lineAndShapeRenderer18.setSeriesStroke(10, stroke20, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = lineAndShapeRenderer18.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint25 = lineAndShapeRenderer18.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer18);
        boolean boolean27 = categoryPlot26.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double33 = rectangleInsets32.getTop();
        categoryPlot26.setInsets(rectangleInsets32, true);
        java.awt.geom.GeneralPath generalPath36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.RenderingSource renderingSource38 = null;
        categoryPlot26.select(generalPath36, rectangle2D37, renderingSource38);
        categoryPlot26.setNotify(true);
        categoryPlot26.setDomainCrosshairRowKey((java.lang.Comparable) 1L, true);
        java.awt.Stroke stroke45 = categoryPlot26.getRangeCrosshairStroke();
        java.lang.Comparable comparable46 = categoryPlot26.getDomainCrosshairRowKey();
        lineAndShapeRenderer0.setPlot(categoryPlot26);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 1L + "'", comparable46.equals(1L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        keyedObjects0.insertValue(0, (java.lang.Comparable) (short) 1, (java.lang.Object) 0.0f);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (100) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.plot.Marker marker31 = null;
        org.jfree.chart.util.Layer layer32 = null;
        try {
            categoryPlot14.addRangeMarker(marker31, layer32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.awt.Stroke stroke37 = categoryPlot17.getRangeZeroBaselineStroke();
        org.jfree.data.KeyedObjects keyedObjects38 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.util.SortOrder sortOrder39 = org.jfree.chart.util.SortOrder.DESCENDING;
        keyedObjects38.sortByKeys(sortOrder39);
        categoryPlot17.setRowRenderingOrder(sortOrder39);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj43 = defaultCategoryDataset42.clone();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo44 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent45 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) sortOrder39, (org.jfree.data.general.Dataset) defaultCategoryDataset42, datasetChangeInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        boolean boolean7 = barRenderer0.isSeriesItemLabelsVisible((int) (short) 100);
        barRenderer0.setItemMargin((double) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer10.getIncludeBaseInRange();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer10.setBaseFillPaint(paint12, true);
        java.awt.Paint paint18 = barRenderer10.getItemOutlinePaint((int) (short) -1, (int) (short) 100, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = barRenderer10.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean21 = barRenderer20.getIncludeBaseInRange();
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer20.setBaseFillPaint(paint22, true);
        java.awt.Paint paint28 = barRenderer20.getItemOutlinePaint((int) (short) -1, (int) (short) 100, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = barRenderer20.getGradientPaintTransformer();
        barRenderer10.setGradientPaintTransformer(gradientPaintTransformer29);
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer29);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(gradientPaintTransformer29);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke13 = null;
        lineAndShapeRenderer11.setSeriesStroke(10, stroke13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = lineAndShapeRenderer11.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint18 = lineAndShapeRenderer11.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean29 = lineAndShapeRenderer22.getBaseItemLabelsVisible();
        lineAndShapeRenderer22.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = lineAndShapeRenderer22.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean38 = lineAndShapeRenderer22.getItemLineVisible(8, (int) (short) 10);
        boolean boolean39 = lineAndShapeRenderer22.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer22.setBaseOutlineStroke(stroke40, false);
        categoryPlot19.setRangeGridlineStroke(stroke40);
        categoryPlot19.setWeight(0);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        try {
            categoryPlot19.drawBackground(graphics2D47, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("TextAnchor.HALF_ASCENT_LEFT");
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean20 = categoryPlot14.removeDomainMarker((int) (short) 1, marker17, layer18, true);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setRangeAxisLocation((int) 'a', axisLocation22);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace24);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint3 = null;
        java.awt.Shape shape4 = null;
        try {
            java.awt.GradientPaint gradientPaint5 = standardGradientPaintTransformer2.transform(gradientPaint3, shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint9 = defaultDrawingSupplier8.getNextPaint();
        java.awt.Shape shape10 = defaultDrawingSupplier8.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke19 = null;
        lineAndShapeRenderer17.setSeriesStroke(10, stroke19, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = lineAndShapeRenderer17.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint24 = lineAndShapeRenderer17.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer17);
        boolean boolean26 = categoryPlot25.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double32 = rectangleInsets31.getTop();
        categoryPlot25.setInsets(rectangleInsets31, true);
        java.awt.geom.GeneralPath generalPath35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.RenderingSource renderingSource37 = null;
        categoryPlot25.select(generalPath35, rectangle2D36, renderingSource37);
        categoryPlot25.setNotify(true);
        boolean boolean41 = categoryPlot25.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity44 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot25, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.awt.Stroke stroke45 = categoryPlot25.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke46 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        categoryPlot25.setRangeCrosshairStroke(stroke46);
        try {
            barRenderer0.setSeriesStroke((-123), stroke46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("TextAnchor.HALF_ASCENT_CENTER");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean20 = categoryPlot14.removeDomainMarker((int) (short) 1, marker17, layer18, true);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setRangeAxisLocation((int) 'a', axisLocation22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = null;
        categoryPlot14.notifyListeners(plotChangeEvent24);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D22, categoryPlot23, valueAxis24, marker25, rectangle2D26);
        try {
            lineAndShapeRenderer2.setSeriesShapesFilled((-2), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        lineAndShapeRenderer0.setSeriesLinesVisible(5, (java.lang.Boolean) true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Shape shape3 = barRenderer0.lookupSeriesShape(0);
        double double4 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean14 = lineAndShapeRenderer7.getBaseItemLabelsVisible();
        lineAndShapeRenderer7.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = lineAndShapeRenderer7.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color1 = defaultShadowGenerator0.getShadowColor();
        int int2 = defaultShadowGenerator0.calculateOffsetY();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str1.equals("TextAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke46 = null;
        lineAndShapeRenderer44.setSeriesStroke(10, stroke46, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = lineAndShapeRenderer44.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint51 = lineAndShapeRenderer44.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer44);
        boolean boolean53 = categoryPlot52.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double59 = rectangleInsets58.getTop();
        categoryPlot52.setInsets(rectangleInsets58, true);
        float float62 = categoryPlot52.getForegroundAlpha();
        boolean boolean63 = categoryPlot17.equals((java.lang.Object) float62);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) 1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(categoryToolTipGenerator50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 100.0d + "'", double59 == 100.0d);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 1.0f + "'", float62 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        int int1 = defaultShadowGenerator0.getShadowSize();
        boolean boolean3 = defaultShadowGenerator0.equals((java.lang.Object) ' ');
        int int4 = defaultShadowGenerator0.getDistance();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = lineAndShapeRenderer2.getSeriesItemLabelGenerator((int) (short) 1);
        java.awt.Font font13 = lineAndShapeRenderer2.getLegendTextFont((-16777024));
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(font13);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseCreateEntities();
        lineAndShapeRenderer0.setUseSeriesOffset(true);
        java.awt.Stroke stroke7 = lineAndShapeRenderer0.getItemOutlineStroke((int) 'a', 89, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer0.setBaseItemLabelFont(font6);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getLegendTextPaint((int) (byte) -1);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        lineAndShapeRenderer0.setUseFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.Stroke stroke24 = categoryPlot14.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomRangeAxes((double) (-2), plotRenderingInfo26, point2D27);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        int int31 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot14, jFreeChart32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot14.getFixedLegendItems();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(legendItemCollection34);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setShapeVisible(false);
        java.awt.Shape shape10 = legendItem7.getLine();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = legendItem7.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        java.awt.Paint paint6 = barRenderer0.getShadowPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke12 = null;
        lineAndShapeRenderer10.setSeriesStroke(10, stroke12, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = lineAndShapeRenderer10.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean17 = lineAndShapeRenderer10.getBaseItemLabelsVisible();
        lineAndShapeRenderer10.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineAndShapeRenderer10.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean26 = lineAndShapeRenderer10.getItemLineVisible(8, (int) (short) 10);
        boolean boolean27 = lineAndShapeRenderer10.getAutoPopulateSeriesShape();
        java.awt.Stroke stroke28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer10.setBaseOutlineStroke(stroke28, false);
        try {
            barRenderer0.setSeriesStroke((int) (short) -1, stroke28, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset40.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int45 = categoryPlot14.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState46 = defaultCategoryDataset40.getSelectionState();
        java.lang.Comparable comparable47 = null;
        try {
            java.lang.Number number49 = defaultCategoryDataset40.getValue(comparable47, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState46);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Paint paint4 = lineAndShapeRenderer2.lookupSeriesOutlinePaint((-1));
        boolean boolean5 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        boolean boolean6 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        float float24 = categoryPlot14.getForegroundAlpha();
        int int25 = categoryPlot14.getDatasetCount();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("rect");
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        categoryPlot14.setNotify(true);
        boolean boolean20 = categoryPlot14.canSelectByRegion();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        org.jfree.data.general.DatasetGroup datasetGroup38 = categoryPlot17.getDatasetGroup();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(datasetGroup38);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot14.zoomDomainAxes((double) (byte) -1, (double) 10, plotRenderingInfo33, point2D34);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation36 = null;
        try {
            categoryPlot14.addAnnotation(categoryAnnotation36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        categoryPlot17.setFixedRangeAxisSpace(axisSpace38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot17.zoomDomainAxes(100.0d, (double) 3, plotRenderingInfo42, point2D43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        categoryPlot17.setRangeAxis(valueAxis45);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot17.getDomainAxisEdge(3);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier49 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint50 = defaultDrawingSupplier49.getNextPaint();
        java.awt.Stroke stroke51 = defaultDrawingSupplier49.getNextStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, (double) (short) 1, (double) (byte) 0);
        java.lang.Object obj57 = null;
        boolean boolean58 = rectangleInsets56.equals(obj57);
        boolean boolean59 = defaultDrawingSupplier49.equals((java.lang.Object) boolean58);
        categoryPlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier49, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Paint paint4 = lineAndShapeRenderer2.lookupSeriesOutlinePaint((-1));
        boolean boolean5 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = lineAndShapeRenderer2.getSelectedItemAttributes();
        java.awt.Paint paint7 = null;
        try {
            renderAttributes6.setDefaultPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(renderAttributes6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setTickLabelsVisible(false);
        int int8 = categoryAxis1.getMaximumCategoryLabelLines();
        double double9 = categoryAxis1.getLabelAngle();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        java.awt.Paint paint8 = barRenderer0.getItemOutlinePaint((int) (short) -1, (int) (short) 100, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer10.getIncludeBaseInRange();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer10.setBaseFillPaint(paint12, true);
        java.awt.Paint paint18 = barRenderer10.getItemOutlinePaint((int) (short) -1, (int) (short) 100, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = barRenderer10.getGradientPaintTransformer();
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer19);
        boolean boolean21 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.setShadowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        lineAndShapeRenderer0.notifyListeners(rendererChangeEvent7);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesItemLabelsVisible((int) '4');
        boolean boolean8 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = lineAndShapeRenderer0.getItemLabelGenerator(100, (int) (short) -1, true);
        lineAndShapeRenderer0.setBaseLinesVisible(true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer7.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        boolean boolean16 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double22 = rectangleInsets21.getTop();
        categoryPlot15.setInsets(rectangleInsets21, true);
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot15.select(generalPath25, rectangle2D26, renderingSource27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        categoryPlot15.setRangeAxes(valueAxisArray30);
        keyedObjects2D0.setObject((java.lang.Object) valueAxisArray30, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) (byte) 10);
        try {
            java.lang.Comparable comparable36 = keyedObjects2D0.getRowKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray30);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Shape shape7 = null;
        lineAndShapeRenderer0.setSeriesShape((int) (short) 100, shape7);
        java.awt.Paint paint10 = lineAndShapeRenderer0.getLegendTextPaint(5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset40.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int45 = categoryPlot14.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset40);
        java.awt.Color color46 = java.awt.Color.YELLOW;
        boolean boolean47 = defaultCategoryDataset40.equals((java.lang.Object) color46);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Color color2 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        float[] floatArray6 = new float[] { 89, (byte) -1, 100L };
        float[] floatArray7 = color2.getRGBColorComponents(floatArray6);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer7.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        boolean boolean16 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double22 = rectangleInsets21.getTop();
        categoryPlot15.setInsets(rectangleInsets21, true);
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot15.select(generalPath25, rectangle2D26, renderingSource27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        categoryPlot15.setRangeAxes(valueAxisArray30);
        keyedObjects2D0.setObject((java.lang.Object) valueAxisArray30, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) (byte) 10);
        keyedObjects2D0.clear();
        try {
            java.lang.Object obj38 = keyedObjects2D0.getObject((java.lang.Comparable) "TextAnchor.BOTTOM_CENTER", (java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (TextAnchor.BOTTOM_CENTER) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray30);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot14.getRangeAxis(100);
        java.awt.Paint paint26 = categoryPlot14.getRangeMinorGridlinePaint();
        float float27 = categoryPlot14.getBackgroundAlpha();
        java.awt.Paint paint28 = null;
        try {
            categoryPlot14.setDomainGridlinePaint(paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator6 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color7 = defaultShadowGenerator6.getShadowColor();
        renderAttributes5.setDefaultPaint((java.awt.Paint) color7);
        java.awt.Shape shape10 = renderAttributes5.getSeriesShape(2);
        java.awt.Shape shape13 = renderAttributes5.getItemShape((int) (byte) 10, 0);
        java.awt.Stroke stroke14 = renderAttributes5.getDefaultOutlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint16 = defaultDrawingSupplier15.getNextPaint();
        java.awt.Shape shape17 = defaultDrawingSupplier15.getNextShape();
        renderAttributes5.setDefaultShape(shape17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer19.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer24.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color28 = java.awt.Color.ORANGE;
        lineAndShapeRenderer24.setBaseFillPaint((java.awt.Paint) color28);
        java.lang.String str30 = color28.toString();
        lineAndShapeRenderer19.setSeriesOutlinePaint(10, (java.awt.Paint) color28);
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer33.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        boolean boolean37 = lineAndShapeRenderer33.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer38.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color42 = java.awt.Color.ORANGE;
        lineAndShapeRenderer38.setBaseFillPaint((java.awt.Paint) color42);
        lineAndShapeRenderer33.setBaseFillPaint((java.awt.Paint) color42);
        try {
            org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem(attributedString0, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "TextAnchor.HALF_ASCENT_CENTER", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", shape17, (java.awt.Paint) color28, stroke32, (java.awt.Paint) color42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str30.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.setSelected((int) (short) 100, 5, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getTickMarkPaint();
        categoryPlot14.setDomainGridlinePaint(paint38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot14.panDomainAxes(10.0d, plotRenderingInfo41, point2D42);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        double double3 = itemLabelPosition2.getAngle();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean7 = lineAndShapeRenderer4.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer4.removeAnnotation(categoryAnnotation8);
        java.awt.Shape shape11 = null;
        lineAndShapeRenderer4.setSeriesShape((int) (short) 100, shape11);
        java.awt.Paint paint16 = lineAndShapeRenderer4.getItemPaint((int) (short) 100, (int) (short) 0, true);
        boolean boolean17 = itemLabelPosition2.equals((java.lang.Object) true);
        org.jfree.chart.text.TextAnchor textAnchor18 = itemLabelPosition2.getTextAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setBaseLinesVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer22.getBaseCreateEntities();
        java.awt.Paint paint25 = lineAndShapeRenderer22.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator26 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer22.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator26);
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator26);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = lineAndShapeRenderer2.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        java.lang.String str38 = plotEntity36.getToolTipText();
        plotEntity36.setURLText("GradientPaintTransformType.CENTER_VERTICAL");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str38.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        int int37 = categoryPlot17.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.data.Range range39 = categoryPlot17.getDataRange(valueAxis38);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Color color12 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12);
        java.awt.Paint paint14 = categoryAxis1.getLabelPaint();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer2.setBaseCreateEntities(false, true);
        lineAndShapeRenderer2.setBaseCreateEntities(false);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean6 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getBaseItemLabelFont();
        lineAndShapeRenderer0.setUseSeriesOffset(true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Shape shape7 = null;
        lineAndShapeRenderer0.setSeriesShape((int) (short) 100, shape7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = lineAndShapeRenderer0.getSeriesItemLabelGenerator((int) (byte) 0);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke20 = null;
        lineAndShapeRenderer18.setSeriesStroke(10, stroke20, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = lineAndShapeRenderer18.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint25 = lineAndShapeRenderer18.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer18);
        boolean boolean27 = categoryPlot26.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot26.zoomRangeAxes((double) 100, plotRenderingInfo29, point2D30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
        java.awt.Paint paint38 = categoryAxis33.getLabelPaint();
        categoryAxis33.setMinorTickMarkOutsideLength((float) (byte) 10);
        double double41 = categoryAxis33.getUpperMargin();
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D11, categoryPlot26, categoryAxis33, categoryMarker42, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color3 = java.awt.Color.ORANGE;
        float[] floatArray9 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray10 = color3.getRGBComponents(floatArray9);
        float[] floatArray11 = color2.getRGBColorComponents(floatArray9);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER", (java.awt.Paint) color2);
        int int13 = color2.getTransparency();
        boolean boolean14 = booleanList0.equals((java.lang.Object) color2);
        org.jfree.chart.renderer.RenderAttributes renderAttributes16 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator17 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color18 = defaultShadowGenerator17.getShadowColor();
        renderAttributes16.setDefaultPaint((java.awt.Paint) color18);
        java.awt.Shape shape21 = renderAttributes16.getSeriesShape(2);
        java.awt.Shape shape24 = renderAttributes16.getItemShape((int) (byte) 10, 0);
        java.awt.Stroke stroke25 = renderAttributes16.getDefaultOutlineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer27.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font32 = lineAndShapeRenderer27.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean33 = lineAndShapeRenderer27.getAutoPopulateSeriesFillPaint();
        java.awt.Font font34 = lineAndShapeRenderer27.getBaseItemLabelFont();
        java.awt.Paint paint38 = lineAndShapeRenderer27.getItemFillPaint((-123), (int) 'a', false);
        lineAndShapeRenderer27.clearSeriesPaints(false);
        boolean boolean42 = lineAndShapeRenderer27.isSeriesItemLabelsVisible(0);
        java.awt.Stroke stroke44 = lineAndShapeRenderer27.lookupSeriesOutlineStroke((int) ' ');
        renderAttributes16.setSeriesStroke((int) ' ', stroke44);
        boolean boolean46 = booleanList0.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertNull(shape24);
        org.junit.Assert.assertNull(stroke25);
        org.junit.Assert.assertNull(font32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.Stroke stroke24 = categoryPlot14.getRangeMinorGridlineStroke();
        categoryPlot14.setRangeCrosshairValue(4.0d, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot14.zoomDomainAxes((double) (-2), plotRenderingInfo29, point2D30);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer7.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        boolean boolean16 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double22 = rectangleInsets21.getTop();
        categoryPlot15.setInsets(rectangleInsets21, true);
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot15.select(generalPath25, rectangle2D26, renderingSource27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        categoryPlot15.setRangeAxes(valueAxisArray30);
        keyedObjects2D0.setObject((java.lang.Object) valueAxisArray30, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) (byte) 10);
        keyedObjects2D0.clear();
        try {
            keyedObjects2D0.removeColumn(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray30);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean5 = lineAndShapeRenderer2.getItemVisible(0, 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer8.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean12 = lineAndShapeRenderer11.getBaseCreateEntities();
        java.awt.Paint paint14 = lineAndShapeRenderer11.lookupSeriesFillPaint((int) (short) -1);
        lineAndShapeRenderer8.setBasePaint(paint14);
        java.awt.Shape shape19 = lineAndShapeRenderer8.getItemShape((int) (short) 1, 192, false);
        lineAndShapeRenderer2.setBaseLegendShape(shape19);
        try {
            shapeList0.setShape((-123), shape19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer0.getBarPainter();
        barRenderer0.setMinimumBarLength((double) 3);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer6.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font11 = lineAndShapeRenderer6.getSeriesItemLabelFont((int) (byte) 100);
        java.awt.Font font12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer6.setBaseItemLabelFont(font12);
        barRenderer0.setSeriesItemLabelFont((int) (byte) 0, font12);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke26 = null;
        lineAndShapeRenderer24.setSeriesStroke(10, stroke26, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = lineAndShapeRenderer24.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint31 = lineAndShapeRenderer24.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        boolean boolean33 = categoryPlot32.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double39 = rectangleInsets38.getTop();
        categoryPlot32.setInsets(rectangleInsets38, true);
        java.awt.geom.GeneralPath generalPath42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.RenderingSource renderingSource44 = null;
        categoryPlot32.select(generalPath42, rectangle2D43, renderingSource44);
        categoryPlot32.setNotify(true);
        categoryPlot32.setDomainCrosshairRowKey((java.lang.Comparable) 1L, true);
        java.awt.Stroke stroke51 = categoryPlot32.getRangeCrosshairStroke();
        boolean boolean52 = categoryPlot32.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis54.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color57 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis54.setTickLabelPaint((java.awt.Paint) color57);
        java.awt.Paint paint59 = categoryAxis54.getLabelPaint();
        categoryAxis54.setMinorTickMarkOutsideLength((float) (byte) 10);
        double double62 = categoryAxis54.getUpperMargin();
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset64 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj65 = defaultCategoryDataset64.clone();
        try {
            barRenderer0.drawItem(graphics2D15, categoryItemRendererState16, rectangle2D17, categoryPlot32, categoryAxis54, valueAxis63, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset64, (int) (byte) 10, 0, true, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertNull(font11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.0d + "'", double39 == 100.0d);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.05d + "'", double62 == 0.05d);
        org.junit.Assert.assertNotNull(obj65);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        barRenderer0.setBaseCreateEntities(true, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarPainter barPainter10 = null;
        try {
            barRenderer0.setBarPainter(barPainter10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(itemLabelPosition9);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Shape shape3 = defaultDrawingSupplier1.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke12 = null;
        lineAndShapeRenderer10.setSeriesStroke(10, stroke12, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = lineAndShapeRenderer10.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint17 = lineAndShapeRenderer10.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10);
        boolean boolean19 = categoryPlot18.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double25 = rectangleInsets24.getTop();
        categoryPlot18.setInsets(rectangleInsets24, true);
        java.awt.geom.GeneralPath generalPath28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        categoryPlot18.select(generalPath28, rectangle2D29, renderingSource30);
        categoryPlot18.setNotify(true);
        boolean boolean34 = categoryPlot18.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity37 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot18, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str38 = categoryPlot18.getNoDataMessage();
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        categoryPlot18.setFixedRangeAxisSpace(axisSpace39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        categoryPlot18.zoomDomainAxes(100.0d, (double) 3, plotRenderingInfo43, point2D44);
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot18);
        java.awt.Stroke stroke47 = lineAndShapeRenderer0.getBaseStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        double double19 = categoryPlot14.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot14.addDomainMarker(categoryMarker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftInset((-1.0d));
        categoryAxis1.setLabelInsets(rectangleInsets5, false);
        java.awt.Stroke stroke10 = categoryAxis1.getTickMarkStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setLabelURL("java.awt.Color[r=255,g=200,b=0]");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setTickLabelsVisible(true);
        float float8 = categoryAxis1.getMinorTickMarkInsideLength();
        boolean boolean9 = categoryAxis1.isVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Shape shape2 = legendItem1.getLine();
        legendItem1.setShapeVisible(false);
        legendItem1.setSeriesIndex(0);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) '#', "UnitType.ABSOLUTE");
        double double18 = categoryAxis2.getCategoryMargin();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        defaultCategoryDataset0.addValue((java.lang.Number) 4, (java.lang.Comparable) true, (java.lang.Comparable) "ChartChangeEventType.GENERAL");
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        java.lang.String str38 = plotEntity36.getToolTipText();
        java.lang.String str39 = plotEntity36.getShapeType();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator40 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator41 = null;
        try {
            java.lang.String str42 = plotEntity36.getImageMapAreaTag(toolTipTagFragmentGenerator40, uRLTagFragmentGenerator41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str38.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "rect" + "'", str39.equals("rect"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        java.lang.Object obj29 = categoryPlot14.clone();
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot14.getDomainMarkers(0, layer31);
        java.awt.Stroke stroke33 = categoryPlot14.getRangeZeroBaselineStroke();
        java.awt.Paint paint34 = categoryPlot14.getRangeCrosshairPaint();
        categoryPlot14.clearDomainMarkers((int) (byte) 0);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER");
        java.lang.String str2 = legendItem1.getLabel();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.HALF_ASCENT_CENTER" + "'", str2.equals("TextAnchor.HALF_ASCENT_CENTER"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        categoryAxis2.setLowerMargin((double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis2.setTickLabelInsets(rectangleInsets17);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean7 = lineAndShapeRenderer4.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = lineAndShapeRenderer4.removeAnnotation(categoryAnnotation8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer4.getSeriesNegativeItemLabelPosition((int) ' ');
        org.jfree.chart.text.TextAnchor textAnchor12 = itemLabelPosition11.getTextAnchor();
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition11);
        org.jfree.chart.text.TextAnchor textAnchor14 = itemLabelPosition11.getRotationAnchor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        java.awt.Shape shape6 = renderAttributes1.getSeriesShape(2);
        java.awt.Shape shape9 = renderAttributes1.getItemShape((int) (byte) 10, 0);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes1.setDefaultLabelFont(font10);
        java.awt.Paint paint12 = renderAttributes1.getDefaultPaint();
        org.jfree.chart.renderer.RenderAttributes renderAttributes14 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator15 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color16 = defaultShadowGenerator15.getShadowColor();
        renderAttributes14.setDefaultPaint((java.awt.Paint) color16);
        java.awt.Shape shape19 = renderAttributes14.getSeriesShape(2);
        java.awt.Shape shape22 = renderAttributes14.getItemShape((int) (byte) 10, 0);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes14.setDefaultLabelFont(font23);
        renderAttributes1.setDefaultLabelFont(font23);
        java.awt.Paint paint26 = renderAttributes1.getDefaultPaint();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke35 = null;
        lineAndShapeRenderer33.setSeriesStroke(10, stroke35, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = lineAndShapeRenderer33.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint40 = lineAndShapeRenderer33.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        boolean boolean42 = categoryPlot41.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double48 = rectangleInsets47.getTop();
        categoryPlot41.setInsets(rectangleInsets47, true);
        java.awt.geom.GeneralPath generalPath51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.RenderingSource renderingSource53 = null;
        categoryPlot41.select(generalPath51, rectangle2D52, renderingSource53);
        categoryPlot41.setNotify(true);
        categoryPlot41.setDomainCrosshairRowKey((java.lang.Comparable) 1L, true);
        java.awt.Stroke stroke60 = categoryPlot41.getRangeCrosshairStroke();
        renderAttributes1.setDefaultOutlineStroke(stroke60);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNull(shape22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(categoryToolTipGenerator39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.0d + "'", double48 == 100.0d);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color5 = color4.darker();
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", (java.awt.Paint) color5);
        legendItem6.setSeriesKey((java.lang.Comparable) 2.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer9.getIncludeBaseInRange();
        java.awt.Shape shape12 = barRenderer9.lookupSeriesShape(0);
        legendItem6.setLine(shape12);
        try {
            shapeList0.setShape((int) (short) -1, shape12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        int int3 = java.awt.Color.HSBtoRGB((float) 1, (float) (short) 10, (float) (-123));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-8458323) + "'", int3 == (-8458323));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesItemLabelsVisible((int) '4');
        boolean boolean8 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator10);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor13, textAnchor14);
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition15, true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot14.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot30.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = categoryPlot30.removeDomainMarker((int) (short) 1, marker33, layer34, true);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot30.setRangeAxisLocation((int) 'a', axisLocation38);
        categoryPlot14.setRangeAxisLocation(axisLocation38, true);
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot14.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot14.getRangeAxis();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNull(valueAxis43);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        int int16 = categoryPlot14.getWeight();
        categoryPlot14.setDrawSharedDomainAxis(false);
        boolean boolean19 = categoryPlot14.isDomainGridlinesVisible();
        categoryPlot14.setRangeCrosshairValue((double) ' ', true);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Shape shape3 = barRenderer0.lookupSeriesShape(0);
        double double4 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator8 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color9 = defaultShadowGenerator8.getShadowColor();
        renderAttributes7.setDefaultPaint((java.awt.Paint) color9);
        java.awt.Shape shape12 = renderAttributes7.getSeriesShape(2);
        java.awt.Shape shape15 = renderAttributes7.getItemShape((int) (byte) 10, 0);
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        renderAttributes7.setDefaultLabelFont(font16);
        java.awt.Paint paint18 = renderAttributes7.getDefaultPaint();
        try {
            barRenderer0.setSeriesPaint((int) (short) -1, paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNull(shape15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Font font10 = lineAndShapeRenderer2.getLegendTextFont((int) 'a');
        boolean boolean11 = lineAndShapeRenderer2.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.calculateRightOutset((double) ' ');
        double double8 = rectangleInsets4.getBottom();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Color color11 = java.awt.Color.ORANGE;
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color11, true);
        int int14 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Paint paint15 = lineAndShapeRenderer2.getBaseOutlinePaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem1.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType4 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str5 = gradientPaintTransformType4.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer6 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType4);
        legendItem1.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke16 = null;
        lineAndShapeRenderer14.setSeriesStroke(10, stroke16, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer14.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint21 = lineAndShapeRenderer14.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        boolean boolean23 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double29 = rectangleInsets28.getTop();
        categoryPlot22.setInsets(rectangleInsets28, true);
        java.awt.Stroke stroke32 = categoryPlot22.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot22.panDomainAxes((double) (-2), plotRenderingInfo34, point2D35);
        int int37 = categoryPlot22.getDomainAxisCount();
        boolean boolean38 = standardGradientPaintTransformer6.equals((java.lang.Object) int37);
        org.junit.Assert.assertNotNull(gradientPaintTransformType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str5.equals("GradientPaintTransformType.CENTER_VERTICAL"));
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range8 = barRenderer0.findRangeBounds(categoryDataset6, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font14 = lineAndShapeRenderer9.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean15 = lineAndShapeRenderer9.getAutoPopulateSeriesFillPaint();
        java.awt.Font font16 = lineAndShapeRenderer9.getBaseItemLabelFont();
        barRenderer0.setBaseLegendTextFont(font16);
        barRenderer0.setItemMargin((double) (-8458323));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Shape shape7 = null;
        lineAndShapeRenderer0.setSeriesShape((int) (short) 100, shape7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke17 = null;
        lineAndShapeRenderer15.setSeriesStroke(10, stroke17, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = lineAndShapeRenderer15.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint22 = lineAndShapeRenderer15.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15);
        lineAndShapeRenderer0.setPlot(categoryPlot23);
        java.awt.Font font26 = null;
        try {
            lineAndShapeRenderer0.setSeriesItemLabelFont((-8458323), font26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = axisLocation0.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        renderAttributes1.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint8 = renderAttributes1.getSeriesOutlinePaint(5);
        java.awt.Paint paint10 = renderAttributes1.getSeriesFillPaint((int) (byte) -1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseFillPaint();
        double double2 = lineAndShapeRenderer0.getItemMargin();
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisible();
        int int4 = lineAndShapeRenderer0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis7.setTickLabelPaint((java.awt.Paint) color10);
        java.awt.Paint paint12 = categoryAxis7.getTickMarkPaint();
        categoryAxis7.setTickLabelsVisible(false);
        org.jfree.chart.plot.Plot plot15 = categoryAxis7.getPlot();
        java.lang.Object obj16 = categoryAxis7.clone();
        java.awt.Paint paint17 = categoryAxis7.getTickLabelPaint();
        lineAndShapeRenderer0.setLegendTextPaint(8, paint17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke29 = null;
        lineAndShapeRenderer27.setSeriesStroke(10, stroke29, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = lineAndShapeRenderer27.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint34 = lineAndShapeRenderer27.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis23, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer27);
        boolean boolean36 = categoryPlot35.isRangeGridlinesVisible();
        java.awt.Stroke stroke37 = categoryPlot35.getRangeZeroBaselineStroke();
        categoryPlot35.setRangePannable(false);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot35.getDomainMarkers(0, layer41);
        java.awt.Paint paint43 = categoryPlot35.getRangeGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState46 = lineAndShapeRenderer0.initialise(graphics2D19, rectangle2D20, categoryPlot35, categoryDataset44, plotRenderingInfo45);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(categoryItemRendererState46);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        categoryPlot30.setNotify(true);
        categoryPlot30.setDomainCrosshairRowKey((java.lang.Comparable) 1L, true);
        java.awt.Stroke stroke49 = categoryPlot30.getRangeCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryPlot14.getInsets();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent52 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent52);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        double double5 = barRenderer0.getShadowYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke14 = null;
        lineAndShapeRenderer12.setSeriesStroke(10, stroke14, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = lineAndShapeRenderer12.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint19 = lineAndShapeRenderer12.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        categoryPlot20.setRangeMinorGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke32 = null;
        lineAndShapeRenderer30.setSeriesStroke(10, stroke32, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = lineAndShapeRenderer30.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint37 = lineAndShapeRenderer30.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis26, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer30);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke48 = null;
        lineAndShapeRenderer46.setSeriesStroke(10, stroke48, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator52 = lineAndShapeRenderer46.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint53 = lineAndShapeRenderer46.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis42, valueAxis43, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer46);
        boolean boolean55 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double61 = rectangleInsets60.getTop();
        categoryPlot54.setInsets(rectangleInsets60, true);
        java.awt.geom.GeneralPath generalPath64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.RenderingSource renderingSource66 = null;
        categoryPlot54.select(generalPath64, rectangle2D65, renderingSource66);
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray69 = new org.jfree.chart.axis.ValueAxis[] { valueAxis68 };
        categoryPlot54.setRangeAxes(valueAxisArray69);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor71 = categoryPlot54.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis73.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color76 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis73.setTickLabelPaint((java.awt.Paint) color76);
        java.awt.Paint paint78 = categoryAxis73.getTickMarkPaint();
        categoryPlot54.setDomainGridlinePaint(paint78);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset80 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset80.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int85 = categoryPlot54.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset80);
        categoryPlot38.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset80);
        categoryPlot20.setDataset(15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset80);
        org.jfree.data.Range range88 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset80);
        defaultCategoryDataset80.setValue((java.lang.Number) 4.0d, (java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=10.0]", (java.lang.Comparable) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryToolTipGenerator36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(categoryToolTipGenerator52);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.0d + "'", double61 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray69);
        org.junit.Assert.assertNotNull(categoryAnchor71);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
        org.junit.Assert.assertNotNull(range88);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        float float18 = categoryPlot14.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot14.zoomDomainAxes((double) 5, plotRenderingInfo20, point2D21);
        java.awt.Stroke stroke23 = categoryPlot14.getOutlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot14.zoomDomainAxes((double) 192, plotRenderingInfo25, point2D26, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        int int19 = categoryPlot14.getBackgroundImageAlignment();
        java.lang.Comparable comparable20 = null;
        categoryPlot14.setDomainCrosshairRowKey(comparable20, false);
        categoryPlot14.setDomainCrosshairVisible(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = categoryPlot14.getDrawingSupplier();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(drawingSupplier25);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        int int37 = categoryPlot17.getDatasetCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = null;
        org.jfree.chart.util.Layer layer40 = null;
        try {
            categoryPlot17.addDomainMarker((-16777024), categoryMarker39, layer40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color3 = java.awt.Color.ORANGE;
        float[] floatArray9 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray10 = color3.getRGBComponents(floatArray9);
        float[] floatArray11 = color2.getRGBColorComponents(floatArray9);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER", (java.awt.Paint) color2);
        int int13 = color2.getTransparency();
        boolean boolean14 = booleanList0.equals((java.lang.Object) color2);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer15.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer20.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color24 = java.awt.Color.ORANGE;
        lineAndShapeRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        java.lang.String str26 = color24.toString();
        lineAndShapeRenderer15.setSeriesOutlinePaint(10, (java.awt.Paint) color24);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color29 = java.awt.Color.ORANGE;
        float[] floatArray35 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray36 = color29.getRGBComponents(floatArray35);
        float[] floatArray37 = color28.getRGBColorComponents(floatArray35);
        float[] floatArray38 = color24.getComponents(floatArray37);
        float[] floatArray39 = color2.getComponents(floatArray38);
        java.awt.color.ColorSpace colorSpace40 = null;
        org.jfree.chart.util.BooleanList booleanList41 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color44 = java.awt.Color.ORANGE;
        float[] floatArray50 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray51 = color44.getRGBComponents(floatArray50);
        float[] floatArray52 = color43.getRGBColorComponents(floatArray50);
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER", (java.awt.Paint) color43);
        int int54 = color43.getTransparency();
        boolean boolean55 = booleanList41.equals((java.lang.Object) color43);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer56.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer61.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color65 = java.awt.Color.ORANGE;
        lineAndShapeRenderer61.setBaseFillPaint((java.awt.Paint) color65);
        java.lang.String str67 = color65.toString();
        lineAndShapeRenderer56.setSeriesOutlinePaint(10, (java.awt.Paint) color65);
        java.awt.Color color69 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color70 = java.awt.Color.ORANGE;
        float[] floatArray76 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray77 = color70.getRGBComponents(floatArray76);
        float[] floatArray78 = color69.getRGBColorComponents(floatArray76);
        float[] floatArray79 = color65.getComponents(floatArray78);
        float[] floatArray80 = color43.getComponents(floatArray79);
        try {
            float[] floatArray81 = color2.getColorComponents(colorSpace40, floatArray80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str26.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str67.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(floatArray76);
        org.junit.Assert.assertNotNull(floatArray77);
        org.junit.Assert.assertNotNull(floatArray78);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertNotNull(floatArray80);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        categoryPlot14.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer2.setBaseCreateEntities(false, true);
        lineAndShapeRenderer2.setBaseCreateEntities(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        int int16 = categoryPlot14.getWeight();
        categoryPlot14.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace19, false);
        java.awt.Stroke stroke22 = categoryPlot14.getRangeCrosshairStroke();
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        try {
            categoryPlot14.addRangeMarker(marker23, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot14.setFixedDomainAxisSpace(axisSpace32, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Color color12 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12);
        int int14 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke15 = categoryAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.Stroke stroke24 = categoryPlot14.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean27 = barRenderer26.getIncludeBaseInRange();
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer26.setBaseFillPaint(paint28, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke35 = null;
        lineAndShapeRenderer33.setSeriesStroke(10, stroke35, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = lineAndShapeRenderer33.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean40 = lineAndShapeRenderer33.getBaseItemLabelsVisible();
        lineAndShapeRenderer33.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = lineAndShapeRenderer33.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean49 = lineAndShapeRenderer33.getItemLineVisible(8, (int) (short) 10);
        boolean boolean50 = lineAndShapeRenderer33.getAutoPopulateSeriesShape();
        lineAndShapeRenderer33.setUseSeriesOffset(true);
        java.awt.Color color53 = java.awt.Color.ORANGE;
        lineAndShapeRenderer33.setBaseOutlinePaint((java.awt.Paint) color53);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer55.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color59 = java.awt.Color.ORANGE;
        lineAndShapeRenderer55.setBaseFillPaint((java.awt.Paint) color59);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean64 = lineAndShapeRenderer61.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation65 = null;
        boolean boolean66 = lineAndShapeRenderer61.removeAnnotation(categoryAnnotation65);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition68 = lineAndShapeRenderer61.getSeriesNegativeItemLabelPosition((int) ' ');
        lineAndShapeRenderer55.setBasePositiveItemLabelPosition(itemLabelPosition68);
        lineAndShapeRenderer33.setBasePositiveItemLabelPosition(itemLabelPosition68);
        barRenderer26.setNegativeItemLabelPositionFallback(itemLabelPosition68);
        try {
            categoryPlot14.setRenderer((int) (byte) -1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(categoryToolTipGenerator39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition68);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke6 = null;
        lineAndShapeRenderer4.setSeriesStroke(10, stroke6, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = lineAndShapeRenderer4.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        lineAndShapeRenderer4.setBaseURLGenerator(categoryURLGenerator11);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer4.setSeriesStroke((int) 'a', stroke14);
        strokeList0.setStroke((int) 'a', stroke14);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot14.getDomainGridlinePosition();
        categoryPlot14.setDomainCrosshairColumnKey((java.lang.Comparable) "hi!", true);
        categoryPlot14.clearDomainMarkers((int) ' ');
        categoryPlot14.setBackgroundImageAlpha(0.0f);
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot14.getDataset();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertNull(categoryDataset39);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        int int16 = categoryPlot14.getWeight();
        categoryPlot14.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace19, false);
        int int22 = categoryPlot14.getDatasetCount();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = booleanList0.equals((java.lang.Object) (-16777024));
        org.jfree.chart.LegendItemCollection legendItemCollection3 = new org.jfree.chart.LegendItemCollection();
        boolean boolean4 = booleanList0.equals((java.lang.Object) legendItemCollection3);
        int int5 = legendItemCollection3.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator2 = new org.jfree.chart.util.DefaultShadowGenerator();
        java.awt.Color color3 = defaultShadowGenerator2.getShadowColor();
        renderAttributes1.setDefaultPaint((java.awt.Paint) color3);
        java.awt.Shape shape6 = renderAttributes1.getSeriesShape(2);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean11 = lineAndShapeRenderer8.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        boolean boolean13 = lineAndShapeRenderer8.removeAnnotation(categoryAnnotation12);
        java.awt.Shape shape15 = null;
        lineAndShapeRenderer8.setSeriesShape((int) (short) 100, shape15);
        java.awt.Paint paint20 = lineAndShapeRenderer8.getItemPaint((int) (short) 100, (int) (short) 0, true);
        renderAttributes1.setSeriesPaint((int) (short) 10, paint20);
        java.awt.Paint paint23 = renderAttributes1.getSeriesOutlinePaint((int) '#');
        java.awt.Shape shape25 = renderAttributes1.getSeriesShape((-123));
        java.awt.Stroke stroke27 = renderAttributes1.getSeriesStroke((-123));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNull(shape25);
        org.junit.Assert.assertNull(stroke27);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Shape shape2 = legendItem1.getLine();
        legendItem1.setShapeVisible(false);
        java.lang.String str5 = legendItem1.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        boolean boolean31 = categoryPlot14.isRangeCrosshairVisible();
        java.awt.Stroke stroke32 = categoryPlot14.getOutlineStroke();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "TextAnchor.BOTTOM_CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        int int16 = categoryPlot14.getWeight();
        categoryPlot14.configureDomainAxes();
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot14, jFreeChart18, chartChangeEventType19);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint4 = defaultDrawingSupplier3.getNextPaint();
        java.awt.Shape shape5 = defaultDrawingSupplier3.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke14 = null;
        lineAndShapeRenderer12.setSeriesStroke(10, stroke14, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = lineAndShapeRenderer12.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint19 = lineAndShapeRenderer12.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        boolean boolean21 = categoryPlot20.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double27 = rectangleInsets26.getTop();
        categoryPlot20.setInsets(rectangleInsets26, true);
        java.awt.geom.GeneralPath generalPath30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.RenderingSource renderingSource32 = null;
        categoryPlot20.select(generalPath30, rectangle2D31, renderingSource32);
        categoryPlot20.setNotify(true);
        boolean boolean36 = categoryPlot20.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity39 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot20, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        shapeList0.setShape((int) (short) 1, shape5);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBase((double) (-1));
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        barRenderer0.setSeriesItemLabelFont(89, font4);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color3 = java.awt.Color.ORANGE;
        float[] floatArray9 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray10 = color3.getRGBComponents(floatArray9);
        float[] floatArray11 = color2.getRGBColorComponents(floatArray9);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER", (java.awt.Paint) color2);
        int int13 = color2.getTransparency();
        boolean boolean14 = booleanList0.equals((java.lang.Object) color2);
        int int15 = color2.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        barRenderer0.setMinimumBarLength((double) (short) 100);
        java.awt.Font font7 = null;
        barRenderer0.setSeriesItemLabelFont(192, font7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis10.setMaximumCategoryLabelWidthRatio((float) 100);
        double double13 = categoryAxis10.getCategoryMargin();
        categoryAxis10.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis10.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke25 = null;
        lineAndShapeRenderer23.setSeriesStroke(10, stroke25, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = lineAndShapeRenderer23.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint30 = lineAndShapeRenderer23.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer23);
        boolean boolean32 = categoryPlot31.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double38 = rectangleInsets37.getTop();
        categoryPlot31.setInsets(rectangleInsets37, true);
        categoryAxis10.setPlot((org.jfree.chart.plot.Plot) categoryPlot31);
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        categoryPlot31.setFixedDomainAxisSpace(axisSpace42, false);
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNull(categoryToolTipGenerator29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double5 = rectangleInsets4.getTop();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets4.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesItemLabelsVisible((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 100, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer2);
        org.jfree.chart.LegendItem legendItem6 = barRenderer0.getLegendItem((int) ' ', 15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        categoryPlot14.setRangeMinorGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke26 = null;
        lineAndShapeRenderer24.setSeriesStroke(10, stroke26, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = lineAndShapeRenderer24.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint31 = lineAndShapeRenderer24.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke42 = null;
        lineAndShapeRenderer40.setSeriesStroke(10, stroke42, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator46 = lineAndShapeRenderer40.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint47 = lineAndShapeRenderer40.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis36, valueAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer40);
        boolean boolean49 = categoryPlot48.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double55 = rectangleInsets54.getTop();
        categoryPlot48.setInsets(rectangleInsets54, true);
        java.awt.geom.GeneralPath generalPath58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.RenderingSource renderingSource60 = null;
        categoryPlot48.select(generalPath58, rectangle2D59, renderingSource60);
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray63 = new org.jfree.chart.axis.ValueAxis[] { valueAxis62 };
        categoryPlot48.setRangeAxes(valueAxisArray63);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor65 = categoryPlot48.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis67.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color70 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis67.setTickLabelPaint((java.awt.Paint) color70);
        java.awt.Paint paint72 = categoryAxis67.getTickMarkPaint();
        categoryPlot48.setDomainGridlinePaint(paint72);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset74 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset74.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int79 = categoryPlot48.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset74);
        categoryPlot32.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset74);
        categoryPlot14.setDataset(15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset74);
        try {
            defaultCategoryDataset74.removeColumn((-16777024));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -16777024");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(categoryToolTipGenerator46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 100.0d + "'", double55 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray63);
        org.junit.Assert.assertNotNull(categoryAnchor65);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        categoryPlot14.setAnchorValue((double) 89);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("-3,-3,3,3");
        java.awt.Font font2 = categoryAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            boolean boolean19 = categoryPlot14.removeAnnotation(categoryAnnotation17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.BooleanList booleanList1 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = java.awt.Color.ORANGE;
        float[] floatArray10 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray11 = color4.getRGBComponents(floatArray10);
        float[] floatArray12 = color3.getRGBColorComponents(floatArray10);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_CENTER", (java.awt.Paint) color3);
        int int14 = color3.getTransparency();
        boolean boolean15 = booleanList1.equals((java.lang.Object) color3);
        org.jfree.data.KeyedObject keyedObject16 = new org.jfree.data.KeyedObject((java.lang.Comparable) 89, (java.lang.Object) color3);
        int int17 = color3.getGreen();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        int int16 = categoryPlot14.getWeight();
        categoryPlot14.configureDomainAxes();
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot14.getRangeMarkers(layer18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        categoryPlot14.addChangeListener(plotChangeListener20);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        java.lang.Object obj15 = categoryPlot14.clone();
        int int16 = categoryPlot14.getWeight();
        categoryPlot14.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace19, false);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot14.removeDomainMarker((int) '4', marker23, layer24);
        java.awt.Paint paint26 = categoryPlot14.getOutlinePaint();
        int int27 = categoryPlot14.getRendererCount();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        java.lang.String str3 = plotOrientation1.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlotOrientation.VERTICAL" + "'", str3.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("GradientPaintTransformType.CENTER_VERTICAL", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseCreateEntities();
        java.awt.Paint paint3 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis5.setTickLabelPaint((java.awt.Paint) color8);
        java.awt.Font font10 = categoryAxis5.getTickLabelFont();
        lineAndShapeRenderer0.setBaseItemLabelFont(font10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        legendItem11.setURLText("TextAnchor.HALF_ASCENT_CENTER");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType14 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str15 = gradientPaintTransformType14.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType14);
        legendItem11.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        legendItem7.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        java.awt.GradientPaint gradientPaint19 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint21 = defaultDrawingSupplier20.getNextPaint();
        java.awt.Shape shape22 = defaultDrawingSupplier20.getNextShape();
        try {
            java.awt.GradientPaint gradientPaint23 = standardGradientPaintTransformer16.transform(gradientPaint19, shape22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str15.equals("GradientPaintTransformType.CENTER_VERTICAL"));
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent2.setChart(jFreeChart3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent2.getType();
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double5 = rectangleInsets4.getTop();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets4.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color4 = java.awt.Color.ORANGE;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) (byte) 1);
        java.awt.Font font9 = lineAndShapeRenderer0.getLegendTextFont(0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(font9);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        int int15 = lineAndShapeRenderer6.getPassCount();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer6.setSeriesStroke((int) (byte) 1, stroke17, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        boolean boolean11 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint13 = lineAndShapeRenderer2.getLegendTextPaint(0);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint5 = defaultDrawingSupplier4.getNextPaint();
        java.awt.Shape shape6 = defaultDrawingSupplier4.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke15 = null;
        lineAndShapeRenderer13.setSeriesStroke(10, stroke15, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = lineAndShapeRenderer13.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint20 = lineAndShapeRenderer13.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer13);
        boolean boolean22 = categoryPlot21.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double28 = rectangleInsets27.getTop();
        categoryPlot21.setInsets(rectangleInsets27, true);
        java.awt.geom.GeneralPath generalPath31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.RenderingSource renderingSource33 = null;
        categoryPlot21.select(generalPath31, rectangle2D32, renderingSource33);
        categoryPlot21.setNotify(true);
        boolean boolean37 = categoryPlot21.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity40 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) categoryPlot21, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.jfree.chart.entity.ChartEntity chartEntity43 = new org.jfree.chart.entity.ChartEntity(shape6, "TextAnchor.HALF_ASCENT_CENTER", "TextAnchor.HALF_ASCENT_LEFT");
        java.awt.Stroke stroke44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color46 = color45.darker();
        try {
            org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem(attributedString0, "TextAnchor.BOTTOM_CENTER", "TextAnchor.HALF_ASCENT_CENTER", "rect", shape6, stroke44, (java.awt.Paint) color46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryToolTipGenerator19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        int int31 = categoryPlot14.getDomainAxisCount();
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot14, jFreeChart32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot14.panDomainAxes(1.0d, plotRenderingInfo35, point2D36);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent38);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue(number0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        double double4 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis1.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke16 = null;
        lineAndShapeRenderer14.setSeriesStroke(10, stroke16, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer14.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint21 = lineAndShapeRenderer14.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        boolean boolean23 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double29 = rectangleInsets28.getTop();
        categoryPlot22.setInsets(rectangleInsets28, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot22);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryPlot22.setDomainGridlinePaint((java.awt.Paint) color33);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation35 = null;
        try {
            boolean boolean36 = categoryPlot22.removeAnnotation(categoryAnnotation35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        categoryPlot14.clearDomainAxes();
        java.awt.Stroke stroke19 = null;
        try {
            categoryPlot14.setRangeGridlineStroke(stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Shape shape10 = lineAndShapeRenderer2.getSeriesShape(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator11, true);
        lineAndShapeRenderer2.clearSeriesStrokes(true);
        lineAndShapeRenderer2.setBaseLinesVisible(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(shape10);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Shape shape3 = barRenderer0.lookupSeriesShape(0);
        double double4 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer5.getIncludeBaseInRange();
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer5.setBaseFillPaint(paint7, true);
        double double10 = barRenderer5.getShadowYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke19 = null;
        lineAndShapeRenderer17.setSeriesStroke(10, stroke19, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = lineAndShapeRenderer17.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint24 = lineAndShapeRenderer17.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer17);
        categoryPlot25.setRangeMinorGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke37 = null;
        lineAndShapeRenderer35.setSeriesStroke(10, stroke37, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator41 = lineAndShapeRenderer35.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint42 = lineAndShapeRenderer35.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis31, valueAxis32, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer35);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke53 = null;
        lineAndShapeRenderer51.setSeriesStroke(10, stroke53, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator57 = lineAndShapeRenderer51.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint58 = lineAndShapeRenderer51.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis47, valueAxis48, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer51);
        boolean boolean60 = categoryPlot59.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double66 = rectangleInsets65.getTop();
        categoryPlot59.setInsets(rectangleInsets65, true);
        java.awt.geom.GeneralPath generalPath69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.RenderingSource renderingSource71 = null;
        categoryPlot59.select(generalPath69, rectangle2D70, renderingSource71);
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray74 = new org.jfree.chart.axis.ValueAxis[] { valueAxis73 };
        categoryPlot59.setRangeAxes(valueAxisArray74);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor76 = categoryPlot59.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis78.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color81 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis78.setTickLabelPaint((java.awt.Paint) color81);
        java.awt.Paint paint83 = categoryAxis78.getTickMarkPaint();
        categoryPlot59.setDomainGridlinePaint(paint83);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset85 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset85.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int90 = categoryPlot59.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset85);
        categoryPlot43.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset85);
        categoryPlot25.setDataset(15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset85);
        org.jfree.data.Range range93 = barRenderer5.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset85);
        org.jfree.data.Range range95 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset85, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryToolTipGenerator41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(categoryToolTipGenerator57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 100.0d + "'", double66 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray74);
        org.junit.Assert.assertNotNull(categoryAnchor76);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertNotNull(range93);
        org.junit.Assert.assertNotNull(range95);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot14.zoomDomainAxes((double) (byte) -1, (double) 10, plotRenderingInfo33, point2D34);
        categoryPlot14.setRangeMinorGridlinesVisible(true);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Shape shape7 = null;
        lineAndShapeRenderer0.setSeriesShape((int) (short) 100, shape7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke17 = null;
        lineAndShapeRenderer15.setSeriesStroke(10, stroke17, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = lineAndShapeRenderer15.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint22 = lineAndShapeRenderer15.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15);
        lineAndShapeRenderer0.setPlot(categoryPlot23);
        boolean boolean25 = lineAndShapeRenderer0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        org.jfree.data.general.DatasetGroup datasetGroup63 = defaultCategoryDataset56.getGroup();
        int int64 = defaultCategoryDataset56.getRowCount();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(datasetGroup63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis4.setTickLabelPaint((java.awt.Paint) color7);
        java.awt.Paint paint9 = categoryAxis4.getTickMarkPaint();
        categoryAxis4.setTickLabelsVisible(false);
        java.awt.Color color15 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis4.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color15);
        java.awt.Color color17 = java.awt.Color.ORANGE;
        float[] floatArray23 = new float[] { 100L, (-1L), 100.0f, (short) 100, (-1L) };
        float[] floatArray24 = color17.getRGBComponents(floatArray23);
        float[] floatArray25 = color15.getComponents(floatArray24);
        float[] floatArray26 = java.awt.Color.RGBtoHSB(4, 0, 0, floatArray24);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue((java.lang.Number) 192, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (-8458323));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Color color12 = java.awt.Color.getColor("java.awt.Color[r=255,g=200,b=0]", 8);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color12);
        int int14 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 192);
        org.jfree.chart.plot.Plot plot3 = categoryAxis0.getPlot();
        boolean boolean4 = categoryAxis0.isMinorTickMarksVisible();
        categoryAxis0.setTickMarkInsideLength(1.0f);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = null;
        boolean boolean2 = paintList0.equals(obj1);
        java.awt.Paint paint4 = paintList0.getPaint((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke13 = null;
        lineAndShapeRenderer11.setSeriesStroke(10, stroke13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = lineAndShapeRenderer11.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint18 = lineAndShapeRenderer11.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        boolean boolean20 = categoryPlot19.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double26 = rectangleInsets25.getTop();
        categoryPlot19.setInsets(rectangleInsets25, true);
        java.awt.Stroke stroke29 = categoryPlot19.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot19.panDomainAxes((double) (-2), plotRenderingInfo31, point2D32);
        boolean boolean34 = paintList0.equals((java.lang.Object) point2D32);
        java.lang.Object obj35 = null;
        boolean boolean36 = paintList0.equals(obj35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        java.lang.String str38 = plotEntity36.getShapeCoords();
        java.lang.Object obj39 = plotEntity36.clone();
        plotEntity36.setToolTipText("PlotOrientation.VERTICAL");
        plotEntity36.setToolTipText("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-3,-3,3,3" + "'", str38.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=200,b=0]");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.awt.Paint paint3 = legendItem1.getFillPaint();
        java.lang.String str4 = legendItem1.getURLText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        int int19 = categoryPlot14.getBackgroundImageAlignment();
        java.lang.Comparable comparable20 = null;
        categoryPlot14.setDomainCrosshairRowKey(comparable20, false);
        java.awt.Stroke stroke23 = categoryPlot14.getDomainGridlineStroke();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke9 = null;
        lineAndShapeRenderer7.setSeriesStroke(10, stroke9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer7.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint14 = lineAndShapeRenderer7.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        boolean boolean16 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double22 = rectangleInsets21.getTop();
        categoryPlot15.setInsets(rectangleInsets21, true);
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot15.select(generalPath25, rectangle2D26, renderingSource27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        categoryPlot15.setRangeAxes(valueAxisArray30);
        keyedObjects2D0.setObject((java.lang.Object) valueAxisArray30, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) (byte) 10);
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) '4');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (4) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray30);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setTickLabelsVisible(false);
        float float8 = categoryAxis1.getTickMarkInsideLength();
        double double9 = categoryAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer2.setBaseCreateEntities(false, true);
        lineAndShapeRenderer2.setDrawOutlines(false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot14.getDomainMarkers(0, layer20);
        java.awt.Paint paint22 = categoryPlot14.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Point2D point2D25 = null;
        org.jfree.chart.plot.PlotState plotState26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            categoryPlot14.draw(graphics2D23, rectangle2D24, point2D25, plotState26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        java.lang.String str38 = plotEntity36.getShapeCoords();
        java.lang.Object obj39 = plotEntity36.clone();
        plotEntity36.setToolTipText("PlotOrientation.VERTICAL");
        plotEntity36.setURLText("");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-3,-3,3,3" + "'", str38.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        java.lang.String str38 = plotEntity36.getToolTipText();
        java.lang.String str39 = plotEntity36.getShapeType();
        java.lang.String str40 = plotEntity36.toString();
        java.lang.String str41 = plotEntity36.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str38.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "rect" + "'", str39.equals("rect"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str40.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str41.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        java.awt.Paint paint8 = barRenderer0.getItemOutlinePaint((int) (short) -1, (int) (short) 100, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        barRenderer0.setSeriesToolTipGenerator((int) ' ', categoryToolTipGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer0.getNegativeItemLabelPositionFallback();
        barRenderer0.setMaximumBarWidth((double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertNull(itemLabelPosition13);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke14 = null;
        lineAndShapeRenderer12.setSeriesStroke(10, stroke14, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = lineAndShapeRenderer12.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        lineAndShapeRenderer12.setBaseURLGenerator(categoryURLGenerator19);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer12.setSeriesStroke((int) 'a', stroke22);
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke22);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint27 = defaultDrawingSupplier26.getNextPaint();
        java.awt.Shape shape28 = defaultDrawingSupplier26.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke37 = null;
        lineAndShapeRenderer35.setSeriesStroke(10, stroke37, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator41 = lineAndShapeRenderer35.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint42 = lineAndShapeRenderer35.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis31, valueAxis32, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer35);
        boolean boolean44 = categoryPlot43.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double50 = rectangleInsets49.getTop();
        categoryPlot43.setInsets(rectangleInsets49, true);
        java.awt.geom.GeneralPath generalPath53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.RenderingSource renderingSource55 = null;
        categoryPlot43.select(generalPath53, rectangle2D54, renderingSource55);
        categoryPlot43.setNotify(true);
        boolean boolean59 = categoryPlot43.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity62 = new org.jfree.chart.entity.PlotEntity(shape28, (org.jfree.chart.plot.Plot) categoryPlot43, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str63 = categoryPlot43.getNoDataMessage();
        org.jfree.chart.axis.AxisSpace axisSpace64 = null;
        categoryPlot43.setFixedRangeAxisSpace(axisSpace64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot43.zoomDomainAxes(100.0d, (double) 3, plotRenderingInfo68, point2D69);
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        categoryPlot43.setRangeAxis(valueAxis71);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot43.getDomainAxisEdge(3);
        java.awt.Graphics2D graphics2D75 = null;
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState79 = null;
        boolean boolean80 = categoryPlot43.render(graphics2D75, rectangle2D76, 1, plotRenderingInfo78, categoryCrosshairState79);
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        try {
            lineAndShapeRenderer2.drawBackground(graphics2D25, categoryPlot43, rectangle2D81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(categoryToolTipGenerator41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 100.0d + "'", double50 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        categoryPlot17.setFixedRangeAxisSpace(axisSpace38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot17.zoomDomainAxes(100.0d, (double) 3, plotRenderingInfo42, point2D43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        categoryPlot17.setRangeAxis(valueAxis45);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot17.getDomainAxisEdge(3);
        categoryPlot17.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.Marker marker51 = null;
        try {
            boolean boolean52 = categoryPlot17.removeRangeMarker(marker51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        double double7 = categoryAxis1.getLowerMargin();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.lang.Class<?> wildcardClass9 = color8.getClass();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        double double3 = itemLabelPosition2.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = itemLabelPosition2.getItemLabelAnchor();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean8 = lineAndShapeRenderer5.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = lineAndShapeRenderer5.removeAnnotation(categoryAnnotation9);
        boolean boolean11 = lineAndShapeRenderer5.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = lineAndShapeRenderer5.getBaseURLGenerator();
        boolean boolean13 = itemLabelPosition2.equals((java.lang.Object) lineAndShapeRenderer5);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer6.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        java.awt.Color color10 = java.awt.Color.ORANGE;
        lineAndShapeRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean15 = lineAndShapeRenderer12.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        boolean boolean17 = lineAndShapeRenderer12.removeAnnotation(categoryAnnotation16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer12.getSeriesNegativeItemLabelPosition((int) ' ');
        lineAndShapeRenderer6.setBasePositiveItemLabelPosition(itemLabelPosition19);
        org.jfree.chart.text.TextAnchor textAnchor21 = itemLabelPosition19.getRotationAnchor();
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition19, true);
        java.awt.Paint paint25 = lineAndShapeRenderer0.getLegendTextPaint(100);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean20 = categoryPlot14.removeDomainMarker((int) (short) 1, marker17, layer18, true);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setRangeAxisLocation((int) 'a', axisLocation22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke32 = null;
        lineAndShapeRenderer30.setSeriesStroke(10, stroke32, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = lineAndShapeRenderer30.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint37 = lineAndShapeRenderer30.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis26, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer30);
        boolean boolean39 = categoryPlot38.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double45 = rectangleInsets44.getTop();
        categoryPlot38.setInsets(rectangleInsets44, true);
        java.awt.geom.GeneralPath generalPath48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.RenderingSource renderingSource50 = null;
        categoryPlot38.select(generalPath48, rectangle2D49, renderingSource50);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray53 = new org.jfree.chart.axis.ValueAxis[] { valueAxis52 };
        categoryPlot38.setRangeAxes(valueAxisArray53);
        categoryPlot14.setRangeAxes(valueAxisArray53);
        java.awt.Font font56 = categoryPlot14.getNoDataMessageFont();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(categoryToolTipGenerator36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray53);
        org.junit.Assert.assertNotNull(font56);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 255, (float) 1L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer0.setBaseItemLabelFont(font6);
        java.awt.Paint paint8 = null;
        lineAndShapeRenderer0.setBasePaint(paint8, false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Font font6 = categoryAxis1.getTickLabelFont();
        categoryAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke21 = null;
        lineAndShapeRenderer19.setSeriesStroke(10, stroke21, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = lineAndShapeRenderer19.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint26 = lineAndShapeRenderer19.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        boolean boolean28 = categoryPlot27.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double34 = rectangleInsets33.getTop();
        categoryPlot27.setInsets(rectangleInsets33, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot27.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo39, point2D40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot27.getRangeAxisEdge((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        try {
            org.jfree.chart.axis.AxisState axisState45 = categoryAxis1.draw(graphics2D9, (double) (-1), rectangle2D11, rectangle2D12, rectangleEdge43, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(categoryToolTipGenerator25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseCreateEntities();
        java.lang.Object obj2 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.clear();
        java.util.List list2 = keyedObjects0.getKeys();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = plotEntity36.toString();
        java.lang.String str38 = plotEntity36.getShapeCoords();
        java.awt.Shape shape39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        plotEntity36.setArea(shape39);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str37.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-3,-3,3,3" + "'", str38.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean9 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        lineAndShapeRenderer2.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean18 = lineAndShapeRenderer2.getItemLineVisible(8, (int) (short) 10);
        boolean boolean19 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D22, categoryPlot23, valueAxis24, marker25, rectangle2D26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = lineAndShapeRenderer2.getNegativeItemLabelPosition(0, (int) 'a', false);
        java.lang.Boolean boolean33 = lineAndShapeRenderer2.getSeriesCreateEntities((-123));
        boolean boolean36 = lineAndShapeRenderer2.getItemVisible((int) (byte) 100, 15);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.setRangePannable(false);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot14.getDomainMarkers(0, layer20);
        categoryPlot14.setForegroundAlpha((float) (short) 1);
        java.lang.Object obj24 = categoryPlot14.clone();
        categoryPlot14.clearDomainMarkers();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = null;
        boolean boolean2 = paintList0.equals(obj1);
        java.awt.Paint paint4 = paintList0.getPaint((int) (short) 1);
        boolean boolean6 = paintList0.equals((java.lang.Object) (-1.0d));
        java.awt.Paint paint8 = paintList0.getPaint((int) (byte) 10);
        java.awt.Paint paint10 = paintList0.getPaint((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        int int16 = categoryPlot14.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot14.panRangeAxes(100.0d, plotRenderingInfo18, point2D19);
        java.awt.Color color21 = java.awt.Color.YELLOW;
        int int22 = color21.getRed();
        categoryPlot14.setDomainCrosshairPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke11 = null;
        lineAndShapeRenderer9.setSeriesStroke(10, stroke11, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer9.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint16 = lineAndShapeRenderer9.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        boolean boolean18 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double24 = rectangleInsets23.getTop();
        categoryPlot17.setInsets(rectangleInsets23, true);
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot17.select(generalPath27, rectangle2D28, renderingSource29);
        categoryPlot17.setNotify(true);
        boolean boolean33 = categoryPlot17.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot17, "org.jfree.chart.event.ChartChangeEvent[source=10.0]", "org.jfree.chart.event.ChartChangeEvent[source=10.0]");
        java.lang.String str37 = categoryPlot17.getNoDataMessage();
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        categoryPlot17.setFixedRangeAxisSpace(axisSpace38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot17.zoomDomainAxes(100.0d, (double) 3, plotRenderingInfo42, point2D43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        categoryPlot17.setRangeAxis(valueAxis45);
        int int47 = categoryPlot17.getDatasetCount();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) itemLabelAnchor1);
        int int3 = keyedObjects2D0.getRowCount();
        try {
            keyedObjects2D0.removeRow((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint6 = null;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", "", "", "org.jfree.chart.event.ChartChangeEvent[source=10.0]", shape4, stroke5, paint6);
        legendItem7.setSeriesIndex((int) '4');
        java.awt.Paint paint10 = legendItem7.getLabelPaint();
        java.awt.Paint paint11 = legendItem7.getFillPaint();
        java.lang.Comparable comparable12 = legendItem7.getSeriesKey();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(comparable12);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean(8, (java.lang.Boolean) false);
        java.lang.Boolean boolean5 = booleanList0.getBoolean((int) '4');
        booleanList0.setBoolean(89, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer0.setDefaultEntityRadius((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = lineAndShapeRenderer0.getSeriesURLGenerator((int) 'a');
        java.awt.Paint paint12 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean6 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getBaseItemLabelFont();
        lineAndShapeRenderer0.setSeriesLinesVisible(255, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer2.setBaseCreateEntities(false, true);
        lineAndShapeRenderer2.setBaseCreateEntities(false);
        lineAndShapeRenderer2.setUseOutlinePaint(false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        double double5 = barRenderer0.getShadowYOffset();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke14 = null;
        lineAndShapeRenderer12.setSeriesStroke(10, stroke14, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = lineAndShapeRenderer12.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint19 = lineAndShapeRenderer12.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        categoryPlot20.setRangeMinorGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke32 = null;
        lineAndShapeRenderer30.setSeriesStroke(10, stroke32, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = lineAndShapeRenderer30.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint37 = lineAndShapeRenderer30.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis26, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer30);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke48 = null;
        lineAndShapeRenderer46.setSeriesStroke(10, stroke48, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator52 = lineAndShapeRenderer46.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint53 = lineAndShapeRenderer46.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis42, valueAxis43, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer46);
        boolean boolean55 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double61 = rectangleInsets60.getTop();
        categoryPlot54.setInsets(rectangleInsets60, true);
        java.awt.geom.GeneralPath generalPath64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.RenderingSource renderingSource66 = null;
        categoryPlot54.select(generalPath64, rectangle2D65, renderingSource66);
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray69 = new org.jfree.chart.axis.ValueAxis[] { valueAxis68 };
        categoryPlot54.setRangeAxes(valueAxisArray69);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor71 = categoryPlot54.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis73.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color76 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis73.setTickLabelPaint((java.awt.Paint) color76);
        java.awt.Paint paint78 = categoryAxis73.getTickMarkPaint();
        categoryPlot54.setDomainGridlinePaint(paint78);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset80 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset80.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int85 = categoryPlot54.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset80);
        categoryPlot38.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset80);
        categoryPlot20.setDataset(15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset80);
        org.jfree.data.Range range88 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset80);
        defaultCategoryDataset80.fireSelectionEvent();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryToolTipGenerator36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(categoryToolTipGenerator52);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.0d + "'", double61 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray69);
        org.junit.Assert.assertNotNull(categoryAnchor71);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
        org.junit.Assert.assertNotNull(range88);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        categoryPlot14.setBackgroundAlpha((float) 2);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot14.getDomainMarkers(layer18);
        boolean boolean20 = categoryPlot14.isRangeZoomable();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        java.awt.Shape shape7 = null;
        lineAndShapeRenderer0.setSeriesShape((int) (short) 100, shape7);
        boolean boolean9 = lineAndShapeRenderer0.getUseFillPaint();
        java.lang.Object obj10 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        lineAndShapeRenderer2.setBaseCreateEntities(false, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator(52, categoryItemLabelGenerator11);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Font font6 = categoryAxis1.getTickLabelFont();
        categoryAxis1.setAxisLineVisible(false);
        java.lang.String str9 = categoryAxis1.getLabelToolTip();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke18 = null;
        lineAndShapeRenderer16.setSeriesStroke(10, stroke18, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = lineAndShapeRenderer16.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint23 = lineAndShapeRenderer16.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        boolean boolean25 = categoryPlot24.isRangeGridlinesVisible();
        categoryPlot24.setBackgroundAlpha((float) 2);
        float float28 = categoryPlot24.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot24.zoomDomainAxes((double) 5, plotRenderingInfo30, point2D31);
        boolean boolean33 = categoryAxis1.equals((java.lang.Object) categoryPlot24);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        categoryAxis1.setTickLabelsVisible(false);
        org.jfree.chart.plot.Plot plot9 = categoryAxis1.getPlot();
        java.lang.Object obj10 = categoryAxis1.clone();
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean15 = lineAndShapeRenderer12.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        boolean boolean17 = lineAndShapeRenderer12.removeAnnotation(categoryAnnotation16);
        boolean boolean18 = lineAndShapeRenderer12.getUseOutlinePaint();
        lineAndShapeRenderer12.setBaseSeriesVisible(false, true);
        boolean boolean22 = lineAndShapeRenderer12.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean25 = barRenderer24.isDrawBarOutline();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = null;
        barRenderer24.setGradientPaintTransformer(gradientPaintTransformer26);
        barRenderer24.setMinimumBarLength((double) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.data.Range range32 = barRenderer24.findRangeBounds(categoryDataset30, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer33.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font38 = lineAndShapeRenderer33.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean39 = lineAndShapeRenderer33.getAutoPopulateSeriesFillPaint();
        java.awt.Font font40 = lineAndShapeRenderer33.getBaseItemLabelFont();
        barRenderer24.setBaseLegendTextFont(font40);
        lineAndShapeRenderer12.setSeriesItemLabelFont((int) (short) 10, font40);
        categoryAxis1.setLabelFont(font40);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNull(font38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(font40);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeZeroBaselineStroke();
        boolean boolean17 = categoryPlot14.isNotify();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke24 = null;
        lineAndShapeRenderer22.setSeriesStroke(10, stroke24, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = lineAndShapeRenderer22.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint29 = lineAndShapeRenderer22.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        boolean boolean31 = categoryPlot30.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double37 = rectangleInsets36.getTop();
        categoryPlot30.setInsets(rectangleInsets36, true);
        java.awt.geom.GeneralPath generalPath40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot30.select(generalPath40, rectangle2D41, renderingSource42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot30.setRangeAxes(valueAxisArray45);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = categoryPlot30.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis49.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis49.setTickLabelPaint((java.awt.Paint) color52);
        java.awt.Paint paint54 = categoryAxis49.getTickMarkPaint();
        categoryPlot30.setDomainGridlinePaint(paint54);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset56 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset56.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int61 = categoryPlot30.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        categoryPlot14.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset56);
        defaultCategoryDataset56.addValue((double) (byte) 100, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) 1.0f);
        defaultCategoryDataset56.addValue((double) 5, (java.lang.Comparable) "-3,-3,3,3", (java.lang.Comparable) (short) 100);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint1 = lineAndShapeRenderer0.getBaseFillPaint();
        double double2 = lineAndShapeRenderer0.getItemMargin();
        boolean boolean3 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean13 = lineAndShapeRenderer6.getBaseItemLabelsVisible();
        lineAndShapeRenderer6.setDefaultEntityRadius(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer6.getNegativeItemLabelPosition(1, (int) (short) 1, true);
        boolean boolean22 = lineAndShapeRenderer6.getItemLineVisible(8, (int) (short) 10);
        java.lang.Boolean boolean24 = lineAndShapeRenderer6.getSeriesVisible((int) '4');
        boolean boolean27 = lineAndShapeRenderer6.getItemLineVisible((int) (short) -1, (-2));
        java.awt.Paint paint28 = lineAndShapeRenderer6.getBasePaint();
        lineAndShapeRenderer0.setBaseItemLabelPaint(paint28);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) itemLabelAnchor1);
        int int3 = keyedObjects2D0.getRowCount();
        try {
            keyedObjects2D0.removeRow((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer0.getBarPainter();
        barRenderer0.setBase(1.0d);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke13 = null;
        lineAndShapeRenderer11.setSeriesStroke(10, stroke13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = lineAndShapeRenderer11.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint18 = lineAndShapeRenderer11.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        categoryPlot19.setRangeMinorGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke31 = null;
        lineAndShapeRenderer29.setSeriesStroke(10, stroke31, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = lineAndShapeRenderer29.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint36 = lineAndShapeRenderer29.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis25, valueAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer29);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke47 = null;
        lineAndShapeRenderer45.setSeriesStroke(10, stroke47, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator51 = lineAndShapeRenderer45.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint52 = lineAndShapeRenderer45.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis41, valueAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer45);
        boolean boolean54 = categoryPlot53.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double60 = rectangleInsets59.getTop();
        categoryPlot53.setInsets(rectangleInsets59, true);
        java.awt.geom.GeneralPath generalPath63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.RenderingSource renderingSource65 = null;
        categoryPlot53.select(generalPath63, rectangle2D64, renderingSource65);
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray68 = new org.jfree.chart.axis.ValueAxis[] { valueAxis67 };
        categoryPlot53.setRangeAxes(valueAxisArray68);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor70 = categoryPlot53.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis72.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color75 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis72.setTickLabelPaint((java.awt.Paint) color75);
        java.awt.Paint paint77 = categoryAxis72.getTickMarkPaint();
        categoryPlot53.setDomainGridlinePaint(paint77);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset79 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset79.addValue((java.lang.Number) (short) 10, (java.lang.Comparable) (short) -1, (java.lang.Comparable) (byte) 100);
        int int84 = categoryPlot53.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset79);
        categoryPlot37.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset79);
        categoryPlot19.setDataset(15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset79);
        org.jfree.data.Range range88 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset79, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryToolTipGenerator35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryToolTipGenerator51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 100.0d + "'", double60 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray68);
        org.junit.Assert.assertNotNull(categoryAnchor70);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(range88);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) 100);
        double double7 = categoryAxis4.getCategoryMargin();
        categoryAxis4.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis4.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke19 = null;
        lineAndShapeRenderer17.setSeriesStroke(10, stroke19, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = lineAndShapeRenderer17.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint24 = lineAndShapeRenderer17.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer17);
        boolean boolean26 = categoryPlot25.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double32 = rectangleInsets31.getTop();
        categoryPlot25.setInsets(rectangleInsets31, true);
        categoryAxis4.setPlot((org.jfree.chart.plot.Plot) categoryPlot25);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis37.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis37.setTickLabelPaint((java.awt.Paint) color40);
        java.awt.Paint paint42 = categoryAxis37.getLabelPaint();
        categoryAxis37.setMinorTickMarkOutsideLength((float) (byte) 10);
        java.lang.String str45 = categoryAxis37.getLabel();
        double double46 = categoryAxis37.getLabelAngle();
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D2, categoryPlot25, categoryAxis37, categoryMarker47, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str45.equals("java.awt.Color[r=255,g=200,b=0]"));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke4 = null;
        lineAndShapeRenderer2.setSeriesStroke(10, stroke4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (byte) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        lineAndShapeRenderer2.setSeriesStroke((int) 'a', stroke12);
        java.awt.Paint paint15 = lineAndShapeRenderer2.getSeriesPaint((int) (short) 0);
        boolean boolean16 = lineAndShapeRenderer2.getUseOutlinePaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Font font6 = categoryAxis1.getTickLabelFont();
        categoryAxis1.setAxisLineVisible(false);
        categoryAxis1.setLabelAngle(0.0d);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType17 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke26 = null;
        lineAndShapeRenderer24.setSeriesStroke(10, stroke26, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = lineAndShapeRenderer24.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint31 = lineAndShapeRenderer24.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        boolean boolean33 = categoryPlot32.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double39 = rectangleInsets38.getTop();
        categoryPlot32.setInsets(rectangleInsets38, true);
        java.awt.geom.GeneralPath generalPath42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.RenderingSource renderingSource44 = null;
        categoryPlot32.select(generalPath42, rectangle2D43, renderingSource44);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray47 = new org.jfree.chart.axis.ValueAxis[] { valueAxis46 };
        categoryPlot32.setRangeAxes(valueAxisArray47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot32.getRangeAxisEdge();
        boolean boolean50 = gradientPaintTransformType17.equals((java.lang.Object) rectangleEdge49);
        try {
            double double51 = categoryAxis1.getCategorySeriesMiddle((int) (byte) 10, (int) (byte) 0, 2, (int) 'a', (double) 'a', rectangle2D16, rectangleEdge49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(gradientPaintTransformType17);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.0d + "'", double39 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray47);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot14.zoomRangeAxes((double) 100, plotRenderingInfo17, point2D18);
        categoryPlot14.clearAnnotations();
        java.awt.Stroke stroke21 = categoryPlot14.getRangeCrosshairStroke();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        java.awt.Paint paint8 = barRenderer0.getItemOutlinePaint((int) (short) -1, (int) (short) 100, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        double double10 = barRenderer0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        java.awt.Font font5 = lineAndShapeRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        boolean boolean6 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Font font7 = lineAndShapeRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint11 = lineAndShapeRenderer0.getItemFillPaint((-123), (int) 'a', false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color14 = color13.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=10.0]", (java.awt.Paint) color14);
        int int16 = color14.getRed();
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color14, true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 89 + "'", int16 == 89);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) 4, (double) (short) 100, (double) (byte) 10);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.Stroke stroke24 = categoryPlot14.getRangeMinorGridlineStroke();
        double double25 = categoryPlot14.getAnchorValue();
        java.util.List list27 = null;
        try {
            categoryPlot14.mapDatasetToDomainAxes((-123), list27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomDomainAxes((double) 100.0f, (double) '4', plotRenderingInfo26, point2D27);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot14.zoomDomainAxes((double) (byte) -1, (double) 10, plotRenderingInfo33, point2D34);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator36 = new org.jfree.chart.util.DefaultShadowGenerator();
        int int37 = defaultShadowGenerator36.getShadowSize();
        categoryPlot14.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot14.zoomRangeAxes(2.0d, plotRenderingInfo40, point2D41, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot14.getDomainAxisLocation();
        int int16 = categoryPlot14.getDatasetCount();
        java.awt.Stroke stroke17 = categoryPlot14.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemVisible(0, 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        java.awt.Paint paint8 = null;
        lineAndShapeRenderer0.setSeriesItemLabelPaint(5, paint8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Paint paint4 = lineAndShapeRenderer2.lookupSeriesOutlinePaint((-1));
        boolean boolean5 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = lineAndShapeRenderer2.getSelectedItemAttributes();
        java.lang.Boolean boolean7 = renderAttributes6.getDefaultCreateEntity();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke12 = null;
        lineAndShapeRenderer10.setSeriesStroke(10, stroke12, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = lineAndShapeRenderer10.getSeriesToolTipGenerator((int) (byte) 1);
        boolean boolean17 = lineAndShapeRenderer10.getBaseItemLabelsVisible();
        lineAndShapeRenderer10.setDefaultEntityRadius(8);
        java.awt.Paint paint21 = lineAndShapeRenderer10.getSeriesItemLabelPaint((int) (short) 10);
        java.awt.Font font23 = lineAndShapeRenderer10.lookupLegendTextFont((int) ' ');
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        lineAndShapeRenderer10.setSeriesPaint(0, (java.awt.Paint) color25);
        renderAttributes6.setDefaultLabelPaint((java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(renderAttributes6);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke8 = null;
        lineAndShapeRenderer6.setSeriesStroke(10, stroke8, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = lineAndShapeRenderer6.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint13 = lineAndShapeRenderer6.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean15 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double21 = rectangleInsets20.getTop();
        categoryPlot14.setInsets(rectangleInsets20, true);
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        categoryPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot14.setRangeAxes(valueAxisArray29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot14.getRangeAxisEdge();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint33 = defaultDrawingSupplier32.getNextPaint();
        java.awt.Paint paint34 = defaultDrawingSupplier32.getNextFillPaint();
        categoryPlot14.setRangeGridlinePaint(paint34);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseFillPaint(paint2, true);
        java.awt.Paint paint8 = barRenderer0.getItemOutlinePaint((int) (short) -1, (int) (short) 100, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer10.getIncludeBaseInRange();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer10.setBaseFillPaint(paint12, true);
        java.awt.Paint paint18 = barRenderer10.getItemOutlinePaint((int) (short) -1, (int) (short) 100, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = barRenderer10.getGradientPaintTransformer();
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer19);
        boolean boolean21 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        java.awt.Stroke stroke30 = null;
        lineAndShapeRenderer28.setSeriesStroke(10, stroke30, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = lineAndShapeRenderer28.getSeriesToolTipGenerator((int) (byte) 1);
        java.awt.Paint paint35 = lineAndShapeRenderer28.getBasePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis24, valueAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer28);
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, (double) ' ', 0.0d, 0.0d);
        double double43 = rectangleInsets42.getTop();
        categoryPlot36.setInsets(rectangleInsets42, true);
        java.awt.geom.GeneralPath generalPath46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.RenderingSource renderingSource48 = null;
        categoryPlot36.select(generalPath46, rectangle2D47, renderingSource48);
        categoryPlot36.setNotify(true);
        boolean boolean52 = categoryPlot36.isNotify();
        categoryPlot36.setForegroundAlpha((float) (short) 1);
        java.awt.Paint paint55 = categoryPlot36.getDomainCrosshairPaint();
        barRenderer0.setPlot(categoryPlot36);
        categoryPlot36.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 100.0d + "'", double43 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(paint55);
    }
}

