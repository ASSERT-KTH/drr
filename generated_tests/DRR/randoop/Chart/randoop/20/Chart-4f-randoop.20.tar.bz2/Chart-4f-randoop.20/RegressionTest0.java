import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int3 = java.awt.Color.HSBtoRGB((float) 100L, (float) (byte) -1, (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound(xYDataset0, (int) (short) 10, (double) (-1), (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis3D1.draw(graphics2D2, (double) 1, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = null;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 0, dateTickUnitType2, (int) (short) 1, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 10, 0.0f, (double) 10L, (float) (byte) 0, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1, 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("GradientPaintTransformType.CENTER_HORIZONTAL", regularTimePeriod1, regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        boolean boolean4 = dateTickMarkPosition0.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.setBaseCreateEntities(true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound(xYDataset0, (int) (short) 0, 0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("GradientPaintTransformType.CENTER_HORIZONTAL", graphics2D1, (double) (byte) 100, (float) (-1), (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        java.lang.String str44 = numberAxis3D10.getLabel();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        try {
            barRenderer3D0.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D5, categoryPlot6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, (org.jfree.chart.axis.ValueAxis) logAxis9, categoryDataset10, (int) (short) 1, 0, false, (-14666742));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        double double2 = crosshairState1.getCrosshairDistance();
        crosshairState1.updateCrosshairX((double) 1.0f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        java.awt.Color color4 = java.awt.Color.yellow;
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D12.setAxisLineVisible(false);
        java.awt.Paint paint15 = numberAxis3D12.getTickMarkPaint();
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { chartColor3, color4, color5, paint6, chartColor10, paint15 };
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = java.awt.Color.yellow;
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { paint17, color18, color19, color20 };
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        xYBarRenderer25.notifyListeners(rendererChangeEvent26);
        java.awt.Stroke stroke29 = xYBarRenderer25.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        xYBarRenderer31.notifyListeners(rendererChangeEvent32);
        java.awt.Stroke stroke35 = xYBarRenderer31.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] { stroke22, stroke23, stroke29, stroke35 };
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer38 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        xYBarRenderer38.notifyListeners(rendererChangeEvent39);
        java.awt.Stroke stroke42 = xYBarRenderer38.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke stroke43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray44 = new java.awt.Stroke[] { stroke42, stroke43 };
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Shape[] shapeArray48 = new java.awt.Shape[] { shape47 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier49 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray21, strokeArray36, strokeArray44, shapeArray48);
        java.lang.Object obj50 = defaultDrawingSupplier49.clone();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(strokeArray44);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shapeArray48);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Paint paint7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color17 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYBarRenderer19.notifyListeners(rendererChangeEvent20);
        java.awt.Stroke stroke23 = xYBarRenderer19.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer10.drawDomainLine(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) periodAxis14, rectangle2D15, (double) 100, (java.awt.Paint) color17, stroke23);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color30 = java.awt.Color.MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "GradientPaintTransformType.CENTER_HORIZONTAL", "", false, shape5, false, paint7, false, (java.awt.Paint) color9, stroke23, false, shape28, stroke29, (java.awt.Paint) color30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        try {
            xYBarRenderer1.setSeriesShape((-14666742), shape12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            chartRenderingInfo0.setChartArea(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        double[] doubleArray6 = new double[] { 100.0d, (short) 100, (byte) 10, 100.0d };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray0, comparableArray1, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        try {
            double double6 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor1, (int) (short) 100, (int) (short) 0, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairX(0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource7 = null;
        chartRenderingInfo6.setRenderingSource(renderingSource7);
        try {
            jFreeChart1.draw(graphics2D3, rectangle2D4, point2D5, chartRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        try {
            barRenderer3D0.setPlot(categoryPlot3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        try {
            java.awt.GradientPaint gradientPaint10 = standardGradientPaintTransformer0.transform(gradientPaint1, shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        int int4 = chartColor3.getRGB();
        float[] floatArray6 = new float[] { 14 };
        try {
            float[] floatArray7 = chartColor3.getRGBComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-14666742) + "'", int4 == (-14666742));
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        boolean boolean4 = xYBarRenderer1.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYBarRenderer1.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYBarRenderer10.notifyListeners(rendererChangeEvent11);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesStroke(0);
        xYBarRenderer1.setBaseStroke(stroke14, false);
        java.awt.Stroke stroke18 = xYBarRenderer1.getSeriesStroke(100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(stroke18);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseLinesVisible(false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        java.util.Locale locale15 = periodAxis4.getLocale();
        java.lang.Class class16 = null;
        try {
            periodAxis4.setMajorTickTimePeriodClass(class16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(locale15);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAxisLineVisible(false);
        java.text.NumberFormat numberFormat4 = numberAxis3D1.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.LegendTitle legendTitle2 = null;
        try {
            jFreeChart1.addLegend(legendTitle2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource8 = null;
        chartRenderingInfo7.setRenderingSource(renderingSource8);
        try {
            java.awt.image.BufferedImage bufferedImage10 = jFreeChart1.createBufferedImage((int) ' ', 0, (double) 100L, (double) 86400000L, chartRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (32) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D10.setAxisLineVisible(false);
        java.awt.Font font13 = numberAxis3D10.getLabelFont();
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            barRenderer3D0.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, marker14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        try {
            java.lang.String str7 = standardXYSeriesLabelGenerator3.generateLabel(xYDataset5, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        java.awt.Paint paint44 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        barRenderer3D0.setShadowPaint(paint44);
        barRenderer3D0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Shape shape0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.Number number0 = null;
        try {
            org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(number0, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'x' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = barRenderer3D0.initialise(graphics2D4, rectangle2D5, categoryPlot6, (int) (byte) 100, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Boolean boolean2 = xYLineAndShapeRenderer0.getSeriesShapesFilled(100);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseCreateEntities(true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setTickLabelsVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            numberAxis3D1.setTickUnit(numberTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAxisLineVisible(false);
        numberAxis3D1.setTickMarkInsideLength((float) 8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType8 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType8, (int) 'a');
        int int11 = dateTickUnit10.getRollMultiple();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) int11);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(dateTickUnitType8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        java.awt.Color color6 = java.awt.Color.yellow;
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.setAxisLineVisible(false);
        java.awt.Paint paint17 = numberAxis3D14.getTickMarkPaint();
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor5, color6, color7, paint8, chartColor12, paint17 };
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color20 = java.awt.Color.WHITE;
        java.awt.Color color21 = java.awt.Color.yellow;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { paint19, color20, color21, color22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYBarRenderer33.notifyListeners(rendererChangeEvent34);
        java.awt.Stroke stroke37 = xYBarRenderer33.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] { stroke24, stroke25, stroke31, stroke37 };
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYBarRenderer40.notifyListeners(rendererChangeEvent41);
        java.awt.Stroke stroke44 = xYBarRenderer40.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray46 = new java.awt.Stroke[] { stroke44, stroke45 };
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] { shape49 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray23, strokeArray38, strokeArray46, shapeArray50);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51, true);
        java.awt.Stroke stroke54 = defaultDrawingSupplier51.getNextStroke();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYBarRenderer1.getBaseToolTipGenerator();
        java.awt.Paint paint13 = xYBarRenderer1.getItemFillPaint((-16777216), (-14666742), true);
        java.awt.Shape shape14 = null;
        try {
            xYBarRenderer1.setLegendBar(shape14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bar' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (byte) -1);
        columnArrangement4.clear();
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) (short) 100, "Layer.FOREGROUND", true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        try {
            int int4 = timeSeriesCollection2.indexOf(timeSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = null;
        try {
            numberAxis3D10.setTickUnit(numberTickUnit44, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Color color8 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYBarRenderer10.notifyListeners(rendererChangeEvent11);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer1.drawDomainLine(graphics2D2, xYPlot3, (org.jfree.chart.axis.ValueAxis) periodAxis5, rectangle2D6, (double) 100, (java.awt.Paint) color8, stroke14);
        int int16 = periodAxis5.getMinorTickCount();
        java.util.Locale locale17 = periodAxis5.getLocale();
        try {
            java.util.ResourceBundle resourceBundle18 = java.util.ResourceBundle.getBundle("Layer.FOREGROUND", locale17);
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Layer.FOREGROUND, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(locale17);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY((double) ' ', (-16777216));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        boolean boolean4 = xYBarRenderer1.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter5 = xYBarRenderer1.getBarPainter();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D11.setAxisLineVisible(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D15.setAxisLineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        try {
            xYBarRenderer1.drawItem(graphics2D6, xYItemRendererState7, rectangle2D8, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.axis.ValueAxis) numberAxis3D15, xYDataset18, 0, 0, true, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(xYBarPainter5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.TimeZone timeZone3 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.Color color11 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        xYBarRenderer13.notifyListeners(rendererChangeEvent14);
        java.awt.Stroke stroke17 = xYBarRenderer13.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer4.drawDomainLine(graphics2D5, xYPlot6, (org.jfree.chart.axis.ValueAxis) periodAxis8, rectangle2D9, (double) 100, (java.awt.Paint) color11, stroke17);
        int int19 = periodAxis8.getMinorTickCount();
        java.util.Locale locale20 = periodAxis8.getLocale();
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month1, (org.jfree.data.time.RegularTimePeriod) month2, timeZone3, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(locale20);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.TextTitle textTitle3 = jFreeChart2.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3D4.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        java.awt.Font font7 = barRenderer3D4.getBaseItemLabelFont();
        textTitle3.setFont(font7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart10 = multiplePiePlot9.getPieChart();
        org.jfree.chart.title.TextTitle textTitle11 = jFreeChart10.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        barRenderer3D12.setPositiveItemLabelPositionFallback(itemLabelPosition13);
        java.awt.Font font15 = barRenderer3D12.getBaseItemLabelFont();
        textTitle11.setFont(font15);
        boolean boolean17 = textTitle11.getNotify();
        java.awt.Paint paint18 = textTitle11.getPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer21 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.HALF_ASCENT_RIGHT", font7, paint18, (float) (byte) 10, (int) (byte) 10, textMeasurer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(textTitle3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(jFreeChart10);
        org.junit.Assert.assertNotNull(textTitle11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        try {
            java.lang.Number number8 = xYSeries3.getX((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!", "GradientPaintTransformType.CENTER_HORIZONTAL");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!", "GradientPaintTransformType.CENTER_HORIZONTAL");
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo11);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        java.lang.Object obj19 = xYStepRenderer0.clone();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        org.jfree.chart.plot.Plot plot19 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity20 = new org.jfree.chart.entity.PlotEntity(shape18, plot19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 5, 1.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        xYBarRenderer1.setSeriesItemLabelsVisible(15, true);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis3D1.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets2.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = combinedDomainXYPlot0.getRangeAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            combinedDomainXYPlot0.handleClick(5, 0, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues0.getKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean4 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.XYPlot xYPlot5 = null;
        try {
            combinedDomainXYPlot0.add(xYPlot5, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subplot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        java.util.Locale locale15 = periodAxis4.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(locale15);
        org.junit.Assert.assertNotNull(tickUnitSource16);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            combinedDomainXYPlot0.drawOutline(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYBarRenderer4.notifyListeners(rendererChangeEvent5);
        java.awt.Stroke stroke8 = xYBarRenderer4.lookupSeriesStroke(0);
        combinedDomainXYPlot0.setDomainMinorGridlineStroke(stroke8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        try {
            combinedDomainXYPlot0.setDomainAxisLocation((int) (byte) -1, axisLocation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((-16777216), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        boolean boolean7 = xYSeries3.getAllowDuplicateXValues();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        xYSeries3.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        java.util.List list9 = xYSeries8.getItems();
        try {
            combinedDomainXYPlot0.mapDatasetToDomainAxes((-14666742), list9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean4 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            combinedDomainXYPlot0.addRangeMarker((int) (short) 10, marker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(layer7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType2, (int) 'a');
        java.text.DateFormat dateFormat6 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 10, dateTickUnitType2, 1, dateFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.0d, true, true);
        java.lang.Comparable comparable4 = null;
        try {
            xYSeries3.setKey(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        try {
            java.lang.Object obj5 = logFormat3.parseObject("hi!");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAxisLineVisible(false);
        java.awt.Paint paint4 = numberAxis3D1.getTickMarkPaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        combinedDomainXYPlot9.datasetChanged(datasetChangeEvent10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = combinedDomainXYPlot9.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.Color color21 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYBarRenderer23.notifyListeners(rendererChangeEvent24);
        java.awt.Stroke stroke27 = xYBarRenderer23.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer14.drawDomainLine(graphics2D15, xYPlot16, (org.jfree.chart.axis.ValueAxis) periodAxis18, rectangle2D19, (double) 100, (java.awt.Paint) color21, stroke27);
        boolean boolean31 = xYStepRenderer14.getItemShapeVisible(100, 0);
        boolean boolean32 = rectangleEdge13.equals((java.lang.Object) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            org.jfree.chart.axis.AxisState axisState34 = numberAxis3D1.draw(graphics2D5, 0.0d, rectangle2D7, rectangle2D8, rectangleEdge13, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        java.awt.Color color6 = java.awt.Color.yellow;
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.setAxisLineVisible(false);
        java.awt.Paint paint17 = numberAxis3D14.getTickMarkPaint();
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor5, color6, color7, paint8, chartColor12, paint17 };
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color20 = java.awt.Color.WHITE;
        java.awt.Color color21 = java.awt.Color.yellow;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { paint19, color20, color21, color22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYBarRenderer33.notifyListeners(rendererChangeEvent34);
        java.awt.Stroke stroke37 = xYBarRenderer33.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] { stroke24, stroke25, stroke31, stroke37 };
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYBarRenderer40.notifyListeners(rendererChangeEvent41);
        java.awt.Stroke stroke44 = xYBarRenderer40.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray46 = new java.awt.Stroke[] { stroke44, stroke45 };
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] { shape49 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray23, strokeArray38, strokeArray46, shapeArray50);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51, true);
        java.awt.Paint paint54 = multiplePiePlot0.getBackgroundPaint();
        java.awt.Paint paint55 = multiplePiePlot0.getBackgroundPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection56 = multiplePiePlot0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem58 = legendItemCollection56.get(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(legendItemCollection56);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        java.lang.String str2 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RangeType.FULL" + "'", str2.equals("RangeType.FULL"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator5 = null;
        xYBarRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis3D1.setTickLabelInsets(rectangleInsets2);
        double double5 = rectangleInsets2.calculateRightInset(0.4d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color2);
        xYBarRenderer1.setBaseSeriesVisibleInLegend(false, true);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.awt.Paint paint3 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) 12);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        combinedDomainXYPlot4.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = combinedDomainXYPlot4.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer9 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.Color color16 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        xYBarRenderer18.notifyListeners(rendererChangeEvent19);
        java.awt.Stroke stroke22 = xYBarRenderer18.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer9.drawDomainLine(graphics2D10, xYPlot11, (org.jfree.chart.axis.ValueAxis) periodAxis13, rectangle2D14, (double) 100, (java.awt.Paint) color16, stroke22);
        boolean boolean26 = xYStepRenderer9.getItemShapeVisible(100, 0);
        boolean boolean27 = rectangleEdge8.equals((java.lang.Object) 100);
        try {
            double double28 = categoryAxis3D0.getCategoryStart((-14666742), (int) (byte) 1, rectangle2D3, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = combinedDomainXYPlot0.getRangeAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            combinedDomainXYPlot0.handleClick(0, (int) (byte) -1, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        java.awt.Paint paint3 = null;
        try {
            numberAxis3D1.setTickMarkPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        boolean boolean7 = xYSeries3.getAllowDuplicateXValues();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        float float3 = multiplePiePlot1.getBackgroundImageAlpha();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot4.getPieChart();
        multiplePiePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart8 = multiplePiePlot7.getPieChart();
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        barRenderer3D10.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        java.awt.Font font13 = barRenderer3D10.getBaseItemLabelFont();
        textTitle9.setFont(font13);
        jFreeChart5.addSubtitle((org.jfree.chart.title.Title) textTitle9);
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity17 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart5, "Combined_Domain_XYPlot");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(jFreeChart5);
        org.junit.Assert.assertNotNull(jFreeChart8);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat2 = null;
        logAxis1.setNumberFormatOverride(numberFormat2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            logAxis1.setTickUnit(numberTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("RangeType.FULL", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double[] doubleArray7 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray13 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray19 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray13, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "series", doubleArray20);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset21);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        int int3 = combinedDomainXYPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot8.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer12.notifyListeners(rendererChangeEvent13);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesStroke(0);
        combinedDomainXYPlot8.setDomainMinorGridlineStroke(stroke16);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        java.util.Locale locale33 = periodAxis22.getLocale();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.Paint paint36 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer1.drawDomainLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D34, (double) (short) 10, paint36, stroke37);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis3D40.setTickLabelInsets(rectangleInsets41);
        periodAxis22.setLabelInsets(rectangleInsets41);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets41);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        boolean boolean4 = xYBarRenderer1.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter5 = xYBarRenderer1.getBarPainter();
        java.awt.Paint paint6 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        xYBarRenderer1.setBaseFillPaint(paint6, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(xYBarPainter5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("series", graphics2D1, 10.0d, (float) '#', (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (byte) -1);
        org.jfree.chart.block.Block block5 = null;
        columnArrangement4.add(block5, (java.lang.Object) 100);
        org.jfree.chart.block.BlockContainer blockContainer8 = null;
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = columnArrangement4.arrange(blockContainer8, graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean4 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation8 = null;
        try {
            boolean boolean10 = combinedDomainXYPlot0.removeAnnotation(xYAnnotation8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            combinedDomainXYPlot0.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        logAxis9.setVisible(false);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        combinedDomainXYPlot38.datasetChanged(datasetChangeEvent39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = combinedDomainXYPlot38.getRangeAxisEdge(0);
        try {
            double double43 = logAxis9.valueToJava2D((double) 0, rectangle2D37, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        int int15 = periodAxis4.getMinorTickCount();
        java.util.Locale locale16 = periodAxis4.getLocale();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        boolean boolean23 = dateRange19.intersects((org.jfree.data.Range) dateRange22);
        periodAxis4.setRange((org.jfree.data.Range) dateRange19, false, false);
        org.jfree.data.Range range27 = periodAxis4.getRange();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = timeSeriesCollection2.hasListener(eventListener4);
        try {
            int int9 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection2, 0, (double) 1.0f, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 24234L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) 86400000L);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition4);
        java.awt.Font font6 = barRenderer3D3.getBaseItemLabelFont();
        textTitle2.setFont(font6);
        boolean boolean8 = textTitle2.getNotify();
        java.awt.Paint paint9 = textTitle2.getPaint();
        org.jfree.chart.axis.TickType tickType10 = org.jfree.chart.axis.TickType.MAJOR;
        boolean boolean11 = textTitle2.equals((java.lang.Object) tickType10);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(tickType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        try {
            double double6 = timeSeriesCollection2.getStartXValue(0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        java.lang.String str1 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.MILLISECOND" + "'", str1.equals("DateTickUnitType.MILLISECOND"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RangeType.FULL", graphics2D1, (float) (short) -1, 0.0f, textAnchor4, 0.4d, 10.0f, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = valueMarker1.getLabelOffsetType();
        java.lang.String str5 = valueMarker1.getLabel();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.Color color13 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        xYBarRenderer15.notifyListeners(rendererChangeEvent16);
        java.awt.Stroke stroke19 = xYBarRenderer15.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer6.drawDomainLine(graphics2D7, xYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis10, rectangle2D11, (double) 100, (java.awt.Paint) color13, stroke19);
        valueMarker1.setLabelPaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYBarRenderer1.setBasePaint(paint5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYBarRenderer8.setBaseOutlinePaint((java.awt.Paint) color9);
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color9);
        float[] floatArray20 = new float[] { 8, 1L, '#', (short) 10, 86400000L };
        float[] floatArray21 = java.awt.Color.RGBtoHSB((int) (short) 100, (int) (byte) 100, 15, floatArray20);
        float[] floatArray22 = color9.getRGBComponents(floatArray21);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        java.lang.String str4 = rectangleAnchor2.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleAnchor.CENTER" + "'", str4.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator35 = xYBarRenderer1.getSeriesItemLabelGenerator(97);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation36 = null;
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str38 = layer37.toString();
        try {
            xYBarRenderer1.addAnnotation(xYAnnotation36, layer37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(xYItemLabelGenerator35);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Layer.FOREGROUND" + "'", str38.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Color color8 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYBarRenderer10.notifyListeners(rendererChangeEvent11);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer1.drawDomainLine(graphics2D2, xYPlot3, (org.jfree.chart.axis.ValueAxis) periodAxis5, rectangle2D6, (double) 100, (java.awt.Paint) color8, stroke14);
        java.util.Locale locale16 = periodAxis5.getLocale();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale16);
        java.lang.ClassLoader classLoader18 = null;
        java.util.ResourceBundle.Control control19 = null;
        try {
            java.util.ResourceBundle resourceBundle20 = java.util.ResourceBundle.getBundle("GradientPaintTransformType.CENTER_HORIZONTAL", locale16, classLoader18, control19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(locale16);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator44 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator44);
        org.jfree.chart.LegendItem legendItem48 = barRenderer3D0.getLegendItem(15, 1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(legendItem48);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        java.awt.Font font3 = numberAxis3D1.getTickLabelFont();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle2.arrange(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertNotNull(blockBorder3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.String[] strArray2 = new java.lang.String[] { "Layer.FOREGROUND" };
        org.jfree.chart.axis.SymbolAxis symbolAxis3 = new org.jfree.chart.axis.SymbolAxis("Layer.FOREGROUND", strArray2);
        try {
            symbolAxis3.setRange(10.0d, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        int int15 = periodAxis4.getMinorTickCount();
        java.util.Locale locale16 = periodAxis4.getLocale();
        java.util.TimeZone timeZone17 = null;
        try {
            periodAxis4.setTimeZone(timeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(locale16);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        barRenderer3D0.setIncludeBaseInRange(false);
        boolean boolean6 = barRenderer3D0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getRotationAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("series", graphics2D1, (float) 5, (float) '4', textAnchor5, (double) (-16777216), 1.0f, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean5 = dateRange3.intersects((org.jfree.data.Range) dateRange4);
        boolean boolean6 = dateRange2.intersects((org.jfree.data.Range) dateRange3);
        double double7 = dateRange2.getLowerBound();
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = combinedDomainXYPlot0.getRangeAxisEdge(0);
        java.lang.String str5 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        try {
            combinedDomainXYPlot0.zoomRangeAxes((double) 97, plotRenderingInfo7, point2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Combined_Domain_XYPlot" + "'", str5.equals("Combined_Domain_XYPlot"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) -1, (double) 2019, (double) 86400000L, (double) 0.5f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        try {
            combinedDomainXYPlot0.addAnnotation(xYAnnotation1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer3D0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer3D0.setSeriesItemLabelGenerator(2958465, categoryItemLabelGenerator7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        barRenderer3D15.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        java.awt.Font font18 = barRenderer3D15.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer3D15.setSeriesURLGenerator(0, categoryURLGenerator20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Color color50 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer52 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        xYBarRenderer52.notifyListeners(rendererChangeEvent53);
        java.awt.Stroke stroke56 = xYBarRenderer52.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer43.drawDomainLine(graphics2D44, xYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D48, (double) 100, (java.awt.Paint) color50, stroke56);
        barRenderer3D15.drawRangeLine(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, rectangle2D26, (double) (byte) -1, (java.awt.Paint) color35, stroke56);
        xYStepRenderer0.setBaseOutlineStroke(stroke56, true);
        xYStepRenderer0.clearSeriesPaints(false);
        boolean boolean66 = xYStepRenderer0.getItemCreateEntity((int) (short) -1, 0, false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot8.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer12.notifyListeners(rendererChangeEvent13);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesStroke(0);
        combinedDomainXYPlot8.setDomainMinorGridlineStroke(stroke16);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        java.util.Locale locale33 = periodAxis22.getLocale();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.Paint paint36 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer1.drawDomainLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D34, (double) (short) 10, paint36, stroke37);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot43 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = null;
        combinedDomainXYPlot43.datasetChanged(datasetChangeEvent44);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = combinedDomainXYPlot43.getRangeAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            org.jfree.chart.axis.AxisState axisState49 = periodAxis22.draw(graphics2D39, (double) 2019, rectangle2D41, rectangle2D42, rectangleEdge47, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "Layer.FOREGROUND", "series", "");
        basicProjectInfo4.setCopyright("series");
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double13 = xYSeriesCollection11.getRangeUpperBound(true);
        try {
            java.lang.Number number16 = xYSeriesCollection11.getX((-16777216), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.0d + "'", double13 == 97.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        java.awt.Paint paint44 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        barRenderer3D0.setShadowPaint(paint44);
        barRenderer3D0.setBaseItemLabelsVisible(false, false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.TimeZone timeZone4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.Color color12 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYBarRenderer14.notifyListeners(rendererChangeEvent15);
        java.awt.Stroke stroke18 = xYBarRenderer14.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer5.drawDomainLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis9, rectangle2D10, (double) 100, (java.awt.Paint) color12, stroke18);
        int int20 = periodAxis9.getMinorTickCount();
        java.util.Locale locale21 = periodAxis9.getLocale();
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day3, timeZone4, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(locale21);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        timeSeriesCollection2.validateObject();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = null;
        timeSeriesCollection2.seriesChanged(seriesChangeEvent7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.Range range11 = intervalXYDelegate9.getDomainBounds(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Color color5 = java.awt.Color.getColor("hi!", (int) 'a');
        combinedDomainXYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            combinedDomainXYPlot0.zoomRangeAxes((double) 5, (double) (-14666742), plotRenderingInfo9, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.title.TextTitle textTitle3 = jFreeChart2.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3D4.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        java.awt.Font font7 = barRenderer3D4.getBaseItemLabelFont();
        textTitle3.setFont(font7);
        java.awt.Paint paint9 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("", font7, paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(textTitle3);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) 'a');
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        java.text.DateFormat dateFormat6 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 0, dateTickUnitType4, 5, dateFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        int int15 = periodAxis4.getMinorTickCount();
        java.util.Locale locale16 = periodAxis4.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = periodAxis4.getStandardTickUnits();
        periodAxis4.resizeRange(8.0d, 12.0d);
        java.lang.Class class21 = null;
        try {
            periodAxis4.setMajorTickTimePeriodClass(class21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNull(tickUnitSource17);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        int int15 = color7.getGreen();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        boolean boolean7 = xYBarRenderer1.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        boolean boolean14 = combinedDomainXYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis16);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker21.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker21.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYBarRenderer1.drawDomainMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis19, (org.jfree.chart.plot.Marker) valueMarker21, rectangle2D25);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis28 = combinedDomainXYPlot10.getRangeAxisForDataset(14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 14 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        combinedDomainXYPlot0.clearDomainMarkers(3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot0.getRangeAxis();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        combinedDomainXYPlot6.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = combinedDomainXYPlot6.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator14 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer12.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator14);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator17 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer12.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator17, true);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        combinedDomainXYPlot21.datasetChanged(datasetChangeEvent22);
        java.awt.Stroke stroke24 = combinedDomainXYPlot21.getRangeCrosshairStroke();
        boolean boolean25 = combinedDomainXYPlot21.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot21.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis27);
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker32.setLabelAnchor(rectangleAnchor33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = valueMarker32.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        xYBarRenderer12.drawDomainMarker(graphics2D20, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot21, (org.jfree.chart.axis.ValueAxis) periodAxis30, (org.jfree.chart.plot.Marker) valueMarker32, rectangle2D36);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot38.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str45 = layer44.toString();
        combinedDomainXYPlot38.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker43, layer44);
        combinedDomainXYPlot6.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker32, layer44);
        combinedDomainXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker32);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Layer.FOREGROUND" + "'", str45.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE1" + "'", str1.equals("ItemLabelAnchor.OUTSIDE1"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double[] doubleArray7 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray13 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray19 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray13, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "series", doubleArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset21, true);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset21, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot8.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer12.notifyListeners(rendererChangeEvent13);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesStroke(0);
        combinedDomainXYPlot8.setDomainMinorGridlineStroke(stroke16);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        java.util.Locale locale33 = periodAxis22.getLocale();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.Paint paint36 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer1.drawDomainLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D34, (double) (short) 10, paint36, stroke37);
        java.lang.Class class39 = null;
        try {
            periodAxis22.setAutoRangeTimePeriodClass(class39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0);
        double double2 = axisState1.getCursor();
        axisState1.cursorLeft((double) (byte) -1);
        axisState1.cursorDown(16.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 100.0f, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        boolean boolean3 = standardXYToolTipGenerator1.equals((java.lang.Object) standardPieSectionLabelGenerator2);
        boolean boolean4 = shapeList0.equals((java.lang.Object) standardXYToolTipGenerator1);
        java.awt.Shape shape6 = shapeList0.getShape(1);
        java.awt.Shape shape8 = shapeList0.getShape(2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        double double5 = timeSeriesCollection2.getDomainLowerBound(true);
        try {
            java.lang.Number number8 = timeSeriesCollection2.getEndX((int) (short) 10, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, (double) 0L, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Font font2 = textFragment1.getFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator4, false);
        barRenderer3D0.setDrawBarOutline(false);
        double double9 = barRenderer3D0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        java.awt.Stroke stroke18 = xYStepRenderer0.getItemOutlineStroke((int) '4', 2958465, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        try {
            java.lang.Number number14 = xYSeriesCollection11.getX((int) (short) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource5 = null;
        chartRenderingInfo4.setRenderingSource(renderingSource5);
        org.jfree.chart.RenderingSource renderingSource7 = chartRenderingInfo4.getRenderingSource();
        try {
            jFreeChart1.draw(graphics2D2, rectangle2D3, chartRenderingInfo4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(renderingSource7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        java.util.List list4 = xYSeries3.getItems();
        try {
            java.lang.Number number6 = xYSeries3.getY(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9, timeZone10);
        int int12 = timeSeriesCollection11.getSeriesCount();
        double double14 = timeSeriesCollection11.getDomainLowerBound(true);
        try {
            java.lang.String str17 = standardXYToolTipGenerator6.generateToolTip((org.jfree.data.xy.XYDataset) timeSeriesCollection11, (int) '#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (35).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        int int4 = barRenderer3D0.getPassCount();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer3D0.getSeriesItemLabelGenerator(5);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.util.LogFormat logFormat7 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat7, (java.text.NumberFormat) logFormat11);
        java.lang.String str14 = logFormat7.format((double) 100);
        logAxis2.setNumberFormatOverride((java.text.NumberFormat) logFormat7);
        java.text.DateFormat dateFormat16 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator17 = new org.jfree.chart.labels.StandardXYToolTipGenerator("RangeType.FULL", (java.text.NumberFormat) logFormat7, dateFormat16);
        java.text.DateFormat dateFormat18 = standardXYToolTipGenerator17.getYDateFormat();
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!^�" + "'", str14.equals("hi!^�"));
        org.junit.Assert.assertNull(dateFormat18);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        timeSeriesCollection2.validateObject();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = null;
        timeSeriesCollection2.seriesChanged(seriesChangeEvent7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        intervalXYDelegate9.datasetChanged(datasetChangeEvent10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        java.awt.Color color16 = java.awt.Color.YELLOW;
        xYStepRenderer0.setSeriesOutlinePaint(100, (java.awt.Paint) color16, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator35 = xYBarRenderer1.getSeriesItemLabelGenerator(97);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        org.jfree.chart.LegendItem legendItem39 = xYBarRenderer1.getLegendItem((-1), 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(xYItemLabelGenerator35);
        org.junit.Assert.assertNull(itemLabelPosition36);
        org.junit.Assert.assertNull(legendItem39);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart1, (int) (short) 100, 0);
        org.jfree.chart.JFreeChart jFreeChart5 = chartProgressEvent4.getChart();
        chartProgressEvent4.setPercent((int) (short) 0);
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        org.jfree.chart.axis.AxisCollection axisCollection3 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list4 = axisCollection3.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis3D6.getTickLabelInsets();
        org.jfree.data.Range range8 = numberAxis3D6.getDefaultAutoRange();
        org.jfree.data.Range range10 = timeSeriesCollection2.getRangeBounds(list4, range8, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range10, 0.0d);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        float float2 = multiplePiePlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart4);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot6.getPieChart();
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart7.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer3D9.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Font font12 = barRenderer3D9.getBaseItemLabelFont();
        textTitle8.setFont(font12);
        jFreeChart4.addSubtitle((org.jfree.chart.title.Title) textTitle8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle8.getHorizontalAlignment();
        java.lang.Object obj16 = textTitle8.clone();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape7 = xYBarRenderer1.getLegendBar();
        xYBarRenderer1.setShadowXOffset(8.0d);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer3D1.setPositiveItemLabelPositionFallback(itemLabelPosition2);
        java.awt.Font font4 = barRenderer3D1.getBaseItemLabelFont();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator8 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer6.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator8);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYBarRenderer6.setBasePaint(paint10);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYBarRenderer13.setBaseOutlinePaint((java.awt.Paint) color14);
        xYBarRenderer6.setBaseOutlinePaint((java.awt.Paint) color14);
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!^�", font4, (java.awt.Paint) color14, (float) (byte) 1, (int) (short) 1, textMeasurer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        java.awt.Color color6 = java.awt.Color.yellow;
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.setAxisLineVisible(false);
        java.awt.Paint paint17 = numberAxis3D14.getTickMarkPaint();
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor5, color6, color7, paint8, chartColor12, paint17 };
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color20 = java.awt.Color.WHITE;
        java.awt.Color color21 = java.awt.Color.yellow;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { paint19, color20, color21, color22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYBarRenderer33.notifyListeners(rendererChangeEvent34);
        java.awt.Stroke stroke37 = xYBarRenderer33.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] { stroke24, stroke25, stroke31, stroke37 };
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYBarRenderer40.notifyListeners(rendererChangeEvent41);
        java.awt.Stroke stroke44 = xYBarRenderer40.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray46 = new java.awt.Stroke[] { stroke44, stroke45 };
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] { shape49 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray23, strokeArray38, strokeArray46, shapeArray50);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51, true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot54 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart55 = multiplePiePlot54.getPieChart();
        org.jfree.chart.title.TextTitle textTitle56 = jFreeChart55.getTitle();
        int int57 = jFreeChart55.getBackgroundImageAlignment();
        multiplePiePlot0.setPieChart(jFreeChart55);
        org.jfree.chart.event.ChartChangeListener chartChangeListener59 = null;
        try {
            jFreeChart55.removeChangeListener(chartChangeListener59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertNotNull(jFreeChart55);
        org.junit.Assert.assertNotNull(textTitle56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 15 + "'", int57 == 15);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "February" + "'", str2.equals("February"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "series");
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        int int4 = barRenderer3D0.getPassCount();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape5, pieDataset6, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        java.awt.Shape shape13 = pieSectionEntity12.getArea();
        boolean boolean14 = barRenderer3D0.equals((java.lang.Object) shape13);
        barRenderer3D0.setMaximumBarWidth((double) (short) -1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double13 = xYSeriesCollection11.getRangeUpperBound(true);
        try {
            xYSeriesCollection11.setSelected(2, (int) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.0d + "'", double13 == 97.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Color color8 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYBarRenderer10.notifyListeners(rendererChangeEvent11);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer1.drawDomainLine(graphics2D2, xYPlot3, (org.jfree.chart.axis.ValueAxis) periodAxis5, rectangle2D6, (double) 100, (java.awt.Paint) color8, stroke14);
        java.util.Locale locale16 = periodAxis5.getLocale();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale16);
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNotNull(tickUnitSource18);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        java.util.Locale locale15 = periodAxis4.getLocale();
        periodAxis4.setMinorTickMarksVisible(true);
        java.lang.Class class18 = null;
        try {
            periodAxis4.setMajorTickTimePeriodClass(class18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(locale15);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis3D1.getTickLabelInsets();
        double double3 = rectangleInsets2.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        double double2 = crosshairState1.getCrosshairDistance();
        double double3 = crosshairState1.getCrosshairX();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.clearCategoryLabelToolTips();
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        java.awt.Paint paint44 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        barRenderer3D0.setShadowPaint(paint44);
        java.awt.Paint paint46 = null;
        try {
            barRenderer3D0.setBaseFillPaint(paint46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        piePlot3D1.setLabelLinksVisible(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator40 = piePlot3D1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(pieToolTipGenerator40);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat2 = null;
        logAxis1.setNumberFormatOverride(numberFormat2);
        java.awt.Paint paint4 = logAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 10L, (double) 2958465, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "hi!", "GradientPaintTransformType.CENTER_HORIZONTAL");
        java.lang.String str6 = basicProjectInfo5.getInfo();
        basicProjectInfo5.addOptionalLibrary("GradientPaintTransformType.CENTER_HORIZONTAL");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean2 = dateRange0.intersects((org.jfree.data.Range) dateRange1);
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double4 = dateRange3.getUpperBound();
        boolean boolean5 = dateRange1.intersects((org.jfree.data.Range) dateRange3);
        long long6 = dateRange1.getLowerMillis();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYBarRenderer2.setBaseOutlinePaint((java.awt.Paint) color3);
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        boolean boolean6 = categoryAxis3D0.equals((java.lang.Object) colorSpace5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        combinedDomainXYPlot11.datasetChanged(datasetChangeEvent12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = combinedDomainXYPlot11.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.Color color23 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        xYBarRenderer25.notifyListeners(rendererChangeEvent26);
        java.awt.Stroke stroke29 = xYBarRenderer25.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer16.drawDomainLine(graphics2D17, xYPlot18, (org.jfree.chart.axis.ValueAxis) periodAxis20, rectangle2D21, (double) 100, (java.awt.Paint) color23, stroke29);
        boolean boolean33 = xYStepRenderer16.getItemShapeVisible(100, 0);
        boolean boolean34 = rectangleEdge15.equals((java.lang.Object) 100);
        try {
            double double35 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor7, 0, 10, rectangle2D10, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        java.awt.Color color4 = java.awt.Color.yellow;
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D12.setAxisLineVisible(false);
        java.awt.Paint paint15 = numberAxis3D12.getTickMarkPaint();
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { chartColor3, color4, color5, paint6, chartColor10, paint15 };
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = java.awt.Color.yellow;
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { paint17, color18, color19, color20 };
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        xYBarRenderer25.notifyListeners(rendererChangeEvent26);
        java.awt.Stroke stroke29 = xYBarRenderer25.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        xYBarRenderer31.notifyListeners(rendererChangeEvent32);
        java.awt.Stroke stroke35 = xYBarRenderer31.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] { stroke22, stroke23, stroke29, stroke35 };
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer38 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        xYBarRenderer38.notifyListeners(rendererChangeEvent39);
        java.awt.Stroke stroke42 = xYBarRenderer38.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke stroke43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray44 = new java.awt.Stroke[] { stroke42, stroke43 };
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Shape[] shapeArray48 = new java.awt.Shape[] { shape47 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier49 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray21, strokeArray36, strokeArray44, shapeArray48);
        java.awt.Stroke stroke50 = defaultDrawingSupplier49.getNextStroke();
        org.jfree.chart.util.ShapeList shapeList51 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj52 = shapeList51.clone();
        boolean boolean53 = defaultDrawingSupplier49.equals((java.lang.Object) shapeList51);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(strokeArray44);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shapeArray48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        xYStepRenderer0.setBaseSeriesVisibleInLegend(false);
        xYStepRenderer0.setBaseShapesFilled(true);
        java.awt.Paint paint26 = xYStepRenderer0.getItemFillPaint(0, 100, false);
        boolean boolean27 = xYStepRenderer0.getDrawSeriesLineAsPath();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.String[] strArray3 = new java.lang.String[] { "Layer.FOREGROUND" };
        org.jfree.chart.axis.SymbolAxis symbolAxis4 = new org.jfree.chart.axis.SymbolAxis("Layer.FOREGROUND", strArray3);
        double[] doubleArray12 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray18 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray24 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[][] doubleArray25 = new double[][] { doubleArray12, doubleArray18, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "series", doubleArray25);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray0, (java.lang.Comparable[]) strArray3, doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        org.jfree.data.Range range37 = combinedDomainXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        combinedDomainXYPlot0.zoomDomainAxes((double) (-1.0f), (double) 86400000L, plotRenderingInfo40, point2D41);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(range37);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        barRenderer3D15.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        java.awt.Font font18 = barRenderer3D15.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer3D15.setSeriesURLGenerator(0, categoryURLGenerator20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Color color50 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer52 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        xYBarRenderer52.notifyListeners(rendererChangeEvent53);
        java.awt.Stroke stroke56 = xYBarRenderer52.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer43.drawDomainLine(graphics2D44, xYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D48, (double) 100, (java.awt.Paint) color50, stroke56);
        barRenderer3D15.drawRangeLine(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, rectangle2D26, (double) (byte) -1, (java.awt.Paint) color35, stroke56);
        xYStepRenderer0.setBaseOutlineStroke(stroke56, true);
        xYStepRenderer0.clearSeriesPaints(false);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator64 = new org.jfree.chart.urls.StandardXYURLGenerator();
        xYStepRenderer0.setSeriesURLGenerator((int) (short) 0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator64);
        try {
            xYStepRenderer0.setStepPoint((double) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires stepPoint in [0.0;1.0]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = null;
        try {
            timeSeries3.add(timeSeriesDataItem4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            defaultKeyedValues0.sortByValues(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        java.util.List list4 = combinedDomainXYPlot0.getAnnotations();
        java.lang.Object obj5 = combinedDomainXYPlot0.clone();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        combinedDomainXYPlot6.datasetChanged(datasetChangeEvent7);
        java.awt.Stroke stroke9 = combinedDomainXYPlot6.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator14 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer12.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator14);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator17 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer12.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator17, true);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        combinedDomainXYPlot21.datasetChanged(datasetChangeEvent22);
        java.awt.Stroke stroke24 = combinedDomainXYPlot21.getRangeCrosshairStroke();
        boolean boolean25 = combinedDomainXYPlot21.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot21.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis27);
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker32.setLabelAnchor(rectangleAnchor33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = valueMarker32.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        xYBarRenderer12.drawDomainMarker(graphics2D20, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot21, (org.jfree.chart.axis.ValueAxis) periodAxis30, (org.jfree.chart.plot.Marker) valueMarker32, rectangle2D36);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot38 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot38.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str45 = layer44.toString();
        combinedDomainXYPlot38.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker43, layer44);
        combinedDomainXYPlot6.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker32, layer44);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker32.setStroke(stroke48);
        combinedDomainXYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker32);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Layer.FOREGROUND" + "'", str45.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat2 = null;
        logAxis1.setNumberFormatOverride(numberFormat2);
        logAxis1.configure();
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        logAxis1.setLabelPaint(paint5);
        java.awt.Shape shape7 = logAxis1.getRightArrow();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot1.setDomainCrosshairVisible(true);
        combinedDomainXYPlot1.clearDomainMarkers(3);
        java.awt.Stroke stroke6 = combinedDomainXYPlot1.getOutlineStroke();
        barRenderer3D0.setBaseStroke(stroke6, false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator8 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer6.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator8);
        xYBarRenderer6.removeAnnotations();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat15 = null;
        logAxis14.setNumberFormatOverride(numberFormat15);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.Color color20 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        boolean boolean25 = xYBarRenderer22.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = xYBarRenderer22.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        xYBarRenderer31.notifyListeners(rendererChangeEvent32);
        java.awt.Stroke stroke35 = xYBarRenderer31.lookupSeriesStroke(0);
        xYBarRenderer22.setBaseStroke(stroke35, false);
        xYBarRenderer6.drawRangeLine(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) logAxis14, rectangle2D17, (-1.0d), (java.awt.Paint) color20, stroke35);
        piePlot3D3.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke35);
        piePlot3D3.setMinimumArcAngleToDraw((double) (-16777216));
        java.awt.Stroke stroke42 = piePlot3D3.getBaseSectionOutlineStroke();
        boolean boolean43 = shapeList0.equals((java.lang.Object) stroke42);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(xYURLGenerator29);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYBarRenderer4.notifyListeners(rendererChangeEvent5);
        java.awt.Stroke stroke8 = xYBarRenderer4.lookupSeriesStroke(0);
        java.awt.Paint paint9 = xYBarRenderer4.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer4.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        combinedDomainXYPlot13.datasetChanged(datasetChangeEvent14);
        java.awt.Stroke stroke16 = combinedDomainXYPlot13.getRangeCrosshairStroke();
        combinedDomainXYPlot13.setWeight(15);
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer21 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.Color color28 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer30 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        xYBarRenderer30.notifyListeners(rendererChangeEvent31);
        java.awt.Stroke stroke34 = xYBarRenderer30.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer21.drawDomainLine(graphics2D22, xYPlot23, (org.jfree.chart.axis.ValueAxis) periodAxis25, rectangle2D26, (double) 100, (java.awt.Paint) color28, stroke34);
        boolean boolean38 = xYStepRenderer21.getItemShapeVisible(100, 0);
        java.awt.Shape shape39 = xYStepRenderer21.getLegendLine();
        periodAxis20.setDownArrow(shape39);
        periodAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot43 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot43.setDomainCrosshairVisible(true);
        combinedDomainXYPlot43.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator51 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer49.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator51);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator54 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer49.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator54, true);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot58 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent59 = null;
        combinedDomainXYPlot58.datasetChanged(datasetChangeEvent59);
        java.awt.Stroke stroke61 = combinedDomainXYPlot58.getRangeCrosshairStroke();
        boolean boolean62 = combinedDomainXYPlot58.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis64 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot58.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis64);
        org.jfree.chart.axis.PeriodAxis periodAxis67 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker69.setLabelAnchor(rectangleAnchor70);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = valueMarker69.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        xYBarRenderer49.drawDomainMarker(graphics2D57, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot58, (org.jfree.chart.axis.ValueAxis) periodAxis67, (org.jfree.chart.plot.Marker) valueMarker69, rectangle2D73);
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot43.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker69, layer75);
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        xYBarRenderer4.drawRangeMarker(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.chart.axis.ValueAxis) periodAxis20, (org.jfree.chart.plot.Marker) valueMarker69, rectangle2D77);
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot13.setRangeAxisLocation(axisLocation79);
        combinedDomainXYPlot0.setDomainAxisLocation(axisLocation79, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation83 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation79, plotOrientation83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator54);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor70);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertNotNull(axisLocation79);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        int int4 = day3.getYear();
        java.util.TimeZone timeZone5 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.Color color13 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        xYBarRenderer15.notifyListeners(rendererChangeEvent16);
        java.awt.Stroke stroke19 = xYBarRenderer15.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer6.drawDomainLine(graphics2D7, xYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis10, rectangle2D11, (double) 100, (java.awt.Paint) color13, stroke19);
        java.util.Locale locale21 = periodAxis10.getLocale();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator22 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale21);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale21);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator24 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale21);
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("TextAnchor.HALF_ASCENT_RIGHT", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day3, timeZone5, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(locale21);
        org.junit.Assert.assertNotNull(tickUnitSource23);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        double double34 = xYBarRenderer1.getItemLabelAnchorOffset();
        java.awt.Paint paint36 = xYBarRenderer1.getSeriesItemLabelPaint((int) '#');
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
        org.junit.Assert.assertNull(paint36);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        java.lang.String str2 = numberFormat0.format(100.0d);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10,000%" + "'", str2.equals("10,000%"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            java.lang.String str2 = numberFormat0.format((java.lang.Object) paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer3D0.getLegendItemURLGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator9);
        barRenderer3D0.setDrawBarOutline(true);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(itemLabelPosition7);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat2 = null;
        logAxis1.setNumberFormatOverride(numberFormat2);
        logAxis1.configure();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) logAxis1);
        logAxis1.zoomRange(100.0d, 12.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        timeSeriesCollection2.validateObject();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = null;
        timeSeriesCollection2.seriesChanged(seriesChangeEvent7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.Range range11 = intervalXYDelegate9.getDomainBounds(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator4, false);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType7 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        int int8 = dateTickUnitType7.getCalendarField();
        boolean boolean9 = barRenderer3D0.equals((java.lang.Object) dateTickUnitType7);
        barRenderer3D0.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(dateTickUnitType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14 + "'", int8 == 14);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = combinedDomainXYPlot0.getRangeAxisEdge(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            boolean boolean6 = combinedDomainXYPlot0.removeAnnotation(xYAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("Combined_Domain_XYPlot");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYBarRenderer11.notifyListeners(rendererChangeEvent12);
        java.awt.Stroke stroke15 = xYBarRenderer11.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer2.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis6, rectangle2D7, (double) 100, (java.awt.Paint) color9, stroke15);
        boolean boolean19 = xYStepRenderer2.getItemShapeVisible(100, 0);
        java.awt.Shape shape20 = xYStepRenderer2.getLegendLine();
        periodAxis1.setDownArrow(shape20);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity22 = new org.jfree.chart.entity.LegendItemEntity(shape20);
        java.lang.Object obj23 = legendItemEntity22.clone();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        int int15 = periodAxis4.getMinorTickCount();
        java.util.Locale locale16 = periodAxis4.getLocale();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator17 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        java.lang.String str20 = standardPieToolTipGenerator17.generateToolTip(pieDataset18, (java.lang.Comparable) "hi!^�");
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition4);
        java.awt.Font font6 = barRenderer3D3.getBaseItemLabelFont();
        textTitle2.setFont(font6);
        textTitle2.setVisible(true);
        double double10 = textTitle2.getContentYOffset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot11.getPieChart();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart12);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(jFreeChart12);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        int int3 = jFreeChart1.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource7 = null;
        chartRenderingInfo6.setRenderingSource(renderingSource7);
        org.jfree.chart.RenderingSource renderingSource9 = chartRenderingInfo6.getRenderingSource();
        try {
            jFreeChart1.draw(graphics2D4, rectangle2D5, chartRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNull(renderingSource9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.lang.String str9 = textAnchor8.toString();
        try {
            float float10 = textFragment6.calculateBaselineOffset(graphics2D7, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str9.equals("TextAnchor.HALF_ASCENT_RIGHT"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        xYStepRenderer0.setBaseSeriesVisibleInLegend(false);
        xYStepRenderer0.setBaseShapesFilled(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYStepRenderer0.getSeriesNegativeItemLabelPosition(2019);
        xYStepRenderer0.setDrawSeriesLineAsPath(false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYBarRenderer8.notifyListeners(rendererChangeEvent9);
        java.awt.Stroke stroke12 = xYBarRenderer8.lookupSeriesStroke(0);
        java.awt.Paint paint13 = xYBarRenderer8.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        combinedDomainXYPlot15.datasetChanged(datasetChangeEvent16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYBarRenderer19.notifyListeners(rendererChangeEvent20);
        java.awt.Stroke stroke23 = xYBarRenderer19.lookupSeriesStroke(0);
        combinedDomainXYPlot15.setDomainMinorGridlineStroke(stroke23);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer25 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.Color color32 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYBarRenderer34.notifyListeners(rendererChangeEvent35);
        java.awt.Stroke stroke38 = xYBarRenderer34.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer25.drawDomainLine(graphics2D26, xYPlot27, (org.jfree.chart.axis.ValueAxis) periodAxis29, rectangle2D30, (double) 100, (java.awt.Paint) color32, stroke38);
        java.util.Locale locale40 = periodAxis29.getLocale();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer8.drawDomainLine(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis29, rectangle2D41, (double) (short) 10, paint43, stroke44);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer46 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        java.awt.Color color53 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer55 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent56 = null;
        xYBarRenderer55.notifyListeners(rendererChangeEvent56);
        java.awt.Stroke stroke59 = xYBarRenderer55.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer46.drawDomainLine(graphics2D47, xYPlot48, (org.jfree.chart.axis.ValueAxis) periodAxis50, rectangle2D51, (double) 100, (java.awt.Paint) color53, stroke59);
        boolean boolean63 = xYStepRenderer46.getItemShapeVisible(100, 0);
        java.awt.Shape shape64 = xYStepRenderer46.getLegendLine();
        xYStepRenderer46.setBaseShapesFilled(true);
        combinedDomainXYPlot15.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer46);
        xYBarRenderer1.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot15);
        java.lang.Object obj69 = xYBarRenderer1.clone();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(locale40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(obj69);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str7 = layer6.toString();
        combinedDomainXYPlot0.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker5, layer6);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        combinedDomainXYPlot0.setOutlineStroke(stroke9);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.Color color18 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        java.awt.Stroke stroke24 = xYBarRenderer20.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer11.drawDomainLine(graphics2D12, xYPlot13, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D16, (double) 100, (java.awt.Paint) color18, stroke24);
        java.util.Locale locale26 = periodAxis15.getLocale();
        periodAxis15.setMinorTickMarksVisible(true);
        boolean boolean29 = combinedDomainXYPlot0.equals((java.lang.Object) periodAxis15);
        double double30 = combinedDomainXYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Layer.FOREGROUND" + "'", str7.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) 'a');
        int int3 = dateTickUnit2.getMultiple();
        java.util.Date date4 = null;
        try {
            java.lang.String str5 = dateTickUnit2.dateToString(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition4);
        java.awt.Font font6 = barRenderer3D3.getBaseItemLabelFont();
        textTitle2.setFont(font6);
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        textTitle2.setFont(font8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot10.getPieChart();
        org.jfree.chart.title.TextTitle textTitle12 = jFreeChart11.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder13 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle12.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle2.getPadding();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertNotNull(textTitle12);
        org.junit.Assert.assertNotNull(blockBorder13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.text.NumberFormat numberFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Combined_Domain_XYPlot", numberFormat1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat2 = null;
        logAxis1.setNumberFormatOverride(numberFormat2);
        logAxis1.configure();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) logAxis1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = null;
        try {
            logAxis1.setTickUnit(numberTickUnit6, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.String[] strArray2 = new java.lang.String[] { "Layer.FOREGROUND" };
        org.jfree.chart.axis.SymbolAxis symbolAxis3 = new org.jfree.chart.axis.SymbolAxis("Layer.FOREGROUND", strArray2);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3D4.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        java.awt.Font font7 = barRenderer3D4.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer3D4.setSeriesURLGenerator(0, categoryURLGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.Color color24 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer17.drawDomainLine(graphics2D18, xYPlot19, (org.jfree.chart.axis.ValueAxis) periodAxis21, rectangle2D22, (double) 100, (java.awt.Paint) color24, stroke30);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer32 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.Color color39 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer41 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent42 = null;
        xYBarRenderer41.notifyListeners(rendererChangeEvent42);
        java.awt.Stroke stroke45 = xYBarRenderer41.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer32.drawDomainLine(graphics2D33, xYPlot34, (org.jfree.chart.axis.ValueAxis) periodAxis36, rectangle2D37, (double) 100, (java.awt.Paint) color39, stroke45);
        barRenderer3D4.drawRangeLine(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, rectangle2D15, (double) (byte) -1, (java.awt.Paint) color24, stroke45);
        symbolAxis3.setGridBandAlternatePaint((java.awt.Paint) color24);
        int int49 = color24.getRGB();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-16711936) + "'", int49 == (-16711936));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(2958465);
        java.lang.String str3 = serialDate2.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 0, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat9 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat9);
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getPercentInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", (java.text.NumberFormat) logFormat5, numberFormat11);
        java.lang.String str14 = numberFormat11.format((long) 10);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1,000%" + "'", str14.equals("1,000%"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-16711936));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3, timeZone4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection5, false);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener8 = null;
        timeSeriesCollection5.addChangeListener(datasetChangeListener8);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        try {
            timeSeries3.update(regularTimePeriod5, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(14, attributedString2);
        java.text.AttributedString attributedString5 = standardPieSectionLabelGenerator0.getAttributedLabel(0);
        org.junit.Assert.assertNull(attributedString5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            boolean boolean5 = categoryPlot0.removeAnnotation(categoryAnnotation3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!^�", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(2958465);
        java.lang.String str14 = serialDate13.getDescription();
        try {
            org.jfree.data.xy.XYSeries xYSeries15 = xYSeriesCollection11.getSeries((java.lang.Comparable) str14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        java.awt.Color color6 = java.awt.Color.yellow;
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.setAxisLineVisible(false);
        java.awt.Paint paint17 = numberAxis3D14.getTickMarkPaint();
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor5, color6, color7, paint8, chartColor12, paint17 };
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color20 = java.awt.Color.WHITE;
        java.awt.Color color21 = java.awt.Color.yellow;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { paint19, color20, color21, color22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYBarRenderer33.notifyListeners(rendererChangeEvent34);
        java.awt.Stroke stroke37 = xYBarRenderer33.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] { stroke24, stroke25, stroke31, stroke37 };
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYBarRenderer40.notifyListeners(rendererChangeEvent41);
        java.awt.Stroke stroke44 = xYBarRenderer40.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray46 = new java.awt.Stroke[] { stroke44, stroke45 };
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] { shape49 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray23, strokeArray38, strokeArray46, shapeArray50);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51, true);
        java.awt.Paint paint54 = multiplePiePlot0.getBackgroundPaint();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D55 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.axis.PeriodAxis periodAxis57 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer58 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis62 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        java.awt.Color color65 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer67 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent68 = null;
        xYBarRenderer67.notifyListeners(rendererChangeEvent68);
        java.awt.Stroke stroke71 = xYBarRenderer67.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer58.drawDomainLine(graphics2D59, xYPlot60, (org.jfree.chart.axis.ValueAxis) periodAxis62, rectangle2D63, (double) 100, (java.awt.Paint) color65, stroke71);
        boolean boolean75 = xYStepRenderer58.getItemShapeVisible(100, 0);
        java.awt.Shape shape76 = xYStepRenderer58.getLegendLine();
        periodAxis57.setDownArrow(shape76);
        periodAxis57.setNegativeArrowVisible(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer80 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D81 = null;
        org.jfree.chart.plot.XYPlot xYPlot82 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis84 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        java.awt.Color color87 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer89 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent90 = null;
        xYBarRenderer89.notifyListeners(rendererChangeEvent90);
        java.awt.Stroke stroke93 = xYBarRenderer89.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer80.drawDomainLine(graphics2D81, xYPlot82, (org.jfree.chart.axis.ValueAxis) periodAxis84, rectangle2D85, (double) 100, (java.awt.Paint) color87, stroke93);
        periodAxis57.setLabelPaint((java.awt.Paint) color87);
        barRenderer3D55.setBaseItemLabelPaint((java.awt.Paint) color87);
        multiplePiePlot0.setBackgroundPaint((java.awt.Paint) color87);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(stroke93);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        timeSeriesCollection2.validateObject();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        combinedDomainXYPlot7.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke10 = combinedDomainXYPlot7.getRangeCrosshairStroke();
        boolean boolean11 = combinedDomainXYPlot7.isDomainCrosshairVisible();
        boolean boolean12 = timeSeriesCollection2.equals((java.lang.Object) boolean11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3D0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer3D0.getLegendItemURLGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator9);
        double double11 = barRenderer3D0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(itemLabelPosition7);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        int int15 = color7.getRGB();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16711936) + "'", int15 == (-16711936));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 2019, (float) 2);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        combinedDomainXYPlot0.setWeight(15);
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.Color color15 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        java.awt.Stroke stroke21 = xYBarRenderer17.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer8.drawDomainLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis12, rectangle2D13, (double) 100, (java.awt.Paint) color15, stroke21);
        boolean boolean25 = xYStepRenderer8.getItemShapeVisible(100, 0);
        java.awt.Shape shape26 = xYStepRenderer8.getLegendLine();
        periodAxis7.setDownArrow(shape26);
        periodAxis7.setNegativeArrowVisible(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer30 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.awt.Color color37 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        xYBarRenderer39.notifyListeners(rendererChangeEvent40);
        java.awt.Stroke stroke43 = xYBarRenderer39.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer30.drawDomainLine(graphics2D31, xYPlot32, (org.jfree.chart.axis.ValueAxis) periodAxis34, rectangle2D35, (double) 100, (java.awt.Paint) color37, stroke43);
        periodAxis7.setLabelPaint((java.awt.Paint) color37);
        int int46 = combinedDomainXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis7);
        org.jfree.chart.plot.PlotOrientation plotOrientation47 = null;
        try {
            combinedDomainXYPlot0.setOrientation(plotOrientation47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        float float2 = multiplePiePlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart4);
        java.awt.Color color8 = java.awt.Color.getColor("hi!", (int) 'a');
        jFreeChart4.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.RenderingHints renderingHints10 = null;
        try {
            jFreeChart4.setRenderingHints(renderingHints10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("October", "10,000%");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "October" + "'", str3.equals("October"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!^�");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(97, xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double13 = xYSeriesCollection11.getRangeUpperBound(true);
        try {
            java.lang.Number number16 = xYSeriesCollection11.getEndX((-16777216), 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.0d + "'", double13 == 97.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        org.jfree.data.Range range37 = combinedDomainXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis12);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        xYBarRenderer39.notifyListeners(rendererChangeEvent40);
        java.awt.Stroke stroke43 = xYBarRenderer39.lookupSeriesStroke(0);
        java.awt.Paint paint44 = xYBarRenderer39.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = null;
        combinedDomainXYPlot46.datasetChanged(datasetChangeEvent47);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer50 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent51 = null;
        xYBarRenderer50.notifyListeners(rendererChangeEvent51);
        java.awt.Stroke stroke54 = xYBarRenderer50.lookupSeriesStroke(0);
        combinedDomainXYPlot46.setDomainMinorGridlineStroke(stroke54);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer56 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis60 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        java.awt.Color color63 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer65 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent66 = null;
        xYBarRenderer65.notifyListeners(rendererChangeEvent66);
        java.awt.Stroke stroke69 = xYBarRenderer65.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer56.drawDomainLine(graphics2D57, xYPlot58, (org.jfree.chart.axis.ValueAxis) periodAxis60, rectangle2D61, (double) 100, (java.awt.Paint) color63, stroke69);
        java.util.Locale locale71 = periodAxis60.getLocale();
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        java.awt.Paint paint74 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke75 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer39.drawDomainLine(graphics2D45, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot46, (org.jfree.chart.axis.ValueAxis) periodAxis60, rectangle2D72, (double) (short) 10, paint74, stroke75);
        combinedDomainXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot46, (int) (short) 10);
        java.awt.Graphics2D graphics2D79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        java.awt.geom.Point2D point2D81 = null;
        org.jfree.chart.plot.PlotState plotState82 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        try {
            combinedDomainXYPlot46.draw(graphics2D79, rectangle2D80, point2D81, plotState82, plotRenderingInfo83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(locale71);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource6 = null;
        chartRenderingInfo5.setRenderingSource(renderingSource6);
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        chartRenderingInfo5.setEntityCollection(entityCollection8);
        try {
            jFreeChart1.draw(graphics2D2, rectangle2D3, point2D4, chartRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getLabelAngle();
        numberAxis3D0.resizeRange2((double) (-2208960000000L), (double) 100L);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis3D0.setTickMarkStroke(stroke5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat9 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat9);
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getPercentInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", (java.text.NumberFormat) logFormat5, numberFormat11);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYBarRenderer14.setBaseOutlinePaint((java.awt.Paint) color15);
        java.awt.color.ColorSpace colorSpace17 = color15.getColorSpace();
        try {
            java.lang.String str18 = logFormat5.format((java.lang.Object) color15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace17);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.setBaseItemLabelsVisible(false, true);
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity15 = new org.jfree.chart.entity.PieSectionEntity(shape8, pieDataset9, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        java.awt.Shape shape16 = pieSectionEntity15.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        xYBarRenderer1.setLegendBar(shape16);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot19.setDomainCrosshairVisible(true);
        java.awt.Paint paint23 = combinedDomainXYPlot19.getQuadrantPaint((int) (byte) 1);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) combinedDomainXYPlot19);
        java.lang.String str25 = plotEntity24.toString();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PlotEntity: tooltip = null" + "'", str25.equals("PlotEntity: tooltip = null"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB(10, 15, (int) (byte) 0, floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("VerticalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key VerticalAlignment.CENTER");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Layer.FOREGROUND", font5);
        java.lang.Object obj7 = labelBlock6.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot8.getPieChart();
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        labelBlock6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        labelBlock6.setPaint(paint14);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        xYSeries3.setNotify(true);
        java.lang.Object obj13 = xYSeries3.clone();
        xYSeries3.fireSeriesChanged();
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setCategoryMargin(0.0d);
        float float4 = categoryAxis3D1.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType5 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType5, (int) 'a');
        int int8 = dateTickUnit7.getRollMultiple();
        int int9 = dateTickUnit7.getCalendarField();
        java.lang.String str10 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) int9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        combinedDomainXYPlot14.datasetChanged(datasetChangeEvent15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = combinedDomainXYPlot14.getRangeAxisEdge(0);
        try {
            double double19 = categoryAxis3D1.getCategoryEnd(97, 97, rectangle2D13, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickUnitType5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        xYBarRenderer1.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        timeSeriesCollection2.validateObject();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = null;
        timeSeriesCollection2.seriesChanged(seriesChangeEvent7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            int[] intArray12 = timeSeriesCollection2.getSurroundingItems((int) '4', (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (52).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(16.0d, 0.4d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (16.0) <= upper (0.4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = null;
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str5 = layer4.toString();
        try {
            categoryPlot0.addDomainMarker(0, categoryMarker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(layer4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Layer.FOREGROUND" + "'", str5.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color2);
        boolean boolean5 = color2.equals((java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double13 = xYSeriesCollection11.getRangeUpperBound(true);
        try {
            java.lang.Number number16 = xYSeriesCollection11.getEndX((-16711936), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.0d + "'", double13 == 97.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        int int3 = jFreeChart1.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart1.getPadding();
        jFreeChart1.setBackgroundImageAlpha((float) (-1));
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat10);
        java.lang.String str13 = logFormat6.format((double) 100);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat6);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        xYBarRenderer16.notifyListeners(rendererChangeEvent17);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesStroke(0);
        java.awt.Paint paint21 = xYBarRenderer16.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYBarRenderer23.notifyListeners(rendererChangeEvent24);
        java.awt.Stroke stroke27 = xYBarRenderer23.lookupSeriesStroke(0);
        java.awt.Paint paint28 = xYBarRenderer23.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        combinedDomainXYPlot30.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYBarRenderer34.notifyListeners(rendererChangeEvent35);
        java.awt.Stroke stroke38 = xYBarRenderer34.lookupSeriesStroke(0);
        combinedDomainXYPlot30.setDomainMinorGridlineStroke(stroke38);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer40 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.Color color47 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        xYBarRenderer49.notifyListeners(rendererChangeEvent50);
        java.awt.Stroke stroke53 = xYBarRenderer49.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer40.drawDomainLine(graphics2D41, xYPlot42, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D45, (double) 100, (java.awt.Paint) color47, stroke53);
        java.util.Locale locale55 = periodAxis44.getLocale();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        java.awt.Paint paint58 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer23.drawDomainLine(graphics2D29, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D56, (double) (short) 10, paint58, stroke59);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer61 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis65 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.Color color68 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer70 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent71 = null;
        xYBarRenderer70.notifyListeners(rendererChangeEvent71);
        java.awt.Stroke stroke74 = xYBarRenderer70.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer61.drawDomainLine(graphics2D62, xYPlot63, (org.jfree.chart.axis.ValueAxis) periodAxis65, rectangle2D66, (double) 100, (java.awt.Paint) color68, stroke74);
        boolean boolean78 = xYStepRenderer61.getItemShapeVisible(100, 0);
        java.awt.Shape shape79 = xYStepRenderer61.getLegendLine();
        xYStepRenderer61.setBaseShapesFilled(true);
        combinedDomainXYPlot30.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer61);
        xYBarRenderer16.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot30);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot30);
        java.awt.Stroke stroke85 = combinedDomainXYPlot30.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!^�" + "'", str13.equals("hi!^�"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(locale55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNotNull(stroke85);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = combinedDomainXYPlot0.getRangeAxisEdge(0);
        java.lang.String str5 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker8.setLabelAnchor(rectangleAnchor9);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot11.setDomainCrosshairVisible(true);
        combinedDomainXYPlot11.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator19 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer17.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator19);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator22 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer17.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator22, true);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        combinedDomainXYPlot26.datasetChanged(datasetChangeEvent27);
        java.awt.Stroke stroke29 = combinedDomainXYPlot26.getRangeCrosshairStroke();
        boolean boolean30 = combinedDomainXYPlot26.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot26.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis32);
        org.jfree.chart.axis.PeriodAxis periodAxis35 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker37.setLabelAnchor(rectangleAnchor38);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = valueMarker37.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        xYBarRenderer17.drawDomainMarker(graphics2D25, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot26, (org.jfree.chart.axis.ValueAxis) periodAxis35, (org.jfree.chart.plot.Marker) valueMarker37, rectangle2D41);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker37, layer43);
        combinedDomainXYPlot0.addDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker8, layer43);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        try {
            combinedDomainXYPlot0.drawBackground(graphics2D46, rectangle2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Combined_Domain_XYPlot" + "'", str5.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator22);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(layer43);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline0.getTimeFromLong(0L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAxisLineVisible(false);
        java.awt.Font font4 = numberAxis3D1.getLabelFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8, timeZone9);
        org.jfree.chart.axis.AxisCollection axisCollection11 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list12 = axisCollection11.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D14.getTickLabelInsets();
        org.jfree.data.Range range16 = numberAxis3D14.getDefaultAutoRange();
        org.jfree.data.Range range18 = timeSeriesCollection10.getRangeBounds(list12, range16, false);
        axisState7.setTicks(list12);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        combinedDomainXYPlot21.datasetChanged(datasetChangeEvent22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = combinedDomainXYPlot21.getRangeAxisEdge(0);
        try {
            java.util.List list26 = numberAxis3D1.refreshTicks(graphics2D5, axisState7, rectangle2D20, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = valueMarker1.getLabelOffsetType();
        java.lang.String str5 = valueMarker1.getLabel();
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        valueMarker1.setPaint(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            categoryPlot0.handleClick((int) 'a', 2, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke4 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean5 = combinedDomainXYPlot0.isRangeZeroBaselineVisible();
        combinedDomainXYPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.Plot plot8 = combinedDomainXYPlot0.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            org.jfree.chart.plot.XYPlot xYPlot11 = combinedDomainXYPlot0.findSubplot(plotRenderingInfo9, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        java.awt.Paint paint38 = piePlot3D1.getBaseSectionOutlinePaint();
        boolean boolean39 = piePlot3D1.getSectionOutlinesVisible();
        piePlot3D1.setLabelLinksVisible(true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        boolean boolean3 = barRenderer3D0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        java.lang.String str2 = pieLabelDistributor1.toString();
        int int3 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedDomainXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Stroke stroke1 = xYStepRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        java.awt.Paint paint38 = piePlot3D1.getBaseSectionOutlinePaint();
        boolean boolean39 = piePlot3D1.getSectionOutlinesVisible();
        boolean boolean40 = piePlot3D1.getAutoPopulateSectionOutlinePaint();
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator9 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat8);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis16 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.Color color19 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        xYBarRenderer21.notifyListeners(rendererChangeEvent22);
        java.awt.Stroke stroke25 = xYBarRenderer21.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer12.drawDomainLine(graphics2D13, xYPlot14, (org.jfree.chart.axis.ValueAxis) periodAxis16, rectangle2D17, (double) 100, (java.awt.Paint) color19, stroke25);
        boolean boolean29 = xYStepRenderer12.getItemShapeVisible(100, 0);
        java.awt.Shape shape30 = xYStepRenderer12.getLegendLine();
        periodAxis11.setDownArrow(shape30);
        periodAxis11.setNegativeArrowVisible(true);
        try {
            java.lang.String str34 = logFormat4.format((java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        java.awt.Shape shape8 = pieSectionEntity7.getArea();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        java.lang.String str10 = pieSectionEntity7.getShapeCoords();
        pieSectionEntity7.setSectionIndex((int) 'a');
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-4,-4,4,4" + "'", str10.equals("-4,-4,4,4"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis3D1.getTickLabelInsets();
        org.jfree.data.Range range3 = numberAxis3D1.getDefaultAutoRange();
        numberAxis3D1.setAutoRange(false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 1L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint0.getHeightConstraintType();
        java.lang.String str4 = lengthConstraintType3.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LengthConstraintType.NONE" + "'", str4.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        combinedDomainXYPlot0.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator8 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer6.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator8);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer6.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator11, true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        combinedDomainXYPlot15.datasetChanged(datasetChangeEvent16);
        java.awt.Stroke stroke18 = combinedDomainXYPlot15.getRangeCrosshairStroke();
        boolean boolean19 = combinedDomainXYPlot15.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis21);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker26.setLabelAnchor(rectangleAnchor27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = valueMarker26.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYBarRenderer6.drawDomainMarker(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis24, (org.jfree.chart.plot.Marker) valueMarker26, rectangle2D30);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker26, layer32);
        java.awt.Stroke stroke34 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        combinedDomainXYPlot0.clearDomainMarkers(255);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        barRenderer3D0.setIncludeBaseInRange(false);
        barRenderer3D0.setBaseSeriesVisibleInLegend(true);
        java.awt.Shape shape49 = barRenderer3D0.lookupSeriesShape(10);
        java.awt.Font font53 = barRenderer3D0.getItemLabelFont(0, (-16711936), false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(font53);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list2 = projectInfo1.getContributors();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        int int3 = jFreeChart1.getBackgroundImageAlignment();
        java.awt.RenderingHints renderingHints4 = jFreeChart1.getRenderingHints();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(renderingHints4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = timeSeriesCollection2.hasListener(eventListener4);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator10 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer8.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator10);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer8.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, true);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        combinedDomainXYPlot17.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke20 = combinedDomainXYPlot17.getRangeCrosshairStroke();
        boolean boolean21 = combinedDomainXYPlot17.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis23);
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker28.setLabelAnchor(rectangleAnchor29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = valueMarker28.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYBarRenderer8.drawDomainMarker(graphics2D16, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot17, (org.jfree.chart.axis.ValueAxis) periodAxis26, (org.jfree.chart.plot.Marker) valueMarker28, rectangle2D32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = null;
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection38 = new org.jfree.data.time.TimeSeriesCollection(timeSeries36, timeZone37);
        org.jfree.chart.axis.AxisCollection axisCollection39 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list40 = axisCollection39.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis3D42.getTickLabelInsets();
        org.jfree.data.Range range44 = numberAxis3D42.getDefaultAutoRange();
        org.jfree.data.Range range46 = timeSeriesCollection38.getRangeBounds(list40, range44, false);
        combinedDomainXYPlot17.drawDomainTickBands(graphics2D34, rectangle2D35, list40);
        org.jfree.data.time.DateRange dateRange48 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range50 = timeSeriesCollection2.getRangeBounds(list40, (org.jfree.data.Range) dateRange48, true);
        java.lang.Number number51 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator13);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(dateRange48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNull(number51);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 0);
        boolean boolean2 = xYStepAreaRenderer1.isShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3, timeZone4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list7 = categoryPlot6.getAnnotations();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.Color color15 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        java.awt.Stroke stroke21 = xYBarRenderer17.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer8.drawDomainLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis12, rectangle2D13, (double) 100, (java.awt.Paint) color15, stroke21);
        int int23 = periodAxis12.getMinorTickCount();
        java.util.Locale locale24 = periodAxis12.getLocale();
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        boolean boolean31 = dateRange27.intersects((org.jfree.data.Range) dateRange30);
        periodAxis12.setRange((org.jfree.data.Range) dateRange27, false, false);
        org.jfree.data.Range range36 = timeSeriesCollection5.getRangeBounds(list7, (org.jfree.data.Range) dateRange27, false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot37.setDomainCrosshairVisible(true);
        java.awt.Paint paint41 = combinedDomainXYPlot37.getQuadrantPaint((int) (byte) 1);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection46 = new org.jfree.data.time.TimeSeriesCollection(timeSeries44, timeZone45);
        org.jfree.chart.axis.AxisCollection axisCollection47 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list48 = axisCollection47.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = numberAxis3D50.getTickLabelInsets();
        org.jfree.data.Range range52 = numberAxis3D50.getDefaultAutoRange();
        org.jfree.data.Range range54 = timeSeriesCollection46.getRangeBounds(list48, range52, false);
        combinedDomainXYPlot37.drawRangeTickBands(graphics2D42, rectangle2D43, list48);
        boolean boolean56 = timeSeriesCollection5.hasListener((java.util.EventListener) combinedDomainXYPlot37);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(locale24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Layer.FOREGROUND", font5);
        java.lang.Object obj7 = labelBlock6.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot8.getPieChart();
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        labelBlock6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = labelBlock6.getContentAlignmentPoint();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart18, (int) (short) 100, 0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart23 = multiplePiePlot22.getPieChart();
        org.jfree.chart.title.TextTitle textTitle24 = jFreeChart23.getTitle();
        chartProgressEvent21.setChart(jFreeChart23);
        try {
            java.lang.Object obj26 = labelBlock6.draw(graphics2D15, rectangle2D16, (java.lang.Object) chartProgressEvent21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(jFreeChart23);
        org.junit.Assert.assertNotNull(textTitle24);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("GradientPaintTransformType.CENTER_HORIZONTAL", graphics2D1, (double) 0.5f, (-1.0f), (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        java.awt.Color color6 = java.awt.Color.yellow;
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.setAxisLineVisible(false);
        java.awt.Paint paint17 = numberAxis3D14.getTickMarkPaint();
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor5, color6, color7, paint8, chartColor12, paint17 };
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color20 = java.awt.Color.WHITE;
        java.awt.Color color21 = java.awt.Color.yellow;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { paint19, color20, color21, color22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYBarRenderer33.notifyListeners(rendererChangeEvent34);
        java.awt.Stroke stroke37 = xYBarRenderer33.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] { stroke24, stroke25, stroke31, stroke37 };
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYBarRenderer40.notifyListeners(rendererChangeEvent41);
        java.awt.Stroke stroke44 = xYBarRenderer40.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray46 = new java.awt.Stroke[] { stroke44, stroke45 };
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] { shape49 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray23, strokeArray38, strokeArray46, shapeArray50);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51, true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot54 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart55 = multiplePiePlot54.getPieChart();
        org.jfree.chart.title.TextTitle textTitle56 = jFreeChart55.getTitle();
        int int57 = jFreeChart55.getBackgroundImageAlignment();
        multiplePiePlot0.setPieChart(jFreeChart55);
        java.awt.Image image59 = jFreeChart55.getBackgroundImage();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertNotNull(jFreeChart55);
        org.junit.Assert.assertNotNull(textTitle56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 15 + "'", int57 == 15);
        org.junit.Assert.assertNull(image59);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = timeSeriesCollection2.hasListener(eventListener4);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator10 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer8.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator10);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer8.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, true);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        combinedDomainXYPlot17.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke20 = combinedDomainXYPlot17.getRangeCrosshairStroke();
        boolean boolean21 = combinedDomainXYPlot17.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis23);
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker28.setLabelAnchor(rectangleAnchor29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = valueMarker28.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYBarRenderer8.drawDomainMarker(graphics2D16, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot17, (org.jfree.chart.axis.ValueAxis) periodAxis26, (org.jfree.chart.plot.Marker) valueMarker28, rectangle2D32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = null;
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection38 = new org.jfree.data.time.TimeSeriesCollection(timeSeries36, timeZone37);
        org.jfree.chart.axis.AxisCollection axisCollection39 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list40 = axisCollection39.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis3D42.getTickLabelInsets();
        org.jfree.data.Range range44 = numberAxis3D42.getDefaultAutoRange();
        org.jfree.data.Range range46 = timeSeriesCollection38.getRangeBounds(list40, range44, false);
        combinedDomainXYPlot17.drawDomainTickBands(graphics2D34, rectangle2D35, list40);
        org.jfree.data.time.DateRange dateRange48 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range50 = timeSeriesCollection2.getRangeBounds(list40, (org.jfree.data.Range) dateRange48, true);
        try {
            double double53 = timeSeriesCollection2.getStartYValue(14, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 14, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator13);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(dateRange48);
        org.junit.Assert.assertNull(range50);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        combinedDomainXYPlot10.setWeight(15);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        boolean boolean35 = xYStepRenderer18.getItemShapeVisible(100, 0);
        java.awt.Shape shape36 = xYStepRenderer18.getLegendLine();
        periodAxis17.setDownArrow(shape36);
        periodAxis17.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot40.setDomainCrosshairVisible(true);
        combinedDomainXYPlot40.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer46 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator48 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer46.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator48);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator51 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer46.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator51, true);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        combinedDomainXYPlot55.datasetChanged(datasetChangeEvent56);
        java.awt.Stroke stroke58 = combinedDomainXYPlot55.getRangeCrosshairStroke();
        boolean boolean59 = combinedDomainXYPlot55.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis61 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot55.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis61);
        org.jfree.chart.axis.PeriodAxis periodAxis64 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker66.setLabelAnchor(rectangleAnchor67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = valueMarker66.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        xYBarRenderer46.drawDomainMarker(graphics2D54, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot55, (org.jfree.chart.axis.ValueAxis) periodAxis64, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D70);
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot40.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker66, layer72);
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        xYBarRenderer1.drawRangeMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D74);
        java.awt.Paint paint77 = xYBarRenderer1.getSeriesFillPaint(8);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator51);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertNull(paint77);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator8 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer6.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator8);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer6.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator11, true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        combinedDomainXYPlot15.datasetChanged(datasetChangeEvent16);
        java.awt.Stroke stroke18 = combinedDomainXYPlot15.getRangeCrosshairStroke();
        boolean boolean19 = combinedDomainXYPlot15.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis21);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker26.setLabelAnchor(rectangleAnchor27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = valueMarker26.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYBarRenderer6.drawDomainMarker(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis24, (org.jfree.chart.plot.Marker) valueMarker26, rectangle2D30);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot32.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str39 = layer38.toString();
        combinedDomainXYPlot32.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker37, layer38);
        combinedDomainXYPlot0.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker26, layer38);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer43 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator45 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer43.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator45);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator48 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer43.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator48, true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator51 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer52 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator48, xYURLGenerator51);
        boolean boolean53 = xYStepRenderer52.getUseFillPaint();
        boolean boolean54 = xYStepRenderer52.getBaseShapesVisible();
        xYStepRenderer52.setItemLabelAnchorOffset((double) 100);
        xYStepRenderer52.setDataBoundsIncludesVisibleSeriesOnly(false);
        java.awt.Stroke stroke59 = xYStepRenderer52.getBaseStroke();
        combinedDomainXYPlot0.setRangeCrosshairStroke(stroke59);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.FOREGROUND" + "'", str39.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYBarRenderer11.notifyListeners(rendererChangeEvent12);
        java.awt.Stroke stroke15 = xYBarRenderer11.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer2.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis6, rectangle2D7, (double) 100, (java.awt.Paint) color9, stroke15);
        int int17 = periodAxis6.getMinorTickCount();
        java.util.Locale locale18 = periodAxis6.getLocale();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator19 = new org.jfree.chart.labels.StandardPieToolTipGenerator("RangeType.FULL", locale18);
        java.lang.ClassLoader classLoader20 = null;
        try {
            java.util.ResourceBundle resourceBundle21 = java.util.ResourceBundle.getBundle("Layer.FOREGROUND", locale18, classLoader20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(locale18);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29 + "'", int2 == 29);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeriesCollection11.setAutoWidth(true);
        org.junit.Assert.assertNull(xYDataItem6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        java.awt.Paint paint4 = combinedDomainXYPlot0.getQuadrantPaint((int) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedDomainXYPlot0.setFixedRangeAxisSpace(axisSpace5);
        combinedDomainXYPlot0.setBackgroundAlpha((float) '#');
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray9 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        combinedDomainXYPlot0.setRenderers(xYItemRendererArray9);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(xYItemRendererArray9);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYBarRenderer11.notifyListeners(rendererChangeEvent12);
        java.awt.Stroke stroke15 = xYBarRenderer11.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer2.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis6, rectangle2D7, (double) 100, (java.awt.Paint) color9, stroke15);
        boolean boolean19 = xYStepRenderer2.getItemShapeVisible(100, 0);
        java.awt.Shape shape20 = xYStepRenderer2.getLegendLine();
        periodAxis1.setDownArrow(shape20);
        periodAxis1.setNegativeArrowVisible(true);
        periodAxis1.setMinorTickMarksVisible(false);
        float float26 = periodAxis1.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getCategories();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint4 = null;
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) 8.0d, paint4);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.util.List list8 = null;
        try {
            categoryPlot0.mapDatasetToDomainAxes(10, list8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(list1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setCategoryMargin(0.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState6 = new org.jfree.chart.axis.AxisState((double) 0);
        double double7 = axisState6.getMax();
        java.util.List list8 = axisState6.getTicks();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = combinedDomainXYPlot10.getRangeAxisEdge(0);
        boolean boolean15 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge14);
        try {
            java.util.List list16 = categoryAxis3D1.refreshTicks(graphics2D4, axisState6, rectangle2D9, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        piePlot3D1.setMinimumArcAngleToDraw((double) (-16777216));
        java.awt.Stroke stroke40 = piePlot3D1.getBaseSectionOutlineStroke();
        boolean boolean41 = piePlot3D1.getAutoPopulateSectionOutlinePaint();
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2958465);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        double double1 = xYCrosshairState0.getCrosshairDistance();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        java.awt.Image image2 = null;
        projectInfo0.setLogo(image2);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator10 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator10);
        boolean boolean13 = xYBarRenderer1.isSeriesItemLabelsVisible((int) (byte) -1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean4 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        java.awt.Stroke stroke5 = combinedDomainXYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setRangeCrosshairLockedOnData(true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            java.lang.Number number3 = defaultXYDataset0.getY((-16777216), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double[] doubleArray7 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray13 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray19 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray13, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "series", doubleArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset21, true);
        org.jfree.chart.axis.AxisState axisState25 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.data.time.TimeSeries timeSeries26 = null;
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection(timeSeries26, timeZone27);
        org.jfree.chart.axis.AxisCollection axisCollection29 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list30 = axisCollection29.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis3D32.getTickLabelInsets();
        org.jfree.data.Range range34 = numberAxis3D32.getDefaultAutoRange();
        org.jfree.data.Range range36 = timeSeriesCollection28.getRangeBounds(list30, range34, false);
        axisState25.setTicks(list30);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset21, list30, true);
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset21);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 30.0d + "'", number40.equals(30.0d));
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator22 = xYStepRenderer0.getToolTipGenerator((int) (short) -1, 255, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator27 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer25.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator27);
        java.awt.Stroke stroke29 = xYBarRenderer25.getBaseOutlineStroke();
        xYStepRenderer0.setSeriesOutlineStroke(3, stroke29, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(xYToolTipGenerator22);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearAnnotations();
        categoryPlot8.configureDomainAxes();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            barRenderer3D0.drawOutline(graphics2D7, categoryPlot8, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double[] doubleArray7 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray13 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray19 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray13, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "series", doubleArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset21, true);
        org.jfree.chart.axis.AxisState axisState25 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.data.time.TimeSeries timeSeries26 = null;
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection(timeSeries26, timeZone27);
        org.jfree.chart.axis.AxisCollection axisCollection29 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list30 = axisCollection29.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis3D32.getTickLabelInsets();
        org.jfree.data.Range range34 = numberAxis3D32.getDefaultAutoRange();
        org.jfree.data.Range range36 = timeSeriesCollection28.getRangeBounds(list30, range34, false);
        axisState25.setTicks(list30);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset21, list30, true);
        try {
            org.jfree.data.general.PieDataset pieDataset41 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset21, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        timeSeriesCollection2.validateObject();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = null;
        timeSeriesCollection2.seriesChanged(seriesChangeEvent7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor10 = null;
        try {
            timeSeriesCollection2.setXPosition(timePeriodAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent34 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) logAxis9);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.AxisState axisState37 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.data.time.TimeSeries timeSeries38 = null;
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection40 = new org.jfree.data.time.TimeSeriesCollection(timeSeries38, timeZone39);
        org.jfree.chart.axis.AxisCollection axisCollection41 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list42 = axisCollection41.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = numberAxis3D44.getTickLabelInsets();
        org.jfree.data.Range range46 = numberAxis3D44.getDefaultAutoRange();
        org.jfree.data.Range range48 = timeSeriesCollection40.getRangeBounds(list42, range46, false);
        axisState37.setTicks(list42);
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot51 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent52 = null;
        combinedDomainXYPlot51.datasetChanged(datasetChangeEvent52);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = combinedDomainXYPlot51.getRangeAxisEdge(0);
        boolean boolean56 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge55);
        try {
            java.util.List list57 = logAxis9.refreshTicks(graphics2D35, axisState37, rectangle2D50, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        try {
            java.util.Collection collection6 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        combinedDomainXYPlot10.setWeight(15);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        boolean boolean35 = xYStepRenderer18.getItemShapeVisible(100, 0);
        java.awt.Shape shape36 = xYStepRenderer18.getLegendLine();
        periodAxis17.setDownArrow(shape36);
        periodAxis17.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot40.setDomainCrosshairVisible(true);
        combinedDomainXYPlot40.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer46 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator48 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer46.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator48);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator51 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer46.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator51, true);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        combinedDomainXYPlot55.datasetChanged(datasetChangeEvent56);
        java.awt.Stroke stroke58 = combinedDomainXYPlot55.getRangeCrosshairStroke();
        boolean boolean59 = combinedDomainXYPlot55.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis61 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot55.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis61);
        org.jfree.chart.axis.PeriodAxis periodAxis64 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker66.setLabelAnchor(rectangleAnchor67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = valueMarker66.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        xYBarRenderer46.drawDomainMarker(graphics2D54, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot55, (org.jfree.chart.axis.ValueAxis) periodAxis64, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D70);
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot40.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker66, layer72);
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        xYBarRenderer1.drawRangeMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D74);
        java.awt.Stroke stroke76 = combinedDomainXYPlot10.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator51);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = null;
        try {
            org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        xYBarRenderer1.removeAnnotations();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart1);
        boolean boolean3 = jFreeChart1.isNotify();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker5.setLabelAnchor(rectangleAnchor6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = valueMarker5.getLabelOffset();
        double double10 = rectangleInsets8.calculateRightOutset((double) 2);
        jFreeChart1.setPadding(rectangleInsets8);
        int int12 = jFreeChart1.getBackgroundImageAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = null;
        try {
            jFreeChart1.titleChanged(titleChangeEvent13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent34 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) logAxis9);
        boolean boolean35 = logAxis9.isAutoRange();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3, timeZone4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection5, false);
        try {
            java.lang.Number number10 = timeSeriesCollection5.getEndY((int) (short) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        java.lang.String str2 = projectInfo0.toString();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        java.util.Currency currency1 = null;
        try {
            numberFormat0.setCurrency(currency1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        java.util.Date date3 = null;
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        java.awt.Paint paint38 = piePlot3D1.getBaseSectionOutlinePaint();
        piePlot3D1.setSectionOutlinesVisible(true);
        java.awt.Shape shape41 = piePlot3D1.getLegendItemShape();
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(shape41);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, 16.0d, (double) 14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.removeValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYBarRenderer11.notifyListeners(rendererChangeEvent12);
        java.awt.Stroke stroke15 = xYBarRenderer11.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer2.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis6, rectangle2D7, (double) 100, (java.awt.Paint) color9, stroke15);
        boolean boolean19 = xYStepRenderer2.getItemShapeVisible(100, 0);
        java.awt.Shape shape20 = xYStepRenderer2.getLegendLine();
        periodAxis1.setDownArrow(shape20);
        periodAxis1.setMinorTickCount(8);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray24 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray24);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray24);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3, timeZone4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        java.awt.Shape shape8 = pieSectionEntity7.getArea();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        pieSectionEntity7.setURLText("[100.0, 24234.0]");
        int int12 = pieSectionEntity7.getSectionIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double13 = xYSeriesCollection11.getRangeUpperBound(true);
        org.jfree.data.xy.XYSeries xYSeries17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem20 = xYSeries17.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries17.add((double) (-14666742), (double) 97, true);
        xYSeriesCollection11.removeSeries(xYSeries17);
        try {
            double double28 = xYSeriesCollection11.getXValue((-14666742), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.0d + "'", double13 == 97.0d);
        org.junit.Assert.assertNull(xYDataItem20);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        org.jfree.data.Range range37 = combinedDomainXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis12);
        logAxis12.setAutoRangeMinimumSize((double) 12, true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(range37);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        int int3 = jFreeChart1.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart1.getPadding();
        int int6 = jFreeChart1.getBackgroundImageAlignment();
        java.awt.Stroke stroke7 = jFreeChart1.getBorderStroke();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.clear();
        org.junit.Assert.assertNull(xYDataItem6);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator8 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer6.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator8);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer6.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator11, true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        combinedDomainXYPlot15.datasetChanged(datasetChangeEvent16);
        java.awt.Stroke stroke18 = combinedDomainXYPlot15.getRangeCrosshairStroke();
        boolean boolean19 = combinedDomainXYPlot15.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis21);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker26.setLabelAnchor(rectangleAnchor27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = valueMarker26.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYBarRenderer6.drawDomainMarker(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis24, (org.jfree.chart.plot.Marker) valueMarker26, rectangle2D30);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot32.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str39 = layer38.toString();
        combinedDomainXYPlot32.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker37, layer38);
        combinedDomainXYPlot0.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker26, layer38);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker26.setStroke(stroke42);
        org.jfree.chart.text.TextAnchor textAnchor44 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        valueMarker26.setLabelTextAnchor(textAnchor44);
        java.awt.Stroke stroke46 = valueMarker26.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.FOREGROUND" + "'", str39.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(textAnchor44);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        combinedDomainXYPlot0.clearDomainMarkers(3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot0.getRangeAxis();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYBarRenderer8.notifyListeners(rendererChangeEvent9);
        java.awt.Stroke stroke12 = xYBarRenderer8.lookupSeriesStroke(0);
        java.awt.Paint paint13 = xYBarRenderer8.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer8.setPositiveItemLabelPositionFallback(itemLabelPosition14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        combinedDomainXYPlot17.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke20 = combinedDomainXYPlot17.getRangeCrosshairStroke();
        combinedDomainXYPlot17.setWeight(15);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer25 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.Color color32 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYBarRenderer34.notifyListeners(rendererChangeEvent35);
        java.awt.Stroke stroke38 = xYBarRenderer34.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer25.drawDomainLine(graphics2D26, xYPlot27, (org.jfree.chart.axis.ValueAxis) periodAxis29, rectangle2D30, (double) 100, (java.awt.Paint) color32, stroke38);
        boolean boolean42 = xYStepRenderer25.getItemShapeVisible(100, 0);
        java.awt.Shape shape43 = xYStepRenderer25.getLegendLine();
        periodAxis24.setDownArrow(shape43);
        periodAxis24.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot47 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot47.setDomainCrosshairVisible(true);
        combinedDomainXYPlot47.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer53 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator55 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer53.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator55);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator58 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer53.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator58, true);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot62 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        combinedDomainXYPlot62.datasetChanged(datasetChangeEvent63);
        java.awt.Stroke stroke65 = combinedDomainXYPlot62.getRangeCrosshairStroke();
        boolean boolean66 = combinedDomainXYPlot62.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis68 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot62.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis68);
        org.jfree.chart.axis.PeriodAxis periodAxis71 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker73 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker73.setLabelAnchor(rectangleAnchor74);
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = valueMarker73.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        xYBarRenderer53.drawDomainMarker(graphics2D61, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot62, (org.jfree.chart.axis.ValueAxis) periodAxis71, (org.jfree.chart.plot.Marker) valueMarker73, rectangle2D77);
        org.jfree.chart.util.Layer layer79 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot47.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker73, layer79);
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        xYBarRenderer8.drawRangeMarker(graphics2D16, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot17, (org.jfree.chart.axis.ValueAxis) periodAxis24, (org.jfree.chart.plot.Marker) valueMarker73, rectangle2D81);
        org.jfree.chart.axis.AxisLocation axisLocation83 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot17.setRangeAxisLocation(axisLocation83);
        org.jfree.chart.axis.AxisLocation axisLocation85 = axisLocation83.getOpposite();
        try {
            combinedDomainXYPlot0.setRangeAxisLocation((-1), axisLocation83, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator58);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor74);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertNotNull(layer79);
        org.junit.Assert.assertNotNull(axisLocation83);
        org.junit.Assert.assertNotNull(axisLocation85);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace2 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        boolean boolean3 = day1.equals((java.lang.Object) itemLabelAnchor2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.Color color24 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer17.drawDomainLine(graphics2D18, xYPlot19, (org.jfree.chart.axis.ValueAxis) periodAxis21, rectangle2D22, (double) 100, (java.awt.Paint) color24, stroke30);
        java.util.Locale locale32 = periodAxis21.getLocale();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator33 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale32);
        org.jfree.chart.axis.TickUnitSource tickUnitSource34 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale32);
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis35 = new org.jfree.chart.axis.PeriodAxis("[100.0, 24234.0]", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) month14, timeZone16, locale32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(locale32);
        org.junit.Assert.assertNotNull(tickUnitSource34);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        xYBarRenderer1.setSeriesItemLabelsVisible((int) (short) 0, true);
        java.lang.Boolean boolean10 = xYBarRenderer1.getSeriesItemLabelsVisible(0);
        java.awt.Shape shape12 = xYBarRenderer1.lookupLegendShape(0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10.equals(true));
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 1L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint0.getHeightConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint0.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        combinedDomainXYPlot10.setWeight(15);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        boolean boolean35 = xYStepRenderer18.getItemShapeVisible(100, 0);
        java.awt.Shape shape36 = xYStepRenderer18.getLegendLine();
        periodAxis17.setDownArrow(shape36);
        periodAxis17.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot40.setDomainCrosshairVisible(true);
        combinedDomainXYPlot40.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer46 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator48 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer46.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator48);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator51 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer46.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator51, true);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        combinedDomainXYPlot55.datasetChanged(datasetChangeEvent56);
        java.awt.Stroke stroke58 = combinedDomainXYPlot55.getRangeCrosshairStroke();
        boolean boolean59 = combinedDomainXYPlot55.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis61 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot55.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis61);
        org.jfree.chart.axis.PeriodAxis periodAxis64 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker66.setLabelAnchor(rectangleAnchor67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = valueMarker66.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        xYBarRenderer46.drawDomainMarker(graphics2D54, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot55, (org.jfree.chart.axis.ValueAxis) periodAxis64, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D70);
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot40.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker66, layer72);
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        xYBarRenderer1.drawRangeMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D74);
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot10.setRangeAxisLocation(axisLocation76);
        java.awt.Graphics2D graphics2D78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        java.awt.geom.Point2D point2D80 = null;
        org.jfree.chart.plot.PlotState plotState81 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        try {
            combinedDomainXYPlot10.draw(graphics2D78, rectangle2D79, point2D80, plotState81, plotRenderingInfo82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator51);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertNotNull(axisLocation76);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        xYSeries3.add((double) (byte) 0, (java.lang.Number) 24234L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.Color color13 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        xYBarRenderer15.notifyListeners(rendererChangeEvent16);
        java.awt.Stroke stroke19 = xYBarRenderer15.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer6.drawDomainLine(graphics2D7, xYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis10, rectangle2D11, (double) 100, (java.awt.Paint) color13, stroke19);
        boolean boolean23 = xYStepRenderer6.getItemShapeVisible(100, 0);
        java.awt.Shape shape24 = xYStepRenderer6.getLegendLine();
        periodAxis5.setDownArrow(shape24);
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity33 = new org.jfree.chart.entity.PieSectionEntity(shape26, pieDataset27, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        periodAxis5.setLeftArrow(shape26);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot35 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot35.setDomainCrosshairVisible(true);
        combinedDomainXYPlot35.clearDomainMarkers(3);
        java.awt.Stroke stroke40 = combinedDomainXYPlot35.getOutlineStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer42 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator44 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer42.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator44);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator47 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer42.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator47, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator50 = xYBarRenderer42.getBaseToolTipGenerator();
        java.awt.Paint paint54 = xYBarRenderer42.getItemFillPaint((-16777216), (-14666742), true);
        try {
            org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "TextAnchor.HALF_ASCENT_RIGHT", shape26, stroke40, paint54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator47);
        org.junit.Assert.assertNull(xYToolTipGenerator50);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.configure();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState5 = new org.jfree.chart.axis.AxisState((double) 0);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list8 = categoryPlot7.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getRangeAxisEdge();
        try {
            java.util.List list10 = categoryAxis3D1.refreshTicks(graphics2D3, axisState5, rectangle2D6, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 100, (double) 24234L);
        double double3 = xYDataItem2.getXValue();
        java.lang.Number number4 = xYDataItem2.getX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0d + "'", number4.equals(100.0d));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        combinedDomainXYPlot10.setWeight(15);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        boolean boolean35 = xYStepRenderer18.getItemShapeVisible(100, 0);
        java.awt.Shape shape36 = xYStepRenderer18.getLegendLine();
        periodAxis17.setDownArrow(shape36);
        periodAxis17.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot40.setDomainCrosshairVisible(true);
        combinedDomainXYPlot40.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer46 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator48 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer46.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator48);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator51 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer46.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator51, true);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        combinedDomainXYPlot55.datasetChanged(datasetChangeEvent56);
        java.awt.Stroke stroke58 = combinedDomainXYPlot55.getRangeCrosshairStroke();
        boolean boolean59 = combinedDomainXYPlot55.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis61 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot55.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis61);
        org.jfree.chart.axis.PeriodAxis periodAxis64 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker66.setLabelAnchor(rectangleAnchor67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = valueMarker66.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        xYBarRenderer46.drawDomainMarker(graphics2D54, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot55, (org.jfree.chart.axis.ValueAxis) periodAxis64, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D70);
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot40.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker66, layer72);
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        xYBarRenderer1.drawRangeMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D74);
        boolean boolean77 = xYBarRenderer1.isSeriesVisible(0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator51);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) '#');
        java.lang.Object obj2 = xYAreaRenderer1.clone();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.text.NumberFormat numberFormat7 = numberAxis3D6.getNumberFormatOverride();
        numberAxis3D6.setMinorTickMarkOutsideLength((float) '#');
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) numberAxis3D6, false);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            xYAreaRenderer1.drawDomainGridLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis3D6, rectangle2D13, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(numberFormat7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
        xYBarRenderer1.setSeriesItemLabelGenerator(29, xYItemLabelGenerator3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean4 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.Paint paint8 = combinedDomainXYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.util.LogFormat logFormat7 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat7, (java.text.NumberFormat) logFormat11);
        java.lang.String str14 = logFormat7.format((double) 100);
        logAxis2.setNumberFormatOverride((java.text.NumberFormat) logFormat7);
        java.text.DateFormat dateFormat16 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator17 = new org.jfree.chart.labels.StandardXYToolTipGenerator("RangeType.FULL", (java.text.NumberFormat) logFormat7, dateFormat16);
        int int18 = logFormat7.getMaximumFractionDigits();
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!^�" + "'", str14.equals("hi!^�"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }
}

