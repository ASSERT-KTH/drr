import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) '#');
        org.jfree.chart.LegendItem legendItem4 = xYAreaRenderer1.getLegendItem(2019, (-1));
        org.junit.Assert.assertNull(legendItem4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        jFreeChart1.setNotify(false);
        int int4 = jFreeChart1.getSubtitleCount();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 100, (double) 24234L);
        double double3 = xYDataItem2.getYValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 24234.0d + "'", double3 == 24234.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.removeValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        double double3 = barRenderer3D0.getYOffset();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.Color color11 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        xYBarRenderer13.notifyListeners(rendererChangeEvent14);
        java.awt.Stroke stroke17 = xYBarRenderer13.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer4.drawDomainLine(graphics2D5, xYPlot6, (org.jfree.chart.axis.ValueAxis) periodAxis8, rectangle2D9, (double) 100, (java.awt.Paint) color11, stroke17);
        int int19 = periodAxis8.getMinorTickCount();
        java.util.Locale locale20 = periodAxis8.getLocale();
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        boolean boolean27 = dateRange23.intersects((org.jfree.data.Range) dateRange26);
        periodAxis8.setRange((org.jfree.data.Range) dateRange23, false, false);
        boolean boolean31 = barRenderer3D0.equals((java.lang.Object) false);
        java.awt.Shape shape33 = barRenderer3D0.getLegendShape(2);
        int int34 = barRenderer3D0.getPassCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(locale20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(shape33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        timeSeriesCollection2.validateObject();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = null;
        timeSeriesCollection2.seriesChanged(seriesChangeEvent7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        timeSeriesCollection2.validateObject();
        try {
            double double13 = timeSeriesCollection2.getStartXValue(0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        double double34 = xYBarRenderer1.getItemLabelAnchorOffset();
        xYBarRenderer1.setDrawBarOutline(false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        numberAxis3D1.setMinorTickMarkOutsideLength((float) '#');
        java.lang.Object obj5 = numberAxis3D1.clone();
        boolean boolean6 = numberAxis3D1.isVerticalTickLabels();
        numberAxis3D1.setAutoRangeStickyZero(false);
        numberAxis3D1.configure();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Color color5 = java.awt.Color.getColor("hi!", (int) 'a');
        combinedDomainXYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        double double8 = numberAxis3D7.getLabelAngle();
        combinedDomainXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D7);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        java.util.Locale locale15 = periodAxis4.getLocale();
        java.text.NumberFormat numberFormat16 = java.text.NumberFormat.getPercentInstance(locale15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(locale15);
        org.junit.Assert.assertNotNull(numberFormat16);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        java.awt.Paint paint38 = piePlot3D1.getBaseSectionOutlinePaint();
        boolean boolean39 = piePlot3D1.getSectionOutlinesVisible();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer40 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.Color color47 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        xYBarRenderer49.notifyListeners(rendererChangeEvent50);
        java.awt.Stroke stroke53 = xYBarRenderer49.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer40.drawDomainLine(graphics2D41, xYPlot42, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D45, (double) 100, (java.awt.Paint) color47, stroke53);
        java.util.Locale locale55 = periodAxis44.getLocale();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator56 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale55);
        boolean boolean57 = piePlot3D1.equals((java.lang.Object) locale55);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(locale55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYBarRenderer11.notifyListeners(rendererChangeEvent12);
        java.awt.Stroke stroke15 = xYBarRenderer11.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer2.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis6, rectangle2D7, (double) 100, (java.awt.Paint) color9, stroke15);
        boolean boolean19 = xYStepRenderer2.getItemShapeVisible(100, 0);
        java.awt.Shape shape20 = xYStepRenderer2.getLegendLine();
        periodAxis1.setDownArrow(shape20);
        periodAxis1.setMinorTickCount(8);
        periodAxis1.pan((double) 10.0f);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYBarRenderer1.getBaseToolTipGenerator();
        java.awt.Paint paint11 = xYBarRenderer1.getSeriesPaint(2958465);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        java.awt.Color color6 = java.awt.Color.yellow;
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.setAxisLineVisible(false);
        java.awt.Paint paint17 = numberAxis3D14.getTickMarkPaint();
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor5, color6, color7, paint8, chartColor12, paint17 };
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color20 = java.awt.Color.WHITE;
        java.awt.Color color21 = java.awt.Color.yellow;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { paint19, color20, color21, color22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYBarRenderer33.notifyListeners(rendererChangeEvent34);
        java.awt.Stroke stroke37 = xYBarRenderer33.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] { stroke24, stroke25, stroke31, stroke37 };
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYBarRenderer40.notifyListeners(rendererChangeEvent41);
        java.awt.Stroke stroke44 = xYBarRenderer40.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray46 = new java.awt.Stroke[] { stroke44, stroke45 };
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] { shape49 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray23, strokeArray38, strokeArray46, shapeArray50);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51, true);
        java.awt.Paint paint54 = multiplePiePlot0.getBackgroundPaint();
        java.awt.Paint paint55 = multiplePiePlot0.getBackgroundPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection56 = multiplePiePlot0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem58 = legendItemCollection56.get((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(legendItemCollection56);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeriesCollection11.setIntervalWidth(30.0d);
        org.junit.Assert.assertNull(xYDataItem6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        long long3 = segmentedTimeline0.getStartTime();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208927600000L) + "'", long3 == (-2208927600000L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat2 = null;
        logAxis1.setNumberFormatOverride(numberFormat2);
        logAxis1.configure();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) logAxis1);
        logAxis1.configure();
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double13 = xYSeriesCollection11.getRangeUpperBound(true);
        try {
            java.lang.Number number16 = xYSeriesCollection11.getEndY(0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.0d + "'", double13 == 97.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator2 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator4 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!^�");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator2, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator4);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator4);
        java.awt.Paint paint10 = xYStepAreaRenderer6.getItemOutlinePaint(1, 97, false);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        boolean boolean14 = combinedDomainXYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis16);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker21.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker21.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYBarRenderer1.drawDomainMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis19, (org.jfree.chart.plot.Marker) valueMarker21, rectangle2D25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = null;
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeSeries29, timeZone30);
        org.jfree.chart.axis.AxisCollection axisCollection32 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list33 = axisCollection32.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = numberAxis3D35.getTickLabelInsets();
        org.jfree.data.Range range37 = numberAxis3D35.getDefaultAutoRange();
        org.jfree.data.Range range39 = timeSeriesCollection31.getRangeBounds(list33, range37, false);
        combinedDomainXYPlot10.drawDomainTickBands(graphics2D27, rectangle2D28, list33);
        boolean boolean41 = combinedDomainXYPlot10.canSelectByRegion();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        boolean boolean2 = jFreeChart1.isNotify();
        jFreeChart1.fireChartChanged();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double[] doubleArray7 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray13 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray19 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray13, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "series", doubleArray20);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset21);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis3D1.getTickLabelInsets();
        boolean boolean3 = numberAxis3D1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis3D1.valueToJava2D((-7.0d), rectangle2D5, rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.awt.Color color2 = java.awt.Color.WHITE;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker(97.0d, (double) 100.0f, (java.awt.Paint) color2);
        org.jfree.chart.plot.CrosshairState crosshairState5 = new org.jfree.chart.plot.CrosshairState(true);
        double double6 = crosshairState5.getCrosshairDistance();
        crosshairState5.updateCrosshairX((double) 0L);
        boolean boolean9 = intervalMarker3.equals((java.lang.Object) 0L);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYBarRenderer11.notifyListeners(rendererChangeEvent12);
        java.awt.Stroke stroke15 = xYBarRenderer11.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer2.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis6, rectangle2D7, (double) 100, (java.awt.Paint) color9, stroke15);
        boolean boolean19 = xYStepRenderer2.getItemShapeVisible(100, 0);
        java.awt.Shape shape20 = xYStepRenderer2.getLegendLine();
        periodAxis1.setDownArrow(shape20);
        periodAxis1.setUpperMargin((double) 3);
        boolean boolean24 = periodAxis1.isAxisLineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        java.awt.Paint paint31 = xYBarRenderer26.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = null;
        combinedDomainXYPlot33.datasetChanged(datasetChangeEvent34);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesStroke(0);
        combinedDomainXYPlot33.setDomainMinorGridlineStroke(stroke41);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Color color50 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer52 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        xYBarRenderer52.notifyListeners(rendererChangeEvent53);
        java.awt.Stroke stroke56 = xYBarRenderer52.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer43.drawDomainLine(graphics2D44, xYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D48, (double) 100, (java.awt.Paint) color50, stroke56);
        java.util.Locale locale58 = periodAxis47.getLocale();
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        java.awt.Paint paint61 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke62 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer26.drawDomainLine(graphics2D32, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot33, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D59, (double) (short) 10, paint61, stroke62);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer64 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis68 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        java.awt.Color color71 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer73 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent74 = null;
        xYBarRenderer73.notifyListeners(rendererChangeEvent74);
        java.awt.Stroke stroke77 = xYBarRenderer73.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer64.drawDomainLine(graphics2D65, xYPlot66, (org.jfree.chart.axis.ValueAxis) periodAxis68, rectangle2D69, (double) 100, (java.awt.Paint) color71, stroke77);
        boolean boolean81 = xYStepRenderer64.getItemShapeVisible(100, 0);
        java.awt.Shape shape82 = xYStepRenderer64.getLegendLine();
        xYStepRenderer64.setBaseShapesFilled(true);
        combinedDomainXYPlot33.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer64);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder86 = combinedDomainXYPlot33.getSeriesRenderingOrder();
        periodAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo89 = null;
        java.awt.geom.Point2D point2D90 = null;
        try {
            combinedDomainXYPlot33.zoomRangeAxes(30.0d, plotRenderingInfo89, point2D90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(locale58);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNotNull(seriesRenderingOrder86);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 97.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYBarRenderer1.getBaseToolTipGenerator();
        java.awt.Paint paint13 = xYBarRenderer1.getItemFillPaint((-16777216), (-14666742), true);
        java.awt.Paint paint15 = xYBarRenderer1.getSeriesPaint((int) (byte) -1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        combinedDomainXYPlot17.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke20 = combinedDomainXYPlot17.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator25 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer23.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator25);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator28 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer23.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator28, true);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent33 = null;
        combinedDomainXYPlot32.datasetChanged(datasetChangeEvent33);
        java.awt.Stroke stroke35 = combinedDomainXYPlot32.getRangeCrosshairStroke();
        boolean boolean36 = combinedDomainXYPlot32.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis38 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot32.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis38);
        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = valueMarker43.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        xYBarRenderer23.drawDomainMarker(graphics2D31, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot32, (org.jfree.chart.axis.ValueAxis) periodAxis41, (org.jfree.chart.plot.Marker) valueMarker43, rectangle2D47);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot49 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot49.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str56 = layer55.toString();
        combinedDomainXYPlot49.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker54, layer55);
        combinedDomainXYPlot17.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker43, layer55);
        try {
            xYBarRenderer1.addAnnotation(xYAnnotation16, layer55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator28);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Layer.FOREGROUND" + "'", str56.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        barRenderer3D15.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        java.awt.Font font18 = barRenderer3D15.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer3D15.setSeriesURLGenerator(0, categoryURLGenerator20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Color color50 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer52 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        xYBarRenderer52.notifyListeners(rendererChangeEvent53);
        java.awt.Stroke stroke56 = xYBarRenderer52.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer43.drawDomainLine(graphics2D44, xYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D48, (double) 100, (java.awt.Paint) color50, stroke56);
        barRenderer3D15.drawRangeLine(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, rectangle2D26, (double) (byte) -1, (java.awt.Paint) color35, stroke56);
        xYStepRenderer0.setBaseOutlineStroke(stroke56, true);
        xYStepRenderer0.clearSeriesPaints(false);
        xYStepRenderer0.setSeriesShapesFilled(12, false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        categoryPlot0.setCrosshairDatasetIndex(2958465, false);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        java.lang.String str2 = pieLabelDistributor1.toString();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator4 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator4);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer2.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator7, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = xYBarRenderer2.getBaseToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer12.notifyListeners(rendererChangeEvent13);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesStroke(0);
        java.awt.Paint paint17 = xYBarRenderer12.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer12.setPositiveItemLabelPositionFallback(itemLabelPosition18);
        xYBarRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition18);
        boolean boolean21 = rotation0.equals((java.lang.Object) xYBarRenderer2);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator7);
        org.junit.Assert.assertNull(xYToolTipGenerator10);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        java.util.List list4 = combinedDomainXYPlot0.getAnnotations();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            combinedDomainXYPlot0.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) '#');
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer2);
        java.awt.Paint paint4 = null;
        try {
            xYAreaRenderer1.setBaseOutlinePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer34 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        xYBarRenderer1.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer34);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator36 = xYBarRenderer1.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator36);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getCategories();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint4 = null;
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) 8.0d, paint4);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType7 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType7, (int) 'a');
        int int10 = dateTickUnit9.getRollMultiple();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType11 = dateTickUnit9.getUnitType();
        double double12 = dateTickUnit9.getSize();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) dateTickUnit9);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot0.getRangeAxisForDataset((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(list1);
        org.junit.Assert.assertNotNull(dateTickUnitType7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertNotNull(dateTickUnitType11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.058992E12d + "'", double12 == 3.058992E12d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        double double3 = barRenderer3D0.getYOffset();
        barRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D9.configure();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            barRenderer3D0.drawDomainMarker(graphics2D6, categoryPlot7, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9, categoryMarker11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        xYStepRenderer0.setBaseShapesFilled(true);
        java.lang.Boolean boolean22 = xYStepRenderer0.getSeriesVisible(100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYStepRenderer0.getSeriesURLGenerator((int) (byte) 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNull(xYURLGenerator24);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double[] doubleArray7 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray13 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray19 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray13, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "series", doubleArray20);
        try {
            org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset21, (java.lang.Comparable) 0.14d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYBarRenderer11.notifyListeners(rendererChangeEvent12);
        java.awt.Stroke stroke15 = xYBarRenderer11.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer2.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis6, rectangle2D7, (double) 100, (java.awt.Paint) color9, stroke15);
        boolean boolean19 = xYStepRenderer2.getItemShapeVisible(100, 0);
        java.awt.Shape shape20 = xYStepRenderer2.getLegendLine();
        periodAxis1.setDownArrow(shape20);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity22 = new org.jfree.chart.entity.LegendItemEntity(shape20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart24 = multiplePiePlot23.getPieChart();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart24);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity26 = new org.jfree.chart.entity.JFreeChartEntity(shape20, jFreeChart24);
        java.lang.String str27 = jFreeChartEntity26.toString();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(jFreeChart24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "JFreeChartEntity: tooltip = null" + "'", str27.equals("JFreeChartEntity: tooltip = null"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double[] doubleArray7 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray13 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray19 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[][] doubleArray20 = new double[][] { doubleArray7, doubleArray13, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "series", doubleArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset21, true);
        org.jfree.chart.axis.AxisState axisState25 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.data.time.TimeSeries timeSeries26 = null;
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection(timeSeries26, timeZone27);
        org.jfree.chart.axis.AxisCollection axisCollection29 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list30 = axisCollection29.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis3D32.getTickLabelInsets();
        org.jfree.data.Range range34 = numberAxis3D32.getDefaultAutoRange();
        org.jfree.data.Range range36 = timeSeriesCollection28.getRangeBounds(list30, range34, false);
        axisState25.setTicks(list30);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset21, list30, true);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        combinedDomainXYPlot3.datasetChanged(datasetChangeEvent4);
        java.awt.Stroke stroke6 = combinedDomainXYPlot3.getRangeCrosshairStroke();
        boolean boolean7 = combinedDomainXYPlot3.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis9);
        java.lang.String str11 = combinedDomainXYPlot3.getPlotType();
        org.jfree.chart.plot.CrosshairState crosshairState13 = new org.jfree.chart.plot.CrosshairState(true);
        double double14 = crosshairState13.getCrosshairDistance();
        crosshairState13.updateCrosshairX((double) 0L);
        crosshairState13.updateCrosshairX((double) 5);
        boolean boolean19 = combinedDomainXYPlot3.equals((java.lang.Object) crosshairState13);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D21.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator27 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer25.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator27);
        xYBarRenderer25.removeAnnotations();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = null;
        org.jfree.chart.axis.LogAxis logAxis33 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat34 = null;
        logAxis33.setNumberFormatOverride(numberFormat34);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.Color color39 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer41 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent42 = null;
        xYBarRenderer41.notifyListeners(rendererChangeEvent42);
        boolean boolean44 = xYBarRenderer41.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator48 = xYBarRenderer41.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer50 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent51 = null;
        xYBarRenderer50.notifyListeners(rendererChangeEvent51);
        java.awt.Stroke stroke54 = xYBarRenderer50.lookupSeriesStroke(0);
        xYBarRenderer41.setBaseStroke(stroke54, false);
        xYBarRenderer25.drawRangeLine(graphics2D30, xYPlot31, (org.jfree.chart.axis.ValueAxis) logAxis33, rectangle2D36, (-1.0d), (java.awt.Paint) color39, stroke54);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot58 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent59 = null;
        combinedDomainXYPlot58.datasetChanged(datasetChangeEvent59);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer62 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator64 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer62.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator64);
        xYBarRenderer62.removeAnnotations();
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = null;
        org.jfree.chart.axis.LogAxis logAxis70 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat71 = null;
        logAxis70.setNumberFormatOverride(numberFormat71);
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        java.awt.Color color76 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer78 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent79 = null;
        xYBarRenderer78.notifyListeners(rendererChangeEvent79);
        boolean boolean81 = xYBarRenderer78.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator85 = xYBarRenderer78.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer87 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent88 = null;
        xYBarRenderer87.notifyListeners(rendererChangeEvent88);
        java.awt.Stroke stroke91 = xYBarRenderer87.lookupSeriesStroke(0);
        xYBarRenderer78.setBaseStroke(stroke91, false);
        xYBarRenderer62.drawRangeLine(graphics2D67, xYPlot68, (org.jfree.chart.axis.ValueAxis) logAxis70, rectangle2D73, (-1.0d), (java.awt.Paint) color76, stroke91);
        org.jfree.data.Range range95 = combinedDomainXYPlot58.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis70);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray96 = new org.jfree.chart.axis.ValueAxis[] { numberAxis3D21, logAxis33, logAxis70 };
        combinedDomainXYPlot3.setRangeAxes(valueAxisArray96);
        categoryPlot0.setRangeAxes(valueAxisArray96);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Combined_Domain_XYPlot" + "'", str11.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(xYURLGenerator48);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNull(xYURLGenerator85);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNull(range95);
        org.junit.Assert.assertNotNull(valueAxisArray96);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        combinedDomainXYPlot1.datasetChanged(datasetChangeEvent2);
        java.awt.Stroke stroke4 = combinedDomainXYPlot1.getRangeCrosshairStroke();
        boolean boolean5 = combinedDomainXYPlot1.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot1.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis7);
        java.lang.String str9 = combinedDomainXYPlot1.getPlotType();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        barRenderer3D10.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        java.awt.Font font13 = barRenderer3D10.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer3D10.setSeriesURLGenerator(0, categoryURLGenerator15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer23 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.Color color30 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        xYBarRenderer32.notifyListeners(rendererChangeEvent33);
        java.awt.Stroke stroke36 = xYBarRenderer32.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer23.drawDomainLine(graphics2D24, xYPlot25, (org.jfree.chart.axis.ValueAxis) periodAxis27, rectangle2D28, (double) 100, (java.awt.Paint) color30, stroke36);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer38 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis42 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.awt.Color color45 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer47 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent48 = null;
        xYBarRenderer47.notifyListeners(rendererChangeEvent48);
        java.awt.Stroke stroke51 = xYBarRenderer47.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer38.drawDomainLine(graphics2D39, xYPlot40, (org.jfree.chart.axis.ValueAxis) periodAxis42, rectangle2D43, (double) 100, (java.awt.Paint) color45, stroke51);
        barRenderer3D10.drawRangeLine(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, rectangle2D21, (double) (byte) -1, (java.awt.Paint) color30, stroke51);
        java.awt.Paint paint54 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        barRenderer3D10.setShadowPaint(paint54);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer57 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator59 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer57.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator59);
        xYBarRenderer57.removeAnnotations();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = null;
        org.jfree.chart.axis.LogAxis logAxis65 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat66 = null;
        logAxis65.setNumberFormatOverride(numberFormat66);
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        java.awt.Color color71 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer73 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent74 = null;
        xYBarRenderer73.notifyListeners(rendererChangeEvent74);
        boolean boolean76 = xYBarRenderer73.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator80 = xYBarRenderer73.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer82 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent83 = null;
        xYBarRenderer82.notifyListeners(rendererChangeEvent83);
        java.awt.Stroke stroke86 = xYBarRenderer82.lookupSeriesStroke(0);
        xYBarRenderer73.setBaseStroke(stroke86, false);
        xYBarRenderer57.drawRangeLine(graphics2D62, xYPlot63, (org.jfree.chart.axis.ValueAxis) logAxis65, rectangle2D68, (-1.0d), (java.awt.Paint) color71, stroke86);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent90 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) logAxis65);
        boolean boolean91 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint54, (java.lang.Object) axisChangeEvent90);
        combinedDomainXYPlot1.axisChanged(axisChangeEvent90);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Combined_Domain_XYPlot" + "'", str9.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNull(xYURLGenerator80);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        try {
            java.lang.Number number8 = timeSeriesCollection2.getStartX((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Color color8 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYBarRenderer10.notifyListeners(rendererChangeEvent11);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer1.drawDomainLine(graphics2D2, xYPlot3, (org.jfree.chart.axis.ValueAxis) periodAxis5, rectangle2D6, (double) 100, (java.awt.Paint) color8, stroke14);
        java.util.Locale locale16 = periodAxis5.getLocale();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale16);
        try {
            java.util.ResourceBundle resourceBundle19 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("Layer.FOREGROUND", locale16);
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Layer.FOREGROUND, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNotNull(tickUnitSource18);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        java.awt.Shape shape8 = pieSectionEntity7.getArea();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        java.lang.String str10 = pieSectionEntity7.getShapeCoords();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        pieSectionEntity7.setArea(shape11);
        java.lang.Comparable comparable13 = pieSectionEntity7.getSectionKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-4,-4,4,4" + "'", str10.equals("-4,-4,4,4"));
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0L + "'", comparable13.equals(0L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean5 = dateRange3.intersects((org.jfree.data.Range) dateRange4);
        boolean boolean6 = dateRange2.intersects((org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange3, (double) (byte) 1, 0.4d);
        double double10 = dateRange3.getCentralValue();
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        boolean boolean14 = combinedDomainXYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis16);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker21.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker21.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYBarRenderer1.drawDomainMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis19, (org.jfree.chart.plot.Marker) valueMarker21, rectangle2D25);
        double double27 = xYBarRenderer1.getBarAlignmentFactor();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy(regularTimePeriod7, regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3, timeZone4);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        java.awt.Paint paint38 = piePlot3D1.getBaseSectionOutlinePaint();
        piePlot3D1.setSectionOutlinesVisible(true);
        double double41 = piePlot3D1.getLabelGap();
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.025d + "'", double41 == 0.025d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Stroke stroke2 = piePlot3D1.getLabelOutlineStroke();
        piePlot3D1.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        java.awt.Shape shape8 = pieSectionEntity7.getArea();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = pieSectionEntity7.equals((java.lang.Object) color10);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        int int4 = barRenderer3D0.getPassCount();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape5, pieDataset6, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        java.awt.Shape shape13 = pieSectionEntity12.getArea();
        boolean boolean14 = barRenderer3D0.equals((java.lang.Object) shape13);
        java.awt.Stroke stroke16 = barRenderer3D0.lookupSeriesOutlineStroke((int) (short) -1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        xYBarRenderer18.notifyListeners(rendererChangeEvent19);
        java.awt.Stroke stroke22 = xYBarRenderer18.lookupSeriesStroke(0);
        java.awt.Paint paint23 = xYBarRenderer18.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer18.setPositiveItemLabelPositionFallback(itemLabelPosition24);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator27 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer18.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator27);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator29 = xYBarRenderer18.getBaseItemLabelGenerator();
        xYBarRenderer18.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYBarRenderer18.getBasePositiveItemLabelPosition();
        double double34 = itemLabelPosition33.getAngle();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition33);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(xYItemLabelGenerator29);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator35 = xYBarRenderer1.getSeriesItemLabelGenerator(97);
        xYBarRenderer1.setAutoPopulateSeriesOutlinePaint(false);
        xYBarRenderer1.setDefaultEntityRadius((int) (byte) 100);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(xYItemLabelGenerator35);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        barRenderer3D0.setIncludeBaseInRange(false);
        barRenderer3D0.setBaseSeriesVisibleInLegend(true);
        java.awt.Shape shape49 = barRenderer3D0.lookupSeriesShape(10);
        barRenderer3D0.setBaseSeriesVisible(true);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(shape49);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        boolean boolean14 = combinedDomainXYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis16);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker21.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker21.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYBarRenderer1.drawDomainMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis19, (org.jfree.chart.plot.Marker) valueMarker21, rectangle2D25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = null;
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeSeries29, timeZone30);
        org.jfree.chart.axis.AxisCollection axisCollection32 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list33 = axisCollection32.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = numberAxis3D35.getTickLabelInsets();
        org.jfree.data.Range range37 = numberAxis3D35.getDefaultAutoRange();
        org.jfree.data.Range range39 = timeSeriesCollection31.getRangeBounds(list33, range37, false);
        combinedDomainXYPlot10.drawDomainTickBands(graphics2D27, rectangle2D28, list33);
        java.awt.Stroke stroke41 = combinedDomainXYPlot10.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemLineVisible((int) ' ', (int) (byte) -1);
        xYStepRenderer0.setSeriesShapesFilled(10, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        double double5 = timeSeriesCollection2.getDomainLowerBound(true);
        org.jfree.data.Range range7 = timeSeriesCollection2.getDomainBounds(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        java.util.Locale locale15 = periodAxis4.getLocale();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale15);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale15);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(locale15);
        org.junit.Assert.assertNotNull(tickUnitSource17);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYBarRenderer4.notifyListeners(rendererChangeEvent5);
        java.awt.Stroke stroke8 = xYBarRenderer4.lookupSeriesStroke(0);
        combinedDomainXYPlot0.setDomainMinorGridlineStroke(stroke8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = combinedDomainXYPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint11 = combinedDomainXYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font5);
        float float7 = textFragment6.getBaselineOffset();
        java.lang.String str8 = textFragment6.getText();
        java.awt.Paint paint9 = textFragment6.getPaint();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        boolean boolean2 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.sort();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator22 = xYStepRenderer0.getToolTipGenerator((int) (short) -1, 255, true);
        java.awt.Stroke stroke23 = xYStepRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(xYToolTipGenerator22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat2 = null;
        logAxis1.setNumberFormatOverride(numberFormat2);
        logAxis1.configure();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) logAxis1);
        logAxis1.zoomRange((double) 60000L, (double) 0.5f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        double double3 = barRenderer3D0.getYOffset();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer3D0.getSeriesItemLabelGenerator((int) '4');
        java.awt.Paint paint6 = barRenderer3D0.getBaseOutlinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        periodAxis4.setVerticalTickLabels(true);
        double double17 = periodAxis4.getFixedDimension();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource6 = null;
        chartRenderingInfo5.setRenderingSource(renderingSource6);
        org.jfree.chart.RenderingSource renderingSource8 = chartRenderingInfo5.getRenderingSource();
        try {
            java.awt.image.BufferedImage bufferedImage9 = jFreeChart1.createBufferedImage(14, (int) (short) 0, chartRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (14) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNull(renderingSource8);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource1 = null;
        chartRenderingInfo0.setRenderingSource(renderingSource1);
        chartRenderingInfo0.clear();
        org.jfree.chart.RenderingSource renderingSource4 = null;
        chartRenderingInfo0.setRenderingSource(renderingSource4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        double double2 = crosshairState1.getCrosshairDistance();
        crosshairState1.setCrosshairY((double) 1.0f);
        crosshairState1.setCrosshairY((double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        double double5 = timeSeriesCollection2.getDomainUpperBound(false);
        try {
            double double8 = timeSeriesCollection2.getStartXValue(3, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYBarRenderer2.setBaseOutlinePaint((java.awt.Paint) color3);
        java.awt.color.ColorSpace colorSpace5 = color3.getColorSpace();
        boolean boolean6 = categoryAxis3D0.equals((java.lang.Object) colorSpace5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        combinedDomainXYPlot11.datasetChanged(datasetChangeEvent12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = combinedDomainXYPlot11.getRangeAxisEdge(0);
        boolean boolean16 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge15);
        java.lang.String str17 = rectangleEdge15.toString();
        try {
            double double18 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor7, 255, 15, rectangle2D10, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleEdge.LEFT" + "'", str17.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth((double) 1L);
        org.jfree.data.Range range3 = rectangleConstraint0.getWidthRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        java.awt.Paint paint4 = combinedDomainXYPlot0.getQuadrantPaint((int) (byte) 1);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot5.setDomainCrosshairVisible(true);
        combinedDomainXYPlot5.clearDomainMarkers(3);
        java.awt.Stroke stroke10 = combinedDomainXYPlot5.getOutlineStroke();
        combinedDomainXYPlot0.setRangeCrosshairStroke(stroke10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = combinedDomainXYPlot0.getDomainAxis();
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(valueAxis12);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        timeSeriesCollection2.validateObject();
        org.jfree.data.Range range8 = timeSeriesCollection2.getDomainBounds(true);
        timeSeriesCollection2.validateObject();
        java.lang.String[] strArray12 = new java.lang.String[] { "Layer.FOREGROUND" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("Layer.FOREGROUND", strArray12);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        barRenderer3D14.setPositiveItemLabelPositionFallback(itemLabelPosition15);
        java.awt.Font font17 = barRenderer3D14.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer3D14.setSeriesURLGenerator(0, categoryURLGenerator19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer27 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.Color color34 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        xYBarRenderer36.notifyListeners(rendererChangeEvent37);
        java.awt.Stroke stroke40 = xYBarRenderer36.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer27.drawDomainLine(graphics2D28, xYPlot29, (org.jfree.chart.axis.ValueAxis) periodAxis31, rectangle2D32, (double) 100, (java.awt.Paint) color34, stroke40);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer42 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis46 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.Color color49 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer51 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = null;
        xYBarRenderer51.notifyListeners(rendererChangeEvent52);
        java.awt.Stroke stroke55 = xYBarRenderer51.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer42.drawDomainLine(graphics2D43, xYPlot44, (org.jfree.chart.axis.ValueAxis) periodAxis46, rectangle2D47, (double) 100, (java.awt.Paint) color49, stroke55);
        barRenderer3D14.drawRangeLine(graphics2D21, categoryPlot22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, rectangle2D25, (double) (byte) -1, (java.awt.Paint) color34, stroke55);
        symbolAxis13.setGridBandAlternatePaint((java.awt.Paint) color34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D60.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer64 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator66 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer64.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator66);
        java.awt.Stroke stroke68 = xYBarRenderer64.getBaseOutlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) symbolAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer64);
        org.jfree.data.Range range71 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(range71);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator9 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat8);
        try {
            java.util.Currency currency10 = logFormat4.getCurrency();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        java.awt.Paint paint4 = combinedDomainXYPlot0.getQuadrantPaint((int) (byte) 1);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries7, timeZone8);
        org.jfree.chart.axis.AxisCollection axisCollection10 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list11 = axisCollection10.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis3D13.getTickLabelInsets();
        org.jfree.data.Range range15 = numberAxis3D13.getDefaultAutoRange();
        org.jfree.data.Range range17 = timeSeriesCollection9.getRangeBounds(list11, range15, false);
        combinedDomainXYPlot0.drawRangeTickBands(graphics2D5, rectangle2D6, list11);
        java.util.Collection collection19 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list11);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) (-1.0f), 0.0f, (float) (short) -1);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 255, (float) 9999, 2.0f);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        int int3 = categoryPlot0.getIndexOf(categoryItemRenderer2);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) 9999, (double) '#', plotRenderingInfo9, point2D10);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxisForDataset((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart1, (int) (short) 100, 0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot5.getPieChart();
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        chartProgressEvent4.setChart(jFreeChart6);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart6.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart6);
        org.junit.Assert.assertNotNull(textTitle7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator4, false);
        barRenderer3D0.setDrawBarOutline(false);
        double double9 = barRenderer3D0.getYOffset();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat10);
        java.lang.String str13 = logFormat6.format((double) 100);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat6);
        java.lang.Object obj15 = null;
        boolean boolean16 = logFormat6.equals(obj15);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!^�" + "'", str13.equals("hi!^�"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, 3.0d, (double) 100.0f, (-14666742), (java.lang.Comparable) "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.general.DatasetGroup datasetGroup12 = xYSeriesCollection11.getGroup();
        try {
            double double15 = xYSeriesCollection11.getEndYValue((int) '#', 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertNotNull(datasetGroup12);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.configure();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot6.setDomainCrosshairVisible(true);
        combinedDomainXYPlot6.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator14 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer12.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator14);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator17 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer12.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator17, true);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        combinedDomainXYPlot21.datasetChanged(datasetChangeEvent22);
        java.awt.Stroke stroke24 = combinedDomainXYPlot21.getRangeCrosshairStroke();
        boolean boolean25 = combinedDomainXYPlot21.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot21.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis27);
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker32.setLabelAnchor(rectangleAnchor33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = valueMarker32.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        xYBarRenderer12.drawDomainMarker(graphics2D20, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot21, (org.jfree.chart.axis.ValueAxis) periodAxis30, (org.jfree.chart.plot.Marker) valueMarker32, rectangle2D36);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker32, layer38);
        java.awt.Stroke stroke40 = combinedDomainXYPlot6.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = combinedDomainXYPlot6.getRangeAxisEdge(15);
        boolean boolean43 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge42);
        org.jfree.chart.axis.AxisState axisState45 = new org.jfree.chart.axis.AxisState((double) 0);
        double double46 = axisState45.getCursor();
        categoryAxis3D1.drawTickMarks(graphics2D3, (double) 0L, rectangle2D5, rectangleEdge42, axisState45);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator17);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart1);
        boolean boolean3 = jFreeChart1.isNotify();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker5.setLabelAnchor(rectangleAnchor6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = valueMarker5.getLabelOffset();
        double double10 = rectangleInsets8.calculateRightOutset((double) 2);
        jFreeChart1.setPadding(rectangleInsets8);
        double double12 = rectangleInsets8.getLeft();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator22 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer20.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator22);
        xYBarRenderer20.removeAnnotations();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = null;
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat29 = null;
        logAxis28.setNumberFormatOverride(numberFormat29);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.Color color34 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        xYBarRenderer36.notifyListeners(rendererChangeEvent37);
        boolean boolean39 = xYBarRenderer36.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator43 = xYBarRenderer36.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer45 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent46 = null;
        xYBarRenderer45.notifyListeners(rendererChangeEvent46);
        java.awt.Stroke stroke49 = xYBarRenderer45.lookupSeriesStroke(0);
        xYBarRenderer36.setBaseStroke(stroke49, false);
        xYBarRenderer20.drawRangeLine(graphics2D25, xYPlot26, (org.jfree.chart.axis.ValueAxis) logAxis28, rectangle2D31, (-1.0d), (java.awt.Paint) color34, stroke49);
        logAxis28.setVisible(false);
        logAxis28.centerRange((double) ' ');
        org.jfree.chart.entity.AxisEntity axisEntity59 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) logAxis28, "", "Layer.FOREGROUND");
        org.jfree.data.xy.XYSeries xYSeries63 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem66 = xYSeries63.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries63.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection71 = new org.jfree.data.xy.XYSeriesCollection(xYSeries63);
        xYSeries63.add((java.lang.Number) 255, (java.lang.Number) 0.2d);
        boolean boolean75 = axisEntity59.equals((java.lang.Object) 0.2d);
        java.lang.Object obj76 = axisEntity59.clone();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(xYURLGenerator43);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(xYDataItem66);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(obj76);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator2 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator4 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!^�");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator2, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator4);
        int int6 = objectList1.indexOf((java.lang.Object) standardXYToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries3.getTimePeriod(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        boolean boolean2 = jFreeChart1.isNotify();
        org.jfree.chart.plot.Plot plot3 = jFreeChart1.getPlot();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(plot3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        boolean boolean14 = combinedDomainXYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis16);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker21.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker21.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYBarRenderer1.drawDomainMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis19, (org.jfree.chart.plot.Marker) valueMarker21, rectangle2D25);
        double double27 = valueMarker21.getValue();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = org.jfree.chart.block.RectangleConstraint.NONE;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) itemLabelAnchor0, (java.lang.Object) rectangleConstraint1);
        java.lang.String str3 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ItemLabelAnchor.CENTER" + "'", str3.equals("ItemLabelAnchor.CENTER"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        java.awt.Paint paint44 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        barRenderer3D0.setShadowPaint(paint44);
        barRenderer3D0.setShadowXOffset(8.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        numberAxis3D2.setLabelPaint(paint3);
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("series", font1, paint3);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        java.awt.Shape shape8 = pieSectionEntity7.getArea();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        pieSectionEntity7.setURLText("[100.0, 24234.0]");
        java.lang.String str12 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PieSection: 52, 10(0)" + "'", str12.equals("PieSection: 52, 10(0)"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator9 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat8);
        java.lang.String str11 = logFormat4.format((double) 100);
        java.lang.String str13 = logFormat4.format((double) 255);
        logFormat4.setMinimumIntegerDigits((int) (byte) -1);
        logFormat4.setGroupingUsed(true);
        int int18 = logFormat4.getMinimumIntegerDigits();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!^�" + "'", str11.equals("hi!^�"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!^�" + "'", str13.equals("hi!^�"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        long long4 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(100.0d, 0.4d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str7 = layer6.toString();
        combinedDomainXYPlot0.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker5, layer6);
        combinedDomainXYPlot0.clearRangeMarkers((int) ' ');
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Layer.FOREGROUND" + "'", str7.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat9 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat9);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat19 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator20 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat15, (java.text.NumberFormat) logFormat19);
        java.lang.String str22 = logFormat15.format((double) 100);
        java.lang.String str24 = logFormat15.format((double) 255);
        java.text.NumberFormat numberFormat25 = logFormat15.getExponentFormat();
        boolean boolean26 = logFormat15.isGroupingUsed();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator27 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat9, (java.text.NumberFormat) logFormat15);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!^�" + "'", str22.equals("hi!^�"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!^�" + "'", str24.equals("hi!^�"));
        org.junit.Assert.assertNotNull(numberFormat25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) '#', categoryItemLabelGenerator8);
        barRenderer3D0.setShadowVisible(false);
        java.awt.Paint paint12 = null;
        try {
            barRenderer3D0.setShadowPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis3D1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        java.awt.Paint paint44 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        barRenderer3D0.setShadowPaint(paint44);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer47 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator49 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer47.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator49);
        xYBarRenderer47.removeAnnotations();
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = null;
        org.jfree.chart.axis.LogAxis logAxis55 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat56 = null;
        logAxis55.setNumberFormatOverride(numberFormat56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.Color color61 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer63 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent64 = null;
        xYBarRenderer63.notifyListeners(rendererChangeEvent64);
        boolean boolean66 = xYBarRenderer63.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator70 = xYBarRenderer63.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer72 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent73 = null;
        xYBarRenderer72.notifyListeners(rendererChangeEvent73);
        java.awt.Stroke stroke76 = xYBarRenderer72.lookupSeriesStroke(0);
        xYBarRenderer63.setBaseStroke(stroke76, false);
        xYBarRenderer47.drawRangeLine(graphics2D52, xYPlot53, (org.jfree.chart.axis.ValueAxis) logAxis55, rectangle2D58, (-1.0d), (java.awt.Paint) color61, stroke76);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent80 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) logAxis55);
        boolean boolean81 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint44, (java.lang.Object) axisChangeEvent80);
        java.lang.String str82 = axisChangeEvent80.toString();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNull(xYURLGenerator70);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) 0L, (double) (byte) -1);
        org.jfree.chart.block.Block block6 = null;
        columnArrangement5.add(block6, (java.lang.Object) 100);
        org.jfree.data.general.Dataset dataset9 = null;
        java.lang.Comparable comparable10 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5, dataset9, comparable10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = org.jfree.chart.block.RectangleConstraint.NONE;
        try {
            org.jfree.chart.util.Size2D size2D14 = centerArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer11, graphics2D12, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint13);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat10);
        java.lang.String str13 = logFormat6.format((double) 100);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat6);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        xYBarRenderer16.notifyListeners(rendererChangeEvent17);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesStroke(0);
        java.awt.Paint paint21 = xYBarRenderer16.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYBarRenderer23.notifyListeners(rendererChangeEvent24);
        java.awt.Stroke stroke27 = xYBarRenderer23.lookupSeriesStroke(0);
        java.awt.Paint paint28 = xYBarRenderer23.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        combinedDomainXYPlot30.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYBarRenderer34.notifyListeners(rendererChangeEvent35);
        java.awt.Stroke stroke38 = xYBarRenderer34.lookupSeriesStroke(0);
        combinedDomainXYPlot30.setDomainMinorGridlineStroke(stroke38);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer40 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.Color color47 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        xYBarRenderer49.notifyListeners(rendererChangeEvent50);
        java.awt.Stroke stroke53 = xYBarRenderer49.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer40.drawDomainLine(graphics2D41, xYPlot42, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D45, (double) 100, (java.awt.Paint) color47, stroke53);
        java.util.Locale locale55 = periodAxis44.getLocale();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        java.awt.Paint paint58 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer23.drawDomainLine(graphics2D29, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D56, (double) (short) 10, paint58, stroke59);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer61 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis65 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.Color color68 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer70 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent71 = null;
        xYBarRenderer70.notifyListeners(rendererChangeEvent71);
        java.awt.Stroke stroke74 = xYBarRenderer70.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer61.drawDomainLine(graphics2D62, xYPlot63, (org.jfree.chart.axis.ValueAxis) periodAxis65, rectangle2D66, (double) 100, (java.awt.Paint) color68, stroke74);
        boolean boolean78 = xYStepRenderer61.getItemShapeVisible(100, 0);
        java.awt.Shape shape79 = xYStepRenderer61.getLegendLine();
        xYStepRenderer61.setBaseShapesFilled(true);
        combinedDomainXYPlot30.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer61);
        xYBarRenderer16.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot30);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot30);
        org.jfree.chart.axis.AxisLocation axisLocation85 = null;
        try {
            combinedDomainXYPlot30.setRangeAxisLocation(axisLocation85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!^�" + "'", str13.equals("hi!^�"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(locale55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(shape79);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        try {
            xYSeriesCollection11.setSelected((int) (byte) 0, (int) (short) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYDataItem6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day7);
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        long long11 = timeSeries9.getMaximumItemAge();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        int int3 = categoryPlot0.getIndexOf(categoryItemRenderer2);
        categoryPlot0.configureRangeAxes();
        java.awt.Stroke stroke5 = categoryPlot0.getRangeZeroBaselineStroke();
        java.lang.Comparable comparable6 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean7 = categoryPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(comparable6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("VerticalAlignment.CENTER", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textLine2.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedDomainXYPlot0.setFixedRangeAxisSpace(axisSpace3, true);
        combinedDomainXYPlot0.setGap((double) 10.0f);
        java.awt.Paint paint8 = combinedDomainXYPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries10, timeZone11);
        int int13 = timeSeriesCollection12.getSeriesCount();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection12, false);
        timeSeriesCollection12.validateObject();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = null;
        timeSeriesCollection12.seriesChanged(seriesChangeEvent17);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate19 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        timeSeries3.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection12);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        combinedDomainXYPlot10.setWeight(15);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        boolean boolean35 = xYStepRenderer18.getItemShapeVisible(100, 0);
        java.awt.Shape shape36 = xYStepRenderer18.getLegendLine();
        periodAxis17.setDownArrow(shape36);
        periodAxis17.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot40.setDomainCrosshairVisible(true);
        combinedDomainXYPlot40.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer46 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator48 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer46.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator48);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator51 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer46.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator51, true);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        combinedDomainXYPlot55.datasetChanged(datasetChangeEvent56);
        java.awt.Stroke stroke58 = combinedDomainXYPlot55.getRangeCrosshairStroke();
        boolean boolean59 = combinedDomainXYPlot55.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis61 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot55.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis61);
        org.jfree.chart.axis.PeriodAxis periodAxis64 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker66.setLabelAnchor(rectangleAnchor67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = valueMarker66.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        xYBarRenderer46.drawDomainMarker(graphics2D54, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot55, (org.jfree.chart.axis.ValueAxis) periodAxis64, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D70);
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot40.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker66, layer72);
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        xYBarRenderer1.drawRangeMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D74);
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot10.setRangeAxisLocation(axisLocation76);
        org.jfree.chart.plot.PlotOrientation plotOrientation78 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge79 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation76, plotOrientation78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator51);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertNotNull(axisLocation76);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        boolean boolean14 = combinedDomainXYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis16);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker21.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker21.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYBarRenderer1.drawDomainMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis19, (org.jfree.chart.plot.Marker) valueMarker21, rectangle2D25);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYBarRenderer1.getNegativeItemLabelPosition(14, (int) (byte) -1, false);
        java.awt.Font font31 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        xYBarRenderer1.setBaseItemLabelFont(font31);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) (short) 1, "hi!", true);
        logFormat3.setMaximumFractionDigits(0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        java.util.List list2 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        boolean boolean3 = day1.equals((java.lang.Object) itemLabelAnchor2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day1.next();
        boolean boolean5 = strokeMap0.containsKey((java.lang.Comparable) day1);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        boolean boolean2 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) day3);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        org.jfree.data.Range range37 = combinedDomainXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis12);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        xYBarRenderer39.notifyListeners(rendererChangeEvent40);
        java.awt.Stroke stroke43 = xYBarRenderer39.lookupSeriesStroke(0);
        java.awt.Paint paint44 = xYBarRenderer39.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = null;
        combinedDomainXYPlot46.datasetChanged(datasetChangeEvent47);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer50 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent51 = null;
        xYBarRenderer50.notifyListeners(rendererChangeEvent51);
        java.awt.Stroke stroke54 = xYBarRenderer50.lookupSeriesStroke(0);
        combinedDomainXYPlot46.setDomainMinorGridlineStroke(stroke54);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer56 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis60 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        java.awt.Color color63 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer65 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent66 = null;
        xYBarRenderer65.notifyListeners(rendererChangeEvent66);
        java.awt.Stroke stroke69 = xYBarRenderer65.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer56.drawDomainLine(graphics2D57, xYPlot58, (org.jfree.chart.axis.ValueAxis) periodAxis60, rectangle2D61, (double) 100, (java.awt.Paint) color63, stroke69);
        java.util.Locale locale71 = periodAxis60.getLocale();
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        java.awt.Paint paint74 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke75 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer39.drawDomainLine(graphics2D45, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot46, (org.jfree.chart.axis.ValueAxis) periodAxis60, rectangle2D72, (double) (short) 10, paint74, stroke75);
        combinedDomainXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot46, (int) (short) 10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot79 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart80 = multiplePiePlot79.getPieChart();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent81 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart80);
        boolean boolean82 = jFreeChart80.isNotify();
        org.jfree.chart.plot.ValueMarker valueMarker84 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker84.setLabelAnchor(rectangleAnchor85);
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = valueMarker84.getLabelOffset();
        double double89 = rectangleInsets87.calculateRightOutset((double) 2);
        jFreeChart80.setPadding(rectangleInsets87);
        combinedDomainXYPlot46.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart80);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(locale71);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(jFreeChart80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 3.0d + "'", double89 == 3.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace2);
        categoryPlot0.clearDomainMarkers();
        double double5 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNull(list1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        numberAxis3D1.setTickLabelInsets(rectangleInsets2);
        double double5 = rectangleInsets2.calculateRightOutset((double) 2019);
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets2.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, (-7.0d), 10.0d, (double) '4', (double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertNotNull(unitType6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Layer.FOREGROUND", font5);
        java.lang.Object obj7 = labelBlock6.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot8.getPieChart();
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        labelBlock6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = labelBlock6.getContentAlignmentPoint();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(2958465);
        java.lang.String str17 = serialDate16.getDescription();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
        boolean boolean19 = labelBlock6.equals((java.lang.Object) day18);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        barRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        barRenderer3D2.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition6);
        categoryPlot0.setRenderer(12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D2);
        categoryPlot0.mapDatasetToDomainAxis(0, (int) (byte) -1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.0d) + "'", double2 == (-5.0d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        xYStepRenderer0.setBaseSeriesVisibleInLegend(false);
        xYStepRenderer0.setBaseShapesFilled(true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator27 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer25.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator27);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator30 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer25.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator30, true);
        java.lang.Object obj33 = standardXYToolTipGenerator30.clone();
        xYStepRenderer0.setSeriesToolTipGenerator((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator30, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator30);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        piePlot3D1.setMinimumArcAngleToDraw((double) (-16777216));
        piePlot3D1.setDepthFactor((double) 9999);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator42 = piePlot3D1.getLegendLabelToolTipGenerator();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot43 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart44 = multiplePiePlot43.getPieChart();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart44);
        boolean boolean46 = jFreeChart44.isNotify();
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker48.setLabelAnchor(rectangleAnchor49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = valueMarker48.getLabelOffset();
        double double53 = rectangleInsets51.calculateRightOutset((double) 2);
        jFreeChart44.setPadding(rectangleInsets51);
        piePlot3D1.setSimpleLabelOffset(rectangleInsets51);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(pieSectionLabelGenerator42);
        org.junit.Assert.assertNotNull(jFreeChart44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 3.0d + "'", double53 == 3.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedDomainXYPlot0.getRangeAxis();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            combinedDomainXYPlot0.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.String[] strArray2 = new java.lang.String[] { "Layer.FOREGROUND" };
        org.jfree.chart.axis.SymbolAxis symbolAxis3 = new org.jfree.chart.axis.SymbolAxis("Layer.FOREGROUND", strArray2);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3D4.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        java.awt.Font font7 = barRenderer3D4.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer3D4.setSeriesURLGenerator(0, categoryURLGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.Color color24 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer17.drawDomainLine(graphics2D18, xYPlot19, (org.jfree.chart.axis.ValueAxis) periodAxis21, rectangle2D22, (double) 100, (java.awt.Paint) color24, stroke30);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer32 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.Color color39 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer41 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent42 = null;
        xYBarRenderer41.notifyListeners(rendererChangeEvent42);
        java.awt.Stroke stroke45 = xYBarRenderer41.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer32.drawDomainLine(graphics2D33, xYPlot34, (org.jfree.chart.axis.ValueAxis) periodAxis36, rectangle2D37, (double) 100, (java.awt.Paint) color39, stroke45);
        barRenderer3D4.drawRangeLine(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, rectangle2D15, (double) (byte) -1, (java.awt.Paint) color24, stroke45);
        symbolAxis3.setGridBandAlternatePaint((java.awt.Paint) color24);
        double double49 = symbolAxis3.getAutoRangeMinimumSize();
        boolean boolean50 = symbolAxis3.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0E-8d + "'", double49 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        int int1 = defaultXYDataset0.getSeriesCount();
        int int2 = defaultXYDataset0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (byte) -1, (double) 14);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((double) (byte) 100, (double) 24234L);
        boolean boolean6 = size2D2.equals((java.lang.Object) 24234L);
        double double7 = size2D2.width;
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day7);
        timeSeries9.removeAgedItems((long) 96, true);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        numberAxis3D1.setMinorTickMarkOutsideLength((float) '#');
        boolean boolean5 = numberAxis3D1.isTickLabelsVisible();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        int int3 = categoryPlot0.getIndexOf(categoryItemRenderer2);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        java.awt.Stroke stroke7 = null;
        try {
            categoryPlot0.setRangeMinorGridlineStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        segmentedTimeline0.setStartTime((long) 'a');
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType6, (int) 'a');
        int int9 = dateTickUnit8.getMultiple();
        java.util.Date date10 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline0.getSegment(date10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType13 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType13, (int) 'a');
        int int16 = dateTickUnit15.getMultiple();
        java.util.Date date17 = dateAxis12.calculateHighestVisibleTickValue(dateTickUnit15);
        long long18 = segmentedTimeline0.getTime(date17);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertNotNull(dateTickUnitType13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-946742400000L) + "'", long18 == (-946742400000L));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer3D0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer3D0.getToolTipGenerator((int) (short) 10, 8, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3D0.getPositiveItemLabelPosition((int) (byte) -1, 12, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = itemLabelPosition13.getItemLabelAnchor();
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) '#');
        java.lang.Object obj2 = xYAreaRenderer1.clone();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator4 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        boolean boolean5 = xYAreaRenderer1.equals((java.lang.Object) standardXYSeriesLabelGenerator4);
        boolean boolean6 = xYAreaRenderer1.getPlotArea();
        xYAreaRenderer1.setOutline(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        barRenderer3D15.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        java.awt.Font font18 = barRenderer3D15.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer3D15.setSeriesURLGenerator(0, categoryURLGenerator20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Color color50 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer52 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        xYBarRenderer52.notifyListeners(rendererChangeEvent53);
        java.awt.Stroke stroke56 = xYBarRenderer52.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer43.drawDomainLine(graphics2D44, xYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D48, (double) 100, (java.awt.Paint) color50, stroke56);
        barRenderer3D15.drawRangeLine(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, rectangle2D26, (double) (byte) -1, (java.awt.Paint) color35, stroke56);
        xYStepRenderer0.setBaseOutlineStroke(stroke56, true);
        xYStepRenderer0.clearSeriesPaints(false);
        xYStepRenderer0.setDrawOutlines(false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator66 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator(97, xYItemLabelGenerator66);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str7 = layer6.toString();
        combinedDomainXYPlot0.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker5, layer6);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        combinedDomainXYPlot0.setOutlineStroke(stroke9);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.Color color18 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        java.awt.Stroke stroke24 = xYBarRenderer20.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer11.drawDomainLine(graphics2D12, xYPlot13, (org.jfree.chart.axis.ValueAxis) periodAxis15, rectangle2D16, (double) 100, (java.awt.Paint) color18, stroke24);
        java.util.Locale locale26 = periodAxis15.getLocale();
        periodAxis15.setMinorTickMarksVisible(true);
        boolean boolean29 = combinedDomainXYPlot0.equals((java.lang.Object) periodAxis15);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.axis.AxisSpace axisSpace32 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = null;
        combinedDomainXYPlot34.datasetChanged(datasetChangeEvent35);
        java.awt.Stroke stroke37 = combinedDomainXYPlot34.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator42 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer40.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator42);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator45 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer40.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator45, true);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot49 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = null;
        combinedDomainXYPlot49.datasetChanged(datasetChangeEvent50);
        java.awt.Stroke stroke52 = combinedDomainXYPlot49.getRangeCrosshairStroke();
        boolean boolean53 = combinedDomainXYPlot49.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis55 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot49.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis55);
        org.jfree.chart.axis.PeriodAxis periodAxis58 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker60.setLabelAnchor(rectangleAnchor61);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = valueMarker60.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        xYBarRenderer40.drawDomainMarker(graphics2D48, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot49, (org.jfree.chart.axis.ValueAxis) periodAxis58, (org.jfree.chart.plot.Marker) valueMarker60, rectangle2D64);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot66 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot66.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker71 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str73 = layer72.toString();
        combinedDomainXYPlot66.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker71, layer72);
        combinedDomainXYPlot34.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker60, layer72);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = combinedDomainXYPlot34.getRangeAxisEdge(12);
        axisSpace32.add((double) 5, rectangleEdge77);
        try {
            double double79 = periodAxis15.lengthToJava2D((double) 24234L, rectangle2D31, rectangleEdge77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Layer.FOREGROUND" + "'", str7.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator45);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Layer.FOREGROUND" + "'", str73.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(rectangleEdge77);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        java.awt.Paint paint38 = piePlot3D1.getBaseSectionOutlinePaint();
        double double39 = piePlot3D1.getStartAngle();
        piePlot3D1.setDarkerSides(true);
        double double43 = piePlot3D1.getExplodePercent((java.lang.Comparable) "series");
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke4 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean5 = combinedDomainXYPlot0.isRangeZeroBaselineVisible();
        combinedDomainXYPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.Plot plot8 = combinedDomainXYPlot0.getRootPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedDomainXYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator1);
        java.awt.Stroke stroke6 = barRenderer3D0.getItemOutlineStroke((int) 'a', 96, false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("-4,-4,4,4", "TextAnchor.HALF_ASCENT_RIGHT", "RectangleAnchor.CENTER");
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot8.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer12.notifyListeners(rendererChangeEvent13);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesStroke(0);
        combinedDomainXYPlot8.setDomainMinorGridlineStroke(stroke16);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        java.util.Locale locale33 = periodAxis22.getLocale();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.Paint paint36 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer1.drawDomainLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D34, (double) (short) 10, paint36, stroke37);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator39 = null;
        xYBarRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator39, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer43 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent44 = null;
        xYBarRenderer43.notifyListeners(rendererChangeEvent44);
        boolean boolean46 = xYBarRenderer43.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter47 = xYBarRenderer43.getBarPainter();
        xYBarRenderer1.setBarPainter(xYBarPainter47);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(xYBarPainter47);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition4);
        java.awt.Font font6 = barRenderer3D3.getBaseItemLabelFont();
        textTitle2.setFont(font6);
        boolean boolean8 = textTitle2.getNotify();
        java.awt.Paint paint9 = textTitle2.getPaint();
        boolean boolean10 = textTitle2.getNotify();
        java.lang.String str11 = textTitle2.getText();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Series Title" + "'", str11.equals("Series Title"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYBarRenderer1.getBaseToolTipGenerator();
        java.awt.Paint paint13 = xYBarRenderer1.getItemFillPaint((-16777216), (-14666742), true);
        java.awt.Paint paint15 = xYBarRenderer1.getSeriesPaint((int) (byte) -1);
        boolean boolean16 = xYBarRenderer1.getShadowsVisible();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator2 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator4 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!^�");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator2, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator4);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator4);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator9 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!^�");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator7, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator9);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator9);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        java.awt.Stroke stroke5 = xYBarRenderer1.getBaseOutlineStroke();
        xYBarRenderer1.setBarAlignmentFactor(30.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator14 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer12.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator14);
        xYBarRenderer12.removeAnnotations();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat21 = null;
        logAxis20.setNumberFormatOverride(numberFormat21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color26 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYBarRenderer28.notifyListeners(rendererChangeEvent29);
        boolean boolean31 = xYBarRenderer28.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = xYBarRenderer28.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesStroke(0);
        xYBarRenderer28.setBaseStroke(stroke41, false);
        xYBarRenderer12.drawRangeLine(graphics2D17, xYPlot18, (org.jfree.chart.axis.ValueAxis) logAxis20, rectangle2D23, (-1.0d), (java.awt.Paint) color26, stroke41);
        piePlot3D9.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke41);
        boolean boolean46 = piePlot3D9.getSectionOutlinesVisible();
        boolean boolean47 = xYBarRenderer1.hasListener((java.util.EventListener) piePlot3D9);
        xYBarRenderer1.setSeriesItemLabelsVisible(29, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(xYURLGenerator35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        combinedDomainXYPlot10.setWeight(15);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        boolean boolean35 = xYStepRenderer18.getItemShapeVisible(100, 0);
        java.awt.Shape shape36 = xYStepRenderer18.getLegendLine();
        periodAxis17.setDownArrow(shape36);
        periodAxis17.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot40.setDomainCrosshairVisible(true);
        combinedDomainXYPlot40.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer46 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator48 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer46.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator48);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator51 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer46.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator51, true);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        combinedDomainXYPlot55.datasetChanged(datasetChangeEvent56);
        java.awt.Stroke stroke58 = combinedDomainXYPlot55.getRangeCrosshairStroke();
        boolean boolean59 = combinedDomainXYPlot55.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis61 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot55.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis61);
        org.jfree.chart.axis.PeriodAxis periodAxis64 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker66.setLabelAnchor(rectangleAnchor67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = valueMarker66.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        xYBarRenderer46.drawDomainMarker(graphics2D54, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot55, (org.jfree.chart.axis.ValueAxis) periodAxis64, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D70);
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot40.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker66, layer72);
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        xYBarRenderer1.drawRangeMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.plot.Marker) valueMarker66, rectangle2D74);
        org.jfree.data.time.DateRange dateRange76 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange77 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean78 = dateRange76.intersects((org.jfree.data.Range) dateRange77);
        periodAxis17.setRange((org.jfree.data.Range) dateRange76);
        org.jfree.data.Range range80 = null;
        org.jfree.data.Range range81 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange76, range80);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator51);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertNotNull(dateRange76);
        org.junit.Assert.assertNotNull(dateRange77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(range81);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (byte) -1);
        org.jfree.chart.block.Block block5 = null;
        columnArrangement4.add(block5, (java.lang.Object) 100);
        org.jfree.data.general.Dataset dataset8 = null;
        java.lang.Comparable comparable9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset8, comparable9);
        legendItemBlockContainer10.setURLText("");
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator4 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator4);
        xYBarRenderer2.removeAnnotations();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat11 = null;
        logAxis10.setNumberFormatOverride(numberFormat11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        xYBarRenderer18.notifyListeners(rendererChangeEvent19);
        boolean boolean21 = xYBarRenderer18.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = xYBarRenderer18.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesStroke(0);
        xYBarRenderer18.setBaseStroke(stroke31, false);
        xYBarRenderer2.drawRangeLine(graphics2D7, xYPlot8, (org.jfree.chart.axis.ValueAxis) logAxis10, rectangle2D13, (-1.0d), (java.awt.Paint) color16, stroke31);
        boolean boolean35 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color0, (java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(xYURLGenerator25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2958465);
        java.lang.String str2 = serialDate1.getDescription();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate1.getNearestDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("JFreeChartEntity: tooltip = null");
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getCategories();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint4 = null;
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) 8.0d, paint4);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Paint paint7 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker12.setLabelAnchor(rectangleAnchor13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot0.removeDomainMarker(2, (org.jfree.chart.plot.Marker) valueMarker12, layer15);
        org.junit.Assert.assertNull(list1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat9 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat9);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat19 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator20 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat15, (java.text.NumberFormat) logFormat19);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[100.0, 24234.0]", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat15);
        int int22 = logFormat15.getMinimumIntegerDigits();
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        java.awt.Stroke stroke5 = xYBarRenderer1.getBaseOutlineStroke();
        xYBarRenderer1.setBarAlignmentFactor(30.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator14 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer12.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator14);
        xYBarRenderer12.removeAnnotations();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat21 = null;
        logAxis20.setNumberFormatOverride(numberFormat21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color26 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYBarRenderer28.notifyListeners(rendererChangeEvent29);
        boolean boolean31 = xYBarRenderer28.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = xYBarRenderer28.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesStroke(0);
        xYBarRenderer28.setBaseStroke(stroke41, false);
        xYBarRenderer12.drawRangeLine(graphics2D17, xYPlot18, (org.jfree.chart.axis.ValueAxis) logAxis20, rectangle2D23, (-1.0d), (java.awt.Paint) color26, stroke41);
        piePlot3D9.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke41);
        boolean boolean46 = piePlot3D9.getSectionOutlinesVisible();
        boolean boolean47 = xYBarRenderer1.hasListener((java.util.EventListener) piePlot3D9);
        piePlot3D9.setStartAngle(0.2d);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(xYURLGenerator35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = timeSeriesCollection2.hasListener(eventListener4);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator10 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer8.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator10);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer8.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, true);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        combinedDomainXYPlot17.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke20 = combinedDomainXYPlot17.getRangeCrosshairStroke();
        boolean boolean21 = combinedDomainXYPlot17.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis23);
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker28.setLabelAnchor(rectangleAnchor29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = valueMarker28.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYBarRenderer8.drawDomainMarker(graphics2D16, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot17, (org.jfree.chart.axis.ValueAxis) periodAxis26, (org.jfree.chart.plot.Marker) valueMarker28, rectangle2D32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = null;
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection38 = new org.jfree.data.time.TimeSeriesCollection(timeSeries36, timeZone37);
        org.jfree.chart.axis.AxisCollection axisCollection39 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list40 = axisCollection39.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = numberAxis3D42.getTickLabelInsets();
        org.jfree.data.Range range44 = numberAxis3D42.getDefaultAutoRange();
        org.jfree.data.Range range46 = timeSeriesCollection38.getRangeBounds(list40, range44, false);
        combinedDomainXYPlot17.drawDomainTickBands(graphics2D34, rectangle2D35, list40);
        org.jfree.data.time.DateRange dateRange48 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range50 = timeSeriesCollection2.getRangeBounds(list40, (org.jfree.data.Range) dateRange48, true);
        org.jfree.chart.util.BooleanList booleanList51 = new org.jfree.chart.util.BooleanList();
        booleanList51.setBoolean(9999, (java.lang.Boolean) true);
        boolean boolean55 = timeSeriesCollection2.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator13);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(dateRange48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 0.0d, (double) 5, 3.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean6 = dateRange4.intersects((org.jfree.data.Range) dateRange5);
        boolean boolean7 = dateRange3.intersects((org.jfree.data.Range) dateRange4);
        org.jfree.data.Range range10 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange4, (double) (byte) 1, 0.4d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range10);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day7);
        int int10 = timeSeries9.getItemCount();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getCategories();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint4 = null;
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) 8.0d, paint4);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Paint paint7 = categoryPlot0.getRangeCrosshairPaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState12 = null;
        boolean boolean13 = categoryPlot0.render(graphics2D8, rectangle2D9, 0, plotRenderingInfo11, categoryCrosshairState12);
        org.junit.Assert.assertNull(list1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        java.lang.Object obj12 = xYSeries3.clone();
        java.lang.String str13 = xYSeries3.getDescription();
        boolean boolean14 = xYSeries3.getAllowDuplicateXValues();
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 1, 0, (int) '4');
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        float float2 = multiplePiePlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart4);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot6.getPieChart();
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart7.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer3D9.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Font font12 = barRenderer3D9.getBaseItemLabelFont();
        textTitle8.setFont(font12);
        jFreeChart4.addSubtitle((org.jfree.chart.title.Title) textTitle8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle8.getHorizontalAlignment();
        java.lang.String str16 = textTitle8.getURLText();
        java.lang.Object obj17 = textTitle8.clone();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        double double3 = barRenderer3D0.getMinimumBarLength();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        barRenderer3D0.setIncludeBaseInRange(false);
        boolean boolean9 = barRenderer3D0.isItemLabelVisible(100, 97, false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Color color8 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYBarRenderer10.notifyListeners(rendererChangeEvent11);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer1.drawDomainLine(graphics2D2, xYPlot3, (org.jfree.chart.axis.ValueAxis) periodAxis5, rectangle2D6, (double) 100, (java.awt.Paint) color8, stroke14);
        java.util.Locale locale16 = periodAxis5.getLocale();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale16);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator19 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale16);
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource20 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNotNull(tickUnitSource18);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMaximumLabelWidth();
        java.awt.Color color3 = java.awt.Color.CYAN;
        piePlot3D1.setLabelPaint((java.awt.Paint) color3);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(false);
        java.awt.Paint paint7 = piePlot3D1.getShadowPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14d + "'", double2 == 0.14d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        java.awt.Paint paint4 = combinedDomainXYPlot0.getQuadrantPaint((int) (byte) 1);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries7, timeZone8);
        org.jfree.chart.axis.AxisCollection axisCollection10 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list11 = axisCollection10.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis3D13.getTickLabelInsets();
        org.jfree.data.Range range15 = numberAxis3D13.getDefaultAutoRange();
        org.jfree.data.Range range17 = timeSeriesCollection9.getRangeBounds(list11, range15, false);
        combinedDomainXYPlot0.drawRangeTickBands(graphics2D5, rectangle2D6, list11);
        combinedDomainXYPlot0.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        boolean boolean4 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double8 = rectangleInsets6.extendHeight((double) 10.0f);
        categoryPlot0.setAxisOffset(rectangleInsets6);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot12.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str19 = layer18.toString();
        combinedDomainXYPlot12.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker17, layer18);
        try {
            categoryPlot0.addRangeMarker((int) (short) 0, marker11, layer18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 16.0d + "'", double8 == 16.0d);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Layer.FOREGROUND" + "'", str19.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) 'a');
        int int4 = dateTickUnit3.getMultiple();
        java.util.Date date5 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator22 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer20.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator22);
        xYBarRenderer20.removeAnnotations();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = null;
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat29 = null;
        logAxis28.setNumberFormatOverride(numberFormat29);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.Color color34 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        xYBarRenderer36.notifyListeners(rendererChangeEvent37);
        boolean boolean39 = xYBarRenderer36.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator43 = xYBarRenderer36.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer45 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent46 = null;
        xYBarRenderer45.notifyListeners(rendererChangeEvent46);
        java.awt.Stroke stroke49 = xYBarRenderer45.lookupSeriesStroke(0);
        xYBarRenderer36.setBaseStroke(stroke49, false);
        xYBarRenderer20.drawRangeLine(graphics2D25, xYPlot26, (org.jfree.chart.axis.ValueAxis) logAxis28, rectangle2D31, (-1.0d), (java.awt.Paint) color34, stroke49);
        logAxis28.setVisible(false);
        logAxis28.centerRange((double) ' ');
        org.jfree.chart.entity.AxisEntity axisEntity59 = new org.jfree.chart.entity.AxisEntity(shape18, (org.jfree.chart.axis.Axis) logAxis28, "", "Layer.FOREGROUND");
        java.awt.Shape shape60 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset61 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity67 = new org.jfree.chart.entity.PieSectionEntity(shape60, pieDataset61, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        pieSectionEntity67.setURLText("Layer.FOREGROUND");
        pieSectionEntity67.setToolTipText("RangeType.FULL");
        boolean boolean72 = axisEntity59.equals((java.lang.Object) pieSectionEntity67);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(xYURLGenerator43);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint2 = null;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) 8.0d, paint2);
        double double4 = categoryAxis3D0.getLabelAngle();
        java.lang.Object obj5 = categoryAxis3D0.clone();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType6, (int) 'a');
        int int9 = dateTickUnit8.getMultiple();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart11, (int) (short) 100, 0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot15.getPieChart();
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart16.getTitle();
        chartProgressEvent14.setChart(jFreeChart16);
        org.jfree.chart.axis.AxisState axisState20 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.data.time.TimeSeries timeSeries21 = null;
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeSeries21, timeZone22);
        org.jfree.chart.axis.AxisCollection axisCollection24 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list25 = axisCollection24.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis3D27.getTickLabelInsets();
        org.jfree.data.Range range29 = numberAxis3D27.getDefaultAutoRange();
        org.jfree.data.Range range31 = timeSeriesCollection23.getRangeBounds(list25, range29, false);
        axisState20.setTicks(list25);
        jFreeChart16.setSubtitles(list25);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot35 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        combinedDomainXYPlot35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = combinedDomainXYPlot35.getRangeAxisEdge(0);
        boolean boolean40 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge39);
        java.lang.String str41 = rectangleEdge39.toString();
        try {
            double double42 = categoryAxis3D0.getCategoryMiddle((java.lang.Comparable) dateTickUnit8, list25, rectangle2D34, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "RectangleEdge.LEFT" + "'", str41.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange();
        boolean boolean35 = logAxis9.equals((java.lang.Object) dateRange34);
        logAxis9.setFixedDimension((-1.0d));
        double double39 = logAxis9.calculateValue(3.058992E12d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + Double.POSITIVE_INFINITY + "'", double39 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getRangeDescription();
        try {
            timeSeries3.delete((int) (short) -1, (int) (byte) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[100.0, 24234.0]" + "'", str5.equals("[100.0, 24234.0]"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (-3.0d));
        timeSeriesDataItem3.setValue((java.lang.Number) 100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.general.DatasetGroup datasetGroup12 = xYSeriesCollection11.getGroup();
        java.lang.String str13 = datasetGroup12.getID();
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertNotNull(datasetGroup12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "NOID" + "'", str13.equals("NOID"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        boolean boolean2 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        int int3 = categoryPlot0.getIndexOf(categoryItemRenderer2);
        categoryPlot0.configureRangeAxes();
        java.awt.Stroke stroke5 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list9 = categoryPlot8.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot8.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        axisSpace6.ensureAtLeast((double) 900000L, rectangleEdge10);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot13.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = combinedDomainXYPlot13.getRangeAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        combinedDomainXYPlot13.setAxisOffset(rectangleInsets17);
        boolean boolean19 = axisSpace6.equals((java.lang.Object) rectangleInsets17);
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator4, false);
        barRenderer3D0.setDrawBarOutline(false);
        int int9 = barRenderer3D0.getRowCount();
        barRenderer3D0.setBaseCreateEntities(true);
        int int12 = barRenderer3D0.getDefaultEntityRadius();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "Layer.FOREGROUND", "series", "");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getCategories();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint4 = null;
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) 8.0d, paint4);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        java.awt.Paint paint7 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge(0);
        org.junit.Assert.assertNull(list1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition4);
        java.awt.Font font6 = barRenderer3D3.getBaseItemLabelFont();
        textTitle2.setFont(font6);
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        textTitle2.setFont(font8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot10.getPieChart();
        org.jfree.chart.title.TextTitle textTitle12 = jFreeChart11.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder13 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle12.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle2.setVerticalAlignment(verticalAlignment16);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        combinedDomainXYPlot18.datasetChanged(datasetChangeEvent19);
        java.awt.Stroke stroke21 = combinedDomainXYPlot18.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer24 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator26 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer24.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator26);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator29 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer24.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator29, true);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = null;
        combinedDomainXYPlot33.datasetChanged(datasetChangeEvent34);
        java.awt.Stroke stroke36 = combinedDomainXYPlot33.getRangeCrosshairStroke();
        boolean boolean37 = combinedDomainXYPlot33.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis39 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot33.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis39);
        org.jfree.chart.axis.PeriodAxis periodAxis42 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker44.setLabelAnchor(rectangleAnchor45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = valueMarker44.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        xYBarRenderer24.drawDomainMarker(graphics2D32, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot33, (org.jfree.chart.axis.ValueAxis) periodAxis42, (org.jfree.chart.plot.Marker) valueMarker44, rectangle2D48);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot50.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str57 = layer56.toString();
        combinedDomainXYPlot50.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker55, layer56);
        combinedDomainXYPlot18.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker44, layer56);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = combinedDomainXYPlot18.getRangeAxisEdge(12);
        textTitle2.setPosition(rectangleEdge61);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertNotNull(textTitle12);
        org.junit.Assert.assertNotNull(blockBorder13);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator29);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Layer.FOREGROUND" + "'", str57.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Layer.FOREGROUND", font5);
        java.lang.Object obj7 = labelBlock6.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot8.getPieChart();
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        labelBlock6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        java.lang.String str14 = labelBlock6.getToolTipText();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.lang.String str3 = rectangleEdge2.toString();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.LEFT" + "'", str3.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Color color5 = java.awt.Color.getColor("hi!", (int) 'a');
        combinedDomainXYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = combinedDomainXYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.CENTER");
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        java.awt.Color color6 = java.awt.Color.yellow;
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) ' ', (int) '4', (int) (byte) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.setAxisLineVisible(false);
        java.awt.Paint paint17 = numberAxis3D14.getTickMarkPaint();
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor5, color6, color7, paint8, chartColor12, paint17 };
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Color color20 = java.awt.Color.WHITE;
        java.awt.Color color21 = java.awt.Color.yellow;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { paint19, color20, color21, color22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYBarRenderer33.notifyListeners(rendererChangeEvent34);
        java.awt.Stroke stroke37 = xYBarRenderer33.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] { stroke24, stroke25, stroke31, stroke37 };
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYBarRenderer40.notifyListeners(rendererChangeEvent41);
        java.awt.Stroke stroke44 = xYBarRenderer40.lookupSeriesOutlineStroke((int) '4');
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray46 = new java.awt.Stroke[] { stroke44, stroke45 };
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 86400000L, (float) (byte) 10);
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] { shape49 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray23, strokeArray38, strokeArray46, shapeArray50);
        multiplePiePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51, true);
        java.awt.Shape shape54 = multiplePiePlot0.getLegendItemShape();
        java.awt.Shape shape55 = multiplePiePlot0.getLegendItemShape();
        multiplePiePlot0.setBackgroundAlpha((float) 12);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(shape55);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Comparable comparable1 = null;
        try {
            defaultKeyedValues0.setValue(comparable1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYBarRenderer8.notifyListeners(rendererChangeEvent9);
        java.awt.Stroke stroke12 = xYBarRenderer8.lookupSeriesStroke(0);
        java.awt.Paint paint13 = xYBarRenderer8.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        combinedDomainXYPlot15.datasetChanged(datasetChangeEvent16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYBarRenderer19.notifyListeners(rendererChangeEvent20);
        java.awt.Stroke stroke23 = xYBarRenderer19.lookupSeriesStroke(0);
        combinedDomainXYPlot15.setDomainMinorGridlineStroke(stroke23);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer25 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis29 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.Color color32 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYBarRenderer34.notifyListeners(rendererChangeEvent35);
        java.awt.Stroke stroke38 = xYBarRenderer34.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer25.drawDomainLine(graphics2D26, xYPlot27, (org.jfree.chart.axis.ValueAxis) periodAxis29, rectangle2D30, (double) 100, (java.awt.Paint) color32, stroke38);
        java.util.Locale locale40 = periodAxis29.getLocale();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer8.drawDomainLine(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis29, rectangle2D41, (double) (short) 10, paint43, stroke44);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer46 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        java.awt.Color color53 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer55 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent56 = null;
        xYBarRenderer55.notifyListeners(rendererChangeEvent56);
        java.awt.Stroke stroke59 = xYBarRenderer55.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer46.drawDomainLine(graphics2D47, xYPlot48, (org.jfree.chart.axis.ValueAxis) periodAxis50, rectangle2D51, (double) 100, (java.awt.Paint) color53, stroke59);
        boolean boolean63 = xYStepRenderer46.getItemShapeVisible(100, 0);
        java.awt.Shape shape64 = xYStepRenderer46.getLegendLine();
        xYStepRenderer46.setBaseShapesFilled(true);
        combinedDomainXYPlot15.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer46);
        xYBarRenderer1.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot15);
        java.awt.Paint paint69 = combinedDomainXYPlot15.getRangeCrosshairPaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation70 = null;
        try {
            combinedDomainXYPlot15.addAnnotation(xYAnnotation70, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(locale40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(paint69);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("1,000%");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        java.lang.Object obj2 = polarPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (byte) 10, (double) (-2208927600000L), plotRenderingInfo5, point2D6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        pieSectionEntity7.setURLText("Layer.FOREGROUND");
        pieSectionEntity7.setToolTipText("RangeType.FULL");
        java.lang.String str12 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PieSection: 52, 10(0)" + "'", str12.equals("PieSection: 52, 10(0)"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange();
        boolean boolean35 = logAxis9.equals((java.lang.Object) dateRange34);
        logAxis9.resizeRange(0.14d, (double) 100);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke4 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedDomainXYPlot0.getRangeAxis((int) (short) 0);
        java.util.List list7 = combinedDomainXYPlot0.getSubplots();
        double double8 = combinedDomainXYPlot0.getDomainCrosshairValue();
        combinedDomainXYPlot0.setRangePannable(true);
        org.jfree.data.xy.XYSeries xYSeries15 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem18 = xYSeries15.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries15.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection23 = new org.jfree.data.xy.XYSeriesCollection(xYSeries15);
        xYSeriesCollection23.setIntervalWidth((double) 'a');
        combinedDomainXYPlot0.setDataset(6, (org.jfree.data.xy.XYDataset) xYSeriesCollection23);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(xYDataItem18);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean4 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9);
        combinedDomainXYPlot0.setDataset((int) (short) 100, (org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 96);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        java.awt.Stroke stroke5 = xYBarRenderer1.getBaseOutlineStroke();
        java.awt.Font font7 = xYBarRenderer1.lookupLegendTextFont((int) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot8 = xYBarRenderer1.getPlot();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNull(xYPlot8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange();
        boolean boolean35 = logAxis9.equals((java.lang.Object) dateRange34);
        logAxis9.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (byte) -1, (double) 14);
        java.lang.Object obj3 = size2D2.clone();
        size2D2.setWidth((double) 1.0f);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke4 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean5 = combinedDomainXYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot0.setRangeAxisLocation(axisLocation6);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 2019);
        java.lang.String str3 = numberTickUnit1.valueToString(30.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "30" + "'", str3.equals("30"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot4.setDomainCrosshairVisible(true);
        combinedDomainXYPlot4.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator12 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer10.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator12);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer10.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        combinedDomainXYPlot19.datasetChanged(datasetChangeEvent20);
        java.awt.Stroke stroke22 = combinedDomainXYPlot19.getRangeCrosshairStroke();
        boolean boolean23 = combinedDomainXYPlot19.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot19.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis25);
        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker30.setLabelAnchor(rectangleAnchor31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = valueMarker30.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        xYBarRenderer10.drawDomainMarker(graphics2D18, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot19, (org.jfree.chart.axis.ValueAxis) periodAxis28, (org.jfree.chart.plot.Marker) valueMarker30, rectangle2D34);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker30, layer36);
        try {
            categoryPlot0.addDomainMarker(5, categoryMarker3, layer36, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(list1);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(layer36);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean4 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.lang.String str8 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.plot.CrosshairState crosshairState10 = new org.jfree.chart.plot.CrosshairState(true);
        double double11 = crosshairState10.getCrosshairDistance();
        crosshairState10.updateCrosshairX((double) 0L);
        crosshairState10.updateCrosshairX((double) 5);
        boolean boolean16 = combinedDomainXYPlot0.equals((java.lang.Object) crosshairState10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D18.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator24 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer22.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator24);
        xYBarRenderer22.removeAnnotations();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = null;
        org.jfree.chart.axis.LogAxis logAxis30 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat31 = null;
        logAxis30.setNumberFormatOverride(numberFormat31);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color36 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer38 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        xYBarRenderer38.notifyListeners(rendererChangeEvent39);
        boolean boolean41 = xYBarRenderer38.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator45 = xYBarRenderer38.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer47 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent48 = null;
        xYBarRenderer47.notifyListeners(rendererChangeEvent48);
        java.awt.Stroke stroke51 = xYBarRenderer47.lookupSeriesStroke(0);
        xYBarRenderer38.setBaseStroke(stroke51, false);
        xYBarRenderer22.drawRangeLine(graphics2D27, xYPlot28, (org.jfree.chart.axis.ValueAxis) logAxis30, rectangle2D33, (-1.0d), (java.awt.Paint) color36, stroke51);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        combinedDomainXYPlot55.datasetChanged(datasetChangeEvent56);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer59 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator61 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer59.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator61);
        xYBarRenderer59.removeAnnotations();
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = null;
        org.jfree.chart.axis.LogAxis logAxis67 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat68 = null;
        logAxis67.setNumberFormatOverride(numberFormat68);
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        java.awt.Color color73 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer75 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent76 = null;
        xYBarRenderer75.notifyListeners(rendererChangeEvent76);
        boolean boolean78 = xYBarRenderer75.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator82 = xYBarRenderer75.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer84 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent85 = null;
        xYBarRenderer84.notifyListeners(rendererChangeEvent85);
        java.awt.Stroke stroke88 = xYBarRenderer84.lookupSeriesStroke(0);
        xYBarRenderer75.setBaseStroke(stroke88, false);
        xYBarRenderer59.drawRangeLine(graphics2D64, xYPlot65, (org.jfree.chart.axis.ValueAxis) logAxis67, rectangle2D70, (-1.0d), (java.awt.Paint) color73, stroke88);
        org.jfree.data.Range range92 = combinedDomainXYPlot55.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis67);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray93 = new org.jfree.chart.axis.ValueAxis[] { numberAxis3D18, logAxis30, logAxis67 };
        combinedDomainXYPlot0.setRangeAxes(valueAxisArray93);
        boolean boolean95 = combinedDomainXYPlot0.isRangeMinorGridlinesVisible();
        combinedDomainXYPlot0.setBackgroundImageAlignment((int) (short) 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Combined_Domain_XYPlot" + "'", str8.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(xYURLGenerator45);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNull(xYURLGenerator82);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNull(range92);
        org.junit.Assert.assertNotNull(valueAxisArray93);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        float float2 = multiplePiePlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart4);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot6.getPieChart();
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart7.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer3D9.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Font font12 = barRenderer3D9.getBaseItemLabelFont();
        textTitle8.setFont(font12);
        jFreeChart4.addSubtitle((org.jfree.chart.title.Title) textTitle8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle8.getHorizontalAlignment();
        java.lang.String str16 = textTitle8.getURLText();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        combinedDomainXYPlot17.datasetChanged(datasetChangeEvent18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = combinedDomainXYPlot17.getRangeAxisEdge(0);
        boolean boolean22 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge21);
        java.lang.String str23 = rectangleEdge21.toString();
        textTitle8.setPosition(rectangleEdge21);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleEdge.LEFT" + "'", str23.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        java.util.Locale locale15 = periodAxis4.getLocale();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale15);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale15);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale15);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(locale15);
        org.junit.Assert.assertNotNull(tickUnitSource17);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYBarRenderer11.notifyListeners(rendererChangeEvent12);
        java.awt.Stroke stroke15 = xYBarRenderer11.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer2.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis6, rectangle2D7, (double) 100, (java.awt.Paint) color9, stroke15);
        boolean boolean19 = xYStepRenderer2.getItemShapeVisible(100, 0);
        java.awt.Shape shape20 = xYStepRenderer2.getLegendLine();
        periodAxis1.setDownArrow(shape20);
        periodAxis1.setUpperMargin((double) 3);
        boolean boolean24 = periodAxis1.isAxisLineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        java.awt.Paint paint31 = xYBarRenderer26.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = null;
        combinedDomainXYPlot33.datasetChanged(datasetChangeEvent34);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesStroke(0);
        combinedDomainXYPlot33.setDomainMinorGridlineStroke(stroke41);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Color color50 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer52 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        xYBarRenderer52.notifyListeners(rendererChangeEvent53);
        java.awt.Stroke stroke56 = xYBarRenderer52.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer43.drawDomainLine(graphics2D44, xYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D48, (double) 100, (java.awt.Paint) color50, stroke56);
        java.util.Locale locale58 = periodAxis47.getLocale();
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        java.awt.Paint paint61 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke62 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer26.drawDomainLine(graphics2D32, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot33, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D59, (double) (short) 10, paint61, stroke62);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer64 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis68 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        java.awt.Color color71 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer73 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent74 = null;
        xYBarRenderer73.notifyListeners(rendererChangeEvent74);
        java.awt.Stroke stroke77 = xYBarRenderer73.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer64.drawDomainLine(graphics2D65, xYPlot66, (org.jfree.chart.axis.ValueAxis) periodAxis68, rectangle2D69, (double) 100, (java.awt.Paint) color71, stroke77);
        boolean boolean81 = xYStepRenderer64.getItemShapeVisible(100, 0);
        java.awt.Shape shape82 = xYStepRenderer64.getLegendLine();
        xYStepRenderer64.setBaseShapesFilled(true);
        combinedDomainXYPlot33.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer64);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder86 = combinedDomainXYPlot33.getSeriesRenderingOrder();
        periodAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot33);
        java.lang.Class class88 = periodAxis1.getMinorTickTimePeriodClass();
        org.jfree.data.Range range89 = periodAxis1.getRange();
        java.lang.Object obj90 = null;
        boolean boolean91 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) range89, obj90);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(locale58);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNotNull(seriesRenderingOrder86);
        org.junit.Assert.assertNotNull(class88);
        org.junit.Assert.assertNotNull(range89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        combinedDomainXYPlot0.clearDomainMarkers(3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedDomainXYPlot0.getRangeAxis();
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.util.LogFormat logFormat12 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat16 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator17 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat12, (java.text.NumberFormat) logFormat16);
        java.lang.String str19 = logFormat12.format((double) 100);
        logAxis7.setNumberFormatOverride((java.text.NumberFormat) logFormat12);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesStroke(0);
        java.awt.Paint paint27 = xYBarRenderer22.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        java.awt.Paint paint34 = xYBarRenderer29.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = null;
        combinedDomainXYPlot36.datasetChanged(datasetChangeEvent37);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYBarRenderer40.notifyListeners(rendererChangeEvent41);
        java.awt.Stroke stroke44 = xYBarRenderer40.lookupSeriesStroke(0);
        combinedDomainXYPlot36.setDomainMinorGridlineStroke(stroke44);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer46 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis50 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        java.awt.Color color53 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer55 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent56 = null;
        xYBarRenderer55.notifyListeners(rendererChangeEvent56);
        java.awt.Stroke stroke59 = xYBarRenderer55.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer46.drawDomainLine(graphics2D47, xYPlot48, (org.jfree.chart.axis.ValueAxis) periodAxis50, rectangle2D51, (double) 100, (java.awt.Paint) color53, stroke59);
        java.util.Locale locale61 = periodAxis50.getLocale();
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        java.awt.Paint paint64 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke65 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer29.drawDomainLine(graphics2D35, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot36, (org.jfree.chart.axis.ValueAxis) periodAxis50, rectangle2D62, (double) (short) 10, paint64, stroke65);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer67 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis71 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        java.awt.Color color74 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer76 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent77 = null;
        xYBarRenderer76.notifyListeners(rendererChangeEvent77);
        java.awt.Stroke stroke80 = xYBarRenderer76.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer67.drawDomainLine(graphics2D68, xYPlot69, (org.jfree.chart.axis.ValueAxis) periodAxis71, rectangle2D72, (double) 100, (java.awt.Paint) color74, stroke80);
        boolean boolean84 = xYStepRenderer67.getItemShapeVisible(100, 0);
        java.awt.Shape shape85 = xYStepRenderer67.getLegendLine();
        xYStepRenderer67.setBaseShapesFilled(true);
        combinedDomainXYPlot36.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer67);
        xYBarRenderer22.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot36);
        logAxis7.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot36);
        combinedDomainXYPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot36);
        org.jfree.chart.plot.CategoryPlot categoryPlot92 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list93 = categoryPlot92.getAnnotations();
        categoryPlot92.setRangeCrosshairLockedOnData(true);
        boolean boolean96 = categoryPlot92.isRangeMinorGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection97 = categoryPlot92.getFixedLegendItems();
        java.awt.Stroke stroke98 = categoryPlot92.getRangeCrosshairStroke();
        combinedDomainXYPlot36.setDomainCrosshairStroke(stroke98);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!^�" + "'", str19.equals("hi!^�"));
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(locale61);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(list93);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNull(legendItemCollection97);
        org.junit.Assert.assertNotNull(stroke98);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        combinedDomainXYPlot2.datasetChanged(datasetChangeEvent3);
        java.awt.Stroke stroke5 = combinedDomainXYPlot2.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator10 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer8.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator10);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer8.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13, true);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        combinedDomainXYPlot17.datasetChanged(datasetChangeEvent18);
        java.awt.Stroke stroke20 = combinedDomainXYPlot17.getRangeCrosshairStroke();
        boolean boolean21 = combinedDomainXYPlot17.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis23);
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker28.setLabelAnchor(rectangleAnchor29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = valueMarker28.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYBarRenderer8.drawDomainMarker(graphics2D16, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot17, (org.jfree.chart.axis.ValueAxis) periodAxis26, (org.jfree.chart.plot.Marker) valueMarker28, rectangle2D32);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot34 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot34.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str41 = layer40.toString();
        combinedDomainXYPlot34.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker39, layer40);
        combinedDomainXYPlot2.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker28, layer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = combinedDomainXYPlot2.getRangeAxisEdge(12);
        axisSpace0.add((double) 5, rectangleEdge45);
        java.awt.Paint paint47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        boolean boolean48 = axisSpace0.equals((java.lang.Object) paint47);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator13);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Layer.FOREGROUND" + "'", str41.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        segmentedTimeline0.setStartTime((long) 'a');
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType6, (int) 'a');
        int int9 = dateTickUnit8.getMultiple();
        java.util.Date date10 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline0.getSegment(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone14;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date10, timeZone14);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setCategoryMargin(0.0d);
        float float4 = categoryAxis3D1.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType5 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType5, (int) 'a');
        int int8 = dateTickUnit7.getRollMultiple();
        int int9 = dateTickUnit7.getCalendarField();
        java.lang.String str10 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) int9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            java.util.List list15 = categoryAxis3D1.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(dateTickUnitType5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) 'a');
        int int4 = dateTickUnit3.getMultiple();
        java.util.Date date5 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType6, (int) 'a');
        int int9 = dateTickUnit8.getRollMultiple();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType10 = dateTickUnit8.getUnitType();
        java.util.Date date11 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit8);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(dateTickUnitType10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Color color8 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYBarRenderer10.notifyListeners(rendererChangeEvent11);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer1.drawDomainLine(graphics2D2, xYPlot3, (org.jfree.chart.axis.ValueAxis) periodAxis5, rectangle2D6, (double) 100, (java.awt.Paint) color8, stroke14);
        int int16 = periodAxis5.getMinorTickCount();
        java.util.Locale locale17 = periodAxis5.getLocale();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator("RangeType.FULL", locale17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart20 = multiplePiePlot19.getPieChart();
        org.jfree.chart.title.TextTitle textTitle21 = jFreeChart20.getTitle();
        int int22 = jFreeChart20.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = jFreeChart20.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = jFreeChart20.getPadding();
        boolean boolean25 = standardPieToolTipGenerator18.equals((java.lang.Object) jFreeChart20);
        org.jfree.chart.title.LegendTitle legendTitle26 = jFreeChart20.getLegend();
        org.jfree.chart.title.LegendTitle legendTitle27 = jFreeChart20.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        try {
            java.awt.image.BufferedImage bufferedImage32 = jFreeChart20.createBufferedImage(29, (int) (byte) 100, (int) 'a', chartRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(locale17);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertNotNull(textTitle21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(legendTitle26);
        org.junit.Assert.assertNull(legendTitle27);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        barRenderer3D0.setIncludeBaseInRange(false);
        double double46 = barRenderer3D0.getXOffset();
        barRenderer3D0.setSeriesItemLabelsVisible((int) (byte) 10, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 12.0d + "'", double46 == 12.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!^�");
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double13 = xYSeriesCollection11.getRangeUpperBound(true);
        org.jfree.data.xy.XYSeries xYSeries17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem20 = xYSeries17.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries17.add((double) (-14666742), (double) 97, true);
        xYSeriesCollection11.removeSeries(xYSeries17);
        java.lang.Number number27 = null;
        org.jfree.data.xy.XYDataItem xYDataItem28 = xYSeries17.addOrUpdate((java.lang.Number) 255, number27);
        org.jfree.data.time.TimeSeries timeSeries29 = null;
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeSeries29, timeZone30);
        int int32 = timeSeriesCollection31.getSeriesCount();
        double double34 = timeSeriesCollection31.getDomainUpperBound(false);
        xYSeries17.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection31);
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.0d + "'", double13 == 97.0d);
        org.junit.Assert.assertNull(xYDataItem20);
        org.junit.Assert.assertNull(xYDataItem28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        boolean boolean38 = piePlot3D1.getSectionOutlinesVisible();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = null;
        combinedDomainXYPlot39.datasetChanged(datasetChangeEvent40);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer43 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent44 = null;
        xYBarRenderer43.notifyListeners(rendererChangeEvent44);
        java.awt.Stroke stroke47 = xYBarRenderer43.lookupSeriesStroke(0);
        combinedDomainXYPlot39.setDomainMinorGridlineStroke(stroke47);
        boolean boolean49 = combinedDomainXYPlot39.canSelectByRegion();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot50.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str57 = layer56.toString();
        combinedDomainXYPlot50.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker55, layer56);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        combinedDomainXYPlot50.setOutlineStroke(stroke59);
        combinedDomainXYPlot39.setRangeCrosshairStroke(stroke59);
        piePlot3D1.setLabelLinkStroke(stroke59);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D64 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = numberAxis3D64.getTickLabelInsets();
        piePlot3D1.setSimpleLabelOffset(rectangleInsets65);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Layer.FOREGROUND" + "'", str57.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(rectangleInsets65);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(100, 0);
        java.awt.Shape shape18 = xYStepRenderer0.getLegendLine();
        xYStepRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot21.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str28 = layer27.toString();
        combinedDomainXYPlot21.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        combinedDomainXYPlot21.setOutlineStroke(stroke30);
        xYStepRenderer0.setBaseOutlineStroke(stroke30, true);
        xYStepRenderer0.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Layer.FOREGROUND" + "'", str28.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis3D1.getTickLabelInsets();
        org.jfree.data.Range range3 = numberAxis3D1.getDefaultAutoRange();
        numberAxis3D1.setAutoRangeStickyZero(true);
        numberAxis3D1.setUpperBound((double) 2958465);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        boolean boolean4 = xYBarRenderer1.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYBarRenderer1.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYBarRenderer10.notifyListeners(rendererChangeEvent11);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesStroke(0);
        xYBarRenderer1.setBaseStroke(stroke14, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = null;
        xYBarRenderer1.setSeriesURLGenerator(0, xYURLGenerator18);
        xYBarRenderer1.setBarAlignmentFactor(12.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection2 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer3D0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer3D0.getToolTipGenerator((int) (short) 10, 8, true);
        double double10 = barRenderer3D0.getXOffset();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        barRenderer3D12.setPositiveItemLabelPositionFallback(itemLabelPosition13);
        java.awt.Font font15 = barRenderer3D12.getBaseItemLabelFont();
        barRenderer3D0.setSeriesItemLabelFont((int) (short) 1, font15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list19 = categoryPlot18.getAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        int int21 = categoryPlot18.getIndexOf(categoryItemRenderer20);
        categoryPlot18.configureRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            barRenderer3D0.drawBackground(graphics2D17, categoryPlot18, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 12.0d + "'", double10 == 12.0d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator7);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer3D9.setBaseURLGenerator(categoryURLGenerator10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer3D9.getLegendItemLabelGenerator();
        barRenderer3D0.setLegendItemURLGenerator(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        int int15 = periodAxis4.getMinorTickCount();
        java.util.Locale locale16 = periodAxis4.getLocale();
        periodAxis4.configure();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(locale16);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Layer.FOREGROUND", font5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            labelBlock6.setBounds(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = xYBarRenderer1.getGradientPaintTransformer();
        java.awt.Paint paint10 = xYBarRenderer1.getItemOutlinePaint((int) (short) 100, (int) (short) 10, false);
        java.awt.Shape shape11 = xYBarRenderer1.getLegendBar();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYBarRenderer1.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean4 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.lang.String str8 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer3D9.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Font font12 = barRenderer3D9.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        barRenderer3D9.setSeriesURLGenerator(0, categoryURLGenerator14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer22 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.Color color29 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        xYBarRenderer31.notifyListeners(rendererChangeEvent32);
        java.awt.Stroke stroke35 = xYBarRenderer31.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer22.drawDomainLine(graphics2D23, xYPlot24, (org.jfree.chart.axis.ValueAxis) periodAxis26, rectangle2D27, (double) 100, (java.awt.Paint) color29, stroke35);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer37 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.Color color44 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer46 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent47 = null;
        xYBarRenderer46.notifyListeners(rendererChangeEvent47);
        java.awt.Stroke stroke50 = xYBarRenderer46.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer37.drawDomainLine(graphics2D38, xYPlot39, (org.jfree.chart.axis.ValueAxis) periodAxis41, rectangle2D42, (double) 100, (java.awt.Paint) color44, stroke50);
        barRenderer3D9.drawRangeLine(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D20, (double) (byte) -1, (java.awt.Paint) color29, stroke50);
        java.awt.Paint paint53 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        barRenderer3D9.setShadowPaint(paint53);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer56 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator58 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer56.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator58);
        xYBarRenderer56.removeAnnotations();
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = null;
        org.jfree.chart.axis.LogAxis logAxis64 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat65 = null;
        logAxis64.setNumberFormatOverride(numberFormat65);
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        java.awt.Color color70 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer72 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent73 = null;
        xYBarRenderer72.notifyListeners(rendererChangeEvent73);
        boolean boolean75 = xYBarRenderer72.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator79 = xYBarRenderer72.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer81 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent82 = null;
        xYBarRenderer81.notifyListeners(rendererChangeEvent82);
        java.awt.Stroke stroke85 = xYBarRenderer81.lookupSeriesStroke(0);
        xYBarRenderer72.setBaseStroke(stroke85, false);
        xYBarRenderer56.drawRangeLine(graphics2D61, xYPlot62, (org.jfree.chart.axis.ValueAxis) logAxis64, rectangle2D67, (-1.0d), (java.awt.Paint) color70, stroke85);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent89 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) logAxis64);
        boolean boolean90 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) paint53, (java.lang.Object) axisChangeEvent89);
        combinedDomainXYPlot0.axisChanged(axisChangeEvent89);
        boolean boolean92 = combinedDomainXYPlot0.isDomainPannable();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Combined_Domain_XYPlot" + "'", str8.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNull(xYURLGenerator79);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0, (float) 100L, 0.0f);
        float[] floatArray12 = new float[] { 8, 1L, '#', (short) 10, 86400000L };
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) (short) 100, (int) (byte) 100, 15, floatArray12);
        float[] floatArray14 = color3.getRGBComponents(floatArray12);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = null;
        segmentedTimeline0.setBaseTimeline(segmentedTimeline3);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMaximumLabelWidth();
        java.awt.Color color3 = java.awt.Color.CYAN;
        piePlot3D1.setLabelPaint((java.awt.Paint) color3);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(false);
        boolean boolean7 = piePlot3D1.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14d + "'", double2 == 0.14d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart1);
        boolean boolean3 = jFreeChart1.isNotify();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker5.setLabelAnchor(rectangleAnchor6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = valueMarker5.getLabelOffset();
        double double10 = rectangleInsets8.calculateRightOutset((double) 2);
        jFreeChart1.setPadding(rectangleInsets8);
        java.text.DateFormat dateFormat13 = null;
        java.text.DateFormat dateFormat14 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", dateFormat13, dateFormat14);
        java.lang.Object obj16 = standardXYToolTipGenerator15.clone();
        try {
            jFreeChart1.setTextAntiAlias(obj16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.labels.StandardXYToolTipGenerator@174400a3 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        java.awt.Shape shape8 = pieSectionEntity7.getArea();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        pieSectionEntity7.setURLText("[100.0, 24234.0]");
        java.lang.Comparable comparable12 = pieSectionEntity7.getSectionKey();
        java.lang.String str13 = pieSectionEntity7.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0L + "'", comparable12.equals(0L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-4,-4,4,4" + "'", str13.equals("-4,-4,4,4"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator0 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries4.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries4.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection(xYSeries4);
        org.jfree.data.general.DatasetGroup datasetGroup13 = xYSeriesCollection12.getGroup();
        xYSeriesCollection12.setIntervalWidth((double) 2);
        java.lang.String str18 = standardXYURLGenerator0.generateURL((org.jfree.data.xy.XYDataset) xYSeriesCollection12, 10, 12);
        org.junit.Assert.assertNull(xYDataItem7);
        org.junit.Assert.assertNotNull(datasetGroup13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "index.html?series=10&amp;item=12" + "'", str18.equals("index.html?series=10&amp;item=12"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType2, (int) 'a');
        int int5 = dateTickUnit4.getMultiple();
        java.util.Date date6 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone8 = dateAxis7.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone8;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6, timeZone8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("February", timeZone8);
        java.text.DateFormat dateFormat12 = dateAxis11.getDateFormatOverride();
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(dateFormat12);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        java.lang.Object obj2 = polarPlot0.clone();
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3, timeZone4);
        int int6 = timeSeriesCollection5.getSeriesCount();
        java.util.EventListener eventListener7 = null;
        boolean boolean8 = timeSeriesCollection5.hasListener(eventListener7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        polarPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Layer.FOREGROUND", font5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        labelBlock6.setContentAlignmentPoint(textBlockAnchor7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = labelBlock6.getTextAnchor();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Layer.FOREGROUND", font5);
        java.lang.Object obj7 = labelBlock6.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot8.getPieChart();
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        labelBlock6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        double double14 = labelBlock6.getHeight();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator6);
        xYBarRenderer4.removeAnnotations();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat13 = null;
        logAxis12.setNumberFormatOverride(numberFormat13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.Color color18 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYBarRenderer20.notifyListeners(rendererChangeEvent21);
        boolean boolean23 = xYBarRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer20.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYBarRenderer29.notifyListeners(rendererChangeEvent30);
        java.awt.Stroke stroke33 = xYBarRenderer29.lookupSeriesStroke(0);
        xYBarRenderer20.setBaseStroke(stroke33, false);
        xYBarRenderer4.drawRangeLine(graphics2D9, xYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (-1.0d), (java.awt.Paint) color18, stroke33);
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke33);
        piePlot3D1.setMinimumArcAngleToDraw((double) (-16777216));
        piePlot3D1.setShadowYOffset(0.0d);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        piePlot3D1.setDataset(pieDataset42);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator44 = piePlot3D1.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator44);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.data.time.DateRange dateRange34 = new org.jfree.data.time.DateRange();
        boolean boolean35 = logAxis9.equals((java.lang.Object) dateRange34);
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range39 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange36, (double) 1L, false);
        boolean boolean41 = range39.contains(16.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange34, range39);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot43 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot43.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str50 = layer49.toString();
        combinedDomainXYPlot43.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker48, layer49);
        java.awt.Stroke stroke52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        combinedDomainXYPlot43.setOutlineStroke(stroke52);
        boolean boolean54 = dateRange34.equals((java.lang.Object) combinedDomainXYPlot43);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Layer.FOREGROUND" + "'", str50.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("GradientPaintTransformType.CENTER_HORIZONTAL");
        java.lang.String str2 = textTitle1.getURLText();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        double double6 = rectangleInsets4.calculateRightOutset((double) 2);
        double double8 = rectangleInsets4.trimWidth((double) 6);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        float float2 = multiplePiePlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart4);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot6.getPieChart();
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart7.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer3D9.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Font font12 = barRenderer3D9.getBaseItemLabelFont();
        textTitle8.setFont(font12);
        jFreeChart4.addSubtitle((org.jfree.chart.title.Title) textTitle8);
        int int15 = jFreeChart4.getSubtitleCount();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer3D0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator9 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer7.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean12 = standardXYSeriesLabelGenerator9.equals((java.lang.Object) paint11);
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator9);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        boolean boolean35 = xYStepRenderer18.getItemShapeVisible(100, 0);
        java.awt.Shape shape36 = xYStepRenderer18.getLegendLine();
        periodAxis17.setDownArrow(shape36);
        periodAxis17.setNegativeArrowVisible(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer40 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.Color color47 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        xYBarRenderer49.notifyListeners(rendererChangeEvent50);
        java.awt.Stroke stroke53 = xYBarRenderer49.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer40.drawDomainLine(graphics2D41, xYPlot42, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D45, (double) 100, (java.awt.Paint) color47, stroke53);
        periodAxis17.setLabelPaint((java.awt.Paint) color47);
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray57 = null;
        float[] floatArray58 = color56.getColorComponents(floatArray57);
        boolean boolean59 = periodAxis17.equals((java.lang.Object) floatArray57);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str62 = layer61.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        xYBarRenderer1.drawAnnotations(graphics2D14, rectangle2D15, (org.jfree.chart.axis.ValueAxis) periodAxis17, valueAxis60, layer61, plotRenderingInfo63);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Layer.FOREGROUND" + "'", str62.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        periodAxis4.setMinorTickMarkOutsideLength((float) 15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        boolean boolean4 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = categoryPlot0.getFixedLegendItems();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.String[] strArray2 = new java.lang.String[] { "Layer.FOREGROUND" };
        org.jfree.chart.axis.SymbolAxis symbolAxis3 = new org.jfree.chart.axis.SymbolAxis("Layer.FOREGROUND", strArray2);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) symbolAxis3);
        java.lang.Class<?> wildcardClass5 = combinedDomainXYPlot4.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYBarRenderer1.getBaseToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setSeriesPositiveItemLabelPosition(14, itemLabelPosition11);
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        xYBarRenderer1.setPlot(xYPlot13);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        double double5 = timeSeriesCollection2.getDomainUpperBound(false);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        java.awt.Stroke stroke10 = xYBarRenderer1.getSeriesOutlineStroke(0);
        xYBarRenderer1.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(stroke10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        int int15 = periodAxis4.getMinorTickCount();
        java.util.Locale locale16 = periodAxis4.getLocale();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator17 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale16);
        java.text.NumberFormat numberFormat18 = java.text.NumberFormat.getInstance(locale16);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNotNull(numberFormat18);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.awt.Color color2 = java.awt.Color.WHITE;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker(97.0d, (double) 100.0f, (java.awt.Paint) color2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        intervalMarker3.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot4);
        double double6 = intervalMarker3.getEndValue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.text.NumberFormat numberFormat4 = numberAxis3D3.getNumberFormatOverride();
        numberAxis3D3.setMinorTickMarkOutsideLength((float) '#');
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D3);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) numberAxis3D3, false);
        boolean boolean10 = rendererChangeEvent9.getSeriesVisibilityChanged();
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart12, (int) (short) 100, 0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart17 = multiplePiePlot16.getPieChart();
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart17.getTitle();
        chartProgressEvent15.setChart(jFreeChart17);
        org.jfree.chart.JFreeChart jFreeChart20 = chartProgressEvent15.getChart();
        rendererChangeEvent9.setChart(jFreeChart20);
        waferMapPlot1.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer23 = null;
        waferMapPlot1.setRenderer(waferMapRenderer23);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jFreeChart17);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertNotNull(jFreeChart20);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        boolean boolean4 = xYBarRenderer1.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYBarRenderer1.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter9 = xYBarRenderer1.getBarPainter();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNotNull(xYBarPainter9);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        long long4 = segmentedTimeline0.getExceptionSegmentCount((-2208960000000L), (long) 10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator9 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat8);
        java.lang.String str11 = logFormat4.format((double) 100);
        java.lang.String str13 = logFormat4.format((double) 255);
        logFormat4.setMinimumIntegerDigits((int) (byte) -1);
        java.util.Currency currency16 = null;
        try {
            logFormat4.setCurrency(currency16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!^�" + "'", str11.equals("hi!^�"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!^�" + "'", str13.equals("hi!^�"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        int int3 = categoryPlot0.getIndexOf(categoryItemRenderer2);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        int int7 = categoryPlot0.getRendererCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot8.getPieChart();
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer3D11.setPositiveItemLabelPositionFallback(itemLabelPosition12);
        java.awt.Font font14 = barRenderer3D11.getBaseItemLabelFont();
        textTitle10.setFont(font14);
        boolean boolean16 = textTitle10.getNotify();
        java.lang.String str17 = textTitle10.getToolTipText();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator21 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer19.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator21);
        java.awt.Stroke stroke23 = xYBarRenderer19.getBaseOutlineStroke();
        org.jfree.data.time.TimeSeries timeSeries24 = null;
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection26 = new org.jfree.data.time.TimeSeriesCollection(timeSeries24, timeZone25);
        int int27 = timeSeriesCollection26.getSeriesCount();
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection26, false);
        timeSeriesCollection26.validateObject();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = null;
        timeSeriesCollection26.seriesChanged(seriesChangeEvent31);
        org.jfree.data.Range range33 = xYBarRenderer19.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection26);
        boolean boolean34 = textTitle10.equals((java.lang.Object) xYBarRenderer19);
        java.awt.Stroke stroke38 = xYBarRenderer19.getItemStroke(2, (int) '4', true);
        categoryPlot0.setRangeZeroBaselineStroke(stroke38);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, true);
        categoryPlot0.setRangePannable(false);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        barRenderer3D0.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, rectangle2D11, (double) (byte) -1, (java.awt.Paint) color20, stroke41);
        java.awt.Paint paint44 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        barRenderer3D0.setShadowPaint(paint44);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = barRenderer3D0.getSeriesURLGenerator(0);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(categoryURLGenerator47);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        java.util.List list4 = combinedDomainXYPlot0.getAnnotations();
        java.lang.Object obj5 = combinedDomainXYPlot0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = combinedDomainXYPlot0.getDomainAxisEdge((int) (short) 10);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone11 = dateAxis10.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone11;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9, timeZone11);
        long long14 = timeSeries9.getMaximumItemAge();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek(1);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        barRenderer3D15.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        java.awt.Font font18 = barRenderer3D15.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer3D15.setSeriesURLGenerator(0, categoryURLGenerator20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Color color50 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer52 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        xYBarRenderer52.notifyListeners(rendererChangeEvent53);
        java.awt.Stroke stroke56 = xYBarRenderer52.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer43.drawDomainLine(graphics2D44, xYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D48, (double) 100, (java.awt.Paint) color50, stroke56);
        barRenderer3D15.drawRangeLine(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, rectangle2D26, (double) (byte) -1, (java.awt.Paint) color35, stroke56);
        xYStepRenderer0.setBaseOutlineStroke(stroke56, true);
        xYStepRenderer0.clearSeriesPaints(false);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator64 = new org.jfree.chart.urls.StandardXYURLGenerator();
        xYStepRenderer0.setSeriesURLGenerator((int) (short) 0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator64);
        boolean boolean66 = xYStepRenderer0.getUseOutlinePaint();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (-3.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        combinedDomainXYPlot0.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator8 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer6.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator8);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer6.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator11, true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        combinedDomainXYPlot15.datasetChanged(datasetChangeEvent16);
        java.awt.Stroke stroke18 = combinedDomainXYPlot15.getRangeCrosshairStroke();
        boolean boolean19 = combinedDomainXYPlot15.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis21);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker26.setLabelAnchor(rectangleAnchor27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = valueMarker26.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYBarRenderer6.drawDomainMarker(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis24, (org.jfree.chart.plot.Marker) valueMarker26, rectangle2D30);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker26, layer32);
        java.awt.Stroke stroke34 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = combinedDomainXYPlot0.getRangeAxisEdge(15);
        java.awt.Paint paint37 = combinedDomainXYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot8.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer12.notifyListeners(rendererChangeEvent13);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesStroke(0);
        combinedDomainXYPlot8.setDomainMinorGridlineStroke(stroke16);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        java.util.Locale locale33 = periodAxis22.getLocale();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.Paint paint36 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer1.drawDomainLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D34, (double) (short) 10, paint36, stroke37);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer39 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.awt.Color color46 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer48 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent49 = null;
        xYBarRenderer48.notifyListeners(rendererChangeEvent49);
        java.awt.Stroke stroke52 = xYBarRenderer48.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer39.drawDomainLine(graphics2D40, xYPlot41, (org.jfree.chart.axis.ValueAxis) periodAxis43, rectangle2D44, (double) 100, (java.awt.Paint) color46, stroke52);
        boolean boolean56 = xYStepRenderer39.getItemShapeVisible(100, 0);
        java.awt.Shape shape57 = xYStepRenderer39.getLegendLine();
        xYStepRenderer39.setBaseShapesFilled(true);
        combinedDomainXYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer39);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder61 = combinedDomainXYPlot8.getSeriesRenderingOrder();
        boolean boolean62 = combinedDomainXYPlot8.isRangeZoomable();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(seriesRenderingOrder61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition4);
        java.awt.Font font6 = barRenderer3D3.getBaseItemLabelFont();
        textTitle2.setFont(font6);
        boolean boolean8 = textTitle2.getNotify();
        java.lang.String str9 = textTitle2.getToolTipText();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator13 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer11.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator13);
        java.awt.Stroke stroke15 = xYBarRenderer11.getBaseOutlineStroke();
        org.jfree.data.time.TimeSeries timeSeries16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeSeries16, timeZone17);
        int int19 = timeSeriesCollection18.getSeriesCount();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection18, false);
        timeSeriesCollection18.validateObject();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = null;
        timeSeriesCollection18.seriesChanged(seriesChangeEvent23);
        org.jfree.data.Range range25 = xYBarRenderer11.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        boolean boolean26 = textTitle2.equals((java.lang.Object) xYBarRenderer11);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator30 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer28.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator30);
        xYBarRenderer28.removeAnnotations();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer33 = xYBarRenderer28.getGradientPaintTransformer();
        java.awt.Paint paint37 = xYBarRenderer28.getItemOutlinePaint((int) (short) 100, (int) (short) 10, false);
        java.awt.Shape shape38 = xYBarRenderer28.getLegendBar();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape38, rectangleAnchor39, (double) 10, (double) 100);
        xYBarRenderer11.setBaseLegendShape(shape38);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(shape42);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemLineVisible((int) ' ', (int) (byte) -1);
        org.jfree.chart.LegendItem legendItem20 = xYStepRenderer0.getLegendItem(2019, 1);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator22 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        boolean boolean23 = standardXYToolTipGenerator21.equals((java.lang.Object) standardPieSectionLabelGenerator22);
        xYStepRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator21, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        boolean boolean3 = standardXYToolTipGenerator1.equals((java.lang.Object) standardPieSectionLabelGenerator2);
        boolean boolean4 = shapeList0.equals((java.lang.Object) standardXYToolTipGenerator1);
        java.awt.Shape shape6 = shapeList0.getShape(1);
        shapeList0.clear();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(shape6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        polarPlot0.removeCornerTextItem("30");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Layer.FOREGROUND", font5);
        java.lang.Object obj7 = labelBlock6.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot8.getPieChart();
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        labelBlock6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = labelBlock6.getContentAlignmentPoint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString17 = null;
        standardPieSectionLabelGenerator15.setAttributedLabel(14, attributedString17);
        java.text.AttributedString attributedString20 = standardPieSectionLabelGenerator15.getAttributedLabel(15);
        boolean boolean21 = labelBlock6.equals((java.lang.Object) attributedString20);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNull(attributedString20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day7);
        java.lang.String str10 = timeSeries9.getDescription();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        java.awt.Stroke stroke5 = xYBarRenderer1.getBaseOutlineStroke();
        xYBarRenderer1.setBarAlignmentFactor(30.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator14 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer12.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator14);
        xYBarRenderer12.removeAnnotations();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat21 = null;
        logAxis20.setNumberFormatOverride(numberFormat21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color26 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYBarRenderer28.notifyListeners(rendererChangeEvent29);
        boolean boolean31 = xYBarRenderer28.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = xYBarRenderer28.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesStroke(0);
        xYBarRenderer28.setBaseStroke(stroke41, false);
        xYBarRenderer12.drawRangeLine(graphics2D17, xYPlot18, (org.jfree.chart.axis.ValueAxis) logAxis20, rectangle2D23, (-1.0d), (java.awt.Paint) color26, stroke41);
        piePlot3D9.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke41);
        boolean boolean46 = piePlot3D9.getSectionOutlinesVisible();
        boolean boolean47 = xYBarRenderer1.hasListener((java.util.EventListener) piePlot3D9);
        piePlot3D9.setDepthFactor((double) 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(xYURLGenerator35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        timeSeriesCollection2.validateObject();
        org.jfree.data.Range range8 = timeSeriesCollection2.getDomainBounds(true);
        timeSeriesCollection2.validateObject();
        java.lang.String[] strArray12 = new java.lang.String[] { "Layer.FOREGROUND" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("Layer.FOREGROUND", strArray12);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        barRenderer3D14.setPositiveItemLabelPositionFallback(itemLabelPosition15);
        java.awt.Font font17 = barRenderer3D14.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer3D14.setSeriesURLGenerator(0, categoryURLGenerator19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer27 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.Color color34 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        xYBarRenderer36.notifyListeners(rendererChangeEvent37);
        java.awt.Stroke stroke40 = xYBarRenderer36.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer27.drawDomainLine(graphics2D28, xYPlot29, (org.jfree.chart.axis.ValueAxis) periodAxis31, rectangle2D32, (double) 100, (java.awt.Paint) color34, stroke40);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer42 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis46 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.Color color49 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer51 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = null;
        xYBarRenderer51.notifyListeners(rendererChangeEvent52);
        java.awt.Stroke stroke55 = xYBarRenderer51.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer42.drawDomainLine(graphics2D43, xYPlot44, (org.jfree.chart.axis.ValueAxis) periodAxis46, rectangle2D47, (double) 100, (java.awt.Paint) color49, stroke55);
        barRenderer3D14.drawRangeLine(graphics2D21, categoryPlot22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, rectangle2D25, (double) (byte) -1, (java.awt.Paint) color34, stroke55);
        symbolAxis13.setGridBandAlternatePaint((java.awt.Paint) color34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D60.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer64 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator66 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer64.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator66);
        java.awt.Stroke stroke68 = xYBarRenderer64.getBaseOutlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) symbolAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer64);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand70 = null;
        symbolAxis13.setMarkerBand(markerAxisBand70);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setTickMarksVisible(false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        boolean boolean2 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) '4', plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list9 = categoryPlot8.getAnnotations();
        categoryPlot8.setRangeCrosshairLockedOnData(true);
        boolean boolean12 = categoryPlot8.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        combinedDomainXYPlot15.datasetChanged(datasetChangeEvent16);
        java.awt.Stroke stroke18 = combinedDomainXYPlot15.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator23 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer21.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator23);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator26 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer21.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator26, true);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        combinedDomainXYPlot30.datasetChanged(datasetChangeEvent31);
        java.awt.Stroke stroke33 = combinedDomainXYPlot30.getRangeCrosshairStroke();
        boolean boolean34 = combinedDomainXYPlot30.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis36 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot30.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis36);
        org.jfree.chart.axis.PeriodAxis periodAxis39 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker41.setLabelAnchor(rectangleAnchor42);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = valueMarker41.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        xYBarRenderer21.drawDomainMarker(graphics2D29, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis39, (org.jfree.chart.plot.Marker) valueMarker41, rectangle2D45);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot47 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot47.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str54 = layer53.toString();
        combinedDomainXYPlot47.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker52, layer53);
        combinedDomainXYPlot15.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker41, layer53);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = combinedDomainXYPlot15.getRangeAxisEdge(12);
        axisSpace13.add((double) 5, rectangleEdge58);
        categoryPlot8.setFixedRangeAxisSpace(axisSpace13, false);
        categoryPlot0.setFixedDomainAxisSpace(axisSpace13);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator26);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Layer.FOREGROUND" + "'", str54.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.text.NumberFormat numberFormat4 = numberAxis3D3.getNumberFormatOverride();
        numberAxis3D3.setMinorTickMarkOutsideLength((float) '#');
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D3);
        java.awt.Paint paint8 = numberAxis3D3.getTickMarkPaint();
        legendItem1.setLinePaint(paint8);
        org.jfree.data.general.Dataset dataset10 = legendItem1.getDataset();
        java.awt.Paint paint11 = legendItem1.getOutlinePaint();
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        int int3 = jFreeChart1.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart1.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart1.getPadding();
        double double7 = rectangleInsets5.calculateLeftOutset(Double.NaN);
        double double8 = rectangleInsets5.getTop();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        barRenderer3D15.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        java.awt.Font font18 = barRenderer3D15.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer3D15.setSeriesURLGenerator(0, categoryURLGenerator20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Color color50 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer52 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        xYBarRenderer52.notifyListeners(rendererChangeEvent53);
        java.awt.Stroke stroke56 = xYBarRenderer52.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer43.drawDomainLine(graphics2D44, xYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D48, (double) 100, (java.awt.Paint) color50, stroke56);
        barRenderer3D15.drawRangeLine(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, rectangle2D26, (double) (byte) -1, (java.awt.Paint) color35, stroke56);
        xYStepRenderer0.setBaseOutlineStroke(stroke56, true);
        xYStepRenderer0.clearSeriesPaints(false);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator64 = new org.jfree.chart.urls.StandardXYURLGenerator();
        xYStepRenderer0.setSeriesURLGenerator((int) (short) 0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator64);
        java.awt.Shape shape66 = xYStepRenderer0.getLegendLine();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator67 = xYStepRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator67);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMaximumLabelWidth();
        java.awt.Color color3 = java.awt.Color.CYAN;
        piePlot3D1.setLabelPaint((java.awt.Paint) color3);
        double double5 = piePlot3D1.getInteriorGap();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14d + "'", double2 == 0.14d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 2019, 0.025d, (double) (short) -1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator9 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer7.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator9);
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYBarRenderer7.setBasePaint(paint11);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYBarRenderer15.setBaseOutlinePaint((java.awt.Paint) color16);
        java.awt.color.ColorSpace colorSpace18 = color16.getColorSpace();
        xYBarRenderer7.setSeriesPaint((int) (byte) 1, (java.awt.Paint) color16);
        categoryPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace18);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot8.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer12.notifyListeners(rendererChangeEvent13);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesStroke(0);
        combinedDomainXYPlot8.setDomainMinorGridlineStroke(stroke16);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        java.util.Locale locale33 = periodAxis22.getLocale();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.Paint paint36 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer1.drawDomainLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D34, (double) (short) 10, paint36, stroke37);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator39 = null;
        xYBarRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator39, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator43 = xYBarRenderer1.getSeriesToolTipGenerator((-1));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(xYToolTipGenerator43);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        barRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition4);
        java.awt.Font font6 = barRenderer3D3.getBaseItemLabelFont();
        textTitle2.setFont(font6);
        boolean boolean8 = textTitle2.getNotify();
        java.lang.String str9 = textTitle2.getToolTipText();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator13 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer11.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator13);
        java.awt.Stroke stroke15 = xYBarRenderer11.getBaseOutlineStroke();
        org.jfree.data.time.TimeSeries timeSeries16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeSeries16, timeZone17);
        int int19 = timeSeriesCollection18.getSeriesCount();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection18, false);
        timeSeriesCollection18.validateObject();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = null;
        timeSeriesCollection18.seriesChanged(seriesChangeEvent23);
        org.jfree.data.Range range25 = xYBarRenderer11.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        boolean boolean26 = textTitle2.equals((java.lang.Object) xYBarRenderer11);
        boolean boolean27 = textTitle2.getNotify();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        int int1 = defaultXYDataset0.getSeriesCount();
        try {
            java.lang.Number number4 = defaultXYDataset0.getY(0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 100, (double) 24234L);
        double double3 = xYDataItem2.getXValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        int int5 = xYDataItem2.compareTo((java.lang.Object) lengthAdjustmentType4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.text.TextAnchor textAnchor9 = itemLabelPosition7.getRotationAnchor();
        java.lang.String str10 = textAnchor9.toString();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.CENTER" + "'", str10.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator4, false);
        barRenderer3D0.setDrawBarOutline(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = barRenderer3D0.getPlot();
        org.junit.Assert.assertNull(categoryPlot9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYBarRenderer11.notifyListeners(rendererChangeEvent12);
        java.awt.Stroke stroke15 = xYBarRenderer11.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer2.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis6, rectangle2D7, (double) 100, (java.awt.Paint) color9, stroke15);
        boolean boolean19 = xYStepRenderer2.getItemShapeVisible(100, 0);
        java.awt.Shape shape20 = xYStepRenderer2.getLegendLine();
        periodAxis1.setDownArrow(shape20);
        periodAxis1.setUpperMargin((double) 3);
        periodAxis1.configure();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setAxisLineVisible(false);
        java.awt.Paint paint4 = numberAxis3D1.getTickMarkPaint();
        java.awt.Paint paint5 = null;
        try {
            numberAxis3D1.setTickMarkPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        double double2 = crosshairState1.getCrosshairDistance();
        crosshairState1.updateCrosshairX((double) 0L);
        crosshairState1.setCrosshairDistance((double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean4 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.lang.String str8 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.plot.CrosshairState crosshairState10 = new org.jfree.chart.plot.CrosshairState(true);
        double double11 = crosshairState10.getCrosshairDistance();
        crosshairState10.updateCrosshairX((double) 0L);
        crosshairState10.updateCrosshairX((double) 5);
        boolean boolean16 = combinedDomainXYPlot0.equals((java.lang.Object) crosshairState10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D18.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator24 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer22.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator24);
        xYBarRenderer22.removeAnnotations();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = null;
        org.jfree.chart.axis.LogAxis logAxis30 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat31 = null;
        logAxis30.setNumberFormatOverride(numberFormat31);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color36 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer38 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        xYBarRenderer38.notifyListeners(rendererChangeEvent39);
        boolean boolean41 = xYBarRenderer38.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator45 = xYBarRenderer38.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer47 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent48 = null;
        xYBarRenderer47.notifyListeners(rendererChangeEvent48);
        java.awt.Stroke stroke51 = xYBarRenderer47.lookupSeriesStroke(0);
        xYBarRenderer38.setBaseStroke(stroke51, false);
        xYBarRenderer22.drawRangeLine(graphics2D27, xYPlot28, (org.jfree.chart.axis.ValueAxis) logAxis30, rectangle2D33, (-1.0d), (java.awt.Paint) color36, stroke51);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        combinedDomainXYPlot55.datasetChanged(datasetChangeEvent56);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer59 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator61 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer59.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator61);
        xYBarRenderer59.removeAnnotations();
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = null;
        org.jfree.chart.axis.LogAxis logAxis67 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat68 = null;
        logAxis67.setNumberFormatOverride(numberFormat68);
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        java.awt.Color color73 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer75 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent76 = null;
        xYBarRenderer75.notifyListeners(rendererChangeEvent76);
        boolean boolean78 = xYBarRenderer75.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator82 = xYBarRenderer75.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer84 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent85 = null;
        xYBarRenderer84.notifyListeners(rendererChangeEvent85);
        java.awt.Stroke stroke88 = xYBarRenderer84.lookupSeriesStroke(0);
        xYBarRenderer75.setBaseStroke(stroke88, false);
        xYBarRenderer59.drawRangeLine(graphics2D64, xYPlot65, (org.jfree.chart.axis.ValueAxis) logAxis67, rectangle2D70, (-1.0d), (java.awt.Paint) color73, stroke88);
        org.jfree.data.Range range92 = combinedDomainXYPlot55.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis67);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray93 = new org.jfree.chart.axis.ValueAxis[] { numberAxis3D18, logAxis30, logAxis67 };
        combinedDomainXYPlot0.setRangeAxes(valueAxisArray93);
        boolean boolean95 = combinedDomainXYPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.util.Layer layer97 = null;
        java.util.Collection collection98 = combinedDomainXYPlot0.getDomainMarkers(6, layer97);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Combined_Domain_XYPlot" + "'", str8.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(xYURLGenerator45);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNull(xYURLGenerator82);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNull(range92);
        org.junit.Assert.assertNotNull(valueAxisArray93);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNull(collection98);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        boolean boolean2 = polarPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.setBaseItemLabelsVisible(false, true);
        xYBarRenderer1.setDrawBarOutline(false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = new org.jfree.chart.axis.NumberTickUnit((double) 97, (java.text.NumberFormat) logFormat6);
        defaultKeyedValues0.addValue((java.lang.Comparable) numberTickUnit12, (java.lang.Number) (byte) 100);
        org.jfree.chart.util.SortOrder sortOrder15 = null;
        try {
            defaultKeyedValues0.sortByValues(sortOrder15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (-3.0d));
        try {
            timeSeries3.add(timeSeriesDataItem11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        int int15 = periodAxis4.getMinorTickCount();
        java.util.Locale locale16 = periodAxis4.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = periodAxis4.getStandardTickUnits();
        periodAxis4.resizeRange(8.0d, 12.0d);
        java.lang.String str21 = periodAxis4.getLabelToolTip();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNull(tickUnitSource17);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0L, (double) (byte) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator2 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator4 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!^�");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator2, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator4);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator4);
        java.awt.Stroke stroke7 = xYStepAreaRenderer6.getBaseStroke();
        java.lang.Object obj8 = xYStepAreaRenderer6.clone();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getYear();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day5, (double) 9999);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) day5, 0.0d);
        int int12 = defaultPieDataset0.getIndex((java.lang.Comparable) 9999);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.NumberFormat numberFormat1 = standardXYToolTipGenerator0.getXFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.lang.String str3 = textAnchor2.toString();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0f, "", textAnchor2, textAnchor4, Double.NaN);
        double double7 = numberTick6.getValue();
        java.lang.Number number8 = numberTick6.getNumber();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str3.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 2.0f + "'", number8.equals(2.0f));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setTickLabelsVisible(false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) '#');
        java.lang.Object obj2 = xYAreaRenderer1.clone();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator4 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        boolean boolean5 = xYAreaRenderer1.equals((java.lang.Object) standardXYSeriesLabelGenerator4);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot7.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        combinedDomainXYPlot7.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        combinedDomainXYPlot7.setOutlineStroke(stroke16);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        java.util.Locale locale33 = periodAxis22.getLocale();
        periodAxis22.setMinorTickMarksVisible(true);
        boolean boolean36 = combinedDomainXYPlot7.equals((java.lang.Object) periodAxis22);
        java.awt.Paint paint37 = periodAxis22.getAxisLinePaint();
        xYAreaRenderer1.setSeriesFillPaint(9999, paint37);
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer41 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D42 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = null;
        barRenderer3D42.setPositiveItemLabelPositionFallback(itemLabelPosition43);
        java.awt.Font font45 = barRenderer3D42.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = null;
        barRenderer3D42.setSeriesURLGenerator(0, categoryURLGenerator47);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = barRenderer3D42.getLegendItemLabelGenerator();
        boolean boolean50 = standardGradientPaintTransformer41.equals((java.lang.Object) categorySeriesLabelGenerator49);
        legendItem40.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer41);
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer41);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean2 = dateRange0.intersects((org.jfree.data.Range) dateRange1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart4);
        boolean boolean6 = jFreeChart4.isNotify();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker8.setLabelAnchor(rectangleAnchor9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = valueMarker8.getLabelOffset();
        double double13 = rectangleInsets11.calculateRightOutset((double) 2);
        jFreeChart4.setPadding(rectangleInsets11);
        int int15 = jFreeChart4.getBackgroundImageAlignment();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) dateRange1, jFreeChart4, (int) (short) 0, (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        java.lang.Object obj15 = periodAxis4.clone();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer3D1.setPositiveItemLabelPositionFallback(itemLabelPosition2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3D1.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer3D1.getToolTipGenerator((int) (short) 10, 8, true);
        double double11 = barRenderer3D1.getXOffset();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        barRenderer3D13.setPositiveItemLabelPositionFallback(itemLabelPosition14);
        java.awt.Font font16 = barRenderer3D13.getBaseItemLabelFont();
        barRenderer3D1.setSeriesItemLabelFont((int) (short) 1, font16);
        java.awt.Paint paint18 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer21 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.CENTER", font16, paint18, (float) 10L, 10, textMeasurer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 12.0d + "'", double11 == 12.0d);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot8.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer12.notifyListeners(rendererChangeEvent13);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesStroke(0);
        combinedDomainXYPlot8.setDomainMinorGridlineStroke(stroke16);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        java.util.Locale locale33 = periodAxis22.getLocale();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.Paint paint36 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer1.drawDomainLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D34, (double) (short) 10, paint36, stroke37);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer39 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.awt.Color color46 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer48 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent49 = null;
        xYBarRenderer48.notifyListeners(rendererChangeEvent49);
        java.awt.Stroke stroke52 = xYBarRenderer48.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer39.drawDomainLine(graphics2D40, xYPlot41, (org.jfree.chart.axis.ValueAxis) periodAxis43, rectangle2D44, (double) 100, (java.awt.Paint) color46, stroke52);
        boolean boolean56 = xYStepRenderer39.getItemShapeVisible(100, 0);
        java.awt.Shape shape57 = xYStepRenderer39.getLegendLine();
        xYStepRenderer39.setBaseShapesFilled(true);
        combinedDomainXYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer39);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder61 = combinedDomainXYPlot8.getSeriesRenderingOrder();
        org.jfree.data.xy.XYDataset xYDataset63 = combinedDomainXYPlot8.getDataset((-14666742));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(seriesRenderingOrder61);
        org.junit.Assert.assertNull(xYDataset63);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) '#', categoryItemLabelGenerator8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list12 = categoryPlot11.getAnnotations();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        boolean boolean15 = categoryPlot11.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray16 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot11.setDomainAxes(categoryAxisArray16);
        int int18 = categoryPlot11.getDomainAxisCount();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            barRenderer3D0.drawBackground(graphics2D10, categoryPlot11, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        periodAxis1.setAutoRange(false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("LengthConstraintType.NONE");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot2.getPieChart();
        float float4 = multiplePiePlot2.getBackgroundImageAlpha();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot5.getPieChart();
        multiplePiePlot2.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot8.getPieChart();
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        barRenderer3D11.setPositiveItemLabelPositionFallback(itemLabelPosition12);
        java.awt.Font font14 = barRenderer3D11.getBaseItemLabelFont();
        textTitle10.setFont(font14);
        jFreeChart6.addSubtitle((org.jfree.chart.title.Title) textTitle10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle10.getHorizontalAlignment();
        textTitle1.setHorizontalAlignment(horizontalAlignment17);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNotNull(jFreeChart6);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean4 = combinedDomainXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.lang.String str8 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.plot.CrosshairState crosshairState10 = new org.jfree.chart.plot.CrosshairState(true);
        double double11 = crosshairState10.getCrosshairDistance();
        crosshairState10.updateCrosshairX((double) 0L);
        crosshairState10.updateCrosshairX((double) 5);
        boolean boolean16 = combinedDomainXYPlot0.equals((java.lang.Object) crosshairState10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D18.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator24 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer22.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator24);
        xYBarRenderer22.removeAnnotations();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = null;
        org.jfree.chart.axis.LogAxis logAxis30 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat31 = null;
        logAxis30.setNumberFormatOverride(numberFormat31);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color36 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer38 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        xYBarRenderer38.notifyListeners(rendererChangeEvent39);
        boolean boolean41 = xYBarRenderer38.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator45 = xYBarRenderer38.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer47 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent48 = null;
        xYBarRenderer47.notifyListeners(rendererChangeEvent48);
        java.awt.Stroke stroke51 = xYBarRenderer47.lookupSeriesStroke(0);
        xYBarRenderer38.setBaseStroke(stroke51, false);
        xYBarRenderer22.drawRangeLine(graphics2D27, xYPlot28, (org.jfree.chart.axis.ValueAxis) logAxis30, rectangle2D33, (-1.0d), (java.awt.Paint) color36, stroke51);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        combinedDomainXYPlot55.datasetChanged(datasetChangeEvent56);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer59 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator61 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer59.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator61);
        xYBarRenderer59.removeAnnotations();
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = null;
        org.jfree.chart.axis.LogAxis logAxis67 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat68 = null;
        logAxis67.setNumberFormatOverride(numberFormat68);
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        java.awt.Color color73 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer75 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent76 = null;
        xYBarRenderer75.notifyListeners(rendererChangeEvent76);
        boolean boolean78 = xYBarRenderer75.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator82 = xYBarRenderer75.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer84 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent85 = null;
        xYBarRenderer84.notifyListeners(rendererChangeEvent85);
        java.awt.Stroke stroke88 = xYBarRenderer84.lookupSeriesStroke(0);
        xYBarRenderer75.setBaseStroke(stroke88, false);
        xYBarRenderer59.drawRangeLine(graphics2D64, xYPlot65, (org.jfree.chart.axis.ValueAxis) logAxis67, rectangle2D70, (-1.0d), (java.awt.Paint) color73, stroke88);
        org.jfree.data.Range range92 = combinedDomainXYPlot55.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis67);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray93 = new org.jfree.chart.axis.ValueAxis[] { numberAxis3D18, logAxis30, logAxis67 };
        combinedDomainXYPlot0.setRangeAxes(valueAxisArray93);
        boolean boolean95 = combinedDomainXYPlot0.isRangeMinorGridlinesVisible();
        combinedDomainXYPlot0.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Combined_Domain_XYPlot" + "'", str8.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(xYURLGenerator45);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNull(xYURLGenerator82);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNull(range92);
        org.junit.Assert.assertNotNull(valueAxisArray93);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeries3.add((java.lang.Number) 255, (java.lang.Number) 0.2d);
        double double15 = xYSeries3.getMaxX();
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 255.0d + "'", double15 == 255.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            defaultPieDataset0.remove((java.lang.Comparable) "RectangleEdge.LEFT");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (RectangleEdge.LEFT) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart1, (int) (short) 100, 0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot5.getPieChart();
        org.jfree.chart.title.TextTitle textTitle7 = jFreeChart6.getTitle();
        chartProgressEvent4.setChart(jFreeChart6);
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11, timeZone12);
        org.jfree.chart.axis.AxisCollection axisCollection14 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list15 = axisCollection14.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis3D17.getTickLabelInsets();
        org.jfree.data.Range range19 = numberAxis3D17.getDefaultAutoRange();
        org.jfree.data.Range range21 = timeSeriesCollection13.getRangeBounds(list15, range19, false);
        axisState10.setTicks(list15);
        jFreeChart6.setSubtitles(list15);
        org.jfree.chart.event.ChartChangeListener chartChangeListener24 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart6);
        org.junit.Assert.assertNotNull(textTitle7);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 1, (float) (-946742400000L), 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setAxisLineVisible(false);
        java.awt.Font font5 = numberAxis3D2.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Layer.FOREGROUND", font5);
        java.lang.Object obj7 = labelBlock6.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot8.getPieChart();
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        labelBlock6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        org.jfree.chart.ui.ProjectInfo projectInfo14 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list15 = projectInfo14.getContributors();
        boolean boolean16 = labelBlock6.equals((java.lang.Object) list15);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(jFreeChart9);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(projectInfo14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        int int15 = periodAxis4.getMinorTickCount();
        java.util.Locale locale16 = periodAxis4.getLocale();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange((double) 100.0f, (double) 100L);
        boolean boolean23 = dateRange19.intersects((org.jfree.data.Range) dateRange22);
        periodAxis4.setRange((org.jfree.data.Range) dateRange19, false, false);
        boolean boolean27 = periodAxis4.isAxisLineVisible();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline1.getSegmentSize();
        int int3 = segmentedTimeline1.getGroupSegmentCount();
        segmentedTimeline1.setStartTime((long) 'a');
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType7 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType7, (int) 'a');
        int int10 = dateTickUnit9.getMultiple();
        java.util.Date date11 = dateAxis6.calculateHighestVisibleTickValue(dateTickUnit9);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment12 = segmentedTimeline1.getSegment(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2, serialDate13);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900000L + "'", long2 == 900000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 96 + "'", int3 == 96);
        org.junit.Assert.assertNotNull(dateTickUnitType7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(segment12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0.5f, 1.0E-8d, (double) 10.0f, (double) (short) -1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day5, (org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) month10);
        timeSeries9.removeAgedItems((long) 6, false);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        boolean boolean2 = categoryPlot0.isRangeZeroBaselineVisible();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo5, point2D6);
        java.lang.Comparable comparable8 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(comparable8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Stroke stroke2 = piePlot3D1.getLabelOutlineStroke();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor4 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 1);
        piePlot3D1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString8 = null;
        standardPieSectionLabelGenerator6.setAttributedLabel(14, attributedString8);
        piePlot3D1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator6);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator19 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer17.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator19);
        xYBarRenderer17.removeAnnotations();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = null;
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat26 = null;
        logAxis25.setNumberFormatOverride(numberFormat26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.Color color31 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYBarRenderer33.notifyListeners(rendererChangeEvent34);
        boolean boolean36 = xYBarRenderer33.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator40 = xYBarRenderer33.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer42 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent43 = null;
        xYBarRenderer42.notifyListeners(rendererChangeEvent43);
        java.awt.Stroke stroke46 = xYBarRenderer42.lookupSeriesStroke(0);
        xYBarRenderer33.setBaseStroke(stroke46, false);
        xYBarRenderer17.drawRangeLine(graphics2D22, xYPlot23, (org.jfree.chart.axis.ValueAxis) logAxis25, rectangle2D28, (-1.0d), (java.awt.Paint) color31, stroke46);
        piePlot3D14.setSectionOutlineStroke((java.lang.Comparable) (byte) 0, stroke46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.plot.PiePlotState piePlotState53 = piePlot3D1.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.PiePlot) piePlot3D14, (java.lang.Integer) 10, plotRenderingInfo52);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(xYURLGenerator40);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(piePlotState53);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState12 = xYSeriesCollection11.getSelectionState();
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState12);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        barRenderer3D15.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        java.awt.Font font18 = barRenderer3D15.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer3D15.setSeriesURLGenerator(0, categoryURLGenerator20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.Color color35 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYBarRenderer37.notifyListeners(rendererChangeEvent38);
        java.awt.Stroke stroke41 = xYBarRenderer37.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer28.drawDomainLine(graphics2D29, xYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis32, rectangle2D33, (double) 100, (java.awt.Paint) color35, stroke41);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis47 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.Color color50 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer52 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        xYBarRenderer52.notifyListeners(rendererChangeEvent53);
        java.awt.Stroke stroke56 = xYBarRenderer52.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer43.drawDomainLine(graphics2D44, xYPlot45, (org.jfree.chart.axis.ValueAxis) periodAxis47, rectangle2D48, (double) 100, (java.awt.Paint) color50, stroke56);
        barRenderer3D15.drawRangeLine(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, rectangle2D26, (double) (byte) -1, (java.awt.Paint) color35, stroke56);
        xYStepRenderer0.setBaseOutlineStroke(stroke56, true);
        xYStepRenderer0.clearSeriesPaints(false);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator64 = new org.jfree.chart.urls.StandardXYURLGenerator();
        xYStepRenderer0.setSeriesURLGenerator((int) (short) 0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator64);
        java.awt.Shape shape66 = xYStepRenderer0.getLegendLine();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot67 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent68 = null;
        combinedDomainXYPlot67.datasetChanged(datasetChangeEvent68);
        java.awt.Stroke stroke70 = combinedDomainXYPlot67.getRangeCrosshairStroke();
        java.awt.Stroke stroke71 = combinedDomainXYPlot67.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis73 = combinedDomainXYPlot67.getRangeAxis((int) (short) 0);
        java.util.List list74 = combinedDomainXYPlot67.getSubplots();
        double double75 = combinedDomainXYPlot67.getDomainCrosshairValue();
        boolean boolean76 = xYStepRenderer0.equals((java.lang.Object) combinedDomainXYPlot67);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(list74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat10 = null;
        logAxis9.setNumberFormatOverride(numberFormat10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYBarRenderer17.notifyListeners(rendererChangeEvent18);
        boolean boolean20 = xYBarRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer17.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYBarRenderer26.notifyListeners(rendererChangeEvent27);
        java.awt.Stroke stroke30 = xYBarRenderer26.lookupSeriesStroke(0);
        xYBarRenderer17.setBaseStroke(stroke30, false);
        xYBarRenderer1.drawRangeLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D12, (-1.0d), (java.awt.Paint) color15, stroke30);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator35 = xYBarRenderer1.getSeriesItemLabelGenerator(97);
        xYBarRenderer1.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator39 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator39);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(xYItemLabelGenerator35);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries3.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries3.add((double) (-14666742), (double) 97, true);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = xYSeries3.getNotify();
        org.junit.Assert.assertNull(xYDataItem6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot3.setDomainCrosshairVisible(true);
        combinedDomainXYPlot3.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator11 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer9.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator11);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer9.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14, true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        combinedDomainXYPlot18.datasetChanged(datasetChangeEvent19);
        java.awt.Stroke stroke21 = combinedDomainXYPlot18.getRangeCrosshairStroke();
        boolean boolean22 = combinedDomainXYPlot18.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis24);
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker29.setLabelAnchor(rectangleAnchor30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = valueMarker29.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        xYBarRenderer9.drawDomainMarker(graphics2D17, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot18, (org.jfree.chart.axis.ValueAxis) periodAxis27, (org.jfree.chart.plot.Marker) valueMarker29, rectangle2D33);
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot3.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker29, layer35);
        boolean boolean37 = axisLocation2.equals((java.lang.Object) valueMarker29);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str2 = verticalAlignment1.toString();
        boolean boolean3 = standardXYToolTipGenerator0.equals((java.lang.Object) verticalAlignment1);
        java.text.NumberFormat numberFormat4 = standardXYToolTipGenerator0.getXFormat();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.CENTER" + "'", str2.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = new org.jfree.chart.axis.NumberTickUnit((double) 97, (java.text.NumberFormat) logFormat6);
        defaultKeyedValues0.addValue((java.lang.Comparable) numberTickUnit12, (java.lang.Number) (byte) 100);
        org.jfree.data.xy.XYDataItem xYDataItem18 = new org.jfree.data.xy.XYDataItem((double) (byte) 100, (double) 24234L);
        java.lang.String str19 = xYDataItem18.toString();
        try {
            defaultKeyedValues0.insertValue((int) (short) -1, (java.lang.Comparable) str19, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[100.0, 24234.0]" + "'", str19.equals("[100.0, 24234.0]"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint2 = null;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) 8.0d, paint2);
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 10L, font5);
        categoryAxis3D0.setVisible(true);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat10);
        java.lang.String str13 = logFormat6.format((double) 100);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat6);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        xYBarRenderer16.notifyListeners(rendererChangeEvent17);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesStroke(0);
        java.awt.Paint paint21 = xYBarRenderer16.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYBarRenderer23.notifyListeners(rendererChangeEvent24);
        java.awt.Stroke stroke27 = xYBarRenderer23.lookupSeriesStroke(0);
        java.awt.Paint paint28 = xYBarRenderer23.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        combinedDomainXYPlot30.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYBarRenderer34.notifyListeners(rendererChangeEvent35);
        java.awt.Stroke stroke38 = xYBarRenderer34.lookupSeriesStroke(0);
        combinedDomainXYPlot30.setDomainMinorGridlineStroke(stroke38);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer40 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.Color color47 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        xYBarRenderer49.notifyListeners(rendererChangeEvent50);
        java.awt.Stroke stroke53 = xYBarRenderer49.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer40.drawDomainLine(graphics2D41, xYPlot42, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D45, (double) 100, (java.awt.Paint) color47, stroke53);
        java.util.Locale locale55 = periodAxis44.getLocale();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        java.awt.Paint paint58 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer23.drawDomainLine(graphics2D29, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D56, (double) (short) 10, paint58, stroke59);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer61 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis65 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.Color color68 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer70 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent71 = null;
        xYBarRenderer70.notifyListeners(rendererChangeEvent71);
        java.awt.Stroke stroke74 = xYBarRenderer70.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer61.drawDomainLine(graphics2D62, xYPlot63, (org.jfree.chart.axis.ValueAxis) periodAxis65, rectangle2D66, (double) 100, (java.awt.Paint) color68, stroke74);
        boolean boolean78 = xYStepRenderer61.getItemShapeVisible(100, 0);
        java.awt.Shape shape79 = xYStepRenderer61.getLegendLine();
        xYStepRenderer61.setBaseShapesFilled(true);
        combinedDomainXYPlot30.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer61);
        xYBarRenderer16.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot30);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot30);
        java.lang.String str85 = combinedDomainXYPlot30.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!^�" + "'", str13.equals("hi!^�"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(locale55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNull(str85);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        barRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
        java.awt.Font font3 = barRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer3D0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer3D0.setSeriesItemLabelGenerator(97, categoryItemLabelGenerator7, false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairVisible(true);
        combinedDomainXYPlot0.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator8 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer6.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator8);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer6.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator11, true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        combinedDomainXYPlot15.datasetChanged(datasetChangeEvent16);
        java.awt.Stroke stroke18 = combinedDomainXYPlot15.getRangeCrosshairStroke();
        boolean boolean19 = combinedDomainXYPlot15.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis21);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker26.setLabelAnchor(rectangleAnchor27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = valueMarker26.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYBarRenderer6.drawDomainMarker(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis24, (org.jfree.chart.plot.Marker) valueMarker26, rectangle2D30);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker26, layer32);
        java.awt.Stroke stroke34 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        java.lang.Object obj35 = combinedDomainXYPlot0.clone();
        org.jfree.data.xy.XYDataset xYDataset37 = combinedDomainXYPlot0.getDataset((int) (byte) -1);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(xYDataset37);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat10);
        java.lang.String str13 = logFormat6.format((double) 100);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat6);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        xYBarRenderer16.notifyListeners(rendererChangeEvent17);
        java.awt.Stroke stroke20 = xYBarRenderer16.lookupSeriesStroke(0);
        java.awt.Paint paint21 = xYBarRenderer16.getBaseItemLabelPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYBarRenderer23.notifyListeners(rendererChangeEvent24);
        java.awt.Stroke stroke27 = xYBarRenderer23.lookupSeriesStroke(0);
        java.awt.Paint paint28 = xYBarRenderer23.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        combinedDomainXYPlot30.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYBarRenderer34.notifyListeners(rendererChangeEvent35);
        java.awt.Stroke stroke38 = xYBarRenderer34.lookupSeriesStroke(0);
        combinedDomainXYPlot30.setDomainMinorGridlineStroke(stroke38);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer40 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.Color color47 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        xYBarRenderer49.notifyListeners(rendererChangeEvent50);
        java.awt.Stroke stroke53 = xYBarRenderer49.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer40.drawDomainLine(graphics2D41, xYPlot42, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D45, (double) 100, (java.awt.Paint) color47, stroke53);
        java.util.Locale locale55 = periodAxis44.getLocale();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        java.awt.Paint paint58 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer23.drawDomainLine(graphics2D29, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot30, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D56, (double) (short) 10, paint58, stroke59);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer61 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis65 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.Color color68 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer70 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent71 = null;
        xYBarRenderer70.notifyListeners(rendererChangeEvent71);
        java.awt.Stroke stroke74 = xYBarRenderer70.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer61.drawDomainLine(graphics2D62, xYPlot63, (org.jfree.chart.axis.ValueAxis) periodAxis65, rectangle2D66, (double) 100, (java.awt.Paint) color68, stroke74);
        boolean boolean78 = xYStepRenderer61.getItemShapeVisible(100, 0);
        java.awt.Shape shape79 = xYStepRenderer61.getLegendLine();
        xYStepRenderer61.setBaseShapesFilled(true);
        combinedDomainXYPlot30.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer61);
        xYBarRenderer16.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot30);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot30);
        double double85 = logAxis1.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker87 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker87.setLabelAnchor(rectangleAnchor88);
        org.jfree.chart.util.RectangleInsets rectangleInsets90 = valueMarker87.getLabelOffset();
        double double92 = rectangleInsets90.calculateRightOutset((double) 2);
        double double94 = rectangleInsets90.trimWidth((double) (-1));
        double double96 = rectangleInsets90.trimHeight((double) 3);
        logAxis1.setLabelInsets(rectangleInsets90, false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!^�" + "'", str13.equals("hi!^�"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(locale55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.05d + "'", double85 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleAnchor88);
        org.junit.Assert.assertNotNull(rectangleInsets90);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 3.0d + "'", double92 == 3.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + (-7.0d) + "'", double94 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + (-3.0d) + "'", double96 == (-3.0d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        xYBarRenderer1.removeAnnotations();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = xYBarRenderer1.getGradientPaintTransformer();
        double double7 = xYBarRenderer1.getMargin();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer1.setBaseStroke(stroke8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        java.awt.Stroke stroke3 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke4 = combinedDomainXYPlot0.getRangeCrosshairStroke();
        boolean boolean5 = combinedDomainXYPlot0.isRangeZeroBaselineVisible();
        combinedDomainXYPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.Plot plot8 = combinedDomainXYPlot0.getRootPlot();
        plot8.setNotify(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYBarRenderer1.notifyListeners(rendererChangeEvent2);
        java.awt.Stroke stroke5 = xYBarRenderer1.lookupSeriesStroke(0);
        java.awt.Paint paint6 = xYBarRenderer1.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot8.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYBarRenderer12.notifyListeners(rendererChangeEvent13);
        java.awt.Stroke stroke16 = xYBarRenderer12.lookupSeriesStroke(0);
        combinedDomainXYPlot8.setDomainMinorGridlineStroke(stroke16);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.Color color25 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYBarRenderer27.notifyListeners(rendererChangeEvent28);
        java.awt.Stroke stroke31 = xYBarRenderer27.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer18.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D23, (double) 100, (java.awt.Paint) color25, stroke31);
        java.util.Locale locale33 = periodAxis22.getLocale();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.Paint paint36 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYBarRenderer1.drawDomainLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D34, (double) (short) 10, paint36, stroke37);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer39 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.awt.Color color46 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer48 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent49 = null;
        xYBarRenderer48.notifyListeners(rendererChangeEvent49);
        java.awt.Stroke stroke52 = xYBarRenderer48.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer39.drawDomainLine(graphics2D40, xYPlot41, (org.jfree.chart.axis.ValueAxis) periodAxis43, rectangle2D44, (double) 100, (java.awt.Paint) color46, stroke52);
        boolean boolean56 = xYStepRenderer39.getItemShapeVisible(100, 0);
        java.awt.Shape shape57 = xYStepRenderer39.getLegendLine();
        xYStepRenderer39.setBaseShapesFilled(true);
        combinedDomainXYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer39);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder61 = combinedDomainXYPlot8.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation63 = combinedDomainXYPlot8.getDomainAxisLocation(4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(seriesRenderingOrder61);
        org.junit.Assert.assertNotNull(axisLocation63);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        java.awt.Stroke stroke5 = xYBarRenderer1.getBaseOutlineStroke();
        java.awt.Font font7 = xYBarRenderer1.lookupLegendTextFont((int) (short) -1);
        java.awt.Color color10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        xYBarRenderer1.setSeriesOutlinePaint(15, (java.awt.Paint) color10);
        boolean boolean12 = xYBarRenderer1.isDrawBarOutline();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator13 = null;
        xYBarRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator13, true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3D4.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        java.awt.Font font7 = barRenderer3D4.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer3D4.setSeriesURLGenerator(0, categoryURLGenerator9);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = barRenderer3D4.getLegendItemLabelGenerator();
        java.awt.Shape shape13 = barRenderer3D4.lookupSeriesShape((int) (byte) 10);
        java.awt.Color color14 = java.awt.Color.green;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "[100.0, 24234.0]", "October", "RectangleAnchor.CENTER", shape13, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) '#');
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer2);
        org.jfree.data.xy.XYSeries xYSeries7 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1L), false, true);
        org.jfree.data.xy.XYDataItem xYDataItem10 = xYSeries7.addOrUpdate((double) ' ', (double) (short) 10);
        xYSeries7.add((double) (-14666742), (double) 97, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection(xYSeries7);
        org.jfree.data.Range range16 = xYAreaRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        try {
            org.jfree.data.xy.XYSeries xYSeries18 = xYSeriesCollection15.getSeries((java.lang.Comparable) (-3.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: -3.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(xYDataItem10);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        segmentedTimeline0.setStartTime((long) 'a');
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType6, (int) 'a');
        int int9 = dateTickUnit8.getMultiple();
        java.util.Date date10 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline0.getSegment(date10);
        double[] doubleArray19 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray25 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[] doubleArray31 = new double[] { 0.2d, 5, 10.0f, (-1.0f), (-1L) };
        double[][] doubleArray32 = new double[][] { doubleArray19, doubleArray25, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Layer.FOREGROUND", "series", doubleArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset33, true);
        org.jfree.chart.axis.AxisState axisState37 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.data.time.TimeSeries timeSeries38 = null;
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection40 = new org.jfree.data.time.TimeSeriesCollection(timeSeries38, timeZone39);
        org.jfree.chart.axis.AxisCollection axisCollection41 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list42 = axisCollection41.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = numberAxis3D44.getTickLabelInsets();
        org.jfree.data.Range range46 = numberAxis3D44.getDefaultAutoRange();
        org.jfree.data.Range range48 = timeSeriesCollection40.getRangeBounds(list42, range46, false);
        axisState37.setTicks(list42);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset33, list42, true);
        segmentedTimeline0.addExceptions(list42);
        int int53 = segmentedTimeline0.getGroupSegmentCount();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 96 + "'", int53 == 96);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        java.awt.Shape shape8 = pieSectionEntity7.getArea();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        pieSectionEntity7.setURLText("[100.0, 24234.0]");
        java.lang.Comparable comparable12 = pieSectionEntity7.getSectionKey();
        java.lang.Comparable comparable13 = pieSectionEntity7.getSectionKey();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        pieSectionEntity7.setArea(shape14);
        java.awt.Shape shape16 = null;
        try {
            pieSectionEntity7.setArea(shape16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0L + "'", comparable12.equals(0L));
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0L + "'", comparable13.equals(0L));
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYBarRenderer1.getBaseToolTipGenerator();
        java.awt.Paint paint13 = xYBarRenderer1.getItemFillPaint((-16777216), (-14666742), true);
        java.awt.Paint paint15 = xYBarRenderer1.getSeriesPaint((int) (byte) -1);
        xYBarRenderer1.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYBarRenderer1.setBasePaint(paint5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYBarRenderer8.setBaseOutlinePaint((java.awt.Paint) color9);
        xYBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color9);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYBarRenderer1.setSeriesOutlinePaint(6, (java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isAngleGridlinesVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((-1.0d), plotRenderingInfo5, point2D6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        barRenderer3D0.setItemMargin(12.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getYear();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day5, (double) 9999);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) day5, 0.0d);
        double double11 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        xYBarRenderer9.notifyListeners(rendererChangeEvent10);
        java.awt.Stroke stroke13 = xYBarRenderer9.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer0.drawDomainLine(graphics2D1, xYPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis4, rectangle2D5, (double) 100, (java.awt.Paint) color7, stroke13);
        boolean boolean17 = xYStepRenderer0.getItemLineVisible((int) ' ', (int) (byte) -1);
        java.lang.Boolean boolean19 = xYStepRenderer0.getSeriesLinesVisible(29);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(boolean19);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat9 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat9);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit((double) 97, (java.text.NumberFormat) logFormat5);
        boolean boolean13 = numberTickUnit11.equals((java.lang.Object) "-4,-4,4,4");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) '#');
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer2);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType4 = standardGradientPaintTransformer2.getType();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator8 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer6.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator8);
        xYBarRenderer6.removeAnnotations();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat15 = null;
        logAxis14.setNumberFormatOverride(numberFormat15);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.Color color20 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        boolean boolean25 = xYBarRenderer22.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = xYBarRenderer22.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        xYBarRenderer31.notifyListeners(rendererChangeEvent32);
        java.awt.Stroke stroke35 = xYBarRenderer31.lookupSeriesStroke(0);
        xYBarRenderer22.setBaseStroke(stroke35, false);
        xYBarRenderer6.drawRangeLine(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) logAxis14, rectangle2D17, (-1.0d), (java.awt.Paint) color20, stroke35);
        boolean boolean39 = gradientPaintTransformType4.equals((java.lang.Object) graphics2D11);
        org.junit.Assert.assertNotNull(gradientPaintTransformType4);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(xYURLGenerator29);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getCategories();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint4 = null;
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) 8.0d, paint4);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis3D2.getTickLabelInsets();
        org.junit.Assert.assertNull(list1);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Color color8 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        xYBarRenderer10.notifyListeners(rendererChangeEvent11);
        java.awt.Stroke stroke14 = xYBarRenderer10.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer1.drawDomainLine(graphics2D2, xYPlot3, (org.jfree.chart.axis.ValueAxis) periodAxis5, rectangle2D6, (double) 100, (java.awt.Paint) color8, stroke14);
        int int16 = periodAxis5.getMinorTickCount();
        java.util.Locale locale17 = periodAxis5.getLocale();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale17);
        java.text.NumberFormat numberFormat19 = java.text.NumberFormat.getNumberInstance(locale17);
        java.lang.ClassLoader classLoader20 = null;
        try {
            java.util.ResourceBundle resourceBundle21 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("{0}", locale17, classLoader20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(locale17);
        org.junit.Assert.assertNotNull(numberFormat19);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setShadowVisible(false);
        java.awt.Stroke stroke4 = barRenderer3D0.lookupSeriesStroke(2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator3 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator3);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot10.datasetChanged(datasetChangeEvent11);
        java.awt.Stroke stroke13 = combinedDomainXYPlot10.getRangeCrosshairStroke();
        boolean boolean14 = combinedDomainXYPlot10.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis16);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker21.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker21.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYBarRenderer1.drawDomainMarker(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis19, (org.jfree.chart.plot.Marker) valueMarker21, rectangle2D25);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = valueMarker21.getLabelOffsetType();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D29.setAxisLineVisible(false);
        java.awt.Paint paint32 = numberAxis3D29.getTickMarkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis3D29.getTickLabelInsets();
        valueMarker21.setLabelOffset(rectangleInsets33);
        java.lang.Object obj35 = valueMarker21.clone();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(lengthAdjustmentType27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYBarRenderer4.notifyListeners(rendererChangeEvent5);
        java.awt.Stroke stroke8 = xYBarRenderer4.lookupSeriesStroke(0);
        combinedDomainXYPlot0.setDomainMinorGridlineStroke(stroke8);
        boolean boolean10 = combinedDomainXYPlot0.canSelectByRegion();
        combinedDomainXYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        combinedDomainXYPlot13.datasetChanged(datasetChangeEvent14);
        java.awt.Stroke stroke16 = combinedDomainXYPlot13.getRangeCrosshairStroke();
        java.awt.Stroke stroke17 = combinedDomainXYPlot13.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis19 = combinedDomainXYPlot13.getRangeAxis((int) (short) 0);
        java.util.List list20 = combinedDomainXYPlot13.getSubplots();
        double double21 = combinedDomainXYPlot13.getDomainCrosshairValue();
        combinedDomainXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat((double) (-1L), "hi!", true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator9 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat8);
        java.text.ParsePosition parsePosition11 = null;
        java.lang.Number number12 = logFormat4.parse("Combined_Domain_XYPlot", parsePosition11);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        float float2 = multiplePiePlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart4);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot6.getPieChart();
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart7.getTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer3D9.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Font font12 = barRenderer3D9.getBaseItemLabelFont();
        textTitle8.setFont(font12);
        jFreeChart4.addSubtitle((org.jfree.chart.title.Title) textTitle8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle8.getHorizontalAlignment();
        textTitle8.setPadding(2.0d, 0.0d, 0.0d, (double) 'a');
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedDomainXYPlot0.setFixedRangeAxisSpace(axisSpace3, true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedDomainXYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedDomainXYPlot8.datasetChanged(datasetChangeEvent9);
        java.awt.Stroke stroke11 = combinedDomainXYPlot8.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator16 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer14.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator16);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator19 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer14.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator19, true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        combinedDomainXYPlot23.datasetChanged(datasetChangeEvent24);
        java.awt.Stroke stroke26 = combinedDomainXYPlot23.getRangeCrosshairStroke();
        boolean boolean27 = combinedDomainXYPlot23.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot23.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis29);
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker34.setLabelAnchor(rectangleAnchor35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = valueMarker34.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        xYBarRenderer14.drawDomainMarker(graphics2D22, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.chart.axis.ValueAxis) periodAxis32, (org.jfree.chart.plot.Marker) valueMarker34, rectangle2D38);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot40.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str47 = layer46.toString();
        combinedDomainXYPlot40.addDomainMarker(12, (org.jfree.chart.plot.Marker) valueMarker45, layer46);
        combinedDomainXYPlot8.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker34, layer46);
        java.awt.Stroke stroke50 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker34.setStroke(stroke50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = valueMarker34.getLabelAnchor();
        java.lang.Object obj53 = valueMarker34.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = valueMarker34.getLabelOffsetType();
        org.jfree.chart.util.Layer layer55 = null;
        boolean boolean56 = combinedDomainXYPlot0.removeDomainMarker(96, (org.jfree.chart.plot.Marker) valueMarker34, layer55);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator19);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Layer.FOREGROUND" + "'", str47.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(lengthAdjustmentType54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.text.NumberFormat numberFormat4 = numberAxis3D3.getNumberFormatOverride();
        numberAxis3D3.setMinorTickMarkOutsideLength((float) '#');
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D3);
        java.awt.Paint paint8 = numberAxis3D3.getTickMarkPaint();
        legendItem1.setLinePaint(paint8);
        java.text.AttributedString attributedString10 = legendItem1.getAttributedLabel();
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(attributedString10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 60000L, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot9.setDomainCrosshairVisible(true);
        java.awt.Paint paint13 = combinedDomainXYPlot9.getQuadrantPaint((int) (byte) 1);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeSeries16, timeZone17);
        org.jfree.chart.axis.AxisCollection axisCollection19 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list20 = axisCollection19.getAxesAtLeft();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis3D22.getTickLabelInsets();
        org.jfree.data.Range range24 = numberAxis3D22.getDefaultAutoRange();
        org.jfree.data.Range range26 = timeSeriesCollection18.getRangeBounds(list20, range24, false);
        combinedDomainXYPlot9.drawRangeTickBands(graphics2D14, rectangle2D15, list20);
        org.jfree.chart.axis.ValueAxis valueAxis29 = combinedDomainXYPlot9.getDomainAxisForDataset(0);
        categoryPlot0.setRangeAxis(9999, valueAxis29, false);
        org.junit.Assert.assertNull(list1);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(valueAxis29);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) '4', 10, (java.lang.Comparable) 0L, "", "");
        pieSectionEntity7.setURLText("Layer.FOREGROUND");
        pieSectionEntity7.setToolTipText("RangeType.FULL");
        java.lang.Object obj12 = pieSectionEntity7.clone();
        java.lang.Comparable comparable13 = pieSectionEntity7.getSectionKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0L + "'", comparable13.equals(0L));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 100, (double) 24234L);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) xYDataItem2, false);
        java.lang.Number number7 = null;
        try {
            xYSeries5.updateByIndex(14, number7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 14, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 24234.0d + "'", number3.equals(24234.0d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        barRenderer3D4.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        java.awt.Font font7 = barRenderer3D4.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer3D4.setSeriesURLGenerator(0, categoryURLGenerator9);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = barRenderer3D4.getLegendItemLabelGenerator();
        java.awt.Shape shape13 = barRenderer3D4.lookupSeriesShape((int) (byte) 10);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        xYBarRenderer15.notifyListeners(rendererChangeEvent16);
        boolean boolean18 = xYBarRenderer15.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYBarRenderer15.getURLGenerator((int) ' ', (int) (short) 0, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer24 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        xYBarRenderer24.notifyListeners(rendererChangeEvent25);
        java.awt.Stroke stroke28 = xYBarRenderer24.lookupSeriesStroke(0);
        xYBarRenderer15.setBaseStroke(stroke28, false);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D34 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = null;
        barRenderer3D34.setPositiveItemLabelPositionFallback(itemLabelPosition35);
        java.awt.Font font37 = barRenderer3D34.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator39 = null;
        barRenderer3D34.setSeriesURLGenerator(0, categoryURLGenerator39);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator41 = barRenderer3D34.getLegendItemLabelGenerator();
        boolean boolean42 = standardGradientPaintTransformer33.equals((java.lang.Object) categorySeriesLabelGenerator41);
        legendItem32.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendItem32.setLinePaint((java.awt.Paint) color44);
        try {
            org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem(attributedString0, "", "PlotEntity: tooltip = null", "30", shape13, stroke28, (java.awt.Paint) color44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(xYURLGenerator22);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        int int3 = timeSeriesCollection2.getSeriesCount();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, false);
        timeSeriesCollection2.validateObject();
        org.jfree.data.Range range8 = timeSeriesCollection2.getDomainBounds(true);
        timeSeriesCollection2.validateObject();
        java.lang.String[] strArray12 = new java.lang.String[] { "Layer.FOREGROUND" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("Layer.FOREGROUND", strArray12);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D14 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        barRenderer3D14.setPositiveItemLabelPositionFallback(itemLabelPosition15);
        java.awt.Font font17 = barRenderer3D14.getBaseItemLabelFont();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer3D14.setSeriesURLGenerator(0, categoryURLGenerator19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer27 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.Color color34 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        xYBarRenderer36.notifyListeners(rendererChangeEvent37);
        java.awt.Stroke stroke40 = xYBarRenderer36.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer27.drawDomainLine(graphics2D28, xYPlot29, (org.jfree.chart.axis.ValueAxis) periodAxis31, rectangle2D32, (double) 100, (java.awt.Paint) color34, stroke40);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer42 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis46 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.Color color49 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer51 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = null;
        xYBarRenderer51.notifyListeners(rendererChangeEvent52);
        java.awt.Stroke stroke55 = xYBarRenderer51.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer42.drawDomainLine(graphics2D43, xYPlot44, (org.jfree.chart.axis.ValueAxis) periodAxis46, rectangle2D47, (double) 100, (java.awt.Paint) color49, stroke55);
        barRenderer3D14.drawRangeLine(graphics2D21, categoryPlot22, (org.jfree.chart.axis.ValueAxis) numberAxis3D24, rectangle2D25, (double) (byte) -1, (java.awt.Paint) color34, stroke55);
        symbolAxis13.setGridBandAlternatePaint((java.awt.Paint) color34);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D60.setAxisLineVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer64 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator66 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer64.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator66);
        java.awt.Stroke stroke68 = xYBarRenderer64.getBaseOutlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, (org.jfree.chart.axis.ValueAxis) symbolAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis3D60, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer64);
        xYBarRenderer64.setBaseItemLabelsVisible(true);
        java.awt.Paint paint75 = xYBarRenderer64.getItemFillPaint(7, (int) (byte) 10, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(paint75);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent1 = null;
        combinedDomainXYPlot0.datasetChanged(datasetChangeEvent1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYBarRenderer4.notifyListeners(rendererChangeEvent5);
        java.awt.Stroke stroke8 = xYBarRenderer4.lookupSeriesStroke(0);
        java.awt.Paint paint9 = xYBarRenderer4.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer4.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        combinedDomainXYPlot13.datasetChanged(datasetChangeEvent14);
        java.awt.Stroke stroke16 = combinedDomainXYPlot13.getRangeCrosshairStroke();
        combinedDomainXYPlot13.setWeight(15);
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer21 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.Color color28 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer30 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        xYBarRenderer30.notifyListeners(rendererChangeEvent31);
        java.awt.Stroke stroke34 = xYBarRenderer30.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer21.drawDomainLine(graphics2D22, xYPlot23, (org.jfree.chart.axis.ValueAxis) periodAxis25, rectangle2D26, (double) 100, (java.awt.Paint) color28, stroke34);
        boolean boolean38 = xYStepRenderer21.getItemShapeVisible(100, 0);
        java.awt.Shape shape39 = xYStepRenderer21.getLegendLine();
        periodAxis20.setDownArrow(shape39);
        periodAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot43 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot43.setDomainCrosshairVisible(true);
        combinedDomainXYPlot43.clearDomainMarkers(3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator51 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer49.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator51);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator54 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer49.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator54, true);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot58 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent59 = null;
        combinedDomainXYPlot58.datasetChanged(datasetChangeEvent59);
        java.awt.Stroke stroke61 = combinedDomainXYPlot58.getRangeCrosshairStroke();
        boolean boolean62 = combinedDomainXYPlot58.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis64 = new org.jfree.chart.axis.LogAxis("");
        combinedDomainXYPlot58.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis64);
        org.jfree.chart.axis.PeriodAxis periodAxis67 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker69.setLabelAnchor(rectangleAnchor70);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = valueMarker69.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        xYBarRenderer49.drawDomainMarker(graphics2D57, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot58, (org.jfree.chart.axis.ValueAxis) periodAxis67, (org.jfree.chart.plot.Marker) valueMarker69, rectangle2D73);
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        combinedDomainXYPlot43.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker69, layer75);
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        xYBarRenderer4.drawRangeMarker(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13, (org.jfree.chart.axis.ValueAxis) periodAxis20, (org.jfree.chart.plot.Marker) valueMarker69, rectangle2D77);
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot13.setRangeAxisLocation(axisLocation79);
        org.jfree.chart.axis.AxisLocation axisLocation81 = axisLocation79.getOpposite();
        combinedDomainXYPlot0.setDomainAxisLocation(axisLocation79, false);
        org.jfree.chart.axis.AxisLocation axisLocation84 = axisLocation79.getOpposite();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator54);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor70);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertNotNull(axisLocation81);
        org.junit.Assert.assertNotNull(axisLocation84);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        int int2 = segmentedTimeline0.getGroupSegmentCount();
        segmentedTimeline0.setStartTime((long) 'a');
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType6 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType6, (int) 'a');
        int int9 = dateTickUnit8.getMultiple();
        java.util.Date date10 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline0.getSegment(date10);
        boolean boolean12 = segment11.inIncludeSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
        org.junit.Assert.assertNotNull(dateTickUnitType6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Color color9 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYBarRenderer11.notifyListeners(rendererChangeEvent12);
        java.awt.Stroke stroke15 = xYBarRenderer11.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer2.drawDomainLine(graphics2D3, xYPlot4, (org.jfree.chart.axis.ValueAxis) periodAxis6, rectangle2D7, (double) 100, (java.awt.Paint) color9, stroke15);
        boolean boolean19 = xYStepRenderer2.getItemShapeVisible(100, 0);
        java.awt.Shape shape20 = xYStepRenderer2.getLegendLine();
        periodAxis1.setDownArrow(shape20);
        periodAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer24 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.Color color31 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYBarRenderer33.notifyListeners(rendererChangeEvent34);
        java.awt.Stroke stroke37 = xYBarRenderer33.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer24.drawDomainLine(graphics2D25, xYPlot26, (org.jfree.chart.axis.ValueAxis) periodAxis28, rectangle2D29, (double) 100, (java.awt.Paint) color31, stroke37);
        periodAxis1.setLabelPaint((java.awt.Paint) color31);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray41 = null;
        float[] floatArray42 = color40.getColorComponents(floatArray41);
        boolean boolean43 = periodAxis1.equals((java.lang.Object) floatArray41);
        periodAxis1.setLowerBound((-5.0d));
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot46 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) periodAxis1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.title.TextTitle textTitle2 = jFreeChart1.getTitle();
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        textTitle2.setMargin((double) 29, 100.0d, (double) (short) 10, (double) (-1L));
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(textTitle2);
        org.junit.Assert.assertNotNull(blockBorder3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.util.Date date0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType3, (int) 'a');
        int int6 = dateTickUnit5.getMultiple();
        java.util.Date date7 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone9;
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone9);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("February", timeZone9);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.Color color20 = java.awt.Color.green;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYBarRenderer22.notifyListeners(rendererChangeEvent23);
        java.awt.Stroke stroke26 = xYBarRenderer22.lookupSeriesOutlineStroke((int) '4');
        xYStepRenderer13.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D18, (double) 100, (java.awt.Paint) color20, stroke26);
        java.util.Locale locale28 = periodAxis17.getLocale();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator29 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale28);
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale28);
        try {
            org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date0, timeZone9, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(locale28);
        org.junit.Assert.assertNotNull(tickUnitSource30);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType2, (int) 'a');
        int int5 = dateTickUnit4.getMultiple();
        java.util.Date date6 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone8 = dateAxis7.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone8;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6, timeZone8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("February", timeZone8);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "RangeType.FULL", "[100.0, 24234.0]");
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) day17, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone23 = dateAxis22.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone23;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection25 = new org.jfree.data.time.TimeSeriesCollection(timeSeries21, timeZone23);
        dateAxis11.setTimeZone(timeZone23);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(timeZone23);
    }
}

