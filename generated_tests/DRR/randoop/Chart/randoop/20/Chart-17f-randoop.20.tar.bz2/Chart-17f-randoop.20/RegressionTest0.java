import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1L);
        java.lang.Number number3 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 1L + "'", number3.equals(1L));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) false, (java.lang.Object) "org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            year2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek((int) (short) 1);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate1.getNearestDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month8.previous();
        try {
            timeSeries7.add(regularTimePeriod11, (java.lang.Number) 0.0f, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        try {
            timeSeries7.update((int) '4', (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        java.lang.String str6 = seriesException5.toString();
        java.lang.Throwable[] throwableArray7 = seriesException5.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str6.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', (int) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        try {
            java.util.Collection collection10 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(comparable8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries7.createCopy(regularTimePeriod9, regularTimePeriod13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setNotify(true);
        try {
            timeSeries7.delete((int) (short) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries7.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441255338L + "'", long1 == 1560441255338L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441255338L + "'", long2 == 1560441255338L);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        boolean boolean15 = timeSeries7.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            timeSeries7.delete(regularTimePeriod16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setNotify(true);
        java.lang.Comparable comparable10 = null;
        try {
            timeSeries7.setKey(comparable10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        try {
            java.lang.Number number14 = timeSeries7.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        java.util.List list10 = timeSeries7.getItems();
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy((int) (byte) 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        try {
            timeSeries7.removeAgedItems((long) ' ', true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("13-June-2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "hi!", "hi!", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        try {
            timeSeries4.add(regularTimePeriod6, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1563303599999L + "'", long7 == 1563303599999L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        try {
            timeSeries7.removeAgedItems((long) 8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(comparable8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        try {
            timeSeries7.removeAgedItems((long) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.getDataItem((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ClassContext");
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2019, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        timeSeries7.clear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            int int11 = timeSeries7.getIndex(regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(comparable8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        boolean boolean4 = day2.equals((java.lang.Object) 7);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek((int) (short) 1);
        try {
            java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441257958L + "'", long2 == 1560441257958L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441257958L + "'", long4 == 1560441257958L);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        timeSeries7.setKey((java.lang.Comparable) "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        org.jfree.data.time.Year year15 = month13.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year15, (double) 1546329600000L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond13.getMiddleMillisecond(calendar15);
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries7.getTimePeriod((-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560441258782L + "'", long14 == 1560441258782L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560441258782L + "'", long16 == 1560441258782L);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "January" + "'", str2.equals("January"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setNotify(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        boolean boolean15 = timeSeries7.isEmpty();
        timeSeries7.setMaximumItemCount(100);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        org.jfree.data.time.Year year10 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month8.next();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "", class14);
        java.lang.Comparable comparable16 = timeSeries15.getKey();
        timeSeries15.clear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        org.jfree.data.time.Year year20 = month18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "", "", class24);
        timeSeries25.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        int int30 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) '4', true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.Object obj17 = null;
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month15, obj17);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441262826L + "'", long1 == 1560441262826L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441262826L + "'", long3 == 1560441262826L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560441262826L + "'", long4 == 1560441262826L);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        int int12 = month10.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 8);
        try {
            timeSeries7.add(timeSeriesDataItem14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("June 2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441264835L + "'", long3 == 1560441264835L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        try {
            timeSeries7.update((int) '#', (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Thu Jun 13 08:54:23 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class1);
        timeSeries2.removeAgedItems(false);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year5);
        long long7 = year5.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            year5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = null;
        try {
            timeSeries7.add(timeSeriesDataItem10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        java.lang.String str4 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day2.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getSerialIndex();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean16 = spreadsheetDate7.isInRange(serialDate10, serialDate14, 5);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        boolean boolean18 = year2.equals((java.lang.Object) serialDate17);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries7.setDomainDescription("Thu Jun 13 08:54:23 PDT 2019");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        java.util.List list10 = timeSeries7.getItems();
        try {
            java.util.Collection collection11 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list10);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries7.removeChangeListener(seriesChangeListener17);
        java.lang.Class class19 = timeSeries7.getTimePeriodClass();
        boolean boolean20 = timeSeries7.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Thu Jun 13 08:54:26 PDT 2019");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        timeSeries7.clear();
        try {
            timeSeries7.update(6, (java.lang.Number) 1560441263554L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(comparable8);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond3.getMiddleMillisecond(calendar5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441268368L + "'", long6 == 1560441268368L);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getLastMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441269368L + "'", long1 == 1560441269368L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441269368L + "'", long3 == 1560441269368L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441269368L + "'", long5 == 1560441269368L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date7, timeZone9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone9);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date15, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date15);
        java.util.Calendar calendar23 = null;
        try {
            day22.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        java.util.Calendar calendar35 = null;
//        try {
//            long long36 = year31.getLastMillisecond(calendar35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        try {
            java.lang.Number number18 = timeSeries7.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries7.removeChangeListener(seriesChangeListener17);
        timeSeries7.setMaximumItemAge((long) '#');
        try {
            timeSeries7.delete(11, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.lang.String str4 = fixedMillisecond0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441270407L + "'", long3 == 1560441270407L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Thu Jun 13 08:54:30 PDT 2019" + "'", str4.equals("Thu Jun 13 08:54:30 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries7.removeChangeListener(seriesChangeListener17);
        java.lang.Class class19 = timeSeries7.getTimePeriodClass();
        boolean boolean21 = timeSeries7.equals((java.lang.Object) (-1.0d));
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class23);
        timeSeries24.removeAgedItems(false);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        long long29 = year27.getFirstMillisecond();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year27, (double) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean7 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, serialDate6);
        java.util.Date date8 = spreadsheetDate2.toDate();
        int int9 = spreadsheetDate2.getDayOfMonth();
        java.util.Date date10 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getStart();
        try {
            java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) year12);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        timeSeries7.setKey((java.lang.Comparable) "");
        timeSeries7.setMaximumItemCount(0);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        long long8 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        java.lang.String str10 = timeSeries7.getDomainDescription();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        org.jfree.data.time.Year year13 = month11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
//        timeSeries18.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
//        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
//        long long29 = fixedMillisecond24.getLastMillisecond();
//        long long30 = fixedMillisecond24.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560441273058L + "'", long29 == 1560441273058L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560441273058L + "'", long30 == 1560441273058L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) ' ', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries7.removeChangeListener(seriesChangeListener17);
        java.lang.String str19 = timeSeries7.getRangeDescription();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
        org.jfree.data.time.Year year22 = month20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month20.next();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "", "", class26);
        timeSeries27.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        java.lang.Class class32 = timeSeries27.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date34 = fixedMillisecond33.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) (short) 10);
        java.lang.Object obj37 = timeSeries27.clone();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.next();
        org.jfree.data.time.Year year40 = month38.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month38, "", "", class44);
        timeSeries45.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month48.next();
        org.jfree.data.time.Year year50 = month48.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.previous();
        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) year50);
        java.util.Date date53 = year50.getStart();
        long long54 = year50.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year50, (java.lang.Number) (-1));
        boolean boolean57 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) str19, (java.lang.Object) timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(year40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1546329600000L + "'", long54 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:54:23 PDT 2019", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        int int36 = year31.compareTo((java.lang.Object) ' ');
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone3);
        java.util.Calendar calendar5 = null;
        try {
            month4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(comparable8);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:54:26 PDT 2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        java.lang.String str35 = day19.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        int int13 = timeSeries7.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) "hi!");
        try {
            java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.SerialDate serialDate4 = serialDate2.getNearestDayOfWeek(6);
        java.lang.String str5 = serialDate4.getDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.Year year3 = month1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month1.next();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month1, "", "", class7);
        timeSeries8.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) year13);
        java.util.Date date16 = year13.getStart();
        long long17 = year13.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(0, year13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getStart();
        long long16 = year12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek((int) (short) 1);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        long long35 = day19.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560495599999L + "'", long35 == 1560495599999L);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
        org.jfree.data.time.Year year8 = month6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "", class12);
        timeSeries13.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
        org.jfree.data.time.Year year18 = month16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year18);
        java.util.Date date21 = year18.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getTime();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date21, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone25);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod29);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 8);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        org.jfree.data.time.Year year7 = month5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.next();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, "", "", class11);
        timeSeries12.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.lang.Class class17 = timeSeries12.getTimePeriodClass();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int21 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) month20);
        timeSeries12.setRangeDescription("Thu Jun 13 08:54:23 PDT 2019");
        int int24 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries12);
        try {
            timeSeries12.update(0, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date15, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date15);
        java.lang.String str23 = day22.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1-January-2019" + "'", str23.equals("1-January-2019"));
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        org.jfree.data.time.Year year3 = month1.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month1.next();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month1, "", "", class7);
//        java.lang.Comparable comparable9 = timeSeries8.getKey();
//        timeSeries8.clear();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        org.jfree.data.time.Year year13 = month11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
//        timeSeries18.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        int int23 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        org.jfree.data.time.Year year26 = month24.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
//        int int28 = year26.getYear();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.Year year31 = month29.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.next();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "", "", class35);
//        timeSeries36.setMaximumItemCount((int) (short) 0);
//        java.lang.String str39 = timeSeries36.getDomainDescription();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
//        org.jfree.data.time.Year year42 = month40.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month40.next();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month40, "", "", class46);
//        timeSeries47.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries47.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        java.lang.Class class52 = timeSeries47.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date54 = fixedMillisecond53.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) (short) 10);
//        timeSeries36.setKey((java.lang.Comparable) fixedMillisecond53);
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond53.getLastMillisecond(calendar58);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date61 = fixedMillisecond60.getTime();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
//        java.lang.String str63 = day62.toString();
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = month64.next();
//        org.jfree.data.time.Year year66 = month64.getYear();
//        long long67 = year66.getFirstMillisecond();
//        int int68 = day62.compareTo((java.lang.Object) long67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day62.next();
//        boolean boolean70 = fixedMillisecond53.equals((java.lang.Object) day62);
//        long long71 = fixedMillisecond53.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = fixedMillisecond53.next();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) year26, regularTimePeriod72);
//        try {
//            org.jfree.data.time.Month month74 = new org.jfree.data.time.Month((int) ' ', year26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(comparable9);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNull(class52);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560441290117L + "'", long59 == 1560441290117L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "13-June-2019" + "'", str63.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1546329600000L + "'", long67 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560441290117L + "'", long71 == 1560441290117L);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeSeries73);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        int int12 = timeSeries7.getMaximumItemCount();
        try {
            timeSeries7.update(13, (java.lang.Number) 1560441263554L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean4 = spreadsheetDate2.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean16 = spreadsheetDate7.isInRange(serialDate10, serialDate14, 5);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate2.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate18);
        try {
            org.jfree.data.time.SerialDate serialDate21 = serialDate19.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "August" + "'", str1.equals("August"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getDayOfMonth();
//        long long6 = day3.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        org.jfree.data.time.Year year37 = month35.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month35.next();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "", class41);
//        timeSeries42.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month45.next();
//        org.jfree.data.time.Year year47 = month45.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) year47);
//        java.util.Date date50 = year47.getStart();
//        long long51 = year47.getFirstMillisecond();
//        java.lang.Number number52 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) year47);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month53.next();
//        org.jfree.data.time.Year year55 = month53.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month53.next();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month53, "", "", class59);
//        java.lang.Comparable comparable61 = timeSeries60.getKey();
//        timeSeries60.setDomainDescription("hi!");
//        boolean boolean64 = timeSeries7.equals((java.lang.Object) timeSeries60);
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
//        org.jfree.data.time.Year year67 = month65.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month65.next();
//        java.lang.Class class71 = null;
//        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month65, "", "", class71);
//        timeSeries72.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries72.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75);
//        java.lang.Class class77 = timeSeries72.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date79 = fixedMillisecond78.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries72.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond78, (java.lang.Number) (short) 10);
//        java.lang.Object obj82 = timeSeries72.clone();
//        boolean boolean83 = timeSeries7.equals(obj82);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(comparable61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNull(class77);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNull(timeSeriesDataItem81);
//        org.junit.Assert.assertNotNull(obj82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        org.jfree.data.time.Year year4 = month2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "", class8);
//        timeSeries9.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.lang.Class class14 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getTime();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        java.lang.String str22 = day21.toString();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
//        org.jfree.data.time.Year year25 = month23.getYear();
//        long long26 = year25.getFirstMillisecond();
//        int int27 = day21.compareTo((java.lang.Object) long26);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class29);
//        timeSeries30.removeAgedItems(false);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        int int34 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
//        long long35 = year33.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) year33);
//        int int37 = fixedMillisecond0.compareTo((java.lang.Object) year33);
//        int int39 = year33.compareTo((java.lang.Object) 1560441268368L);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        boolean boolean17 = timeSeries7.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1L);
        long long3 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        int int13 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        org.jfree.data.time.Year year16 = month14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "", "", class20);
        timeSeries21.setMaximumItemCount((int) (short) 0);
        timeSeries21.clear();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries7.addAndOrUpdate(timeSeries21);
        timeSeries25.setNotify(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:54:18 PDT 2019", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getStart();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year12.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getNearestDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        java.lang.String str21 = day19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.TimeSeries timeSeries26 = null;
//        try {
//            java.util.Collection collection27 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560441294099L + "'", long24 == 1560441294099L);
//        org.junit.Assert.assertNotNull(timeSeries25);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getStart();
        long long16 = year12.getFirstMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year12.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("August", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean4 = spreadsheetDate2.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean16 = spreadsheetDate7.isInRange(serialDate10, serialDate14, 5);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate2.getEndOfCurrentMonth(serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(35, serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        java.lang.String str10 = timeSeries7.getDomainDescription();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        org.jfree.data.time.Year year13 = month11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
//        timeSeries18.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
//        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond24.getLastMillisecond(calendar29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date32 = fixedMillisecond31.getTime();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
//        java.lang.String str34 = day33.toString();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        org.jfree.data.time.Year year37 = month35.getYear();
//        long long38 = year37.getFirstMillisecond();
//        int int39 = day33.compareTo((java.lang.Object) long38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day33.next();
//        boolean boolean41 = fixedMillisecond24.equals((java.lang.Object) day33);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond24.getLastMillisecond(calendar42);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560441294531L + "'", long30 == 1560441294531L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560441294531L + "'", long43 == 1560441294531L);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        java.lang.Comparable comparable8 = timeSeries7.getKey();
//        timeSeries7.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getTime();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond10.getFirstMillisecond(calendar12);
//        java.lang.String str14 = fixedMillisecond10.toString();
//        try {
//            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 1560441259746L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(comparable8);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560441294784L + "'", long13 == 1560441294784L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thu Jun 13 08:54:54 PDT 2019" + "'", str14.equals("Thu Jun 13 08:54:54 PDT 2019"));
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        java.lang.Comparable comparable8 = timeSeries7.getKey();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
//        org.jfree.data.time.Year year12 = month10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "", class16);
//        timeSeries17.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        int int22 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
//        org.jfree.data.time.Year year25 = month23.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        int int27 = year25.getYear();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.next();
//        org.jfree.data.time.Year year30 = month28.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "", "", class34);
//        timeSeries35.setMaximumItemCount((int) (short) 0);
//        java.lang.String str38 = timeSeries35.getDomainDescription();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month39.next();
//        org.jfree.data.time.Year year41 = month39.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month39.next();
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "", "", class45);
//        timeSeries46.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        java.lang.Class class51 = timeSeries46.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date53 = fixedMillisecond52.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) (short) 10);
//        timeSeries35.setKey((java.lang.Comparable) fixedMillisecond52);
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond52.getLastMillisecond(calendar57);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date60 = fixedMillisecond59.getTime();
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
//        java.lang.String str62 = day61.toString();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month63.next();
//        org.jfree.data.time.Year year65 = month63.getYear();
//        long long66 = year65.getFirstMillisecond();
//        int int67 = day61.compareTo((java.lang.Object) long66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day61.next();
//        boolean boolean69 = fixedMillisecond52.equals((java.lang.Object) day61);
//        long long70 = fixedMillisecond52.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond52.next();
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, regularTimePeriod71);
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = month73.next();
//        int int75 = month73.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month73, (java.lang.Number) 8);
//        boolean boolean79 = timeSeriesDataItem77.equals((java.lang.Object) true);
//        try {
//            timeSeries72.add(timeSeriesDataItem77);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(comparable8);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(class51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560441294813L + "'", long58 == 1560441294813L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "13-June-2019" + "'", str62.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1546329600000L + "'", long66 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560441294813L + "'", long70 == 1560441294813L);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2019 + "'", int75 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        java.util.Date date7 = spreadsheetDate1.toDate();
        int int8 = spreadsheetDate1.getDayOfMonth();
        java.util.Date date9 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        org.jfree.data.time.Year year4 = month2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "", class8);
//        timeSeries9.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.lang.Class class14 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getTime();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        java.lang.String str22 = day21.toString();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
//        org.jfree.data.time.Year year25 = month23.getYear();
//        long long26 = year25.getFirstMillisecond();
//        int int27 = day21.compareTo((java.lang.Object) long26);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class29);
//        timeSeries30.removeAgedItems(false);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        int int34 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
//        long long35 = year33.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) year33);
//        int int37 = fixedMillisecond0.compareTo((java.lang.Object) year33);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.next();
//        org.jfree.data.time.Year year40 = month38.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month38, "", "", class44);
//        timeSeries45.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month48.next();
//        org.jfree.data.time.Year year50 = month48.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.previous();
//        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) year50);
//        java.util.Date date53 = year50.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date55, timeZone57);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date53, timeZone57);
//        boolean boolean60 = year33.equals((java.lang.Object) timeZone57);
//        long long61 = year33.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 2019L + "'", long61 == 2019L);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
        timeSeries18.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
        try {
            org.jfree.data.time.TimeSeries timeSeries31 = timeSeries7.createCopy(2019, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        timeSeries7.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
        timeSeries18.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
        int int24 = timeSeries18.getMaximumItemCount();
        java.util.Collection collection25 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        java.util.Collection collection26 = org.jfree.chart.util.ObjectUtilities.deepClone(collection25);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Thu Jun 13 08:54:23 PDT 2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
        java.lang.Object obj17 = timeSeries7.clone();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        org.jfree.data.time.Year year20 = month18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "", "", class24);
        timeSeries25.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.next();
        org.jfree.data.time.Year year30 = month28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) year30);
        java.util.Date date33 = year30.getStart();
        long long34 = year30.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) (-1));
        java.util.Calendar calendar37 = null;
        try {
            year30.peg(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        java.lang.String str21 = day19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond23.getFirstMillisecond(calendar26);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560441297236L + "'", long24 == 1560441297236L);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560441297236L + "'", long27 == 1560441297236L);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        try {
//            timeSeries7.removeAgedItems(1560441266750L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        java.util.Date date7 = spreadsheetDate3.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getNearestDayOfWeek(6);
        boolean boolean13 = spreadsheetDate3.isOnOrAfter(serialDate10);
        org.jfree.data.time.SerialDate serialDate14 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean18 = spreadsheetDate16.equals((java.lang.Object) "hi!");
        java.util.Date date19 = spreadsheetDate16.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean23 = spreadsheetDate21.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean35 = spreadsheetDate26.isInRange(serialDate29, serialDate33, 5);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays(13, serialDate29);
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate21.getEndOfCurrentMonth(serialDate29);
        boolean boolean38 = spreadsheetDate16.isOnOrAfter(serialDate29);
        try {
            boolean boolean39 = spreadsheetDate3.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1, "ClassContext", "hi!", class5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        timeSeries7.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        int int3 = month0.getMonth();
        int int4 = month0.getYearValue();
        org.jfree.data.time.Year year5 = month0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            month0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
        timeSeries18.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date30 = fixedMillisecond29.getTime();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560441287526L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean15 = spreadsheetDate6.isInRange(serialDate9, serialDate13, 5);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(13, serialDate9);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate1.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate20 = serialDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getFirstMillisecond();
        int int4 = year2.getYear();
        long long5 = year2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Thu Jun 13 08:54:30 PDT 2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Date date4 = fixedMillisecond3.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable throwable4 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.Date date2 = fixedMillisecond0.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date15, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date15);
        int int23 = day22.getMonth();
        org.jfree.data.time.SerialDate serialDate24 = day22.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        timeSeries7.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertNull(class12);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.Comparable comparable17 = timeSeries7.getKey();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            timeSeries7.delete(regularTimePeriod20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(comparable17);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "hi!", "ClassContext", class7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
//        org.jfree.data.time.Year year11 = month9.getYear();
//        try {
//            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year11, (double) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441306286L + "'", long1 == 1560441306286L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441306286L + "'", long3 == 1560441306286L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        timeSeries7.setDomainDescription("hi!");
        try {
            timeSeries7.update(1, (java.lang.Number) 1560441269651L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(comparable8);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1546329600000L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1900, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        java.lang.String str21 = day19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        try {
//            timeSeries25.delete((int) 'a', (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560441308108L + "'", long24 == 1560441308108L);
//        org.junit.Assert.assertNotNull(timeSeries25);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class1);
        timeSeries2.removeAgedItems(false);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year5);
        java.util.List list7 = timeSeries2.getItems();
        try {
            java.util.Collection collection8 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list7);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("August");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener17);
//        java.lang.Class class19 = timeSeries7.getTimePeriodClass();
//        boolean boolean21 = timeSeries7.equals((java.lang.Object) (-1.0d));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1560441264835L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(class19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560441308243L + "'", long24 == 1560441308243L);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "hi!", "hi!", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        int int7 = month5.getYearValue();
        org.jfree.data.time.Year year8 = month5.getYear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
        org.jfree.data.time.Year year11 = month9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "", class15);
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        timeSeries16.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.addChangeListener(seriesChangeListener19);
        java.util.Collection collection21 = timeSeries16.getTimePeriods();
        int int22 = year8.compareTo((java.lang.Object) timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.addAndOrUpdate(timeSeries16);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener24);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        timeSeries7.clear();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        java.lang.String str21 = day19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        boolean boolean31 = timeSeriesDataItem28.equals((java.lang.Object) regularTimePeriod30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond32.getFirstMillisecond(calendar34);
//        java.lang.String str36 = fixedMillisecond32.toString();
//        boolean boolean37 = timeSeriesDataItem28.equals((java.lang.Object) fixedMillisecond32);
//        try {
//            timeSeries7.add(timeSeriesDataItem28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560441308421L + "'", long24 == 1560441308421L);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560441308423L + "'", long35 == 1560441308423L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Thu Jun 13 08:55:08 PDT 2019" + "'", str36.equals("Thu Jun 13 08:55:08 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        java.lang.String str4 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        org.jfree.data.time.Year year8 = month6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "", class12);
//        java.lang.Comparable comparable14 = timeSeries13.getKey();
//        timeSeries13.clear();
//        boolean boolean16 = day2.equals((java.lang.Object) timeSeries13);
//        timeSeries13.setNotify(true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = null;
//        try {
//            timeSeries13.add(timeSeriesDataItem19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(comparable14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        java.util.Date date7 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean14 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getTime();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean25 = spreadsheetDate16.isInRange(serialDate19, serialDate23, 5);
        boolean boolean27 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, serialDate23, 1);
        org.jfree.data.time.SerialDate serialDate28 = null;
        try {
            boolean boolean29 = spreadsheetDate9.isAfter(serialDate28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        java.lang.String str21 = day19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        long long26 = day19.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560441308759L + "'", long24 == 1560441308759L);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560409200000L + "'", long26 == 1560409200000L);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        int int13 = timeSeries7.getMaximumItemCount();
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) "hi!");
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean8 = spreadsheetDate6.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean20 = spreadsheetDate11.isInRange(serialDate14, serialDate18, 5);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(13, serialDate14);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate6.getEndOfCurrentMonth(serialDate14);
        boolean boolean23 = spreadsheetDate1.isOnOrAfter(serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate25 = serialDate14.getNearestDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("January");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
//        boolean boolean7 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, serialDate6);
//        java.util.Date date8 = spreadsheetDate4.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
//        boolean boolean15 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, serialDate14);
//        java.util.Date date16 = spreadsheetDate12.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date18, timeZone20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date16, timeZone20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getTime();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
//        org.jfree.data.time.Year year27 = month25.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month25.next();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month25, "", "", class31);
//        timeSeries32.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        java.lang.Class class37 = timeSeries32.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date39 = fixedMillisecond38.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getTime();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        java.lang.String str45 = day44.toString();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month46.next();
//        org.jfree.data.time.Year year48 = month46.getYear();
//        long long49 = year48.getFirstMillisecond();
//        int int50 = day44.compareTo((java.lang.Object) long49);
//        java.lang.Class class52 = null;
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class52);
//        timeSeries53.removeAgedItems(false);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        int int57 = timeSeries53.getIndex((org.jfree.data.time.RegularTimePeriod) year56);
//        long long58 = year56.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day44, (org.jfree.data.time.RegularTimePeriod) year56);
//        int int60 = fixedMillisecond23.compareTo((java.lang.Object) year56);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month61.next();
//        org.jfree.data.time.Year year63 = month61.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month61.next();
//        java.lang.Class class67 = null;
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month61, "", "", class67);
//        timeSeries68.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = month71.next();
//        org.jfree.data.time.Year year73 = month71.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year73.previous();
//        timeSeries68.delete((org.jfree.data.time.RegularTimePeriod) year73);
//        java.util.Date date76 = year73.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date78 = fixedMillisecond77.getTime();
//        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(date78);
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month81 = new org.jfree.data.time.Month(date78, timeZone80);
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date76, timeZone80);
//        boolean boolean83 = year56.equals((java.lang.Object) timeZone80);
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date16, timeZone80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone80);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNull(class37);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "13-June-2019" + "'", str45.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(year63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(year73);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.lang.String str2 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.Comparable comparable17 = timeSeries7.getKey();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        org.jfree.data.time.Year year20 = month18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "", "", class24);
        timeSeries25.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.next();
        org.jfree.data.time.Year year30 = month28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) year30);
        java.util.Date date33 = year30.getStart();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 1563303599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        java.util.Date date7 = spreadsheetDate3.toDate();
        java.util.Date date8 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean15 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, serialDate14);
        java.util.Date date16 = spreadsheetDate12.toDate();
        boolean boolean17 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) 10, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean15 = spreadsheetDate6.isInRange(serialDate9, serialDate13, 5);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(13, serialDate9);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate1.getEndOfCurrentMonth(serialDate9);
        try {
            org.jfree.data.time.SerialDate serialDate19 = serialDate17.getFollowingDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class1);
        timeSeries2.removeAgedItems(false);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d);
        java.util.Collection collection9 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.createCopy((int) (short) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(collection9);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
//        boolean boolean5 = timeSeriesDataItem2.equals((java.lang.Object) regularTimePeriod4);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
//        boolean boolean11 = timeSeriesDataItem8.equals((java.lang.Object) regularTimePeriod10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond12.getFirstMillisecond(calendar14);
//        java.lang.String str16 = fixedMillisecond12.toString();
//        boolean boolean17 = timeSeriesDataItem8.equals((java.lang.Object) fixedMillisecond12);
//        int int18 = timeSeriesDataItem2.compareTo((java.lang.Object) boolean17);
//        timeSeriesDataItem2.setValue((java.lang.Number) 0L);
//        timeSeriesDataItem2.setValue((java.lang.Number) (short) 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560441312608L + "'", long15 == 1560441312608L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Thu Jun 13 08:55:12 PDT 2019" + "'", str16.equals("Thu Jun 13 08:55:12 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Date date4 = fixedMillisecond3.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 100L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        org.jfree.data.time.Year year4 = month2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "", class8);
//        timeSeries9.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.lang.Class class14 = timeSeries9.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getTime();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        java.lang.String str22 = day21.toString();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
//        org.jfree.data.time.Year year25 = month23.getYear();
//        long long26 = year25.getFirstMillisecond();
//        int int27 = day21.compareTo((java.lang.Object) long26);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class29);
//        timeSeries30.removeAgedItems(false);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        int int34 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
//        long long35 = year33.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) year33);
//        int int37 = fixedMillisecond0.compareTo((java.lang.Object) year33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Thu Jun 13 08:55:12 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.next();
//        boolean boolean40 = timeSeriesDataItem37.equals((java.lang.Object) regularTimePeriod39);
//        try {
//            timeSeries7.add(timeSeriesDataItem37, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560441258212L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "hi!", "hi!", class3);
        try {
            timeSeries4.delete(8, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        int int7 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean11 = spreadsheetDate9.equals((java.lang.Object) "hi!");
        int int12 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean16 = spreadsheetDate14.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean23 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, serialDate22);
        java.util.Date date24 = spreadsheetDate20.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean31 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date35 = fixedMillisecond34.getTime();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate38 = serialDate36.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean42 = spreadsheetDate33.isInRange(serialDate36, serialDate40, 5);
        boolean boolean44 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, serialDate40, 1);
        boolean boolean46 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, serialDate40, (int) (short) 0);
        boolean boolean47 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int48 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1900 + "'", int48 == 1900);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
//        boolean boolean9 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, serialDate8);
//        java.util.Date date10 = spreadsheetDate6.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12, timeZone14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date10, timeZone14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
//        org.jfree.data.time.Year year21 = month19.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.next();
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19, "", "", class25);
//        timeSeries26.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        java.lang.Class class31 = timeSeries26.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
//        java.lang.String str39 = day38.toString();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
//        org.jfree.data.time.Year year42 = month40.getYear();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = day38.compareTo((java.lang.Object) long43);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class46);
//        timeSeries47.removeAgedItems(false);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        int int51 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) year50);
//        long long52 = year50.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) day38, (org.jfree.data.time.RegularTimePeriod) year50);
//        int int54 = fixedMillisecond17.compareTo((java.lang.Object) year50);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month55.next();
//        org.jfree.data.time.Year year57 = month55.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month55.next();
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month55, "", "", class61);
//        timeSeries62.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
//        org.jfree.data.time.Year year67 = month65.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year67.previous();
//        timeSeries62.delete((org.jfree.data.time.RegularTimePeriod) year67);
//        java.util.Date date70 = year67.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date72 = fixedMillisecond71.getTime();
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(date72);
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date72, timeZone74);
//        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date70, timeZone74);
//        boolean boolean77 = year50.equals((java.lang.Object) timeZone74);
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date10, timeZone74);
//        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month(date1, timeZone74);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1546329600000L + "'", long52 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries7.removeChangeListener(seriesChangeListener17);
        java.lang.Class class19 = timeSeries7.getTimePeriodClass();
        boolean boolean21 = timeSeries7.equals((java.lang.Object) (-1.0d));
        java.lang.String str22 = timeSeries7.getDomainDescription();
        timeSeries7.setMaximumItemAge((long) 5);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date15, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date15);
        int int23 = day22.getMonth();
        int int24 = day22.getYear();
        long long25 = day22.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class1);
        timeSeries2.removeAgedItems(false);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 1L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean16 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, serialDate15);
        java.util.Date date17 = spreadsheetDate13.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean24 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, serialDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean35 = spreadsheetDate26.isInRange(serialDate29, serialDate33, 5);
        boolean boolean37 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, serialDate33, 1);
        int int38 = spreadsheetDate13.getYYYY();
        boolean boolean39 = timeSeriesDataItem9.equals((java.lang.Object) int38);
        try {
            timeSeries2.add(timeSeriesDataItem9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable throwable3 = null;
        try {
            seriesException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        java.lang.Comparable comparable8 = timeSeries7.getKey();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
//        org.jfree.data.time.Year year12 = month10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "", class16);
//        timeSeries17.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        int int22 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
//        org.jfree.data.time.Year year25 = month23.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        int int27 = year25.getYear();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.next();
//        org.jfree.data.time.Year year30 = month28.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "", "", class34);
//        timeSeries35.setMaximumItemCount((int) (short) 0);
//        java.lang.String str38 = timeSeries35.getDomainDescription();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month39.next();
//        org.jfree.data.time.Year year41 = month39.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month39.next();
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "", "", class45);
//        timeSeries46.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        java.lang.Class class51 = timeSeries46.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date53 = fixedMillisecond52.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) (short) 10);
//        timeSeries35.setKey((java.lang.Comparable) fixedMillisecond52);
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond52.getLastMillisecond(calendar57);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date60 = fixedMillisecond59.getTime();
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
//        java.lang.String str62 = day61.toString();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month63.next();
//        org.jfree.data.time.Year year65 = month63.getYear();
//        long long66 = year65.getFirstMillisecond();
//        int int67 = day61.compareTo((java.lang.Object) long66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day61.next();
//        boolean boolean69 = fixedMillisecond52.equals((java.lang.Object) day61);
//        long long70 = fixedMillisecond52.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond52.next();
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, regularTimePeriod71);
//        long long73 = year25.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(comparable8);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(class51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560441318442L + "'", long58 == 1560441318442L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "13-June-2019" + "'", str62.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1546329600000L + "'", long66 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560441318442L + "'", long70 == 1560441318442L);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1546329600000L + "'", long73 == 1546329600000L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "hi!", "hi!", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        int int7 = month5.getYearValue();
        org.jfree.data.time.Year year8 = month5.getYear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
        org.jfree.data.time.Year year11 = month9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "", class15);
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        timeSeries16.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.addChangeListener(seriesChangeListener19);
        java.util.Collection collection21 = timeSeries16.getTimePeriods();
        int int22 = year8.compareTo((java.lang.Object) timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.Object obj25 = null;
        boolean boolean26 = month24.equals(obj25);
        int int27 = month24.getMonth();
        java.lang.String str28 = month24.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (double) 0.0f);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem30);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        java.lang.String str10 = timeSeries7.getDomainDescription();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        org.jfree.data.time.Year year13 = month11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
//        timeSeries18.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
//        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond24.getLastMillisecond(calendar29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date32 = fixedMillisecond31.getTime();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
//        java.lang.String str34 = day33.toString();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        org.jfree.data.time.Year year37 = month35.getYear();
//        long long38 = year37.getFirstMillisecond();
//        int int39 = day33.compareTo((java.lang.Object) long38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day33.next();
//        boolean boolean41 = fixedMillisecond24.equals((java.lang.Object) day33);
//        long long42 = fixedMillisecond24.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond24.next();
//        long long44 = fixedMillisecond24.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560441319429L + "'", long30 == 1560441319429L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560441319429L + "'", long42 == 1560441319429L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560441319429L + "'", long44 == 1560441319429L);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean10 = spreadsheetDate1.isInRange(serialDate4, serialDate8, 5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean14 = spreadsheetDate12.equals((java.lang.Object) "hi!");
        java.util.Date date15 = spreadsheetDate12.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean22 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, serialDate21);
        java.util.Date date23 = spreadsheetDate19.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean30 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date34 = fixedMillisecond33.getTime();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
        org.jfree.data.time.SerialDate serialDate37 = serialDate35.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean41 = spreadsheetDate32.isInRange(serialDate35, serialDate39, 5);
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, serialDate39, 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean50 = spreadsheetDate45.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, serialDate49);
        java.util.Date date51 = spreadsheetDate45.toDate();
        int int52 = spreadsheetDate45.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean59 = spreadsheetDate54.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate56, serialDate58);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date61 = fixedMillisecond60.getTime();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date61);
        org.jfree.data.time.SerialDate serialDate64 = serialDate62.getNearestDayOfWeek(6);
        boolean boolean65 = spreadsheetDate56.isOn(serialDate62);
        boolean boolean66 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, serialDate62);
        boolean boolean68 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate25, (int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean72 = spreadsheetDate70.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date77 = fixedMillisecond76.getTime();
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(date77);
        org.jfree.data.time.SerialDate serialDate80 = serialDate78.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean84 = spreadsheetDate75.isInRange(serialDate78, serialDate82, 5);
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.addDays(13, serialDate78);
        org.jfree.data.time.SerialDate serialDate86 = spreadsheetDate70.getEndOfCurrentMonth(serialDate78);
        boolean boolean87 = spreadsheetDate12.isBefore(serialDate86);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean10 = spreadsheetDate1.isInRange(serialDate4, serialDate8, 5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean14 = spreadsheetDate12.equals((java.lang.Object) "hi!");
        java.util.Date date15 = spreadsheetDate12.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean22 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, serialDate21);
        java.util.Date date23 = spreadsheetDate19.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean30 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date34 = fixedMillisecond33.getTime();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
        org.jfree.data.time.SerialDate serialDate37 = serialDate35.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean41 = spreadsheetDate32.isInRange(serialDate35, serialDate39, 5);
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, serialDate39, 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean50 = spreadsheetDate45.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, serialDate49);
        java.util.Date date51 = spreadsheetDate45.toDate();
        int int52 = spreadsheetDate45.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean59 = spreadsheetDate54.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate56, serialDate58);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date61 = fixedMillisecond60.getTime();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date61);
        org.jfree.data.time.SerialDate serialDate64 = serialDate62.getNearestDayOfWeek(6);
        boolean boolean65 = spreadsheetDate56.isOn(serialDate62);
        boolean boolean66 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, serialDate62);
        boolean boolean68 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate25, (int) ' ');
        int int69 = spreadsheetDate12.getYYYY();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1900 + "'", int69 == 1900);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
//        org.jfree.data.time.Year year6 = month4.getYear();
//        long long7 = year6.getFirstMillisecond();
//        int int8 = day2.compareTo((java.lang.Object) long7);
//        java.lang.Object obj9 = null;
//        int int10 = day2.compareTo(obj9);
//        org.jfree.data.time.SerialDate serialDate11 = day2.getSerialDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
//        org.jfree.data.time.SerialDate serialDate20 = serialDate18.getNearestDayOfWeek(6);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
//        boolean boolean24 = spreadsheetDate15.isInRange(serialDate18, serialDate22, 5);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays(13, serialDate18);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2, serialDate18);
//        boolean boolean27 = day2.equals((java.lang.Object) 2);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        java.lang.String str10 = timeSeries7.getDomainDescription();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        org.jfree.data.time.Year year13 = month11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
//        timeSeries18.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
//        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
//        long long29 = fixedMillisecond24.getLastMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond24.getFirstMillisecond(calendar30);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560441322208L + "'", long29 == 1560441322208L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560441322208L + "'", long31 == 1560441322208L);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getDayOfMonth();
//        int int6 = day3.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries7.removeChangeListener(seriesChangeListener17);
        java.lang.String str19 = timeSeries7.getRangeDescription();
        int int20 = timeSeries7.getMaximumItemCount();
        try {
            timeSeries7.delete((int) '#', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getDayOfMonth();
//        long long6 = day3.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        timeSeries7.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
        timeSeries18.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
        int int24 = timeSeries18.getMaximumItemCount();
        java.util.Collection collection25 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
        org.jfree.data.time.Year year28 = month26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "", class32);
        timeSeries33.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        java.lang.Class class38 = timeSeries33.getTimePeriodClass();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int42 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) month41);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timeSeries33.removeChangeListener(seriesChangeListener43);
        java.lang.String str45 = timeSeries33.getRangeDescription();
        int int46 = timeSeries33.getMaximumItemCount();
        java.util.Collection collection47 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(class38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(collection47);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean5 = spreadsheetDate3.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean17 = spreadsheetDate8.isInRange(serialDate11, serialDate15, 5);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate3.getEndOfCurrentMonth(serialDate11);
        java.lang.Class<?> wildcardClass20 = serialDate11.getClass();
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass20);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("1-January-2019", (java.lang.Class) wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(inputStream21);
        org.junit.Assert.assertNull(uRL22);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        org.jfree.data.time.Year year3 = month0.getYear();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.next();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "", class10);
        java.lang.Comparable comparable12 = timeSeries11.getKey();
        timeSeries11.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries11.addChangeListener(seriesChangeListener14);
        java.util.Collection collection16 = timeSeries11.getTimePeriods();
        int int17 = year3.compareTo((java.lang.Object) timeSeries11);
        java.util.Calendar calendar18 = null;
        try {
            year3.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(comparable12);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries7.removeChangeListener(seriesChangeListener17);
        java.lang.Class class19 = timeSeries7.getTimePeriodClass();
        boolean boolean21 = timeSeries7.equals((java.lang.Object) (-1.0d));
        java.lang.String str22 = timeSeries7.getDomainDescription();
        boolean boolean23 = timeSeries7.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
//        boolean boolean5 = timeSeriesDataItem2.equals((java.lang.Object) regularTimePeriod4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        java.lang.String str10 = fixedMillisecond6.toString();
//        boolean boolean11 = timeSeriesDataItem2.equals((java.lang.Object) fixedMillisecond6);
//        long long12 = fixedMillisecond6.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560441323846L + "'", long9 == 1560441323846L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Thu Jun 13 08:55:23 PDT 2019" + "'", str10.equals("Thu Jun 13 08:55:23 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560441323846L + "'", long12 == 1560441323846L);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
//        boolean boolean5 = timeSeriesDataItem2.equals((java.lang.Object) regularTimePeriod4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        java.lang.String str10 = fixedMillisecond6.toString();
//        boolean boolean11 = timeSeriesDataItem2.equals((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond6.getLastMillisecond(calendar12);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560441323886L + "'", long9 == 1560441323886L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Thu Jun 13 08:55:23 PDT 2019" + "'", str10.equals("Thu Jun 13 08:55:23 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560441323886L + "'", long13 == 1560441323886L);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        java.util.Date date7 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean14 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getTime();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean25 = spreadsheetDate16.isInRange(serialDate19, serialDate23, 5);
        boolean boolean27 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, serialDate23, 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean34 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, serialDate33);
        java.util.Date date35 = spreadsheetDate29.toDate();
        int int36 = spreadsheetDate29.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean43 = spreadsheetDate38.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date45 = fixedMillisecond44.getTime();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getNearestDayOfWeek(6);
        boolean boolean49 = spreadsheetDate40.isOn(serialDate46);
        boolean boolean50 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate46);
        int int51 = spreadsheetDate9.toSerial();
        java.util.Date date52 = spreadsheetDate9.toDate();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 35 + "'", int51 == 35);
        org.junit.Assert.assertNotNull(date52);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean10 = spreadsheetDate1.isInRange(serialDate4, serialDate8, 5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean14 = spreadsheetDate12.equals((java.lang.Object) "hi!");
        java.util.Date date15 = spreadsheetDate12.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean22 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, serialDate21);
        java.util.Date date23 = spreadsheetDate19.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean30 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date34 = fixedMillisecond33.getTime();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
        org.jfree.data.time.SerialDate serialDate37 = serialDate35.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean41 = spreadsheetDate32.isInRange(serialDate35, serialDate39, 5);
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, serialDate39, 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean50 = spreadsheetDate45.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, serialDate49);
        java.util.Date date51 = spreadsheetDate45.toDate();
        int int52 = spreadsheetDate45.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean59 = spreadsheetDate54.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate56, serialDate58);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date61 = fixedMillisecond60.getTime();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date61);
        org.jfree.data.time.SerialDate serialDate64 = serialDate62.getNearestDayOfWeek(6);
        boolean boolean65 = spreadsheetDate56.isOn(serialDate62);
        boolean boolean66 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, serialDate62);
        boolean boolean68 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate25, (int) ' ');
        int int69 = spreadsheetDate25.toSerial();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 35 + "'", int69 == 35);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        int int2 = month0.getYearValue();
//        org.jfree.data.time.Year year3 = month0.getYear();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
//        boolean boolean9 = timeSeriesDataItem6.equals((java.lang.Object) regularTimePeriod8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getTime();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond10.getFirstMillisecond(calendar12);
//        java.lang.String str14 = fixedMillisecond10.toString();
//        boolean boolean15 = timeSeriesDataItem6.equals((java.lang.Object) fixedMillisecond10);
//        boolean boolean16 = month0.equals((java.lang.Object) fixedMillisecond10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date18, timeZone20);
//        boolean boolean22 = month0.equals((java.lang.Object) timeZone20);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560441324986L + "'", long13 == 1560441324986L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thu Jun 13 08:55:24 PDT 2019" + "'", str14.equals("Thu Jun 13 08:55:24 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean4 = spreadsheetDate2.equals((java.lang.Object) "hi!");
        int int5 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean9 = spreadsheetDate7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean16 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, serialDate15);
        java.util.Date date17 = spreadsheetDate13.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean24 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, serialDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean35 = spreadsheetDate26.isInRange(serialDate29, serialDate33, 5);
        boolean boolean37 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, serialDate33, 1);
        boolean boolean39 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, serialDate33, (int) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean46 = spreadsheetDate41.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, serialDate45);
        java.util.Date date47 = spreadsheetDate43.toDate();
        boolean boolean48 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean52 = spreadsheetDate50.equals((java.lang.Object) "hi!");
        int int53 = spreadsheetDate50.getDayOfWeek();
        boolean boolean54 = spreadsheetDate43.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addYears(8, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 7 + "'", int53 == 7);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(serialDate55);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        java.lang.String str10 = timeSeries7.getDomainDescription();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        org.jfree.data.time.Year year13 = month11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
//        timeSeries18.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
//        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond24.getLastMillisecond(calendar29);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond24.peg(calendar31);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560441325511L + "'", long30 == 1560441325511L);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries7.removeChangeListener(seriesChangeListener17);
        java.lang.Class class19 = timeSeries7.getTimePeriodClass();
        boolean boolean21 = timeSeries7.equals((java.lang.Object) (-1.0d));
        java.lang.String str22 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
        org.jfree.data.time.Year year25 = month23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month23.next();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "", "", class29);
        timeSeries30.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.next();
        org.jfree.data.time.Year year35 = month33.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.previous();
        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) year35);
        java.util.Date date38 = year35.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date40 = fixedMillisecond39.getTime();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date40, timeZone42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date38, timeZone42);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date38);
        int int46 = day45.getMonth();
        int int47 = day45.getYear();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day45, (double) 1560441269179L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        timeSeries7.clear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "", class16);
        timeSeries17.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.lang.Class class22 = timeSeries17.getTimePeriodClass();
        int int23 = timeSeries17.getMaximumItemCount();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        org.jfree.data.time.Year year26 = month24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.next();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month24, "", "", class30);
        timeSeries31.setMaximumItemCount((int) (short) 0);
        timeSeries31.clear();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries17.addAndOrUpdate(timeSeries31);
        boolean boolean36 = timeSeries7.equals((java.lang.Object) timeSeries31);
        java.lang.Object obj37 = null;
        boolean boolean38 = timeSeries31.equals(obj37);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(comparable8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(class22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
        timeSeries18.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "hi!", "hi!", class32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.addAndOrUpdate(timeSeries33);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries33.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate4);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441326148L + "'", long2 == 1560441326148L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
//        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getTime();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getNearestDayOfWeek(6);
//        boolean boolean12 = spreadsheetDate3.isOn(serialDate9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        java.lang.String str16 = day15.toString();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        org.jfree.data.time.Year year19 = month17.getYear();
//        long long20 = year19.getFirstMillisecond();
//        int int21 = day15.compareTo((java.lang.Object) long20);
//        java.lang.Object obj22 = null;
//        int int23 = day15.compareTo(obj22);
//        org.jfree.data.time.SerialDate serialDate24 = day15.getSerialDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getTime();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(6);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
//        boolean boolean35 = spreadsheetDate26.isInRange(serialDate29, serialDate33, 5);
//        boolean boolean36 = spreadsheetDate3.isInRange(serialDate24, serialDate33);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
//        org.jfree.data.time.Year year6 = month4.getYear();
//        long long7 = year6.getFirstMillisecond();
//        int int8 = day2.compareTo((java.lang.Object) long7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day2.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day2.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getSerialIndex();
        long long5 = year2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "hi!", "hi!", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        int int7 = month5.getYearValue();
        org.jfree.data.time.Year year8 = month5.getYear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
        org.jfree.data.time.Year year11 = month9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "", class15);
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        timeSeries16.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.addChangeListener(seriesChangeListener19);
        java.util.Collection collection21 = timeSeries16.getTimePeriods();
        int int22 = year8.compareTo((java.lang.Object) timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = null;
        try {
            timeSeries23.add(regularTimePeriod24, (double) 11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.Comparable comparable17 = timeSeries7.getKey();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        org.jfree.data.time.Year year20 = month18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        long long22 = year20.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year20.previous();
        java.lang.String str24 = year20.toString();
        int int25 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        int int35 = day19.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 13 + "'", int35 == 13);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "hi!", "hi!", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        int int7 = month5.getYearValue();
        org.jfree.data.time.Year year8 = month5.getYear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
        org.jfree.data.time.Year year11 = month9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "", "", class15);
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        timeSeries16.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.addChangeListener(seriesChangeListener19);
        java.util.Collection collection21 = timeSeries16.getTimePeriods();
        int int22 = year8.compareTo((java.lang.Object) timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.addAndOrUpdate(timeSeries16);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(comparable17);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "hi!", "ClassContext", class7);
//        long long9 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441326935L + "'", long1 == 1560441326935L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441326935L + "'", long3 == 1560441326935L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560441326935L + "'", long9 == 1560441326935L);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        java.lang.Comparable comparable8 = timeSeries7.getKey();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
//        org.jfree.data.time.Year year12 = month10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "", class16);
//        timeSeries17.setMaximumItemCount((int) (short) 0);
//        java.util.List list20 = timeSeries17.getItems();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "", "", class27);
//        timeSeries28.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
//        java.lang.Class class33 = timeSeries28.getTimePeriodClass();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int37 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date39 = fixedMillisecond38.getTime();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        java.lang.String str41 = day40.toString();
//        java.lang.String str42 = day40.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day40.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        long long45 = fixedMillisecond44.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) day40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries7.addAndOrUpdate(timeSeries17);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(comparable8);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(class33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "13-June-2019" + "'", str41.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560441326966L + "'", long45 == 1560441326966L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNotNull(timeSeries48);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getStart();
        java.util.Calendar calendar16 = null;
        try {
            year12.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str4 = spreadsheetDate3.getDescription();
        int int5 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 1L);
//        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (byte) -1);
//        boolean boolean11 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem8);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond0.getFirstMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441327649L + "'", long1 == 1560441327649L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441327649L + "'", long3 == 1560441327649L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441327649L + "'", long5 == 1560441327649L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560441327649L + "'", long13 == 1560441327649L);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        java.util.Date date7 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean14 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getTime();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean25 = spreadsheetDate16.isInRange(serialDate19, serialDate23, 5);
        boolean boolean27 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, serialDate23, 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean34 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, serialDate33);
        java.util.Date date35 = spreadsheetDate29.toDate();
        int int36 = spreadsheetDate29.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean43 = spreadsheetDate38.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date45 = fixedMillisecond44.getTime();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getNearestDayOfWeek(6);
        boolean boolean49 = spreadsheetDate40.isOn(serialDate46);
        boolean boolean50 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate46);
        int int51 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean58 = spreadsheetDate53.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate55, serialDate57);
        java.util.Date date59 = spreadsheetDate53.toDate();
        int int60 = spreadsheetDate53.getDayOfMonth();
        java.util.Date date61 = spreadsheetDate53.toDate();
        java.lang.String str62 = spreadsheetDate53.toString();
        int int63 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 35 + "'", int51 == 35);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "3-February-1900" + "'", str62.equals("3-February-1900"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        boolean boolean15 = timeSeries7.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.createCopy(2, (int) (byte) 100);
        timeSeries7.setMaximumItemCount(5);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        int int7 = spreadsheetDate3.toSerial();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        org.jfree.data.time.Year year10 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month8.next();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "", "", class14);
        java.lang.Comparable comparable16 = timeSeries15.getKey();
        timeSeries15.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries15.addChangeListener(seriesChangeListener18);
        timeSeries15.clear();
        try {
            int int21 = spreadsheetDate3.compareTo((java.lang.Object) timeSeries15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable16);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        org.jfree.data.time.Year year37 = month35.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month35.next();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "", class41);
//        timeSeries42.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month45.next();
//        org.jfree.data.time.Year year47 = month45.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) year47);
//        java.util.Date date50 = year47.getStart();
//        long long51 = year47.getFirstMillisecond();
//        java.lang.Number number52 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) year47);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month53.next();
//        org.jfree.data.time.Year year55 = month53.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month53.next();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month53, "", "", class59);
//        java.lang.Comparable comparable61 = timeSeries60.getKey();
//        timeSeries60.setDomainDescription("hi!");
//        boolean boolean64 = timeSeries7.equals((java.lang.Object) timeSeries60);
//        timeSeries7.clear();
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month66.next();
//        org.jfree.data.time.Year year68 = month66.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = month66.next();
//        java.lang.Class class72 = null;
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month66, "", "", class72);
//        timeSeries73.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries73.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76);
//        java.lang.Class class78 = timeSeries73.getTimePeriodClass();
//        org.jfree.data.time.Month month81 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int82 = timeSeries73.getIndex((org.jfree.data.time.RegularTimePeriod) month81);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date84 = fixedMillisecond83.getTime();
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date84);
//        java.lang.String str86 = day85.toString();
//        java.lang.String str87 = day85.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = day85.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond89 = new org.jfree.data.time.FixedMillisecond();
//        long long90 = fixedMillisecond89.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries73.createCopy((org.jfree.data.time.RegularTimePeriod) day85, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond89);
//        java.lang.Number number92 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem93 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day85, number92);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(comparable61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNull(class78);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "13-June-2019" + "'", str86.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "13-June-2019" + "'", str87.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560441328435L + "'", long90 == 1560441328435L);
//        org.junit.Assert.assertNotNull(timeSeries91);
//        org.junit.Assert.assertNull(timeSeriesDataItem93);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        java.lang.String str10 = timeSeries7.getDomainDescription();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
//        org.jfree.data.time.Year year13 = month11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
//        timeSeries18.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
//        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
//        long long29 = fixedMillisecond24.getLastMillisecond();
//        long long30 = fixedMillisecond24.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560441330590L + "'", long29 == 1560441330590L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560441330590L + "'", long30 == 1560441330590L);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        java.lang.Comparable comparable8 = timeSeries7.getKey();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
//        org.jfree.data.time.Year year12 = month10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "", class16);
//        timeSeries17.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        int int22 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
//        org.jfree.data.time.Year year25 = month23.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        int int27 = year25.getYear();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.next();
//        org.jfree.data.time.Year year30 = month28.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "", "", class34);
//        timeSeries35.setMaximumItemCount((int) (short) 0);
//        java.lang.String str38 = timeSeries35.getDomainDescription();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month39.next();
//        org.jfree.data.time.Year year41 = month39.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month39.next();
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "", "", class45);
//        timeSeries46.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        java.lang.Class class51 = timeSeries46.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date53 = fixedMillisecond52.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) (short) 10);
//        timeSeries35.setKey((java.lang.Comparable) fixedMillisecond52);
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond52.getLastMillisecond(calendar57);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date60 = fixedMillisecond59.getTime();
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
//        java.lang.String str62 = day61.toString();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month63.next();
//        org.jfree.data.time.Year year65 = month63.getYear();
//        long long66 = year65.getFirstMillisecond();
//        int int67 = day61.compareTo((java.lang.Object) long66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day61.next();
//        boolean boolean69 = fixedMillisecond52.equals((java.lang.Object) day61);
//        long long70 = fixedMillisecond52.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond52.next();
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, regularTimePeriod71);
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month();
//        java.lang.Object obj74 = null;
//        boolean boolean75 = month73.equals(obj74);
//        long long76 = month73.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month73, 0.0d);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(comparable8);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(class51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560441330735L + "'", long58 == 1560441330735L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "13-June-2019" + "'", str62.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1546329600000L + "'", long66 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560441330735L + "'", long70 == 1560441330735L);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 24234L + "'", long76 == 24234L);
//        org.junit.Assert.assertNull(timeSeriesDataItem78);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        java.util.Date date7 = spreadsheetDate3.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date7, timeZone11);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date7);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("January");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        long long4 = day2.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
        timeSeries18.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "hi!", "hi!", class32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.addAndOrUpdate(timeSeries33);
        timeSeries7.setDescription("ClassContext");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        int int3 = month0.getMonth();
        int int4 = month0.getYearValue();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getStart();
        long long16 = year12.getFirstMillisecond();
        int int18 = year12.compareTo((java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
//        org.jfree.data.time.Year year6 = month4.getYear();
//        long long7 = year6.getFirstMillisecond();
//        int int8 = day2.compareTo((java.lang.Object) long7);
//        long long9 = day2.getFirstMillisecond();
//        int int10 = day2.getDayOfMonth();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day2.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.addChangeListener(seriesChangeListener10);
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries7.createCopy(9999, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        java.util.Collection collection13 = timeSeries7.getTimePeriods();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNotNull(collection13);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        java.lang.Comparable comparable8 = timeSeries7.getKey();
//        timeSeries7.clear();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
//        org.jfree.data.time.Year year12 = month10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "", "", class16);
//        timeSeries17.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        int int22 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
//        org.jfree.data.time.Year year25 = month23.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
//        int int27 = year25.getYear();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.next();
//        org.jfree.data.time.Year year30 = month28.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "", "", class34);
//        timeSeries35.setMaximumItemCount((int) (short) 0);
//        java.lang.String str38 = timeSeries35.getDomainDescription();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month39.next();
//        org.jfree.data.time.Year year41 = month39.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month39.next();
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "", "", class45);
//        timeSeries46.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        java.lang.Class class51 = timeSeries46.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date53 = fixedMillisecond52.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) (short) 10);
//        timeSeries35.setKey((java.lang.Comparable) fixedMillisecond52);
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond52.getLastMillisecond(calendar57);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date60 = fixedMillisecond59.getTime();
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
//        java.lang.String str62 = day61.toString();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month63.next();
//        org.jfree.data.time.Year year65 = month63.getYear();
//        long long66 = year65.getFirstMillisecond();
//        int int67 = day61.compareTo((java.lang.Object) long66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day61.next();
//        boolean boolean69 = fixedMillisecond52.equals((java.lang.Object) day61);
//        long long70 = fixedMillisecond52.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond52.next();
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, regularTimePeriod71);
//        java.lang.String str73 = timeSeries7.getDomainDescription();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(comparable8);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(class51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560441338926L + "'", long58 == 1560441338926L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "13-June-2019" + "'", str62.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1546329600000L + "'", long66 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560441338926L + "'", long70 == 1560441338926L);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "" + "'", str73.equals(""));
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        org.jfree.data.time.Year year3 = month0.getYear();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = year4.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        java.lang.String str4 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        org.jfree.data.time.Year year8 = month6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "", class12);
//        java.lang.Comparable comparable14 = timeSeries13.getKey();
//        timeSeries13.clear();
//        boolean boolean16 = day2.equals((java.lang.Object) timeSeries13);
//        java.lang.String str17 = day2.toString();
//        int int18 = day2.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(comparable14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Thu Jun 13 08:54:30 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        boolean boolean2 = month0.equals(obj1);
        int int3 = month0.getMonth();
        long long4 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        java.lang.String str4 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        org.jfree.data.time.Year year8 = month6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "", class12);
//        java.lang.Comparable comparable14 = timeSeries13.getKey();
//        timeSeries13.clear();
//        boolean boolean16 = day2.equals((java.lang.Object) timeSeries13);
//        int int17 = day2.getDayOfMonth();
//        int int18 = day2.getMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(comparable14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        long long6 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441340389L + "'", long1 == 1560441340389L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441340389L + "'", long3 == 1560441340389L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441340389L + "'", long5 == 1560441340389L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560441340389L + "'", long6 == 1560441340389L);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 1L);
//        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (byte) -1);
//        boolean boolean11 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem8);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond0.getLastMillisecond(calendar12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441340405L + "'", long1 == 1560441340405L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441340405L + "'", long3 == 1560441340405L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441340405L + "'", long5 == 1560441340405L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560441340405L + "'", long13 == 1560441340405L);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
//        boolean boolean5 = timeSeriesDataItem2.equals((java.lang.Object) regularTimePeriod4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        java.lang.String str10 = fixedMillisecond6.toString();
//        boolean boolean11 = timeSeriesDataItem2.equals((java.lang.Object) fixedMillisecond6);
//        java.lang.Object obj12 = timeSeriesDataItem2.clone();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560441340428L + "'", long9 == 1560441340428L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Thu Jun 13 08:55:40 PDT 2019" + "'", str10.equals("Thu Jun 13 08:55:40 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(obj12);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean4 = spreadsheetDate2.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean16 = spreadsheetDate7.isInRange(serialDate10, serialDate14, 5);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate2.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate18);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate19);
        java.lang.Object obj21 = seriesChangeEvent20.getSource();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1L);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        boolean boolean5 = timeSeriesDataItem2.equals((java.lang.Object) regularTimePeriod4);
        java.lang.Number number6 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1L + "'", number6.equals(1L));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.Year year14 = month12.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.next();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, "", "", class18);
        timeSeries19.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.lang.Class class24 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int28 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries19.removeChangeListener(seriesChangeListener29);
        java.lang.String str31 = timeSeries19.getRangeDescription();
        int int32 = timeSeries19.getMaximumItemCount();
        java.util.Collection collection33 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        try {
            timeSeries19.update((int) (byte) 0, (java.lang.Number) 24234L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(collection33);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean10 = spreadsheetDate8.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean22 = spreadsheetDate13.isInRange(serialDate16, serialDate20, 5);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(13, serialDate16);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate8.getEndOfCurrentMonth(serialDate16);
        int int25 = spreadsheetDate3.compare(serialDate24);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-43611) + "'", int25 == (-43611));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
//        boolean boolean25 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, serialDate24);
//        java.util.Date date26 = spreadsheetDate20.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getTime();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.Year year31 = month29.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.next();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "", "", class35);
//        timeSeries36.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries36.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        java.lang.Class class41 = timeSeries36.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getTime();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.next();
//        org.jfree.data.time.Year year52 = month50.getYear();
//        long long53 = year52.getFirstMillisecond();
//        int int54 = day48.compareTo((java.lang.Object) long53);
//        java.lang.Class class56 = null;
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class56);
//        timeSeries57.removeAgedItems(false);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
//        int int61 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) year60);
//        long long62 = year60.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) year60);
//        int int64 = fixedMillisecond27.compareTo((java.lang.Object) year60);
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
//        org.jfree.data.time.Year year67 = month65.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month65.next();
//        java.lang.Class class71 = null;
//        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month65, "", "", class71);
//        timeSeries72.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = month75.next();
//        org.jfree.data.time.Year year77 = month75.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = year77.previous();
//        timeSeries72.delete((org.jfree.data.time.RegularTimePeriod) year77);
//        java.util.Date date80 = year77.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date82 = fixedMillisecond81.getTime();
//        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date82);
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month85 = new org.jfree.data.time.Month(date82, timeZone84);
//        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date80, timeZone84);
//        boolean boolean87 = year60.equals((java.lang.Object) timeZone84);
//        org.jfree.data.time.Month month88 = new org.jfree.data.time.Month(date26, timeZone84);
//        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month89, (java.lang.Number) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = month89.previous();
//        java.util.Date date93 = regularTimePeriod92.getStart();
//        org.jfree.data.time.TimeSeries timeSeries94 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month88, regularTimePeriod92);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = timeSeries94.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(class41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(year52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1546329600000L + "'", long53 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1546329600000L + "'", long62 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(year77);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(date93);
//        org.junit.Assert.assertNotNull(timeSeries94);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        org.jfree.data.time.Year year37 = month35.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month35.next();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "", class41);
//        timeSeries42.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month45.next();
//        org.jfree.data.time.Year year47 = month45.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) year47);
//        java.util.Date date50 = year47.getStart();
//        long long51 = year47.getFirstMillisecond();
//        java.lang.Number number52 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) year47);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month53.next();
//        org.jfree.data.time.Year year55 = month53.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month53.next();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month53, "", "", class59);
//        java.lang.Comparable comparable61 = timeSeries60.getKey();
//        timeSeries60.setDomainDescription("hi!");
//        boolean boolean64 = timeSeries7.equals((java.lang.Object) timeSeries60);
//        java.lang.Class class65 = timeSeries7.getTimePeriodClass();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.createCopy(10, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(comparable61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNull(class65);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        java.util.Date date7 = spreadsheetDate3.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date7, timeZone11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean20 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, serialDate19);
        java.util.Date date21 = spreadsheetDate17.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getTime();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date21, timeZone25);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date7, timeZone25);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(timeZone25);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "", "", class17);
        timeSeries18.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (short) 10);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond24);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "hi!", "hi!", class32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.addAndOrUpdate(timeSeries33);
        int int35 = timeSeries33.getMaximumItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str6 = seriesException5.toString();
//        java.lang.Throwable[] throwableArray7 = seriesException5.getSuppressed();
//        int int8 = day2.compareTo((java.lang.Object) throwableArray7);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str6.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.next();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "", class10);
        timeSeries11.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        int int16 = timeSeries11.getMaximumItemCount();
        int int17 = fixedMillisecond3.compareTo((java.lang.Object) int16);
        java.util.Date date18 = fixedMillisecond3.getTime();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean4 = spreadsheetDate2.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean16 = spreadsheetDate7.isInRange(serialDate10, serialDate14, 5);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate2.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate18);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate19);
        java.lang.String str21 = seriesChangeEvent20.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=30-October-2027]" + "'", str21.equals("org.jfree.data.general.SeriesChangeEvent[source=30-October-2027]"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) "hi!");
        java.util.Date date4 = spreadsheetDate1.toDate();
        int int5 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        org.jfree.data.time.Year year37 = month35.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month35.next();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "", class41);
//        timeSeries42.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month45.next();
//        org.jfree.data.time.Year year47 = month45.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) year47);
//        java.util.Date date50 = year47.getStart();
//        long long51 = year47.getFirstMillisecond();
//        java.lang.Number number52 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) year47);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month53.next();
//        org.jfree.data.time.Year year55 = month53.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month53.next();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month53, "", "", class59);
//        java.lang.Comparable comparable61 = timeSeries60.getKey();
//        timeSeries60.setDomainDescription("hi!");
//        boolean boolean64 = timeSeries7.equals((java.lang.Object) timeSeries60);
//        timeSeries7.clear();
//        try {
//            timeSeries7.delete(2147483647, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(comparable61);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        boolean boolean15 = timeSeries7.isEmpty();
        timeSeries7.setRangeDescription("");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate(regularTimePeriod18, (double) 1560441326966L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class1);
        timeSeries2.removeAgedItems(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.removeChangeListener(seriesChangeListener5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getSerialIndex();
        long long5 = year2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        java.lang.String str4 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        org.jfree.data.time.Year year8 = month6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "", class12);
//        java.lang.Comparable comparable14 = timeSeries13.getKey();
//        timeSeries13.clear();
//        boolean boolean16 = day2.equals((java.lang.Object) timeSeries13);
//        int int17 = day2.getMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(comparable14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) "hi!");
        java.util.Date date4 = spreadsheetDate1.toDate();
        int int5 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int7 = day6.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        java.lang.String str4 = day2.toString();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
//        org.jfree.data.time.Year year7 = month5.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.next();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month5, "", "", class11);
//        timeSeries12.setMaximumItemCount((int) (short) 0);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
//        org.jfree.data.time.Year year18 = month16.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month16.next();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month16, "", "", class22);
//        timeSeries23.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        java.lang.Class class28 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) (short) 10);
//        timeSeries12.setKey((java.lang.Comparable) fixedMillisecond29);
//        long long34 = fixedMillisecond29.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond29.next();
//        int int36 = day2.compareTo((java.lang.Object) regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(class28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560441342505L + "'", long34 == 1560441342505L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ThreadContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
        java.lang.Object obj17 = timeSeries7.clone();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        org.jfree.data.time.Year year20 = month18.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "", "", class24);
        timeSeries25.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.next();
        org.jfree.data.time.Year year30 = month28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) year30);
        java.util.Date date33 = year30.getStart();
        long long34 = year30.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) (-1));
        boolean boolean37 = timeSeries7.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Sunday");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries7.createCopy((int) (byte) 0, 13);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean14 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, serialDate13);
        int int15 = spreadsheetDate9.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean19 = spreadsheetDate17.equals((java.lang.Object) "hi!");
        int int20 = spreadsheetDate17.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean24 = spreadsheetDate22.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean31 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, serialDate30);
        java.util.Date date32 = spreadsheetDate28.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean39 = spreadsheetDate34.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, serialDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date43 = fixedMillisecond42.getTime();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date43);
        org.jfree.data.time.SerialDate serialDate46 = serialDate44.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean50 = spreadsheetDate41.isInRange(serialDate44, serialDate48, 5);
        boolean boolean52 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate34, serialDate48, 1);
        boolean boolean54 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, serialDate48, (int) (short) 0);
        boolean boolean55 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int56 = spreadsheetDate1.compareTo((java.lang.Object) spreadsheetDate17);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 7 + "'", int20 == 7);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.Year year4 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "", "", class8);
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        int int11 = day0.compareTo((java.lang.Object) timeSeries9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(comparable10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
//        boolean boolean25 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, serialDate24);
//        java.util.Date date26 = spreadsheetDate20.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getTime();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.Year year31 = month29.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.next();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "", "", class35);
//        timeSeries36.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries36.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        java.lang.Class class41 = timeSeries36.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getTime();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.next();
//        org.jfree.data.time.Year year52 = month50.getYear();
//        long long53 = year52.getFirstMillisecond();
//        int int54 = day48.compareTo((java.lang.Object) long53);
//        java.lang.Class class56 = null;
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class56);
//        timeSeries57.removeAgedItems(false);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
//        int int61 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) year60);
//        long long62 = year60.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) year60);
//        int int64 = fixedMillisecond27.compareTo((java.lang.Object) year60);
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.next();
//        org.jfree.data.time.Year year67 = month65.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month65.next();
//        java.lang.Class class71 = null;
//        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month65, "", "", class71);
//        timeSeries72.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = month75.next();
//        org.jfree.data.time.Year year77 = month75.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = year77.previous();
//        timeSeries72.delete((org.jfree.data.time.RegularTimePeriod) year77);
//        java.util.Date date80 = year77.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date82 = fixedMillisecond81.getTime();
//        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date82);
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month85 = new org.jfree.data.time.Month(date82, timeZone84);
//        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date80, timeZone84);
//        boolean boolean87 = year60.equals((java.lang.Object) timeZone84);
//        org.jfree.data.time.Month month88 = new org.jfree.data.time.Month(date26, timeZone84);
//        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month89, (java.lang.Number) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = month89.previous();
//        java.util.Date date93 = regularTimePeriod92.getStart();
//        org.jfree.data.time.TimeSeries timeSeries94 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month88, regularTimePeriod92);
//        java.lang.Class class95 = timeSeries7.getTimePeriodClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(class41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(year52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1546329600000L + "'", long53 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1546329600000L + "'", long62 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(year77);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(date93);
//        org.junit.Assert.assertNotNull(timeSeries94);
//        org.junit.Assert.assertNull(class95);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        timeSeries7.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.addChangeListener(seriesChangeListener10);
        timeSeries7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(comparable8);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 1L);
//        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (byte) -1);
//        boolean boolean11 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        boolean boolean14 = fixedMillisecond0.equals((java.lang.Object) fixedMillisecond12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441347131L + "'", long1 == 1560441347131L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441347131L + "'", long3 == 1560441347131L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560441347131L + "'", long5 == 1560441347131L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 10, 100);
//        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        java.lang.String str21 = day19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
//        org.jfree.data.time.Year year28 = month26.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "", "", class32);
//        timeSeries33.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
//        java.lang.Class class38 = timeSeries33.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date40 = fixedMillisecond39.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date44 = fixedMillisecond43.getTime();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        java.lang.String str46 = day45.toString();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month47.next();
//        org.jfree.data.time.Year year49 = month47.getYear();
//        long long50 = year49.getFirstMillisecond();
//        int int51 = day45.compareTo((java.lang.Object) long50);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class53);
//        timeSeries54.removeAgedItems(false);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
//        int int58 = timeSeries54.getIndex((org.jfree.data.time.RegularTimePeriod) year57);
//        long long59 = year57.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) day45, (org.jfree.data.time.RegularTimePeriod) year57);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year57, (double) 6);
//        long long63 = year57.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560441347210L + "'", long24 == 1560441347210L);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNull(class38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "13-June-2019" + "'", str46.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1546329600000L + "'", long59 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1577865599999L + "'", long63 == 1577865599999L);
//    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
//        org.jfree.data.time.Year year6 = month4.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.next();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "", "", class10);
//        timeSeries11.setMaximumItemCount((int) (short) 0);
//        java.lang.String str14 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.next();
//        org.jfree.data.time.Year year17 = month15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.next();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month15, "", "", class21);
//        timeSeries22.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        java.lang.Class class27 = timeSeries22.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date29 = fixedMillisecond28.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (short) 10);
//        timeSeries11.setKey((java.lang.Comparable) fixedMillisecond28);
//        long long33 = fixedMillisecond28.getLastMillisecond();
//        boolean boolean34 = day2.equals((java.lang.Object) long33);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(class27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560441347990L + "'", long33 == 1560441347990L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate3.getFollowingDayOfWeek(1);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean3 = spreadsheetDate1.equals((java.lang.Object) "hi!");
        java.util.Date date4 = spreadsheetDate1.toDate();
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean13 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, serialDate12);
        java.util.Date date14 = spreadsheetDate8.toDate();
        int int15 = spreadsheetDate8.getDayOfMonth();
        int int16 = spreadsheetDate8.toSerial();
        boolean boolean17 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean21 = spreadsheetDate19.equals((java.lang.Object) "hi!");
        int int22 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate5.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean19 = spreadsheetDate10.isInRange(serialDate13, serialDate17, 5);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays(13, serialDate13);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate5.getEndOfCurrentMonth(serialDate13);
        java.lang.Class<?> wildcardClass22 = serialDate13.getClass();
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "3-February-1900", "Thu Jun 13 08:55:40 PDT 2019", "Sunday", (java.lang.Class) wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(uRL23);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond3.peg(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond3.getFirstMillisecond(calendar7);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560441348596L + "'", long8 == 1560441348596L);
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond13.getMiddleMillisecond(calendar15);
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        long long18 = fixedMillisecond13.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560441348639L + "'", long14 == 1560441348639L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560441348639L + "'", long16 == 1560441348639L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560441348639L + "'", long18 == 1560441348639L);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean6 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate5);
        java.util.Date date7 = spreadsheetDate3.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date7, timeZone11);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        org.jfree.data.time.Year year16 = month14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "", "", class20);
        timeSeries21.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        org.jfree.data.time.Year year26 = month24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) year26);
        java.util.Date date29 = year26.getStart();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        int int31 = year13.compareTo((java.lang.Object) month30);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone3);
        long long5 = month4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
        timeSeries7.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        org.jfree.data.time.Year year12 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year12);
        boolean boolean15 = timeSeries7.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.createCopy(2, (int) (byte) 100);
        timeSeries18.setMaximumItemAge(1560441259746L);
        timeSeries18.setMaximumItemAge((long) 12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone3);
        long long5 = month4.getFirstMillisecond();
        int int6 = month4.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=30-October-2027]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate5.equals((java.lang.Object) "hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        boolean boolean19 = spreadsheetDate10.isInRange(serialDate13, serialDate17, 5);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays(13, serialDate13);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate5.getEndOfCurrentMonth(serialDate13);
        java.lang.Class<?> wildcardClass22 = serialDate13.getClass();
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass22);
        java.io.InputStream inputStream24 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("13-June-2019", (java.lang.Class) wildcardClass22);
        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:54:23 PDT 2019", (java.lang.Class) wildcardClass22);
        java.lang.Object obj26 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", (java.lang.Class) wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(uRL23);
        org.junit.Assert.assertNull(inputStream24);
        org.junit.Assert.assertNull(uRL25);
        org.junit.Assert.assertNull(obj26);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond13.getMiddleMillisecond(calendar15);
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        org.jfree.data.time.Year year20 = month18.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "", "", class24);
//        timeSeries25.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        java.lang.Class class30 = timeSeries25.getTimePeriodClass();
//        int int31 = timeSeries25.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries25);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560441349517L + "'", long14 == 1560441349517L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560441349517L + "'", long16 == 1560441349517L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(class30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(timeSeries32);
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.lang.String str3 = day2.toString();
//        java.lang.String str4 = day2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        org.jfree.data.time.Year year8 = month6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "", "", class12);
//        java.lang.Comparable comparable14 = timeSeries13.getKey();
//        timeSeries13.clear();
//        boolean boolean16 = day2.equals((java.lang.Object) timeSeries13);
//        java.lang.String str17 = day2.toString();
//        int int19 = day2.compareTo((java.lang.Object) 1560441322208L);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(comparable14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "", "", class6);
//        timeSeries7.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.Year year23 = month21.getYear();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = day19.compareTo((java.lang.Object) long24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, class27);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
//        long long33 = year31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) year31);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
//        org.jfree.data.time.Year year37 = month35.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month35.next();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "", "", class41);
//        timeSeries42.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month45.next();
//        org.jfree.data.time.Year year47 = month45.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) year47);
//        java.util.Date date50 = year47.getStart();
//        long long51 = year47.getFirstMillisecond();
//        java.lang.Number number52 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) year47);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month53.next();
//        int int55 = month53.getYearValue();
//        org.jfree.data.time.Year year56 = month53.getYear();
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month57, (java.lang.Number) 1L);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month60.next();
//        boolean boolean62 = timeSeriesDataItem59.equals((java.lang.Object) regularTimePeriod61);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date64 = fixedMillisecond63.getTime();
//        java.util.Calendar calendar65 = null;
//        long long66 = fixedMillisecond63.getFirstMillisecond(calendar65);
//        java.lang.String str67 = fixedMillisecond63.toString();
//        boolean boolean68 = timeSeriesDataItem59.equals((java.lang.Object) fixedMillisecond63);
//        boolean boolean69 = month53.equals((java.lang.Object) fixedMillisecond63);
//        int int70 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560441349960L + "'", long66 == 1560441349960L);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Thu Jun 13 08:55:49 PDT 2019" + "'", str67.equals("Thu Jun 13 08:55:49 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
//    }
//}

