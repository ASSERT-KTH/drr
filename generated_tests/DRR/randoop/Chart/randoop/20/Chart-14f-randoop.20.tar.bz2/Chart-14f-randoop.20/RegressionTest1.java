import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.DatasetChangeEvent[source=-1.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        java.awt.Stroke stroke18 = xYPlot14.getDomainCrosshairStroke();
        double double19 = xYPlot14.getDomainCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot14.setRangeAxisLocation(11, axisLocation21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot14.setRangeZeroBaselineStroke(stroke23);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot8.getDataset((int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setTickMarkStroke(stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis24.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot29.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot29.getLegendItems();
        categoryPlot29.clearDomainMarkers();
        float float33 = categoryPlot29.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset35);
        java.lang.Object obj37 = datasetChangeEvent36.getSource();
        org.jfree.data.general.Dataset dataset38 = datasetChangeEvent36.getDataset();
        categoryPlot29.datasetChanged(datasetChangeEvent36);
        categoryPlot8.datasetChanged(datasetChangeEvent36);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNotNull(legendItemCollection31);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj37 + "' != '" + (-1.0f) + "'", obj37.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset38);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot14.zoomDomainAxes((double) (-52), (double) (byte) 100, plotRenderingInfo38, point2D39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot14.getRangeAxisEdge();
        xYPlot14.setDomainZeroBaselineVisible(true);
        java.awt.Stroke stroke44 = xYPlot14.getOutlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace45 = xYPlot14.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(axisSpace45);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot14.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint30 = xYPlot14.getRangeCrosshairPaint();
        boolean boolean31 = xYPlot14.isDomainCrosshairLockedOnData();
        xYPlot14.setForegroundAlpha(0.8f);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder34 = xYPlot14.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder34);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        double double12 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str20 = axisLocation19.toString();
        categoryPlot8.setDomainAxisLocation(axisLocation19);
        categoryPlot8.zoom((double) 4);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str20.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        xYPlot17.setDomainCrosshairLockedOnData(true);
        int int24 = xYPlot17.getRangeAxisCount();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        categoryPlot8.clearDomainMarkers((int) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis25.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = null;
        dateAxis30.setTickUnit(dateTickUnit31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke33);
        java.awt.Shape shape35 = dateAxis30.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer36);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        xYPlot37.addChangeListener(plotChangeListener38);
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot37.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis44.setTickMarkStroke(stroke45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = dateAxis44.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer48);
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot49.setDomainAxisLocation((int) (short) 1, axisLocation51);
        xYPlot37.setRangeAxisLocation(axisLocation51);
        boolean boolean54 = xYPlot37.isSubplot();
        java.awt.geom.Point2D point2D55 = xYPlot37.getQuadrantOrigin();
        categoryPlot8.zoomDomainAxes((double) (-1), plotRenderingInfo22, point2D55);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(point2D55);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis9.setAxisLineStroke(stroke12);
        java.awt.Shape shape14 = dateAxis9.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        boolean boolean17 = xYPlot16.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup18 = xYPlot16.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot16.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        dateAxis21.setLowerMargin((double) 8);
        dateAxis21.setFixedDimension((double) (byte) 1);
        int int28 = xYPlot16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis21);
        xYPlot16.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = null;
        dateAxis32.setTickUnit(dateTickUnit33);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis32.setAxisLineStroke(stroke35);
        java.awt.Shape shape37 = dateAxis32.getDownArrow();
        xYPlot16.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        xYPlot16.setFixedRangeAxisSpace(axisSpace39, false);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis46.setTickMarkStroke(stroke47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = dateAxis46.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis46, categoryItemRenderer50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = categoryPlot51.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection53 = categoryPlot51.getLegendItems();
        categoryPlot51.clearDomainMarkers();
        float float55 = categoryPlot51.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset57 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent58 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset57);
        java.lang.Object obj59 = datasetChangeEvent58.getSource();
        org.jfree.data.general.Dataset dataset60 = datasetChangeEvent58.getDataset();
        categoryPlot51.datasetChanged(datasetChangeEvent58);
        boolean boolean62 = categoryPlot51.isDomainGridlinesVisible();
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color65 = java.awt.Color.getColor("", color64);
        categoryPlot51.setOutlinePaint((java.awt.Paint) color65);
        categoryPlot51.configureDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = categoryPlot51.getDomainAxisEdge(10);
        org.jfree.chart.axis.AxisSpace axisSpace70 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace71 = categoryAxis0.reserveSpace(graphics2D1, (org.jfree.chart.plot.Plot) xYPlot16, rectangle2D42, rectangleEdge69, axisSpace70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNull(categoryAxis52);
        org.junit.Assert.assertNotNull(legendItemCollection53);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 1.0f + "'", float55 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj59 + "' != '" + (-1.0f) + "'", obj59.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(rectangleEdge69);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot8.addDomainMarker((int) (byte) -1, categoryMarker15, layer16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis22.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.data.time.DateRange dateRange30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis27.setRangeWithMargins((org.jfree.data.Range) dateRange30);
        dateAxis22.setRangeWithMargins((org.jfree.data.Range) dateRange30, true, false);
        dateAxis19.setRange((org.jfree.data.Range) dateRange30);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setTickMarkStroke(stroke38);
        java.util.TimeZone timeZone40 = dateAxis37.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis37.setTickUnit(dateTickUnit41, false, false);
        java.util.Date date45 = dateAxis19.calculateLowestVisibleTickValue(dateTickUnit41);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        categoryMarker15.setKey((java.lang.Comparable) day46);
        java.util.Calendar calendar48 = null;
        try {
            day46.peg(calendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(dateRange30);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(dateTickUnit41);
        org.junit.Assert.assertNotNull(date45);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        int int2 = day1.getMonth();
        java.util.Date date3 = day1.getEnd();
        java.lang.Class class4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis6.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis9.setTickMarkStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis9.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = null;
        dateAxis14.setTickUnit(dateTickUnit15);
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis14.setRangeWithMargins((org.jfree.data.Range) dateRange17);
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange17, true, false);
        dateAxis6.setRange((org.jfree.data.Range) dateRange17);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setTickMarkStroke(stroke25);
        java.util.TimeZone timeZone27 = dateAxis24.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis24.setTickUnit(dateTickUnit28, false, false);
        java.util.Date date32 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit28);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = dateAxis34.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setTickMarkStroke(stroke38);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = dateAxis37.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = null;
        dateAxis42.setTickUnit(dateTickUnit43);
        org.jfree.data.time.DateRange dateRange45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis42.setRangeWithMargins((org.jfree.data.Range) dateRange45);
        dateAxis37.setRangeWithMargins((org.jfree.data.Range) dateRange45, true, false);
        dateAxis34.setRange((org.jfree.data.Range) dateRange45);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis52.setTickMarkStroke(stroke53);
        java.util.TimeZone timeZone55 = dateAxis52.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit56 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis52.setTickUnit(dateTickUnit56, false, false);
        java.util.Date date60 = dateAxis34.calculateLowestVisibleTickValue(dateTickUnit56);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis63.setTickMarkStroke(stroke64);
        java.util.TimeZone timeZone66 = dateAxis63.getTimeZone();
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date60, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date32, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone66);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(dateTickUnit28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(dateRange45);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(dateTickUnit56);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNull(regularTimePeriod69);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis(0, (int) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot8.zoomDomainAxes((double) 11, plotRenderingInfo13, point2D14, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.setMaximumCategoryLabelWidthRatio(0.0f);
        int int21 = categoryAxis18.getMaximumCategoryLabelLines();
        double double22 = categoryAxis18.getLowerMargin();
        java.lang.Object obj23 = categoryAxis18.clone();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis27.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot32.setDomainAxisLocation((int) (short) 1, axisLocation34);
        boolean boolean36 = categoryPlot32.isSubplot();
        java.util.List list37 = categoryPlot32.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = null;
        dateAxis39.setTickUnit(dateTickUnit40);
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis39.setAxisLineStroke(stroke42);
        categoryPlot32.setOutlineStroke(stroke42);
        boolean boolean45 = categoryAxis18.equals((java.lang.Object) stroke42);
        categoryAxis18.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis54.setTickMarkStroke(stroke55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = dateAxis54.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis54, categoryItemRenderer58);
        org.jfree.chart.axis.AxisLocation axisLocation61 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot59.setDomainAxisLocation((int) (short) 1, axisLocation61);
        boolean boolean63 = categoryPlot59.isDomainZoomable();
        org.jfree.chart.util.Layer layer65 = null;
        java.util.Collection collection66 = categoryPlot59.getRangeMarkers(5, layer65);
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis69.setTickMarkStroke(stroke70);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = dateAxis69.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit75 = null;
        dateAxis74.setTickUnit(dateTickUnit75);
        java.awt.Stroke stroke77 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis74.setAxisLineStroke(stroke77);
        java.awt.Shape shape79 = dateAxis74.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer80 = null;
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot(xYDataset67, (org.jfree.chart.axis.ValueAxis) dateAxis69, (org.jfree.chart.axis.ValueAxis) dateAxis74, xYItemRenderer80);
        org.jfree.chart.event.PlotChangeListener plotChangeListener82 = null;
        xYPlot81.addChangeListener(plotChangeListener82);
        org.jfree.chart.axis.AxisLocation axisLocation84 = xYPlot81.getDomainAxisLocation();
        categoryPlot59.setDomainAxisLocation(axisLocation84);
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = categoryPlot59.getDomainAxisEdge(0);
        double double88 = categoryAxis18.getCategoryJava2DCoordinate(categoryAnchor47, (int) (byte) 1, 5, rectangle2D50, rectangleEdge87);
        categoryPlot8.setDomainAxis(100, categoryAxis18);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(collection66);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(rectangleEdge87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setUpperMargin(0.05d);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        java.util.TimeZone timeZone6 = dateAxis3.getTimeZone();
        dateAxis3.setLabelAngle(0.0d);
        java.awt.Font font9 = dateAxis3.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke14);
        java.awt.Shape shape16 = dateAxis11.getUpArrow();
        dateAxis3.setRightArrow(shape16);
        objectList0.set((int) ' ', (java.lang.Object) dateAxis3);
        objectList0.clear();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot14.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker22, layer23, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = intervalMarker22.getLabelOffsetType();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = intervalMarker22.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
        org.junit.Assert.assertNull(gradientPaintTransformer27);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        int int2 = day0.compareTo(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = color1.brighter();
        java.awt.Color color3 = java.awt.Color.BLACK;
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = color4.brighter();
        java.awt.color.ColorSpace colorSpace6 = color4.getColorSpace();
        float[] floatArray7 = null;
        float[] floatArray8 = color3.getComponents(colorSpace6, floatArray7);
        java.awt.Color color9 = java.awt.Color.white;
        java.awt.Color color10 = java.awt.Color.white;
        float[] floatArray15 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray16 = color10.getRGBColorComponents(floatArray15);
        float[] floatArray17 = color9.getRGBColorComponents(floatArray15);
        float[] floatArray18 = color1.getComponents(colorSpace6, floatArray17);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis(0, (int) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot8.zoomDomainAxes((double) 11, plotRenderingInfo13, point2D14, true);
        categoryPlot8.setRangeGridlinesVisible(false);
        categoryPlot8.setRangeCrosshairValue(0.0d, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        categoryPlot8.drawBackgroundImage(graphics2D20, rectangle2D21);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        xYPlot14.clearDomainMarkers((int) (byte) 10);
        xYPlot14.setRangeCrosshairValue(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot14.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit5, false, false);
        org.jfree.data.Range range9 = dateAxis1.getDefaultAutoRange();
        boolean boolean10 = dateAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot8.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        java.lang.Object obj16 = null;
        boolean boolean17 = categoryMarker15.equals(obj16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot26.render(graphics2D27, rectangle2D28, (int) (short) 100, plotRenderingInfo30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot26.setFixedDomainAxisSpace(axisSpace32, false);
        double double35 = categoryPlot26.getRangeCrosshairValue();
        categoryPlot26.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot26.getDataset((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
        categoryPlot26.setDomainAxisLocation((int) (byte) 10, axisLocation40);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection44 = categoryPlot26.getRangeMarkers(3, layer43);
        boolean boolean45 = categoryPlot8.removeDomainMarker(1, (org.jfree.chart.plot.Marker) categoryMarker15, layer43);
        org.jfree.chart.util.SortOrder sortOrder46 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis49.setTickMarkStroke(stroke50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = dateAxis49.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = null;
        dateAxis54.setTickUnit(dateTickUnit55);
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis54.setAxisLineStroke(stroke57);
        java.awt.Shape shape59 = dateAxis54.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) dateAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer60);
        org.jfree.chart.event.PlotChangeListener plotChangeListener62 = null;
        xYPlot61.addChangeListener(plotChangeListener62);
        org.jfree.chart.axis.AxisLocation axisLocation64 = xYPlot61.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis67.setTickMarkStroke(stroke68);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = dateAxis67.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit73 = null;
        dateAxis72.setTickUnit(dateTickUnit73);
        java.awt.Stroke stroke75 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis72.setAxisLineStroke(stroke75);
        java.awt.Shape shape77 = dateAxis72.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer78 = null;
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot(xYDataset65, (org.jfree.chart.axis.ValueAxis) dateAxis67, (org.jfree.chart.axis.ValueAxis) dateAxis72, xYItemRenderer78);
        org.jfree.chart.event.PlotChangeListener plotChangeListener80 = null;
        xYPlot79.addChangeListener(plotChangeListener80);
        org.jfree.chart.axis.AxisLocation axisLocation82 = xYPlot79.getDomainAxisLocation();
        xYPlot61.setRangeAxisLocation(axisLocation82);
        java.awt.Stroke stroke84 = xYPlot61.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = dateAxis86.getLabelInsets();
        xYPlot61.setAxisOffset(rectangleInsets87);
        double double90 = rectangleInsets87.trimHeight((double) 8);
        categoryPlot8.setAxisOffset(rectangleInsets87);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset38);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(sortOrder46);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(axisLocation64);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 2.0d + "'", double90 == 2.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis20.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setAxisLineStroke(stroke28);
        java.awt.Shape shape30 = dateAxis25.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot32.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation35);
        java.awt.Stroke stroke37 = xYPlot14.getRangeZeroBaselineStroke();
        xYPlot14.setDomainCrosshairValue((double) 1.0f, false);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = xYPlot14.getRendererForDataset(xYDataset41);
        org.jfree.chart.plot.Marker marker44 = null;
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis48.setTickMarkStroke(stroke49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = dateAxis48.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) dateAxis48, categoryItemRenderer52);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        boolean boolean58 = categoryPlot53.render(graphics2D54, rectangle2D55, (int) (short) 100, plotRenderingInfo57);
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        categoryPlot53.setFixedDomainAxisSpace(axisSpace59, false);
        double double62 = categoryPlot53.getRangeCrosshairValue();
        categoryPlot53.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset65 = categoryPlot53.getDataset((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation67 = null;
        categoryPlot53.setDomainAxisLocation((int) (byte) 10, axisLocation67);
        org.jfree.chart.util.Layer layer70 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection71 = categoryPlot53.getRangeMarkers(3, layer70);
        boolean boolean73 = xYPlot14.removeDomainMarker(0, marker44, layer70, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(xYItemRenderer42);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset65);
        org.junit.Assert.assertNotNull(layer70);
        org.junit.Assert.assertNull(collection71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setWeight((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot14.zoomRangeAxes((double) 1.0f, plotRenderingInfo21, point2D22, false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        xYPlot14.removeChangeListener(plotChangeListener25);
        float float27 = xYPlot14.getBackgroundImageAlpha();
        xYPlot14.clearRangeMarkers(11);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot8.getRowRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        double double22 = dateAxis19.getLowerMargin();
        boolean boolean23 = dateAxis19.isVerticalTickLabels();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setTickMarkStroke(stroke27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = dateAxis26.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = null;
        dateAxis31.setTickUnit(dateTickUnit32);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis31.setAxisLineStroke(stroke34);
        java.awt.Shape shape36 = dateAxis31.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer37);
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        xYPlot38.addChangeListener(plotChangeListener39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot38.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer46 = null;
        xYPlot38.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker45, layer46, true);
        org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot38.getRangeAxis(0);
        java.awt.Stroke stroke51 = valueAxis50.getTickMarkStroke();
        java.lang.String str52 = valueAxis50.getLabelToolTip();
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setTickMarkStroke(stroke56);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = dateAxis55.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = null;
        dateAxis60.setTickUnit(dateTickUnit61);
        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis60.setAxisLineStroke(stroke63);
        java.awt.Shape shape65 = dateAxis60.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) dateAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis60, xYItemRenderer66);
        org.jfree.chart.event.PlotChangeListener plotChangeListener68 = null;
        xYPlot67.addChangeListener(plotChangeListener68);
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot67.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset71 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke75 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis74.setTickMarkStroke(stroke75);
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = dateAxis74.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis72, (org.jfree.chart.axis.ValueAxis) dateAxis74, categoryItemRenderer78);
        org.jfree.chart.axis.AxisLocation axisLocation81 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot79.setDomainAxisLocation((int) (short) 1, axisLocation81);
        xYPlot67.setRangeAxisLocation(axisLocation81);
        org.jfree.chart.axis.ValueAxis valueAxis84 = xYPlot67.getRangeAxis();
        double double85 = valueAxis84.getFixedAutoRange();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray86 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, valueAxis50, valueAxis84 };
        categoryPlot8.setRangeAxes(valueAxisArray86);
        org.jfree.chart.plot.CategoryMarker categoryMarker90 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        java.lang.Object obj91 = null;
        boolean boolean92 = categoryMarker90.equals(obj91);
        org.jfree.chart.util.Layer layer93 = null;
        boolean boolean94 = categoryPlot8.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker90, layer93);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer95 = null;
        int int96 = categoryPlot8.getIndexOf(categoryItemRenderer95);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(valueAxis50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertNotNull(axisLocation81);
        org.junit.Assert.assertNotNull(valueAxis84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray86);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.lang.String str22 = xYPlot17.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot17.getRangeAxis();
        xYPlot17.setNoDataMessage("UnitType.RELATIVE");
        org.jfree.chart.axis.AxisSpace axisSpace26 = xYPlot17.getFixedRangeAxisSpace();
        float float27 = xYPlot17.getForegroundAlpha();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis23);
        org.junit.Assert.assertNull(axisSpace26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
//        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
//        categoryAxis1.setCategoryMargin((double) 0.0f);
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        int int12 = day10.getDayOfMonth();
//        java.awt.Paint paint13 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) day10);
//        java.util.Date date14 = day10.getEnd();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        dateAxis19.setLowerMargin((double) 8);
        dateAxis19.setFixedDimension((double) (byte) 1);
        int int26 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        boolean boolean27 = xYPlot14.isRangeGridlinesVisible();
        xYPlot14.setRangeCrosshairValue((double) 6);
        java.awt.Stroke stroke30 = xYPlot14.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.plot.Plot plot23 = null;
        categoryPlot21.setParent(plot23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot21.getDomainAxisLocation((int) (short) -1);
        categoryPlot8.setDomainAxisLocation(axisLocation26, false);
        java.util.List list29 = categoryPlot8.getAnnotations();
        java.lang.String str30 = categoryPlot8.getNoDataMessage();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        java.awt.Font font21 = intervalMarker17.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis23.getLabelInsets();
        double double25 = dateAxis23.getLowerBound();
        java.awt.Font font26 = dateAxis23.getTickLabelFont();
        intervalMarker17.setLabelFont(font26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis31.setTickMarkStroke(stroke32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = dateAxis31.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot36.setDomainAxisLocation((int) (short) 1, axisLocation38);
        boolean boolean40 = categoryPlot36.isDomainZoomable();
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = categoryPlot36.getRangeMarkers(5, layer42);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier44 = null;
        categoryPlot36.setDrawingSupplier(drawingSupplier44);
        categoryPlot36.configureDomainAxes();
        intervalMarker17.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot36);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer48 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer48);
        double double50 = intervalMarker17.getEndValue();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setDomainCrosshairVisible(true);
        xYPlot14.setRangeCrosshairValue((double) 11);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot14.getDomainAxis(8);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        boolean boolean19 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color22 = java.awt.Color.getColor("", color21);
        categoryPlot8.setOutlinePaint((java.awt.Paint) color22);
        categoryPlot8.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("org.jfree.data.general.DatasetChangeEvent[source=-1.0]");
        java.util.List list27 = categoryPlot8.getCategoriesForAxis(categoryAxis26);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Color color0 = java.awt.Color.orange;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str1.equals("java.awt.Color[r=255,g=200,b=0]"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        objectList0.clear();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.Color color6 = color5.brighter();
        java.awt.color.ColorSpace colorSpace7 = color5.getColorSpace();
        objectList0.set(0, (java.lang.Object) colorSpace7);
        java.lang.Object obj9 = objectList0.clone();
        java.lang.Object obj10 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis10.setRangeWithMargins((org.jfree.data.Range) dateRange13);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange13, true, false);
        dateAxis2.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        java.util.TimeZone timeZone23 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis20.setTickUnit(dateTickUnit24, false, false);
        java.util.Date date28 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit24);
        dateAxis2.setAutoTickUnitSelection(false, false);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setTickMarkStroke(stroke34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = dateAxis33.getLabelInsets();
        dateAxis2.setLabelInsets(rectangleInsets36);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis39.setTickMarkStroke(stroke40);
        java.util.TimeZone timeZone42 = dateAxis39.getTimeZone();
        dateAxis39.setLabelAngle(0.0d);
        dateAxis39.setNegativeArrowVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis39, xYItemRenderer47);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(timeZone42);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setTickMarkStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis17.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = null;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setAxisLineStroke(stroke25);
        java.awt.Shape shape27 = dateAxis22.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer28);
        boolean boolean30 = xYPlot29.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot29.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer38 = null;
        xYPlot29.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker37, layer38, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = intervalMarker37.getLabelOffsetType();
        boolean boolean42 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker37);
        xYPlot14.setBackgroundAlpha(0.0f);
        java.awt.Paint paint46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        xYPlot14.setQuadrantPaint(0, paint46);
        xYPlot14.clearRangeMarkers();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit23, false, false);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit23);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        java.util.TimeZone timeZone33 = dateAxis30.getTimeZone();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27, timeZone33);
        org.jfree.data.general.Dataset dataset36 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset36);
        int int38 = day34.compareTo((java.lang.Object) datasetChangeEvent37);
        long long39 = day34.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 71999999L + "'", long39 == 71999999L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            java.awt.Color color1 = java.awt.Color.decode("XY Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"XY Plot\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange9, true, false);
        boolean boolean14 = dateAxis1.isPositiveArrowVisible();
        java.awt.Color color16 = java.awt.Color.WHITE;
        java.awt.Color color17 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=0]", color16);
        dateAxis1.setTickMarkPaint((java.awt.Paint) color16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color21 = java.awt.Color.getColor("", color20);
        dateAxis1.setTickLabelPaint((java.awt.Paint) color20);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(tickUnitSource23);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        xYPlot17.setDomainCrosshairLockedOnData(true);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setTickMarkStroke(stroke27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = dateAxis26.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = null;
        dateAxis31.setTickUnit(dateTickUnit32);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis31.setAxisLineStroke(stroke34);
        java.awt.Shape shape36 = dateAxis31.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer37);
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        xYPlot38.addChangeListener(plotChangeListener39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot38.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis45.setTickMarkStroke(stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = dateAxis45.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer49);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = categoryPlot50.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection52 = categoryPlot50.getLegendItems();
        xYPlot38.setFixedLegendItems(legendItemCollection52);
        xYPlot17.setFixedLegendItems(legendItemCollection52);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent55 = null;
        xYPlot17.notifyListeners(plotChangeEvent55);
        xYPlot17.configureRangeAxes();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNull(categoryAxis51);
        org.junit.Assert.assertNotNull(legendItemCollection52);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot8.getDatasetRenderingOrder();
        int int12 = categoryPlot8.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot21.getLegendItems();
        categoryPlot21.clearDomainMarkers();
        float float25 = categoryPlot21.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setTickMarkStroke(stroke30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = dateAxis29.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot34.getDomainAxis();
        org.jfree.chart.plot.Plot plot36 = null;
        categoryPlot34.setParent(plot36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot34.getDomainAxisLocation((int) (short) -1);
        categoryPlot21.setDomainAxisLocation(axisLocation39, false);
        categoryPlot8.setDomainAxisLocation(axisLocation39);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNull(categoryAxis35);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        java.util.TimeZone timeZone5 = dateAxis2.getTimeZone();
        dateAxis2.setLabelAngle(0.0d);
        java.awt.Font font8 = dateAxis2.getTickLabelFont();
        boolean boolean9 = unitType0.equals((java.lang.Object) font8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setTickMarkStroke(stroke12);
        java.util.TimeZone timeZone14 = dateAxis11.getTimeZone();
        dateAxis11.setLabelAngle(0.0d);
        dateAxis11.setNegativeArrowVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis22.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot27.setDomainAxisLocation((int) (short) 1, axisLocation29);
        boolean boolean31 = categoryPlot27.isDomainZoomable();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot27.getRangeMarkers(5, layer33);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot27.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        categoryPlot27.setDataset(0, categoryDataset37);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot27.setRangeCrosshairStroke(stroke39);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setTickMarkStroke(stroke43);
        categoryPlot27.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis42);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = null;
        dateAxis47.setTickUnit(dateTickUnit48);
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setAxisLineStroke(stroke50);
        java.awt.Shape shape52 = dateAxis47.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = dateAxis54.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis57.setTickMarkStroke(stroke58);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = dateAxis57.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit63 = null;
        dateAxis62.setTickUnit(dateTickUnit63);
        org.jfree.data.time.DateRange dateRange65 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis62.setRangeWithMargins((org.jfree.data.Range) dateRange65);
        dateAxis57.setRangeWithMargins((org.jfree.data.Range) dateRange65, true, false);
        dateAxis54.setRange((org.jfree.data.Range) dateRange65);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke73 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis72.setTickMarkStroke(stroke73);
        java.util.TimeZone timeZone75 = dateAxis72.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit76 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis72.setTickUnit(dateTickUnit76, false, false);
        java.util.Date date80 = dateAxis54.calculateLowestVisibleTickValue(dateTickUnit76);
        java.util.Date date81 = dateAxis47.calculateLowestVisibleTickValue(dateTickUnit76);
        java.util.Date date82 = dateAxis42.calculateHighestVisibleTickValue(dateTickUnit76);
        java.util.Date date83 = dateAxis11.calculateLowestVisibleTickValue(dateTickUnit76);
        boolean boolean84 = unitType0.equals((java.lang.Object) date83);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(dateRange65);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNotNull(dateTickUnit76);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        int int16 = categoryPlot8.getDatasetCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            boolean boolean19 = categoryPlot8.removeAnnotation(categoryAnnotation17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYPlot17.setDomainGridlinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis20.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setAxisLineStroke(stroke28);
        java.awt.Shape shape30 = dateAxis25.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot32.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation35);
        xYPlot14.clearDomainAxes();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit23, false, false);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit23);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        long long29 = day28.getMiddleMillisecond();
        long long30 = day28.getFirstMillisecond();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 71999999L + "'", long29 == 71999999L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28800000L + "'", long30 == 28800000L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setLowerMargin((double) 6);
        double double7 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        dateAxis7.setTickLabelInsets(rectangleInsets19);
        double double22 = rectangleInsets19.extendHeight(0.2d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 6.2d + "'", double22 == 6.2d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("SortOrder.ASCENDING");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        dateAxis1.setFixedDimension((double) (byte) 1);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setTickMarkStroke(stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis11.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot16.setDomainAxisLocation((int) (short) 1, axisLocation18);
        boolean boolean20 = categoryPlot16.isDomainZoomable();
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot16.getRangeMarkers(5, layer22);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = null;
        categoryPlot16.setDrawingSupplier(drawingSupplier24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = categoryPlot16.getOrientation();
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        dateAxis1.setAutoRangeMinimumSize((double) 28800000L);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(plotOrientation26);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainAxes();
        java.awt.Stroke stroke12 = null;
        categoryPlot8.setOutlineStroke(stroke12);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        java.awt.Stroke stroke18 = xYPlot14.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace19);
        try {
            java.awt.Paint paint22 = xYPlot14.getQuadrantPaint(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (5) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = null;
        dateAxis21.setTickUnit(dateTickUnit22);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setAxisLineStroke(stroke24);
        java.awt.Shape shape26 = dateAxis21.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer27);
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        xYPlot28.addChangeListener(plotChangeListener29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot28.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setTickMarkStroke(stroke36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = dateAxis35.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis35, categoryItemRenderer39);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot40.setDomainAxisLocation((int) (short) 1, axisLocation42);
        xYPlot28.setRangeAxisLocation(axisLocation42);
        org.jfree.chart.axis.ValueAxis valueAxis45 = xYPlot28.getRangeAxis();
        categoryPlot8.setRangeAxis(0, valueAxis45);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(valueAxis45);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        xYPlot14.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.05d);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean24 = xYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker22, layer23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot14.getRenderer((int) (short) -1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(xYItemRenderer26);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot8.getDataset((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis28.setTickUnit(dateTickUnit29);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setAxisLineStroke(stroke31);
        java.awt.Shape shape33 = dateAxis28.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer34);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = null;
        intervalMarker38.setGradientPaintTransformer(gradientPaintTransformer39);
        boolean boolean41 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        java.awt.Font font42 = intervalMarker38.getLabelFont();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        java.awt.Paint paint44 = categoryPlot8.getBackgroundPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        xYPlot14.setDomainZeroBaselineVisible(true);
        xYPlot14.clearRangeMarkers();
        java.awt.Paint paint31 = null;
        xYPlot14.setDomainTickBandPaint(paint31);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange9, true, false);
        double double14 = dateAxis1.getUpperMargin();
        java.awt.Stroke stroke15 = dateAxis1.getTickMarkStroke();
        float float16 = dateAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 0, (double) ' ', (double) (short) 100, (double) (-1L));
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 0.5f, (double) (-52), (double) 71999999L, (double) (short) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.Object obj13 = null;
        boolean boolean14 = rectangleAnchor12.equals(obj13);
        java.lang.String str15 = rectangleAnchor12.toString();
        boolean boolean16 = unitType0.equals((java.lang.Object) rectangleAnchor12);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleAnchor.LEFT" + "'", str15.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        double double12 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        categoryPlot8.notifyListeners(plotChangeEvent19);
        categoryPlot8.zoom(1.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setWeight((int) (byte) -1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        boolean boolean22 = seriesRenderingOrder20.equals((java.lang.Object) '#');
        xYPlot14.setSeriesRenderingOrder(seriesRenderingOrder20);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot14.getLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str26 = datasetRenderingOrder25.toString();
        xYPlot14.setDatasetRenderingOrder(datasetRenderingOrder25);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        java.util.TimeZone timeZone33 = dateAxis30.getTimeZone();
        dateAxis30.setLabelAngle(0.0d);
        java.awt.Font font36 = dateAxis30.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = null;
        dateAxis38.setTickUnit(dateTickUnit39);
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis38.setAxisLineStroke(stroke41);
        java.awt.Shape shape43 = dateAxis38.getUpArrow();
        dateAxis30.setRightArrow(shape43);
        dateAxis30.setAxisLineVisible(false);
        xYPlot14.setDomainAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis30, true);
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot14.getDomainAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape51 = defaultDrawingSupplier50.getNextShape();
        valueAxis49.setLeftArrow(shape51);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str26.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(valueAxis49);
        org.junit.Assert.assertNotNull(shape51);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        java.awt.Font font15 = xYPlot14.getNoDataMessageFont();
        java.awt.Color color16 = java.awt.Color.yellow;
        xYPlot14.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        int int19 = xYPlot14.indexOf(xYDataset18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot14.drawAnnotations(graphics2D20, rectangle2D21, plotRenderingInfo22);
        int int24 = xYPlot14.getBackgroundImageAlignment();
        xYPlot14.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        xYPlot14.setDomainCrosshairValue((double) (-52), false);
        double double22 = xYPlot14.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot14.setDataset(xYDataset23);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        double double12 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str20 = axisLocation19.toString();
        categoryPlot8.setDomainAxisLocation(axisLocation19);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot8.setFixedRangeAxisSpace(axisSpace22, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str26 = categoryAnchor25.toString();
        categoryPlot8.setDomainGridlinePosition(categoryAnchor25);
        java.lang.String str28 = categoryAnchor25.toString();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str20.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "CategoryAnchor.START" + "'", str26.equals("CategoryAnchor.START"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "CategoryAnchor.START" + "'", str28.equals("CategoryAnchor.START"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        dateAxis1.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setTickLabelInsets(rectangleInsets12);
        dateAxis1.setVerticalTickLabels(false);
        java.awt.Paint paint16 = dateAxis1.getAxisLinePaint();
        java.awt.Color color20 = java.awt.Color.getHSBColor((float) (byte) 10, (float) 0, (-1.0f));
        boolean boolean21 = dateAxis1.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        java.util.TimeZone timeZone6 = dateAxis3.getTimeZone();
        dateAxis3.setLabelAngle(0.0d);
        java.awt.Font font9 = dateAxis3.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke14);
        java.awt.Shape shape16 = dateAxis11.getUpArrow();
        dateAxis3.setRightArrow(shape16);
        objectList0.set((int) ' ', (java.lang.Object) dateAxis3);
        java.text.DateFormat dateFormat19 = null;
        dateAxis3.setDateFormatOverride(dateFormat19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        java.util.TimeZone timeZone25 = dateAxis22.getTimeZone();
        dateAxis22.setLabelAngle(0.0d);
        java.awt.Font font28 = dateAxis22.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = null;
        dateAxis30.setTickUnit(dateTickUnit31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke33);
        java.awt.Shape shape35 = dateAxis30.getUpArrow();
        dateAxis22.setRightArrow(shape35);
        dateAxis3.setLeftArrow(shape35);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str1.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot8.setDatasetRenderingOrder(datasetRenderingOrder11);
        java.lang.String str13 = categoryPlot8.getPlotType();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        java.awt.Paint paint12 = categoryPlot8.getNoDataMessagePaint();
        java.awt.Color color13 = java.awt.Color.white;
        float[] floatArray18 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray19 = color13.getRGBColorComponents(floatArray18);
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color13);
        double double21 = categoryPlot8.getAnchorValue();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setTickMarkStroke(stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis24.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = null;
        dateAxis29.setTickUnit(dateTickUnit30);
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setAxisLineStroke(stroke32);
        java.awt.Shape shape34 = dateAxis29.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer35);
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        xYPlot36.addChangeListener(plotChangeListener37);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis41.setTickMarkStroke(stroke42);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = dateAxis41.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = null;
        dateAxis46.setTickUnit(dateTickUnit47);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis46.setAxisLineStroke(stroke49);
        java.awt.Shape shape51 = dateAxis46.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis46, xYItemRenderer52);
        org.jfree.chart.event.PlotChangeListener plotChangeListener54 = null;
        xYPlot53.addChangeListener(plotChangeListener54);
        org.jfree.chart.axis.AxisLocation axisLocation56 = xYPlot53.getDomainAxisLocation();
        xYPlot36.setRangeAxisLocation(axisLocation56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        java.awt.geom.Point2D point2D61 = null;
        xYPlot36.zoomDomainAxes((double) (-52), (double) (byte) 100, plotRenderingInfo60, point2D61);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = xYPlot36.getRangeAxisEdge();
        xYPlot36.setDomainZeroBaselineVisible(true);
        boolean boolean66 = categoryPlot8.equals((java.lang.Object) xYPlot36);
        org.jfree.data.category.CategoryDataset categoryDataset67 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = null;
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis70.setTickMarkStroke(stroke71);
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = dateAxis70.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset67, categoryAxis68, (org.jfree.chart.axis.ValueAxis) dateAxis70, categoryItemRenderer74);
        java.awt.Graphics2D graphics2D76 = null;
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        boolean boolean80 = categoryPlot75.render(graphics2D76, rectangle2D77, (int) (short) 100, plotRenderingInfo79);
        org.jfree.chart.axis.CategoryAxis categoryAxis82 = null;
        categoryPlot75.setDomainAxis((int) (short) 100, categoryAxis82);
        java.awt.Stroke stroke84 = categoryPlot75.getRangeCrosshairStroke();
        categoryPlot8.setRangeGridlineStroke(stroke84);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(stroke84);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(tickUnitSource6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke4);
        java.awt.Shape shape6 = dateAxis1.getDownArrow();
        java.lang.Class class7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis9.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis12.setTickMarkStroke(stroke13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = dateAxis12.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis17.setRangeWithMargins((org.jfree.data.Range) dateRange20);
        dateAxis12.setRangeWithMargins((org.jfree.data.Range) dateRange20, true, false);
        dateAxis9.setRange((org.jfree.data.Range) dateRange20);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        java.util.TimeZone timeZone30 = dateAxis27.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis27.setTickUnit(dateTickUnit31, false, false);
        java.util.Date date35 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit31);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = dateAxis37.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis40.setTickMarkStroke(stroke41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = dateAxis40.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = null;
        dateAxis45.setTickUnit(dateTickUnit46);
        org.jfree.data.time.DateRange dateRange48 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis45.setRangeWithMargins((org.jfree.data.Range) dateRange48);
        dateAxis40.setRangeWithMargins((org.jfree.data.Range) dateRange48, true, false);
        dateAxis37.setRange((org.jfree.data.Range) dateRange48);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setTickMarkStroke(stroke56);
        java.util.TimeZone timeZone58 = dateAxis55.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit59 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis55.setTickUnit(dateTickUnit59, false, false);
        java.util.Date date63 = dateAxis37.calculateLowestVisibleTickValue(dateTickUnit59);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke67 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis66.setTickMarkStroke(stroke67);
        java.util.TimeZone timeZone69 = dateAxis66.getTimeZone();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date63, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date35, timeZone69);
        dateAxis1.setTimeZone(timeZone69);
        org.jfree.chart.util.UnitType unitType73 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.data.category.CategoryDataset categoryDataset74 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = null;
        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke78 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis77.setTickMarkStroke(stroke78);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = dateAxis77.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer81 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot82 = new org.jfree.chart.plot.CategoryPlot(categoryDataset74, categoryAxis75, (org.jfree.chart.axis.ValueAxis) dateAxis77, categoryItemRenderer81);
        java.text.DateFormat dateFormat83 = dateAxis77.getDateFormatOverride();
        org.jfree.data.time.DateRange dateRange84 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis77.setRange((org.jfree.data.Range) dateRange84, true, true);
        boolean boolean88 = unitType73.equals((java.lang.Object) dateRange84);
        dateAxis1.setRange((org.jfree.data.Range) dateRange84);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(dateRange48);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(dateTickUnit59);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(unitType73);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertNull(dateFormat83);
        org.junit.Assert.assertNotNull(dateRange84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        categoryPlot8.setOutlineStroke(stroke18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot8.getRangeAxisLocation();
        categoryPlot8.setBackgroundAlpha((float) 1560409200000L);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        xYPlot14.setDomainCrosshairValue((double) (-52), false);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis25.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        boolean boolean35 = categoryPlot30.render(graphics2D31, rectangle2D32, (int) (short) 100, plotRenderingInfo34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot30.setFixedDomainAxisSpace(axisSpace36, false);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setTickMarkStroke(stroke43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = dateAxis42.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = null;
        dateAxis47.setTickUnit(dateTickUnit48);
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setAxisLineStroke(stroke50);
        java.awt.Shape shape52 = dateAxis47.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer53);
        org.jfree.chart.event.PlotChangeListener plotChangeListener55 = null;
        xYPlot54.addChangeListener(plotChangeListener55);
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot54.getDomainAxisLocation();
        categoryPlot30.setRangeAxisLocation(13, axisLocation57, false);
        xYPlot14.setDomainAxisLocation(axisLocation57, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(axisLocation57);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        dateAxis2.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = null;
        dateAxis18.setTickUnit(dateTickUnit19);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setAxisLineStroke(stroke21);
        java.awt.Shape shape23 = dateAxis18.getUpArrow();
        dateAxis2.setLeftArrow(shape23);
        double double25 = dateAxis2.getLabelAngle();
        double double26 = dateAxis2.getLabelAngle();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        java.awt.Paint paint12 = categoryPlot8.getNoDataMessagePaint();
        java.awt.Color color13 = java.awt.Color.white;
        float[] floatArray18 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray19 = color13.getRGBColorComponents(floatArray18);
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color13);
        double double21 = categoryPlot8.getAnchorValue();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setTickMarkStroke(stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis24.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = null;
        dateAxis29.setTickUnit(dateTickUnit30);
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setAxisLineStroke(stroke32);
        java.awt.Shape shape34 = dateAxis29.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer35);
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        xYPlot36.addChangeListener(plotChangeListener37);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis41.setTickMarkStroke(stroke42);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = dateAxis41.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = null;
        dateAxis46.setTickUnit(dateTickUnit47);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis46.setAxisLineStroke(stroke49);
        java.awt.Shape shape51 = dateAxis46.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis46, xYItemRenderer52);
        org.jfree.chart.event.PlotChangeListener plotChangeListener54 = null;
        xYPlot53.addChangeListener(plotChangeListener54);
        org.jfree.chart.axis.AxisLocation axisLocation56 = xYPlot53.getDomainAxisLocation();
        xYPlot36.setRangeAxisLocation(axisLocation56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        java.awt.geom.Point2D point2D61 = null;
        xYPlot36.zoomDomainAxes((double) (-52), (double) (byte) 100, plotRenderingInfo60, point2D61);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = xYPlot36.getRangeAxisEdge();
        xYPlot36.setDomainZeroBaselineVisible(true);
        boolean boolean66 = categoryPlot8.equals((java.lang.Object) xYPlot36);
        org.jfree.data.category.CategoryDataset categoryDataset67 = categoryPlot8.getDataset();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(categoryDataset67);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot14.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker22, layer23, false);
        boolean boolean26 = xYPlot14.isRangeZoomable();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot14.getDomainAxisForDataset((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 52 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        xYPlot14.setDomainCrosshairValue((double) (-52), false);
        double double22 = xYPlot14.getRangeCrosshairValue();
        java.awt.Paint paint23 = xYPlot14.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Color color0 = java.awt.Color.white;
        float[] floatArray5 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray6 = color0.getRGBColorComponents(floatArray5);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray6, jFreeChart7);
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        chartChangeEvent8.setChart(jFreeChart9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=255,b=255]");
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        categoryPlot8.setOutlineStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot8.getAxisOffset();
        double double23 = rectangleInsets21.calculateLeftOutset((double) 71999999L);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        java.util.TimeZone timeZone6 = dateAxis3.getTimeZone();
        dateAxis3.setLabelAngle(0.0d);
        java.awt.Font font9 = dateAxis3.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke14);
        java.awt.Shape shape16 = dateAxis11.getUpArrow();
        dateAxis3.setRightArrow(shape16);
        objectList0.set((int) ' ', (java.lang.Object) dateAxis3);
        dateAxis3.resizeRange((double) (-1), (double) 0L);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        int int14 = categoryPlot8.getIndexOf(categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot8.getDomainAxisForDataset((int) (byte) -1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(categoryAxis16);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        double double5 = rectangleInsets4.getRight();
        double double6 = rectangleInsets4.getTop();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str10 = lengthAdjustmentType9.toString();
        boolean boolean12 = lengthAdjustmentType9.equals((java.lang.Object) 500);
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createAdjustedRectangle(rectangle2D7, lengthAdjustmentType8, lengthAdjustmentType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "NO_CHANGE" + "'", str10.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot17.setDomainCrosshairStroke(stroke22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setTickMarkStroke(stroke27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = dateAxis26.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = null;
        dateAxis31.setTickUnit(dateTickUnit32);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis31.setAxisLineStroke(stroke34);
        java.awt.Shape shape36 = dateAxis31.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer37);
        boolean boolean39 = xYPlot38.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup40 = xYPlot38.getDatasetGroup();
        java.awt.Paint paint41 = xYPlot38.getDomainTickBandPaint();
        xYPlot38.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.05d);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean48 = xYPlot38.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker46, layer47);
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot38.getRangeAxisLocation();
        xYPlot17.setDomainAxisLocation(axisLocation49);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(datasetGroup40);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(false);
        double double3 = dateAxis0.getLowerBound();
        java.awt.Font font4 = dateAxis0.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        objectList0.clear();
        int int4 = objectList0.size();
        int int5 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit5, false, false);
        java.awt.Stroke stroke9 = dateAxis1.getAxisLineStroke();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke14);
        java.awt.Shape shape16 = dateAxis11.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis18.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = null;
        dateAxis26.setTickUnit(dateTickUnit27);
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis26.setRangeWithMargins((org.jfree.data.Range) dateRange29);
        dateAxis21.setRangeWithMargins((org.jfree.data.Range) dateRange29, true, false);
        dateAxis18.setRange((org.jfree.data.Range) dateRange29);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis36.setTickMarkStroke(stroke37);
        java.util.TimeZone timeZone39 = dateAxis36.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis36.setTickUnit(dateTickUnit40, false, false);
        java.util.Date date44 = dateAxis18.calculateLowestVisibleTickValue(dateTickUnit40);
        java.util.Date date45 = dateAxis11.calculateLowestVisibleTickValue(dateTickUnit40);
        java.util.Date date46 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit40);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date46);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit23, false, false);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit23);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        java.util.TimeZone timeZone33 = dateAxis30.getTimeZone();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27, timeZone33);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setTickMarkStroke(stroke38);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = dateAxis37.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = null;
        dateAxis42.setTickUnit(dateTickUnit43);
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setAxisLineStroke(stroke45);
        java.awt.Shape shape47 = dateAxis42.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis42, xYItemRenderer48);
        boolean boolean50 = xYPlot49.isDomainGridlinesVisible();
        int int51 = day34.compareTo((java.lang.Object) boolean50);
        java.util.Calendar calendar52 = null;
        try {
            day34.peg(calendar52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Category Plot");
        double double2 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        java.awt.Font font15 = xYPlot14.getNoDataMessageFont();
        java.awt.Color color16 = java.awt.Color.yellow;
        xYPlot14.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        int int19 = xYPlot14.indexOf(xYDataset18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot14.drawAnnotations(graphics2D20, rectangle2D21, plotRenderingInfo22);
        int int24 = xYPlot14.getBackgroundImageAlignment();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        java.util.TimeZone timeZone30 = dateAxis27.getTimeZone();
        dateAxis27.setLabelAngle(0.0d);
        java.awt.Font font33 = dateAxis27.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = null;
        dateAxis35.setTickUnit(dateTickUnit36);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setAxisLineStroke(stroke38);
        java.awt.Shape shape40 = dateAxis35.getUpArrow();
        dateAxis27.setRightArrow(shape40);
        xYPlot14.setRangeAxis(3, (org.jfree.chart.axis.ValueAxis) dateAxis27, true);
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setTickMarkStroke(stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = dateAxis47.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = categoryPlot52.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection54 = categoryPlot52.getLegendItems();
        categoryPlot52.setRangeCrosshairValue((double) (short) 10);
        xYPlot14.setParent((org.jfree.chart.plot.Plot) categoryPlot52);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNull(categoryAxis53);
        org.junit.Assert.assertNotNull(legendItemCollection54);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis20.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setAxisLineStroke(stroke28);
        java.awt.Shape shape30 = dateAxis25.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot32.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation35);
        java.awt.Stroke stroke37 = xYPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot14.setDomainAxis((int) (short) 100, valueAxis39);
        xYPlot14.configureDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        xYPlot14.setRangeAxis((int) (byte) 100, valueAxis43, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            xYPlot14.handleClick((int) (short) 1, 500, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = intervalMarker2.getLabelOffset();
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer20);
        categoryPlot21.mapDatasetToRangeAxis(0, (int) (short) 10);
        double double25 = categoryPlot21.getAnchorValue();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setTickMarkStroke(stroke30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = dateAxis29.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = null;
        dateAxis34.setTickUnit(dateTickUnit35);
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis34.setAxisLineStroke(stroke37);
        java.awt.Shape shape39 = dateAxis34.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer40);
        boolean boolean42 = xYPlot41.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup43 = xYPlot41.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot41.getDomainAxisLocation();
        categoryPlot21.setDomainAxisLocation((int) (short) 0, axisLocation44, true);
        categoryPlot8.setRangeAxisLocation(axisLocation44, false);
        java.awt.Image image49 = null;
        categoryPlot8.setBackgroundImage(image49);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis52.setTickMarkStroke(stroke53);
        java.util.TimeZone timeZone55 = dateAxis52.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit56 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis52.setTickUnit(dateTickUnit56, false, false);
        java.awt.Stroke stroke60 = dateAxis52.getAxisLineStroke();
        categoryPlot8.setRangeCrosshairStroke(stroke60);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(datasetGroup43);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(dateTickUnit56);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setTickMarkStroke(stroke34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = dateAxis33.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = null;
        dateAxis38.setTickUnit(dateTickUnit39);
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis38.setAxisLineStroke(stroke41);
        java.awt.Shape shape43 = dateAxis38.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer44);
        org.jfree.chart.event.PlotChangeListener plotChangeListener46 = null;
        xYPlot45.addChangeListener(plotChangeListener46);
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot45.getDomainAxisLocation();
        intervalMarker30.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot45);
        java.awt.Color color50 = java.awt.Color.BLACK;
        java.awt.Color color51 = java.awt.Color.white;
        java.awt.Color color52 = color51.brighter();
        java.awt.color.ColorSpace colorSpace53 = color51.getColorSpace();
        float[] floatArray54 = null;
        float[] floatArray55 = color50.getComponents(colorSpace53, floatArray54);
        intervalMarker30.setOutlinePaint((java.awt.Paint) color50);
        xYPlot14.setOutlinePaint((java.awt.Paint) color50);
        org.jfree.chart.axis.AxisLocation axisLocation58 = null;
        try {
            xYPlot14.setRangeAxisLocation(axisLocation58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(colorSpace53);
        org.junit.Assert.assertNotNull(floatArray55);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot26.setDomainAxisLocation((int) (short) 1, axisLocation28);
        xYPlot14.setRangeAxisLocation(axisLocation28);
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot14.getRangeAxis();
        java.awt.Paint paint32 = xYPlot14.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(valueAxis31);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot8.setRenderer(categoryItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        dateAxis20.setLowerMargin((double) 8);
        dateAxis20.setFixedDimension((double) (byte) 1);
        org.jfree.data.Range range27 = categoryPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        java.lang.String str4 = intervalMarker2.getLabel();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        intervalMarker2.setLabelAnchor(rectangleAnchor5);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Font font4 = dateAxis1.getTickLabelFont();
        dateAxis1.setRangeWithMargins((double) 12, (double) 500);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        xYPlot14.setDomainZeroBaselineVisible(true);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot14.getDataset((int) (byte) 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(xYDataset31);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        categoryAxis0.configure();
        double double6 = categoryAxis0.getCategoryMargin();
        categoryAxis0.configure();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        double double18 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Color color1 = java.awt.Color.PINK;
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) color1);
        java.lang.String str3 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleAnchor.LEFT" + "'", str3.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio(0.0f);
        int int15 = categoryAxis12.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis12.getCategoryLabelPositions();
        categoryAxis12.setLowerMargin((double) 6);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.setMaximumCategoryLabelWidthRatio(0.0f);
        int int25 = categoryAxis22.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = categoryAxis22.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        float float28 = categoryAxis27.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis29.setMaximumCategoryLabelWidthRatio(0.0f);
        int int32 = categoryAxis29.getMaximumCategoryLabelLines();
        double double33 = categoryAxis29.getLowerMargin();
        java.lang.Object obj34 = categoryAxis29.clone();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis38.setTickMarkStroke(stroke39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = dateAxis38.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer42);
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot43.setDomainAxisLocation((int) (short) 1, axisLocation45);
        boolean boolean47 = categoryPlot43.isSubplot();
        java.util.List list48 = categoryPlot43.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = null;
        dateAxis50.setTickUnit(dateTickUnit51);
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis50.setAxisLineStroke(stroke53);
        categoryPlot43.setOutlineStroke(stroke53);
        boolean boolean56 = categoryAxis29.equals((java.lang.Object) stroke53);
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis58.setMaximumCategoryLabelWidthRatio(0.0f);
        int int61 = categoryAxis58.getMaximumCategoryLabelLines();
        categoryAxis58.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, (org.jfree.chart.axis.ValueAxis) dateAxis64, categoryItemRenderer65);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray67 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis12, categoryAxis19, categoryAxis22, categoryAxis27, categoryAxis29, categoryAxis58 };
        categoryPlot8.setDomainAxes(categoryAxisArray67);
        java.awt.Paint paint69 = categoryPlot8.getDomainGridlinePaint();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent70 = null;
        categoryPlot8.axisChanged(axisChangeEvent70);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray67);
        org.junit.Assert.assertNotNull(paint69);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        double double6 = rectangleInsets4.calculateTopOutset((double) '#');
        double double8 = rectangleInsets4.calculateTopInset((double) (-1.0f));
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        java.awt.Color color1 = java.awt.Color.white;
        java.awt.Color color2 = color1.brighter();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color5 = java.awt.Color.GRAY;
        boolean boolean6 = plotOrientation4.equals((java.lang.Object) color5);
        java.awt.Color color7 = java.awt.Color.white;
        float[] floatArray12 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray13 = color7.getRGBColorComponents(floatArray12);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray13, jFreeChart14);
        float[] floatArray16 = color5.getComponents(floatArray13);
        int int17 = color5.getBlue();
        java.awt.Color color18 = java.awt.Color.getColor("DatasetRenderingOrder.FORWARD", color5);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        java.util.TimeZone timeZone23 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis20.setTickUnit(dateTickUnit24, false, false);
        java.awt.Stroke stroke28 = dateAxis20.getAxisLineStroke();
        java.awt.Color color29 = java.awt.Color.ORANGE;
        dateAxis20.setLabelPaint((java.awt.Paint) color29);
        java.awt.Paint[] paintArray31 = new java.awt.Paint[] { color0, color1, color5, color29 };
        java.awt.Paint[] paintArray32 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray33 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray34 = null;
        java.awt.Shape[] shapeArray35 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray31, paintArray32, strokeArray33, strokeArray34, shapeArray35);
        try {
            java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 128 + "'", int17 == 128);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintArray31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        java.util.TimeZone timeZone6 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED", timeZone6);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        int int17 = xYPlot14.getWeight();
        java.awt.Paint paint18 = xYPlot14.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis22.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot27.setDomainAxisLocation((int) (short) 1, axisLocation29);
        boolean boolean31 = categoryPlot27.isDomainZoomable();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot27.getRangeMarkers(5, layer33);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot27.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        categoryPlot27.setDataset(0, categoryDataset37);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot27.setRangeCrosshairStroke(stroke39);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setTickMarkStroke(stroke43);
        categoryPlot27.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis42);
        java.awt.Stroke stroke46 = dateAxis42.getTickMarkStroke();
        xYPlot14.setDomainCrosshairStroke(stroke46);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis49.setTickMarkStroke(stroke50);
        dateAxis49.setPositiveArrowVisible(true);
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis49);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        int int17 = xYPlot14.getWeight();
        xYPlot14.clearDomainMarkers(2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.plot.Plot plot10 = null;
        categoryPlot8.setParent(plot10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot8.getDomainAxisLocation((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setTickMarkStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis17.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot22.setDomainAxisLocation((int) (short) 1, axisLocation24);
        boolean boolean26 = categoryPlot22.isDomainZoomable();
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot22.getRangeMarkers(5, layer28);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot22.getRowRenderingOrder();
        java.lang.String str31 = sortOrder30.toString();
        categoryPlot8.setRowRenderingOrder(sortOrder30);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.setMaximumCategoryLabelWidthRatio(0.0f);
        int int37 = categoryAxis34.getMaximumCategoryLabelLines();
        java.lang.Object obj38 = categoryAxis34.clone();
        categoryPlot8.setDomainAxis((int) '4', categoryAxis34);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "SortOrder.ASCENDING" + "'", str31.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.setRangeCrosshairValue((double) (short) 10);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot8.render(graphics2D13, rectangle2D14, (int) '#', plotRenderingInfo16);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.lang.String str22 = xYPlot17.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot17.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis27.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot32.getDomainAxis();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getDomainMarkers(layer34);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = categoryPlot32.getOrientation();
        xYPlot17.setOrientation(plotOrientation36);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        int int39 = xYPlot17.getIndexOf(xYItemRenderer38);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setTickMarkStroke(stroke16);
        dateAxis15.setPositiveArrowVisible(true);
        org.jfree.chart.plot.Plot plot20 = dateAxis15.getPlot();
        categoryPlot8.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(plot20);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        java.awt.Font font21 = intervalMarker17.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis23.getLabelInsets();
        double double25 = dateAxis23.getLowerBound();
        java.awt.Font font26 = dateAxis23.getTickLabelFont();
        intervalMarker17.setLabelFont(font26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis31.setTickMarkStroke(stroke32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = dateAxis31.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot36.setDomainAxisLocation((int) (short) 1, axisLocation38);
        boolean boolean40 = categoryPlot36.isDomainZoomable();
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = categoryPlot36.getRangeMarkers(5, layer42);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier44 = null;
        categoryPlot36.setDrawingSupplier(drawingSupplier44);
        categoryPlot36.configureDomainAxes();
        intervalMarker17.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot36);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot36.getRangeAxisEdge(0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot14.zoomDomainAxes((double) (-52), (double) (byte) 100, plotRenderingInfo38, point2D39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot14.getRangeAxisEdge();
        xYPlot14.setDomainZeroBaselineVisible(true);
        java.awt.Stroke stroke44 = xYPlot14.getOutlineStroke();
        org.jfree.chart.plot.Marker marker46 = null;
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis49.setTickMarkStroke(stroke50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = dateAxis49.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = null;
        dateAxis54.setTickUnit(dateTickUnit55);
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis54.setAxisLineStroke(stroke57);
        java.awt.Shape shape59 = dateAxis54.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) dateAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer60);
        org.jfree.chart.event.PlotChangeListener plotChangeListener62 = null;
        xYPlot61.addChangeListener(plotChangeListener62);
        org.jfree.chart.axis.AxisLocation axisLocation64 = xYPlot61.getDomainAxisLocation();
        xYPlot61.setDomainCrosshairVisible(true);
        xYPlot61.setRangeCrosshairValue((double) 11);
        org.jfree.data.xy.XYDataset xYDataset69 = null;
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke72 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis71.setTickMarkStroke(stroke72);
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = dateAxis71.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit77 = null;
        dateAxis76.setTickUnit(dateTickUnit77);
        java.awt.Stroke stroke79 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis76.setAxisLineStroke(stroke79);
        java.awt.Shape shape81 = dateAxis76.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer82 = null;
        org.jfree.chart.plot.XYPlot xYPlot83 = new org.jfree.chart.plot.XYPlot(xYDataset69, (org.jfree.chart.axis.ValueAxis) dateAxis71, (org.jfree.chart.axis.ValueAxis) dateAxis76, xYItemRenderer82);
        org.jfree.chart.event.PlotChangeListener plotChangeListener84 = null;
        xYPlot83.addChangeListener(plotChangeListener84);
        org.jfree.chart.axis.AxisLocation axisLocation86 = xYPlot83.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker90 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer91 = null;
        xYPlot83.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker90, layer91, true);
        org.jfree.chart.util.Layer layer94 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean95 = xYPlot61.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker90, layer94);
        try {
            xYPlot14.addRangeMarker(0, marker46, layer94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(axisLocation64);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(shape81);
        org.junit.Assert.assertNotNull(axisLocation86);
        org.junit.Assert.assertNotNull(layer94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot8.getDataset((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis28.setTickUnit(dateTickUnit29);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setAxisLineStroke(stroke31);
        java.awt.Shape shape33 = dateAxis28.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer34);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = null;
        intervalMarker38.setGradientPaintTransformer(gradientPaintTransformer39);
        boolean boolean41 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        java.awt.Font font42 = intervalMarker38.getLabelFont();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        categoryPlot8.setDrawSharedDomainAxis(false);
        categoryPlot8.setRangeCrosshairValue((double) 0.0f, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font42);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        java.awt.Paint paint28 = xYPlot14.getRangeGridlinePaint();
        java.lang.Object obj29 = xYPlot14.clone();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot14.getRangeAxis((int) (byte) 100);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot14.setOrientation(plotOrientation30);
        java.lang.String str32 = plotOrientation30.toString();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str32.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 3, 1.0d, (double) (byte) 10, 0.0d);
        double double6 = rectangleInsets4.trimHeight((double) (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-14.0d) + "'", double6 == (-14.0d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setTickMarkStroke(stroke15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis14.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = null;
        dateAxis19.setTickUnit(dateTickUnit20);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke22);
        java.awt.Shape shape24 = dateAxis19.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot26.addChangeListener(plotChangeListener27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot26.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer34 = null;
        xYPlot26.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker33, layer34, true);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot26.setDataset(xYDataset37);
        int int39 = xYPlot26.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot26.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint42 = xYPlot26.getRangeCrosshairPaint();
        categoryPlot8.setDomainGridlinePaint(paint42);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        java.awt.Font font21 = intervalMarker17.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis23.getLabelInsets();
        double double25 = dateAxis23.getLowerBound();
        java.awt.Font font26 = dateAxis23.getTickLabelFont();
        intervalMarker17.setLabelFont(font26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis31.setTickMarkStroke(stroke32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = dateAxis31.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot36.setDomainAxisLocation((int) (short) 1, axisLocation38);
        boolean boolean40 = categoryPlot36.isDomainZoomable();
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = categoryPlot36.getRangeMarkers(5, layer42);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier44 = null;
        categoryPlot36.setDrawingSupplier(drawingSupplier44);
        categoryPlot36.configureDomainAxes();
        intervalMarker17.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot36);
        org.jfree.data.general.Dataset dataset49 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset49);
        categoryPlot36.datasetChanged(datasetChangeEvent50);
        java.lang.Object obj52 = datasetChangeEvent50.getSource();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertTrue("'" + obj52 + "' != '" + (-1.0f) + "'", obj52.equals((-1.0f)));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis20.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setAxisLineStroke(stroke28);
        java.awt.Shape shape30 = dateAxis25.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot32.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation35);
        java.awt.Stroke stroke37 = xYPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot14.setDomainAxis((int) (short) 100, valueAxis39);
        float float41 = xYPlot14.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 1.0f + "'", float41 == 1.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        double double12 = categoryPlot8.getRangeCrosshairValue();
        boolean boolean13 = categoryPlot8.isDomainGridlinesVisible();
        categoryPlot8.mapDatasetToRangeAxis((int) (byte) 10, (int) (byte) -1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.plot.Plot plot10 = null;
        categoryPlot8.setParent(plot10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot8.getDomainAxisLocation((int) (short) -1);
        java.lang.String str14 = categoryPlot8.getPlotType();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Color color17 = java.awt.Color.white;
        java.awt.Color color18 = color17.brighter();
        xYPlot14.setRangeTickBandPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot14.getDomainMarkers(layer20);
        java.awt.Stroke stroke22 = xYPlot14.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot8.getRangeAxis(10);
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        java.lang.Comparable comparable18 = categoryMarker17.getKey();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = null;
        dateAxis26.setTickUnit(dateTickUnit27);
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setAxisLineStroke(stroke29);
        java.awt.Shape shape31 = dateAxis26.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer32);
        boolean boolean34 = xYPlot33.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup35 = xYPlot33.getDatasetGroup();
        java.awt.Paint paint36 = xYPlot33.getDomainTickBandPaint();
        xYPlot33.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker41 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.05d);
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = xYPlot33.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker41, layer42);
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setTickMarkStroke(stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = dateAxis47.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = categoryPlot52.getDomainAxis();
        org.jfree.chart.plot.Plot plot54 = null;
        categoryPlot52.setParent(plot54);
        org.jfree.chart.axis.AxisLocation axisLocation57 = categoryPlot52.getDomainAxisLocation((int) (short) -1);
        double double58 = categoryPlot52.getAnchorValue();
        boolean boolean59 = layer42.equals((java.lang.Object) double58);
        categoryPlot8.addDomainMarker((int) (short) 1, categoryMarker17, layer42, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(datasetGroup35);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNull(categoryAxis53);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis(0, (int) (short) 10);
        double double12 = categoryPlot8.getAnchorValue();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = null;
        dateAxis21.setTickUnit(dateTickUnit22);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setAxisLineStroke(stroke24);
        java.awt.Shape shape26 = dateAxis21.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer27);
        boolean boolean29 = xYPlot28.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup30 = xYPlot28.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot28.getDomainAxisLocation();
        categoryPlot8.setDomainAxisLocation((int) (short) 0, axisLocation31, true);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis38.setTickMarkStroke(stroke39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = dateAxis38.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = categoryPlot43.getDomainAxis();
        org.jfree.chart.plot.Plot plot45 = null;
        categoryPlot43.setParent(plot45);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot43.getDomainAxisLocation((int) (short) -1);
        categoryPlot8.setRangeAxisLocation(13, axisLocation48, false);
        org.jfree.chart.axis.ValueAxis valueAxis52 = categoryPlot8.getRangeAxisForDataset(12);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNull(categoryAxis44);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(valueAxis52);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        int int14 = categoryPlot8.getIndexOf(categoryItemRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot8.getRangeAxis((int) (short) -1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(valueAxis16);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        boolean boolean27 = dateAxis23.isNegativeArrowVisible();
        boolean boolean28 = dateAxis23.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int1 = color0.getAlpha();
        java.awt.Color color2 = java.awt.Color.white;
        java.awt.Color color3 = java.awt.Color.white;
        float[] floatArray8 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray9 = color3.getRGBColorComponents(floatArray8);
        float[] floatArray10 = color2.getRGBColorComponents(floatArray8);
        float[] floatArray11 = color0.getColorComponents(floatArray8);
        int int12 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        dateAxis1.setLabelAngle(0.0d);
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis11.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setTickMarkStroke(stroke15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis14.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = null;
        dateAxis19.setTickUnit(dateTickUnit20);
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis19.setRangeWithMargins((org.jfree.data.Range) dateRange22);
        dateAxis14.setRangeWithMargins((org.jfree.data.Range) dateRange22, true, false);
        dateAxis11.setRange((org.jfree.data.Range) dateRange22);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = null;
        dateAxis29.setTickUnit(dateTickUnit30);
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setAxisLineStroke(stroke32);
        java.awt.Shape shape34 = dateAxis29.getUpArrow();
        dateAxis11.setUpArrow(shape34);
        dateAxis1.setDownArrow(shape34);
        float float37 = dateAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Category Plot");
        categoryAxis1.clearCategoryLabelToolTips();
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        java.awt.Font font19 = categoryPlot8.getNoDataMessageFont();
        java.awt.Color color20 = java.awt.Color.yellow;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        dateAxis23.setLowerMargin((double) 8);
        dateAxis23.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis23.setTickLabelInsets(rectangleInsets34);
        double double36 = rectangleInsets34.getRight();
        categoryPlot8.setAxisOffset(rectangleInsets34);
        double double39 = rectangleInsets34.calculateLeftOutset(3.0d);
        double double41 = rectangleInsets34.calculateLeftInset((double) 1560409200000L);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.0d + "'", double39 == 3.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 3.0d + "'", double41 == 3.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis(0, (int) (short) 10);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot21.getLegendItems();
        categoryPlot21.clearDomainMarkers();
        float float25 = categoryPlot21.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setTickMarkStroke(stroke30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = dateAxis29.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot34.getDomainAxis();
        org.jfree.chart.plot.Plot plot36 = null;
        categoryPlot34.setParent(plot36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot34.getDomainAxisLocation((int) (short) -1);
        categoryPlot21.setDomainAxisLocation(axisLocation39, false);
        categoryPlot8.setDomainAxisLocation((int) '4', axisLocation39, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNull(categoryAxis35);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = dateAxis2.lengthToJava2D((-1.0d), rectangle2D16, rectangleEdge17);
        dateAxis2.setRangeWithMargins(2.0d, (double) 1560409200000L);
        java.lang.String str22 = dateAxis2.getLabelToolTip();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis(0, (int) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot8.zoomDomainAxes((double) 11, plotRenderingInfo13, point2D14, true);
        categoryPlot8.setRangeGridlinesVisible(false);
        categoryPlot8.clearRangeMarkers();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        java.awt.Paint paint13 = categoryPlot8.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setTickMarkStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis17.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot22.setDomainAxisLocation((int) (short) 1, axisLocation24);
        boolean boolean26 = categoryPlot22.isDomainZoomable();
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot22.getRangeMarkers(5, layer28);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot22.getRowRenderingOrder();
        categoryPlot8.setColumnRenderingOrder(sortOrder30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis34.setTickMarkStroke(stroke35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = dateAxis34.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = null;
        dateAxis39.setTickUnit(dateTickUnit40);
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis39.setAxisLineStroke(stroke42);
        java.awt.Shape shape44 = dateAxis39.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis39, xYItemRenderer45);
        org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer50 = null;
        intervalMarker49.setGradientPaintTransformer(gradientPaintTransformer50);
        boolean boolean52 = xYPlot46.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker49);
        java.awt.Font font53 = intervalMarker49.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = dateAxis55.getLabelInsets();
        double double57 = dateAxis55.getLowerBound();
        java.awt.Font font58 = dateAxis55.getTickLabelFont();
        intervalMarker49.setLabelFont(font58);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke62 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis61.setTickMarkStroke(stroke62);
        java.util.TimeZone timeZone64 = dateAxis61.getTimeZone();
        dateAxis61.setLabelAngle(0.0d);
        java.awt.Font font67 = dateAxis61.getTickLabelFont();
        intervalMarker49.setLabelFont(font67);
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker49);
        org.jfree.data.category.CategoryDataset categoryDataset70 = null;
        categoryPlot8.setDataset(categoryDataset70);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation72 = null;
        try {
            categoryPlot8.addAnnotation(categoryAnnotation72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(font67);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.setRangeCrosshairValue((double) (short) 10);
        float float13 = categoryPlot8.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis25.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = null;
        dateAxis30.setTickUnit(dateTickUnit31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke33);
        java.awt.Shape shape35 = dateAxis30.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer36);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        xYPlot37.addChangeListener(plotChangeListener38);
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot37.getDomainAxisLocation();
        intervalMarker22.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot37);
        java.lang.String str42 = xYPlot37.getPlotType();
        xYPlot37.clearRangeAxes();
        java.awt.Color color44 = java.awt.Color.MAGENTA;
        xYPlot37.setDomainTickBandPaint((java.awt.Paint) color44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot37.getDomainAxisEdge();
        int int47 = xYPlot37.getDatasetCount();
        java.awt.geom.Point2D point2D48 = xYPlot37.getQuadrantOrigin();
        xYPlot14.zoomDomainAxes((double) (byte) 1, plotRenderingInfo19, point2D48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot14.setDomainCrosshairPaint((java.awt.Paint) color50);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "XY Plot" + "'", str42.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNotNull(color50);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = xYPlot14.getRenderer((int) ' ');
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot14.setDataset(xYDataset38);
        java.awt.Stroke stroke40 = xYPlot14.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNull(xYItemRenderer37);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        int int17 = xYPlot14.getWeight();
        double double18 = xYPlot14.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Paint paint16 = xYPlot14.getDomainTickBandPaint();
        java.awt.Stroke stroke17 = xYPlot14.getRangeGridlineStroke();
        xYPlot14.setDomainCrosshairValue((double) 0, true);
        boolean boolean21 = xYPlot14.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot14.zoomDomainAxes((double) (-52), (double) (byte) 100, plotRenderingInfo38, point2D39);
        xYPlot14.configureRangeAxes();
        boolean boolean42 = xYPlot14.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis44.setTickMarkStroke(stroke45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit49 = null;
        dateAxis48.setTickUnit(dateTickUnit49);
        org.jfree.data.time.DateRange dateRange51 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis48.setRangeWithMargins((org.jfree.data.Range) dateRange51);
        dateAxis44.setRange((org.jfree.data.Range) dateRange51, false, false);
        java.awt.Paint paint56 = dateAxis44.getLabelPaint();
        int int57 = xYPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis44);
        java.awt.Shape shape58 = dateAxis44.getLeftArrow();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(dateRange51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(shape58);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) 3, 1.0d, (double) (byte) 10, 0.0d);
        categoryAxis1.setTickLabelInsets(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot14.zoomDomainAxes((double) (-52), (double) (byte) 100, plotRenderingInfo38, point2D39);
        xYPlot14.configureRangeAxes();
        boolean boolean42 = xYPlot14.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot14.getRangeAxisLocation(15);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(axisLocation44);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        int int17 = xYPlot14.getWeight();
        java.awt.Paint paint18 = xYPlot14.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis22.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot27.setDomainAxisLocation((int) (short) 1, axisLocation29);
        boolean boolean31 = categoryPlot27.isDomainZoomable();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot27.getRangeMarkers(5, layer33);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot27.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        categoryPlot27.setDataset(0, categoryDataset37);
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot27.setRangeCrosshairStroke(stroke39);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setTickMarkStroke(stroke43);
        categoryPlot27.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis42);
        java.awt.Stroke stroke46 = dateAxis42.getTickMarkStroke();
        xYPlot14.setDomainCrosshairStroke(stroke46);
        int int48 = xYPlot14.getRangeAxisCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getMonth();
        java.util.Date date12 = day10.getEnd();
        dateAxis7.setMinimumDate(date12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        double double9 = rectangleInsets7.calculateTopOutset((double) '#');
        dateAxis1.setTickLabelInsets(rectangleInsets7);
        java.awt.Stroke stroke11 = dateAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot14.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint30 = xYPlot14.getRangeCrosshairPaint();
        boolean boolean31 = xYPlot14.isDomainCrosshairLockedOnData();
        xYPlot14.setForegroundAlpha(0.8f);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setTickMarkStroke(stroke38);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = dateAxis37.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = null;
        dateAxis42.setTickUnit(dateTickUnit43);
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setAxisLineStroke(stroke45);
        java.awt.Shape shape47 = dateAxis42.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis42, xYItemRenderer48);
        org.jfree.chart.event.PlotChangeListener plotChangeListener50 = null;
        xYPlot49.addChangeListener(plotChangeListener50);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot49.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeListener plotChangeListener53 = null;
        xYPlot49.removeChangeListener(plotChangeListener53);
        xYPlot49.clearRangeAxes();
        java.awt.Color color58 = java.awt.Color.getColor("SortOrder.ASCENDING", 11);
        xYPlot49.setRangeCrosshairPaint((java.awt.Paint) color58);
        try {
            xYPlot14.setQuadrantPaint((int) (short) 100, (java.awt.Paint) color58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(color58);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot8.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot8.getFixedRangeAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot8.setDataset((int) (byte) 1, categoryDataset14);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot14.getDomainAxisLocation((int) (byte) -1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        dateAxis1.setLabelAngle(0.0d);
        java.awt.Font font7 = dateAxis1.getTickLabelFont();
        double double8 = dateAxis1.getAutoRangeMinimumSize();
        double double9 = dateAxis1.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis11.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setTickMarkStroke(stroke15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis14.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = null;
        dateAxis19.setTickUnit(dateTickUnit20);
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis19.setRangeWithMargins((org.jfree.data.Range) dateRange22);
        dateAxis14.setRangeWithMargins((org.jfree.data.Range) dateRange22, true, false);
        dateAxis11.setRange((org.jfree.data.Range) dateRange22);
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange22);
        org.jfree.data.Range range29 = dateAxis1.getRange();
        java.lang.String str30 = dateAxis1.getLabel();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "NO_CHANGE" + "'", str30.equals("NO_CHANGE"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        categoryPlot8.setOutlineStroke(stroke18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot8.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation21, plotOrientation22);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color25 = java.awt.Color.GRAY;
        boolean boolean26 = plotOrientation24.equals((java.lang.Object) color25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation24);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        java.awt.Stroke stroke18 = xYPlot14.getDomainCrosshairStroke();
        double double19 = xYPlot14.getDomainCrosshairValue();
        java.awt.Paint paint20 = xYPlot14.getOutlinePaint();
        xYPlot14.clearDomainAxes();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        xYPlot14.setDomainCrosshairValue((double) (-52), false);
        java.awt.Stroke stroke22 = xYPlot14.getDomainCrosshairStroke();
        boolean boolean23 = xYPlot14.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            xYPlot14.handleClick((-1), 7, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        categoryPlot8.setOutlineStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot8.getAxisOffset();
        double double23 = rectangleInsets21.calculateRightOutset((double) 6);
        double double25 = rectangleInsets21.calculateBottomOutset((double) (byte) 100);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot14.setRenderer(1, xYItemRenderer20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot14.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot10.setDomainAxisLocation((int) (short) 1, axisLocation12);
        boolean boolean14 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        int int16 = categoryPlot10.getIndexOf(categoryItemRenderer15);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        categoryPlot10.clearDomainMarkers((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot10.setFixedDomainAxisSpace(axisSpace20);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Color color0 = java.awt.Color.BLACK;
        java.awt.Color color1 = java.awt.Color.white;
        java.awt.Color color2 = color1.brighter();
        java.awt.color.ColorSpace colorSpace3 = color1.getColorSpace();
        float[] floatArray4 = null;
        float[] floatArray5 = color0.getComponents(colorSpace3, floatArray4);
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color0.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(paintContext11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit5, false, false);
        org.jfree.data.Range range9 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setTickLabelsVisible(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = dateAxis1.getTickMarkPosition();
        dateAxis1.setLabel("XY Plot");
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        xYPlot14.clearDomainMarkers((int) (byte) 10);
        xYPlot14.mapDatasetToRangeAxis(5, (int) ' ');
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot14.zoomDomainAxes((double) (-52), (double) (byte) 100, plotRenderingInfo38, point2D39);
        xYPlot14.configureRangeAxes();
        boolean boolean42 = xYPlot14.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis44.setTickMarkStroke(stroke45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit49 = null;
        dateAxis48.setTickUnit(dateTickUnit49);
        org.jfree.data.time.DateRange dateRange51 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis48.setRangeWithMargins((org.jfree.data.Range) dateRange51);
        dateAxis44.setRange((org.jfree.data.Range) dateRange51, false, false);
        java.awt.Paint paint56 = dateAxis44.getLabelPaint();
        int int57 = xYPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis44);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = xYPlot14.getFixedLegendItems();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(dateRange51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNull(legendItemCollection58);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        xYPlot14.setDomainCrosshairValue((double) (-52), false);
        double double22 = xYPlot14.getRangeCrosshairValue();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setTickMarkStroke(stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = dateAxis28.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer32);
        categoryPlot33.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = categoryPlot33.getDatasetRenderingOrder();
        int int37 = categoryPlot33.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setTickMarkStroke(stroke43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = dateAxis42.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = null;
        dateAxis47.setTickUnit(dateTickUnit48);
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setAxisLineStroke(stroke50);
        java.awt.Shape shape52 = dateAxis47.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer53);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker59 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis62.setTickMarkStroke(stroke63);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = dateAxis62.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit68 = null;
        dateAxis67.setTickUnit(dateTickUnit68);
        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis67.setAxisLineStroke(stroke70);
        java.awt.Shape shape72 = dateAxis67.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) dateAxis62, (org.jfree.chart.axis.ValueAxis) dateAxis67, xYItemRenderer73);
        org.jfree.chart.event.PlotChangeListener plotChangeListener75 = null;
        xYPlot74.addChangeListener(plotChangeListener75);
        org.jfree.chart.axis.AxisLocation axisLocation77 = xYPlot74.getDomainAxisLocation();
        intervalMarker59.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot74);
        java.lang.String str79 = xYPlot74.getPlotType();
        xYPlot74.clearRangeAxes();
        java.awt.Color color81 = java.awt.Color.MAGENTA;
        xYPlot74.setDomainTickBandPaint((java.awt.Paint) color81);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = xYPlot74.getDomainAxisEdge();
        int int84 = xYPlot74.getDatasetCount();
        java.awt.geom.Point2D point2D85 = xYPlot74.getQuadrantOrigin();
        xYPlot54.zoomRangeAxes((double) (-1), plotRenderingInfo56, point2D85);
        categoryPlot33.zoomRangeAxes((double) 12, plotRenderingInfo39, point2D85);
        org.jfree.chart.plot.PlotState plotState88 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo89 = null;
        try {
            xYPlot14.draw(graphics2D23, rectangle2D24, point2D85, plotState88, plotRenderingInfo89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "XY Plot" + "'", str79.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(point2D85);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        xYPlot14.setDomainZeroBaselineVisible(false);
        boolean boolean23 = xYPlot14.isDomainZoomable();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot8.getDatasetRenderingOrder();
        int int12 = categoryPlot8.getDomainAxisCount();
        boolean boolean13 = categoryPlot8.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        java.awt.Paint paint13 = categoryPlot8.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setTickMarkStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis17.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot22.setDomainAxisLocation((int) (short) 1, axisLocation24);
        boolean boolean26 = categoryPlot22.isDomainZoomable();
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot22.getRangeMarkers(5, layer28);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot22.getRowRenderingOrder();
        categoryPlot8.setColumnRenderingOrder(sortOrder30);
        categoryPlot8.setBackgroundImageAlignment((-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(sortOrder30);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot8.setRenderer((int) '#', categoryItemRenderer17, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot8.addDomainMarker((int) (byte) -1, categoryMarker15, layer16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis22.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.data.time.DateRange dateRange30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis27.setRangeWithMargins((org.jfree.data.Range) dateRange30);
        dateAxis22.setRangeWithMargins((org.jfree.data.Range) dateRange30, true, false);
        dateAxis19.setRange((org.jfree.data.Range) dateRange30);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setTickMarkStroke(stroke38);
        java.util.TimeZone timeZone40 = dateAxis37.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis37.setTickUnit(dateTickUnit41, false, false);
        java.util.Date date45 = dateAxis19.calculateLowestVisibleTickValue(dateTickUnit41);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        categoryMarker15.setKey((java.lang.Comparable) day46);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = dateAxis49.getLabelInsets();
        categoryMarker15.setLabelOffset(rectangleInsets50);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(dateRange30);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(dateTickUnit41);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(rectangleInsets50);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit1);
        org.junit.Assert.assertNotNull(numberTickUnit1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8, false, false);
        double double13 = dateAxis1.getFixedAutoRange();
        boolean boolean14 = dateAxis1.isTickMarksVisible();
        dateAxis1.setAutoTickUnitSelection(false);
        boolean boolean17 = dateAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        double double4 = dateAxis1.getLowerMargin();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setTickMarkStroke(stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = dateAxis10.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot15.setDomainAxisLocation((int) (short) 1, axisLocation17);
        boolean boolean19 = categoryPlot15.isDomainZoomable();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot15.getRangeMarkers(5, layer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot15.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        categoryPlot15.setDataset(0, categoryDataset25);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = dateAxis30.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = null;
        dateAxis35.setTickUnit(dateTickUnit36);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setAxisLineStroke(stroke38);
        java.awt.Shape shape40 = dateAxis35.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer41);
        boolean boolean43 = xYPlot42.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = xYPlot42.getRangeAxisEdge(500);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace47 = dateAxis1.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) categoryPlot15, rectangle2D27, rectangleEdge45, axisSpace46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot8.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot8.getDomainAxisForDataset(7);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setMaximumCategoryLabelWidthRatio(0.0f);
        int int18 = categoryAxis15.getMaximumCategoryLabelLines();
        double double19 = categoryAxis15.getLowerMargin();
        double double20 = categoryAxis15.getUpperMargin();
        int int21 = categoryPlot8.getDomainAxisIndex(categoryAxis15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot8.zoomDomainAxes((double) 0.5f, plotRenderingInfo23, point2D24);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setDomainAxisLocation((int) (short) 1, axisLocation30);
        boolean boolean32 = categoryPlot28.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot28.addDomainMarker((int) (byte) -1, categoryMarker35, layer36);
        java.util.Collection collection38 = xYPlot14.getDomainMarkers(100, layer36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot14.setRangeAxis(valueAxis39);
        xYPlot14.clearRangeMarkers(255);
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot14.getRangeAxis();
        java.awt.Stroke stroke44 = xYPlot14.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot8.addDomainMarker((int) (byte) -1, categoryMarker15, layer16);
        java.lang.Comparable comparable18 = categoryMarker15.getKey();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0d + "'", comparable18.equals(100.0d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier16);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = categoryPlot8.getOrientation();
        int int19 = categoryPlot8.getDatasetCount();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot10.setDomainAxisLocation((int) (short) 1, axisLocation12);
        boolean boolean14 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        int int16 = categoryPlot10.getIndexOf(categoryItemRenderer15);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        boolean boolean18 = categoryPlot10.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot26.setDomainAxisLocation((int) (short) 1, axisLocation28);
        xYPlot14.setRangeAxisLocation(axisLocation28);
        boolean boolean31 = xYPlot14.isSubplot();
        java.awt.geom.Point2D point2D32 = xYPlot14.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis34.setTickMarkStroke(stroke35);
        java.util.TimeZone timeZone37 = dateAxis34.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis34.setTickUnit(dateTickUnit38, false, false);
        dateAxis34.setRangeWithMargins(0.0d, (double) 10);
        int int45 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis34);
        xYPlot14.setDomainCrosshairValue((double) 71999999L);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(dateTickUnit38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot8.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        java.lang.Object obj16 = null;
        boolean boolean17 = categoryMarker15.equals(obj16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot26.render(graphics2D27, rectangle2D28, (int) (short) 100, plotRenderingInfo30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot26.setFixedDomainAxisSpace(axisSpace32, false);
        double double35 = categoryPlot26.getRangeCrosshairValue();
        categoryPlot26.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot26.getDataset((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
        categoryPlot26.setDomainAxisLocation((int) (byte) 10, axisLocation40);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection44 = categoryPlot26.getRangeMarkers(3, layer43);
        boolean boolean45 = categoryPlot8.removeDomainMarker(1, (org.jfree.chart.plot.Marker) categoryMarker15, layer43);
        double double46 = categoryPlot8.getAnchorValue();
        categoryPlot8.setRangeCrosshairValue((double) 100);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset38);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.lang.String str22 = intervalMarker2.getLabel();
        java.lang.Object obj23 = null;
        boolean boolean24 = intervalMarker2.equals(obj23);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        boolean boolean2 = dateAxis1.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit5, false, false);
        java.awt.Stroke stroke9 = dateAxis1.getAxisLineStroke();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke14);
        java.awt.Shape shape16 = dateAxis11.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis18.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = null;
        dateAxis26.setTickUnit(dateTickUnit27);
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis26.setRangeWithMargins((org.jfree.data.Range) dateRange29);
        dateAxis21.setRangeWithMargins((org.jfree.data.Range) dateRange29, true, false);
        dateAxis18.setRange((org.jfree.data.Range) dateRange29);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis36.setTickMarkStroke(stroke37);
        java.util.TimeZone timeZone39 = dateAxis36.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis36.setTickUnit(dateTickUnit40, false, false);
        java.util.Date date44 = dateAxis18.calculateLowestVisibleTickValue(dateTickUnit40);
        java.util.Date date45 = dateAxis11.calculateLowestVisibleTickValue(dateTickUnit40);
        java.util.Date date46 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit40);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date46, timeZone47);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.Class class0 = null;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis3.setTickUnit(dateTickUnit4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis9.setTickMarkStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis9.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        boolean boolean19 = categoryPlot14.render(graphics2D15, rectangle2D16, (int) (short) 100, plotRenderingInfo18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot14.setFixedDomainAxisSpace(axisSpace20, false);
        double double23 = categoryPlot14.getRangeCrosshairValue();
        dateAxis3.setPlot((org.jfree.chart.plot.Plot) categoryPlot14);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setTickMarkStroke(stroke27);
        java.util.TimeZone timeZone29 = dateAxis26.getTimeZone();
        dateAxis3.setTimeZone(timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone29);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        boolean boolean9 = dateAxis3.isAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setTickMarkStroke(stroke14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = dateAxis13.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot18.setDomainAxisLocation((int) (short) 1, axisLocation20);
        boolean boolean22 = categoryPlot18.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setTickMarkStroke(stroke27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = dateAxis26.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer30);
        categoryPlot31.mapDatasetToRangeAxis(0, (int) (short) 10);
        double double35 = categoryPlot31.getAnchorValue();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis39.setTickMarkStroke(stroke40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = dateAxis39.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = null;
        dateAxis44.setTickUnit(dateTickUnit45);
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis44.setAxisLineStroke(stroke47);
        java.awt.Shape shape49 = dateAxis44.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer50);
        boolean boolean52 = xYPlot51.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup53 = xYPlot51.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation54 = xYPlot51.getDomainAxisLocation();
        categoryPlot31.setDomainAxisLocation((int) (short) 0, axisLocation54, true);
        categoryPlot18.setRangeAxisLocation(axisLocation54, false);
        java.awt.Image image59 = null;
        categoryPlot18.setBackgroundImage(image59);
        dateAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(datasetGroup53);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        double double5 = rectangleInsets4.getRight();
        double double6 = rectangleInsets4.getTop();
        double double8 = rectangleInsets4.calculateBottomInset((double) 2.0f);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis10.setRangeWithMargins((org.jfree.data.Range) dateRange13);
        double double15 = dateAxis10.getLabelAngle();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer23);
        categoryPlot24.mapDatasetToRangeAxis(0, (int) (short) 10);
        double double28 = categoryPlot24.getAnchorValue();
        dateAxis10.setPlot((org.jfree.chart.plot.Plot) categoryPlot24);
        float float30 = categoryPlot24.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setTickMarkStroke(stroke36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = dateAxis35.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = null;
        dateAxis40.setTickUnit(dateTickUnit41);
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis40.setAxisLineStroke(stroke43);
        java.awt.Shape shape45 = dateAxis40.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis40, xYItemRenderer46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker52 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setTickMarkStroke(stroke56);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = dateAxis55.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = null;
        dateAxis60.setTickUnit(dateTickUnit61);
        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis60.setAxisLineStroke(stroke63);
        java.awt.Shape shape65 = dateAxis60.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) dateAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis60, xYItemRenderer66);
        org.jfree.chart.event.PlotChangeListener plotChangeListener68 = null;
        xYPlot67.addChangeListener(plotChangeListener68);
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot67.getDomainAxisLocation();
        intervalMarker52.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot67);
        java.lang.String str72 = xYPlot67.getPlotType();
        xYPlot67.clearRangeAxes();
        java.awt.Color color74 = java.awt.Color.MAGENTA;
        xYPlot67.setDomainTickBandPaint((java.awt.Paint) color74);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = xYPlot67.getDomainAxisEdge();
        int int77 = xYPlot67.getDatasetCount();
        java.awt.geom.Point2D point2D78 = xYPlot67.getQuadrantOrigin();
        xYPlot47.zoomRangeAxes((double) (-1), plotRenderingInfo49, point2D78);
        categoryPlot24.zoomDomainAxes((double) '4', plotRenderingInfo32, point2D78);
        boolean boolean81 = rectangleInsets4.equals((java.lang.Object) plotRenderingInfo32);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "XY Plot" + "'", str72.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(point2D78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        xYPlot17.setDomainCrosshairLockedOnData(true);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setTickMarkStroke(stroke27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = dateAxis26.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = null;
        dateAxis31.setTickUnit(dateTickUnit32);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis31.setAxisLineStroke(stroke34);
        java.awt.Shape shape36 = dateAxis31.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer37);
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        xYPlot38.addChangeListener(plotChangeListener39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot38.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis45.setTickMarkStroke(stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = dateAxis45.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer49);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = categoryPlot50.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection52 = categoryPlot50.getLegendItems();
        xYPlot38.setFixedLegendItems(legendItemCollection52);
        xYPlot17.setFixedLegendItems(legendItemCollection52);
        boolean boolean55 = xYPlot17.isRangeCrosshairVisible();
        java.awt.Stroke stroke56 = xYPlot17.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNull(categoryAxis51);
        org.junit.Assert.assertNotNull(legendItemCollection52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        java.util.TimeZone timeZone6 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone6);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        boolean boolean2 = dateAxis1.isVerticalTickLabels();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getTickLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setTickMarkStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis8.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot13.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot13.getLegendItems();
        categoryPlot13.clearDomainMarkers();
        float float17 = categoryPlot13.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset19 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset19);
        java.lang.Object obj21 = datasetChangeEvent20.getSource();
        org.jfree.data.general.Dataset dataset22 = datasetChangeEvent20.getDataset();
        categoryPlot13.datasetChanged(datasetChangeEvent20);
        boolean boolean24 = categoryPlot13.isDomainGridlinesVisible();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color27 = java.awt.Color.getColor("", color26);
        categoryPlot13.setOutlinePaint((java.awt.Paint) color27);
        categoryPlot13.configureDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot13.getDomainAxisEdge(10);
        boolean boolean32 = rectangleInsets4.equals((java.lang.Object) rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj21 + "' != '" + (-1.0f) + "'", obj21.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit23, false, false);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit23);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        java.util.TimeZone timeZone33 = dateAxis30.getTimeZone();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27, timeZone33);
        org.jfree.data.general.Dataset dataset36 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset36);
        int int38 = day34.compareTo((java.lang.Object) datasetChangeEvent37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day34.next();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int41 = day34.compareTo((java.lang.Object) color40);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        boolean boolean19 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color22 = java.awt.Color.getColor("", color21);
        categoryPlot8.setOutlinePaint((java.awt.Paint) color22);
        categoryPlot8.configureDomainAxes();
        categoryPlot8.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setTickMarkStroke(stroke30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = dateAxis29.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = null;
        dateAxis34.setTickUnit(dateTickUnit35);
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis34.setAxisLineStroke(stroke37);
        java.awt.Shape shape39 = dateAxis34.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer40);
        boolean boolean42 = xYPlot41.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = xYPlot41.getRangeAxisEdge(500);
        boolean boolean45 = xYPlot41.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis50.setTickMarkStroke(stroke51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = dateAxis50.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer54);
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot55.setDomainAxisLocation((int) (short) 1, axisLocation57);
        boolean boolean59 = categoryPlot55.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker62 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot55.addDomainMarker((int) (byte) -1, categoryMarker62, layer63);
        java.util.Collection collection65 = xYPlot41.getDomainMarkers(100, layer63);
        java.util.Collection collection66 = categoryPlot8.getDomainMarkers(layer63);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertNull(collection65);
        org.junit.Assert.assertNull(collection66);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        java.awt.Paint paint22 = intervalMarker21.getLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis25.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = null;
        dateAxis30.setTickUnit(dateTickUnit31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke33);
        java.awt.Shape shape35 = dateAxis30.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer36);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        xYPlot37.addChangeListener(plotChangeListener38);
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot37.getDomainAxisLocation();
        xYPlot37.setWeight((int) (byte) -1);
        java.awt.Paint paint43 = xYPlot37.getDomainGridlinePaint();
        intervalMarker21.setLabelPaint(paint43);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setTickMarkStroke(stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = dateAxis47.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit53 = null;
        dateAxis52.setTickUnit(dateTickUnit53);
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis52.setAxisLineStroke(stroke55);
        java.awt.Shape shape57 = dateAxis52.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis52, xYItemRenderer58);
        org.jfree.chart.event.PlotChangeListener plotChangeListener60 = null;
        xYPlot59.addChangeListener(plotChangeListener60);
        org.jfree.chart.axis.AxisLocation axisLocation62 = xYPlot59.getDomainAxisLocation();
        xYPlot59.setDomainCrosshairVisible(true);
        xYPlot59.setRangeCrosshairValue((double) 11);
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis69.setTickMarkStroke(stroke70);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = dateAxis69.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit75 = null;
        dateAxis74.setTickUnit(dateTickUnit75);
        java.awt.Stroke stroke77 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis74.setAxisLineStroke(stroke77);
        java.awt.Shape shape79 = dateAxis74.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer80 = null;
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot(xYDataset67, (org.jfree.chart.axis.ValueAxis) dateAxis69, (org.jfree.chart.axis.ValueAxis) dateAxis74, xYItemRenderer80);
        org.jfree.chart.event.PlotChangeListener plotChangeListener82 = null;
        xYPlot81.addChangeListener(plotChangeListener82);
        org.jfree.chart.axis.AxisLocation axisLocation84 = xYPlot81.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker88 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer89 = null;
        xYPlot81.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker88, layer89, true);
        org.jfree.chart.util.Layer layer92 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean93 = xYPlot59.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker88, layer92);
        boolean boolean94 = categoryPlot8.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker21, layer92);
        org.jfree.chart.axis.AxisSpace axisSpace95 = null;
        categoryPlot8.setFixedRangeAxisSpace(axisSpace95, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(layer92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        categoryPlot8.configureDomainAxes();
        categoryPlot8.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis32.setTickMarkStroke(stroke33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = dateAxis32.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = null;
        dateAxis37.setTickUnit(dateTickUnit38);
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setAxisLineStroke(stroke40);
        java.awt.Shape shape42 = dateAxis37.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer43);
        boolean boolean45 = xYPlot44.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = xYPlot44.getRangeAxisEdge(500);
        boolean boolean48 = xYPlot44.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        xYPlot44.setRenderer(1, xYItemRenderer50);
        java.awt.Stroke stroke52 = xYPlot44.getOutlineStroke();
        categoryPlot8.setOutlineStroke(stroke52);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = categoryPlot8.getDomainAxis(0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(categoryAxis55);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        java.util.TimeZone timeZone5 = dateAxis2.getTimeZone();
        dateAxis2.setLabelAngle(0.0d);
        java.awt.Font font8 = dateAxis2.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        dateAxis2.setRightArrow(shape15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis20.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setDomainAxisLocation((int) (short) 1, axisLocation27);
        boolean boolean29 = categoryPlot25.isDomainZoomable();
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot25.getRangeMarkers(5, layer31);
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot25.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        categoryPlot25.setDataset(0, categoryDataset35);
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot25.setRangeCrosshairStroke(stroke37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis40.setTickMarkStroke(stroke41);
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis40, xYItemRenderer44);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        xYPlot45.drawAnnotations(graphics2D46, rectangle2D47, plotRenderingInfo48);
        xYPlot45.setBackgroundImageAlpha((float) 1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit23, false, false);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit23);
        dateAxis1.setAutoTickUnitSelection(false, false);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis32.setTickMarkStroke(stroke33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = dateAxis32.getLabelInsets();
        dateAxis1.setLabelInsets(rectangleInsets35);
        dateAxis1.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        dateAxis1.setLabelAngle(0.0d);
        java.awt.Font font7 = dateAxis1.getTickLabelFont();
        dateAxis1.setLabelAngle((double) 128);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.setRangeCrosshairValue((double) (short) 10);
        categoryPlot8.configureRangeAxes();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot21.setDomainAxisLocation((int) (short) 1, axisLocation23);
        boolean boolean25 = categoryPlot21.isDomainZoomable();
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot21.getRangeMarkers(5, layer27);
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot21.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot21.setDataset(0, categoryDataset31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis36.setTickMarkStroke(stroke37);
        categoryPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis36);
        categoryPlot21.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot21.getLegendItems();
        categoryPlot8.setFixedLegendItems(legendItemCollection41);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(sortOrder29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(legendItemCollection41);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str23 = chartChangeEventType22.toString();
        java.lang.String str24 = chartChangeEventType22.toString();
        markerChangeEvent21.setType(chartChangeEventType22);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str23.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str24.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setTickMarkStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis7.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot12.setDomainAxisLocation((int) (short) 1, axisLocation14);
        java.awt.Paint paint16 = categoryPlot12.getNoDataMessagePaint();
        java.awt.Color color17 = java.awt.Color.white;
        float[] floatArray22 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray23 = color17.getRGBColorComponents(floatArray22);
        categoryPlot12.setRangeGridlinePaint((java.awt.Paint) color17);
        dateAxis1.setLabelPaint((java.awt.Paint) color17);
        java.lang.String str26 = dateAxis1.getLabelURL();
        dateAxis1.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = xYPlot14.getRenderer((int) ' ');
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot14.setDataset(xYDataset38);
        java.awt.Paint paint40 = xYPlot14.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNull(xYItemRenderer37);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        org.jfree.chart.plot.Plot plot23 = null;
        categoryPlot21.setParent(plot23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot21.getDomainAxisLocation((int) (short) -1);
        categoryPlot8.setDomainAxisLocation(axisLocation26, false);
        java.util.List list29 = categoryPlot8.getAnnotations();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        categoryPlot8.drawBackgroundImage(graphics2D30, rectangle2D31);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange9, true, false);
        double double14 = dateAxis1.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis16.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        org.jfree.data.time.DateRange dateRange27 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis24.setRangeWithMargins((org.jfree.data.Range) dateRange27);
        dateAxis19.setRangeWithMargins((org.jfree.data.Range) dateRange27, true, false);
        dateAxis16.setRange((org.jfree.data.Range) dateRange27);
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange27);
        org.jfree.chart.plot.Plot plot34 = dateAxis1.getPlot();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(dateRange27);
        org.junit.Assert.assertNull(plot34);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio(0.0f);
        int int15 = categoryAxis12.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis12.getCategoryLabelPositions();
        categoryAxis12.setLowerMargin((double) 6);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.setMaximumCategoryLabelWidthRatio(0.0f);
        int int25 = categoryAxis22.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = categoryAxis22.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        float float28 = categoryAxis27.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis29.setMaximumCategoryLabelWidthRatio(0.0f);
        int int32 = categoryAxis29.getMaximumCategoryLabelLines();
        double double33 = categoryAxis29.getLowerMargin();
        java.lang.Object obj34 = categoryAxis29.clone();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis38.setTickMarkStroke(stroke39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = dateAxis38.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer42);
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot43.setDomainAxisLocation((int) (short) 1, axisLocation45);
        boolean boolean47 = categoryPlot43.isSubplot();
        java.util.List list48 = categoryPlot43.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = null;
        dateAxis50.setTickUnit(dateTickUnit51);
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis50.setAxisLineStroke(stroke53);
        categoryPlot43.setOutlineStroke(stroke53);
        boolean boolean56 = categoryAxis29.equals((java.lang.Object) stroke53);
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis58.setMaximumCategoryLabelWidthRatio(0.0f);
        int int61 = categoryAxis58.getMaximumCategoryLabelLines();
        categoryAxis58.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, (org.jfree.chart.axis.ValueAxis) dateAxis64, categoryItemRenderer65);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray67 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis12, categoryAxis19, categoryAxis22, categoryAxis27, categoryAxis29, categoryAxis58 };
        categoryPlot8.setDomainAxes(categoryAxisArray67);
        java.awt.Paint paint69 = categoryPlot8.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset70 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = null;
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke74 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis73.setTickMarkStroke(stroke74);
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = dateAxis73.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer77 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot(categoryDataset70, categoryAxis71, (org.jfree.chart.axis.ValueAxis) dateAxis73, categoryItemRenderer77);
        java.awt.Graphics2D graphics2D79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        boolean boolean83 = categoryPlot78.render(graphics2D79, rectangle2D80, (int) (short) 100, plotRenderingInfo82);
        org.jfree.chart.axis.AxisSpace axisSpace84 = null;
        categoryPlot78.setFixedDomainAxisSpace(axisSpace84, false);
        double double87 = categoryPlot78.getRangeCrosshairValue();
        categoryPlot78.configureDomainAxes();
        java.awt.Font font89 = categoryPlot78.getNoDataMessageFont();
        java.awt.Color color90 = java.awt.Color.yellow;
        categoryPlot78.setBackgroundPaint((java.awt.Paint) color90);
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color90);
        org.jfree.chart.util.RectangleInsets rectangleInsets93 = categoryPlot8.getAxisOffset();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(categoryAxisArray67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(font89);
        org.junit.Assert.assertNotNull(color90);
        org.junit.Assert.assertNotNull(rectangleInsets93);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        java.awt.Font font21 = intervalMarker17.getLabelFont();
        java.awt.Stroke stroke22 = intervalMarker17.getStroke();
        java.awt.Paint paint23 = intervalMarker17.getOutlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) 0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer25 = null;
        xYPlot17.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker24, layer25, true);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        xYPlot17.setDataset(xYDataset28);
        int int30 = xYPlot17.getRangeAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis36.setTickMarkStroke(stroke37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = dateAxis36.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = null;
        dateAxis41.setTickUnit(dateTickUnit42);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis41.setAxisLineStroke(stroke44);
        java.awt.Shape shape46 = dateAxis41.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis41, xYItemRenderer47);
        org.jfree.chart.event.PlotChangeListener plotChangeListener49 = null;
        xYPlot48.addChangeListener(plotChangeListener49);
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot48.getDomainAxisLocation();
        intervalMarker33.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot48);
        java.awt.Color color53 = java.awt.Color.BLACK;
        java.awt.Color color54 = java.awt.Color.white;
        java.awt.Color color55 = color54.brighter();
        java.awt.color.ColorSpace colorSpace56 = color54.getColorSpace();
        float[] floatArray57 = null;
        float[] floatArray58 = color53.getComponents(colorSpace56, floatArray57);
        intervalMarker33.setOutlinePaint((java.awt.Paint) color53);
        xYPlot17.setOutlinePaint((java.awt.Paint) color53);
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(colorSpace56);
        org.junit.Assert.assertNotNull(floatArray58);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange9, true, false);
        double double14 = dateAxis1.getUpperMargin();
        java.awt.Stroke stroke15 = dateAxis1.getTickMarkStroke();
        dateAxis1.setNegativeArrowVisible(false);
        java.awt.Paint paint18 = dateAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot14.zoomDomainAxes((double) (-52), (double) (byte) 100, plotRenderingInfo38, point2D39);
        xYPlot14.configureRangeAxes();
        boolean boolean42 = xYPlot14.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis44.setTickMarkStroke(stroke45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit49 = null;
        dateAxis48.setTickUnit(dateTickUnit49);
        org.jfree.data.time.DateRange dateRange51 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis48.setRangeWithMargins((org.jfree.data.Range) dateRange51);
        dateAxis44.setRange((org.jfree.data.Range) dateRange51, false, false);
        java.awt.Paint paint56 = dateAxis44.getLabelPaint();
        int int57 = xYPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis44);
        int int58 = xYPlot14.getDomainAxisCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(dateRange51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Paint paint16 = xYPlot14.getDomainTickBandPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot14.markerChanged(markerChangeEvent17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = null;
        dateAxis26.setTickUnit(dateTickUnit27);
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setAxisLineStroke(stroke29);
        java.awt.Shape shape31 = dateAxis26.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer32);
        boolean boolean34 = xYPlot33.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot33.getRangeAxisEdge(500);
        boolean boolean37 = xYPlot33.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        xYPlot33.setRenderer(1, xYItemRenderer39);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier41 = xYPlot33.getDrawingSupplier();
        xYPlot14.setDrawingSupplier(drawingSupplier41);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = xYPlot14.getRendererForDataset(xYDataset43);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(drawingSupplier41);
        org.junit.Assert.assertNull(xYItemRenderer44);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        categoryPlot8.clearDomainMarkers((int) (short) 1);
        boolean boolean21 = categoryPlot8.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        java.awt.Font font15 = xYPlot14.getNoDataMessageFont();
        java.awt.Color color16 = java.awt.Color.yellow;
        xYPlot14.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        int int19 = xYPlot14.indexOf(xYDataset18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot14.drawAnnotations(graphics2D20, rectangle2D21, plotRenderingInfo22);
        int int24 = xYPlot14.getBackgroundImageAlignment();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        java.util.TimeZone timeZone30 = dateAxis27.getTimeZone();
        dateAxis27.setLabelAngle(0.0d);
        java.awt.Font font33 = dateAxis27.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = null;
        dateAxis35.setTickUnit(dateTickUnit36);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setAxisLineStroke(stroke38);
        java.awt.Shape shape40 = dateAxis35.getUpArrow();
        dateAxis27.setRightArrow(shape40);
        xYPlot14.setRangeAxis(3, (org.jfree.chart.axis.ValueAxis) dateAxis27, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis50.setTickMarkStroke(stroke51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = dateAxis50.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit56 = null;
        dateAxis55.setTickUnit(dateTickUnit56);
        java.awt.Stroke stroke58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setAxisLineStroke(stroke58);
        java.awt.Shape shape60 = dateAxis55.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis55, xYItemRenderer61);
        org.jfree.chart.event.PlotChangeListener plotChangeListener63 = null;
        xYPlot62.addChangeListener(plotChangeListener63);
        org.jfree.chart.axis.AxisLocation axisLocation65 = xYPlot62.getDomainAxisLocation();
        intervalMarker47.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot62);
        java.lang.String str67 = xYPlot62.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis68 = xYPlot62.getRangeAxis();
        java.awt.Shape shape69 = valueAxis68.getUpArrow();
        valueAxis68.setVisible(false);
        xYPlot14.setDomainAxis((int) (short) 10, valueAxis68);
        org.jfree.data.xy.XYDataset xYDataset74 = xYPlot14.getDataset((int) (byte) -1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "XY Plot" + "'", str67.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis68);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNull(xYDataset74);
    }
}

