import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 100, 0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-52) + "'", int3 == (-52));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        float[] floatArray4 = new float[] { 100.0f };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB((int) 'a', (int) (short) 0, (int) (byte) -1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Stroke stroke2 = null;
        java.awt.Color color3 = java.awt.Color.white;
        java.awt.Color color4 = color3.brighter();
        java.awt.Stroke stroke5 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D5, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.plot.Marker marker9 = null;
        try {
            categoryPlot8.addRangeMarker(marker9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Font font9 = null;
        try {
            dateAxis3.setTickLabelFont(font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        java.awt.Paint paint14 = null;
        try {
            categoryPlot8.setRangeGridlinePaint(paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = color6.brighter();
        java.awt.Color color8 = color7.brighter();
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, (java.awt.Paint) color1, stroke4, (java.awt.Paint) color7, stroke9, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        try {
            categoryPlot8.addDomainMarker(categoryMarker10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.util.Date date0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        java.util.TimeZone timeZone5 = dateAxis2.getTimeZone();
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date0, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot8.addRangeMarker((-52), marker14, layer15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        try {
            java.awt.Paint paint16 = xYPlot14.getQuadrantPaint((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            boolean boolean12 = categoryPlot8.removeAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color2 = java.awt.Color.getColor("SortOrder.ASCENDING", (int) (byte) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        java.awt.Paint paint13 = categoryPlot8.getBackgroundPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        try {
            categoryPlot8.addDomainMarker(categoryMarker14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis6.setTickMarkStroke(stroke7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis6.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke14);
        java.awt.Shape shape16 = dateAxis11.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer17);
        boolean boolean19 = xYPlot18.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot18.getRangeAxisEdge(500);
        try {
            double double22 = categoryAxis0.getCategoryMiddle(10, 0, rectangle2D3, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        try {
            java.util.Date date6 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = java.awt.Color.white;
        float[] floatArray5 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray6 = color0.getRGBColorComponents(floatArray5);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray6, jFreeChart7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        try {
            dateAxis3.zoomRange((double) 10.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        double double18 = xYPlot14.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        java.lang.Comparable comparable5 = null;
        try {
            java.awt.Paint paint6 = categoryAxis0.getTickLabelPaint(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setDomainCrosshairVisible(true);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.Point2D point2D22 = null;
        org.jfree.chart.plot.PlotState plotState23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            xYPlot14.draw(graphics2D20, rectangle2D21, point2D22, plotState23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        int int16 = xYPlot14.getWeight();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setTickMarkStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis8.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = null;
        dateAxis13.setTickUnit(dateTickUnit14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setAxisLineStroke(stroke16);
        java.awt.Shape shape18 = dateAxis13.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer19);
        boolean boolean21 = xYPlot20.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot20.getRangeAxisEdge(500);
        try {
            double double24 = categoryAxis0.getCategoryMiddle((int) '4', 500, rectangle2D5, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot10.setDomainAxisLocation((int) (short) 1, axisLocation12);
        boolean boolean14 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        int int16 = categoryPlot10.getIndexOf(categoryItemRenderer15);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        java.awt.Paint paint18 = null;
        try {
            categoryAxis0.setTickLabelPaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double3 = dateAxis1.getLowerBound();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setTickMarkStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis8.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = null;
        dateAxis13.setTickUnit(dateTickUnit14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setAxisLineStroke(stroke16);
        java.awt.Shape shape18 = dateAxis13.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer19);
        boolean boolean21 = xYPlot20.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot20.getRangeAxisEdge(500);
        try {
            double double24 = dateAxis1.lengthToJava2D((double) (short) 1, rectangle2D5, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Paint paint1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10.0f, paint1, stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier16);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = categoryPlot8.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setMaximumCategoryLabelWidthRatio(0.0f);
        int int23 = categoryAxis20.getMaximumCategoryLabelLines();
        double double24 = categoryAxis20.getLowerMargin();
        try {
            categoryPlot8.setDomainAxis((-52), categoryAxis20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot8.addDomainMarker(categoryMarker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Paint paint16 = xYPlot14.getDomainTickBandPaint();
        java.awt.Stroke stroke17 = null;
        try {
            xYPlot14.setRangeCrosshairStroke(stroke17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        java.util.Date date6 = null;
        java.util.Date date7 = null;
        try {
            dateAxis1.setRange(date6, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color0 = java.awt.Color.BLACK;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str1.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color1 = java.awt.Color.white;
        java.awt.Color color2 = java.awt.Color.white;
        float[] floatArray7 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray8 = color2.getRGBColorComponents(floatArray7);
        float[] floatArray9 = color1.getRGBColorComponents(floatArray7);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis12.setTickMarkStroke(stroke13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = dateAxis12.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setAxisLineStroke(stroke20);
        java.awt.Shape shape22 = dateAxis17.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer23);
        boolean boolean25 = xYPlot24.isDomainGridlinesVisible();
        java.awt.Paint paint26 = xYPlot24.getDomainTickBandPaint();
        java.awt.Stroke stroke27 = xYPlot24.getRangeGridlineStroke();
        java.awt.Color color28 = java.awt.Color.black;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis32.setTickMarkStroke(stroke33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = dateAxis32.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot37.setDomainAxisLocation((int) (short) 1, axisLocation39);
        boolean boolean41 = categoryPlot37.isDomainZoomable();
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = categoryPlot37.getRangeMarkers(5, layer43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot37.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        categoryPlot37.setDataset(0, categoryDataset47);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot37.setRangeCrosshairStroke(stroke49);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 0, (java.awt.Paint) color1, stroke27, (java.awt.Paint) color28, stroke49, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        try {
            intervalMarker2.setLabelOffsetType(lengthAdjustmentType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        java.awt.Font font3 = dateAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot14.setOrientation(plotOrientation27);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(plotOrientation27);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        categoryPlot8.setBackgroundImageAlignment(500);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot26.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot26.getLegendItems();
        xYPlot14.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = xYPlot14.getRangeGridlinePaint();
        xYPlot14.setRangeZeroBaselineVisible(false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot14.getDomainAxisForDataset((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setDomainCrosshairVisible(true);
        xYPlot14.setRangeCrosshairValue((double) 11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        try {
            xYPlot14.zoomDomainAxes(100.0d, (-1.0d), plotRenderingInfo24, point2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        try {
            categoryPlot8.setRangeAxis((-1), valueAxis10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        int int20 = xYPlot14.getIndexOf(xYItemRenderer19);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis6.setTickMarkStroke(stroke7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis6.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke14);
        java.awt.Shape shape16 = dateAxis11.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        xYPlot18.addChangeListener(plotChangeListener19);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot18.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot18.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker25, layer26, true);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot18.setDataset(xYDataset29);
        int int31 = xYPlot18.getRangeAxisCount();
        xYPlot18.setDomainZeroBaselineVisible(true);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setTickMarkStroke(stroke38);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = dateAxis37.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = null;
        dateAxis42.setTickUnit(dateTickUnit43);
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setAxisLineStroke(stroke45);
        java.awt.Shape shape47 = dateAxis42.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis42, xYItemRenderer48);
        boolean boolean50 = xYPlot49.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = xYPlot49.getRangeAxisEdge(500);
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace54 = categoryAxis0.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) xYPlot18, rectangle2D34, rectangleEdge52, axisSpace53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateTopInset((double) ' ');
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        double double5 = rectangleInsets4.getTop();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets4.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        double double12 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        try {
            categoryPlot8.addDomainMarker(categoryMarker19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        double double9 = rectangleInsets7.calculateTopOutset((double) '#');
        dateAxis1.setTickLabelInsets(rectangleInsets7);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = null;
        dateAxis12.setTickUnit(dateTickUnit13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis12.setAxisLineStroke(stroke15);
        java.awt.Shape shape17 = dateAxis12.getDownArrow();
        dateAxis1.setDownArrow(shape17);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        try {
            intervalMarker2.setAlpha((float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = null;
        dateAxis8.setTickUnit(dateTickUnit9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setAxisLineStroke(stroke11);
        java.awt.Shape shape13 = dateAxis8.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot15.addChangeListener(plotChangeListener16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot15.getDomainAxisLocation();
        xYPlot15.setDomainCrosshairVisible(true);
        xYPlot15.setRangeCrosshairValue((double) 11);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_RED;
        xYPlot15.setDomainZeroBaselinePaint((java.awt.Paint) color23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setTickMarkStroke(stroke30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = dateAxis29.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = null;
        dateAxis34.setTickUnit(dateTickUnit35);
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis34.setAxisLineStroke(stroke37);
        java.awt.Shape shape39 = dateAxis34.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer40);
        org.jfree.chart.event.PlotChangeListener plotChangeListener42 = null;
        xYPlot41.addChangeListener(plotChangeListener42);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot41.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker48 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer49 = null;
        xYPlot41.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker48, layer49, true);
        org.jfree.chart.axis.ValueAxis valueAxis53 = xYPlot41.getRangeAxis(0);
        java.awt.Stroke stroke54 = valueAxis53.getTickMarkStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color23, stroke25, (java.awt.Paint) color26, stroke54, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(valueAxis53);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        boolean boolean2 = dateAxis1.isVerticalTickLabels();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.centerRange((double) 10);
        dateAxis1.setFixedDimension((double) 500);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Paint paint16 = xYPlot14.getDomainTickBandPaint();
        java.awt.Stroke stroke17 = xYPlot14.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            xYPlot14.handleClick((int) (byte) 100, 0, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot14.getRangeAxis(0);
        java.awt.Stroke stroke27 = valueAxis26.getTickMarkStroke();
        java.lang.String str28 = valueAxis26.getLabelToolTip();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(valueAxis26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.setRangeCrosshairValue((double) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            boolean boolean15 = categoryPlot8.removeAnnotation(categoryAnnotation13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setTickMarkStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis7.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot12.render(graphics2D13, rectangle2D14, (int) (short) 100, plotRenderingInfo16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot12.setFixedDomainAxisSpace(axisSpace18, false);
        double double21 = categoryPlot12.getRangeCrosshairValue();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot12.getRangeAxis((int) '#');
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        dateAxis1.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setTickLabelInsets(rectangleInsets12);
        double double14 = rectangleInsets12.getRight();
        double double16 = rectangleInsets12.calculateBottomOutset((double) (byte) 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.0d + "'", double16 == 10.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        dateAxis1.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setTickLabelInsets(rectangleInsets12);
        double double14 = rectangleInsets12.getRight();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets12.createOutsetRectangle(rectangle2D15, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        double double5 = rectangleInsets4.getTop();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis9.setTickMarkStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis9.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = null;
        dateAxis14.setTickUnit(dateTickUnit15);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setAxisLineStroke(stroke17);
        java.awt.Shape shape19 = dateAxis14.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer20);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        xYPlot21.addChangeListener(plotChangeListener22);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot21.getDomainAxisLocation();
        intervalMarker6.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot21);
        java.lang.String str26 = xYPlot21.getPlotType();
        xYPlot21.clearRangeAxes();
        java.awt.Color color28 = java.awt.Color.MAGENTA;
        xYPlot21.setDomainTickBandPaint((java.awt.Paint) color28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot21.getDomainAxisEdge();
        try {
            double double31 = categoryAxis0.getCategoryStart(0, 6, rectangle2D3, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.lang.String str22 = xYPlot17.getPlotType();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot17.getRangeAxisForDataset((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        dateAxis1.setFixedAutoRange((double) 10L);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(dateTickUnit4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot10.setDomainAxisLocation((int) (short) 1, axisLocation12);
        boolean boolean14 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        int int16 = categoryPlot10.getIndexOf(categoryItemRenderer15);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        categoryPlot10.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8, false, false);
        try {
            dateAxis1.zoomRange(100.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateRange8);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        double double5 = rectangleInsets4.getRight();
        double double6 = rectangleInsets4.getTop();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setWeight((int) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis21.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setTickMarkStroke(stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis24.getLabelInsets();
        double double29 = rectangleInsets27.calculateTopOutset((double) '#');
        dateAxis21.setTickLabelInsets(rectangleInsets27);
        xYPlot14.setAxisOffset(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Font font4 = dateAxis1.getTickLabelFont();
        float float5 = dateAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Paint paint5 = null;
        try {
            categoryAxis0.setTickMarkPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke4);
        java.awt.Shape shape6 = dateAxis1.getDownArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setLabelInsets(rectangleInsets11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets11.createInsetRectangle(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot14.setDomainGridlinePaint((java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setTickMarkStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis7.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot12.render(graphics2D13, rectangle2D14, (int) (short) 100, plotRenderingInfo16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot12.setFixedDomainAxisSpace(axisSpace18, false);
        double double21 = categoryPlot12.getRangeCrosshairValue();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis25.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = null;
        dateAxis30.setTickUnit(dateTickUnit31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke33);
        java.awt.Shape shape35 = dateAxis30.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer36);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        xYPlot37.addChangeListener(plotChangeListener38);
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot37.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis44.setTickMarkStroke(stroke45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = dateAxis44.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer48);
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot49.setDomainAxisLocation((int) (short) 1, axisLocation51);
        xYPlot37.setRangeAxisLocation(axisLocation51);
        categoryPlot12.setRangeAxisLocation(axisLocation51);
        java.awt.Stroke stroke55 = categoryPlot12.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot8.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        categoryPlot8.setWeight(3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Color color0 = java.awt.Color.white;
        float[] floatArray5 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray6 = color0.getRGBColorComponents(floatArray5);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray6, jFreeChart7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        chartChangeEvent8.setType(chartChangeEventType9);
        java.lang.String str11 = chartChangeEvent8.toString();
        java.lang.Object obj12 = chartChangeEvent8.getSource();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        boolean boolean19 = xYPlot14.isRangeZoomable();
        java.awt.Paint paint20 = null;
        try {
            xYPlot14.setRangeCrosshairPaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        dateAxis7.setTickLabelInsets(rectangleInsets19);
        java.util.Date date21 = null;
        try {
            dateAxis7.setMinimumDate(date21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        dateAxis2.setRange((org.jfree.data.Range) dateRange9, false, false);
        double double14 = dateAxis2.getFixedAutoRange();
        boolean boolean15 = dateAxis2.isTickMarksVisible();
        boolean boolean16 = textAnchor0.equals((java.lang.Object) boolean15);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        boolean boolean2 = dateAxis1.isVerticalTickLabels();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getTickLabelInsets();
        double double5 = rectangleInsets4.getRight();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        boolean boolean2 = dateAxis1.isVisible();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        java.awt.Font font15 = xYPlot14.getNoDataMessageFont();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            xYPlot14.drawBackground(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.data.Range range27 = null;
        try {
            dateAxis23.setRange(range27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis20.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setAxisLineStroke(stroke28);
        java.awt.Shape shape30 = dateAxis25.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot32.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation35);
        java.awt.Stroke stroke37 = xYPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = dateAxis39.getLabelInsets();
        xYPlot14.setAxisOffset(rectangleInsets40);
        xYPlot14.setRangeCrosshairValue((double) (byte) -1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
//        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
//        double double4 = categoryAxis0.getLowerMargin();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        int int8 = day6.getDayOfMonth();
//        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
//        org.jfree.data.xy.XYDataset xYDataset15 = null;
//        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
//        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis17.setTickMarkStroke(stroke18);
//        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis17.getLabelInsets();
//        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = null;
//        dateAxis22.setTickUnit(dateTickUnit23);
//        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        dateAxis22.setAxisLineStroke(stroke25);
//        java.awt.Shape shape27 = dateAxis22.getUpArrow();
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
//        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer28);
//        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
//        xYPlot29.addChangeListener(plotChangeListener30);
//        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot29.getDomainAxisLocation();
//        intervalMarker14.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot29);
//        java.lang.String str34 = xYPlot29.getPlotType();
//        xYPlot29.clearRangeAxes();
//        java.awt.Color color36 = java.awt.Color.MAGENTA;
//        xYPlot29.setDomainTickBandPaint((java.awt.Paint) color36);
//        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot29.getDomainAxisEdge();
//        try {
//            double double39 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) false, (java.lang.Comparable) int8, categoryDataset9, (double) '#', rectangle2D11, rectangleEdge38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(rectangleInsets20);
//        org.junit.Assert.assertNotNull(stroke25);
//        org.junit.Assert.assertNotNull(shape27);
//        org.junit.Assert.assertNotNull(axisLocation32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "XY Plot" + "'", str34.equals("XY Plot"));
//        org.junit.Assert.assertNotNull(color36);
//        org.junit.Assert.assertNotNull(rectangleEdge38);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) '#', rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.plot.Plot plot10 = null;
        categoryPlot8.setParent(plot10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot8.getDomainAxisLocation((int) (short) -1);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        categoryPlot8.setRenderer(categoryItemRenderer27);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Color color0 = java.awt.Color.white;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setDomainAxisLocation((int) (short) 1, axisLocation30);
        boolean boolean32 = categoryPlot28.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot28.addDomainMarker((int) (byte) -1, categoryMarker35, layer36);
        java.util.Collection collection38 = xYPlot14.getDomainMarkers(100, layer36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot14.setRangeAxis(valueAxis39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        xYPlot14.setDomainCrosshairPaint((java.awt.Paint) color41);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        double double14 = categoryPlot8.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        dateAxis1.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setTickLabelInsets(rectangleInsets12);
        double double15 = rectangleInsets12.calculateBottomInset((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets12.createOutsetRectangle(rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            java.awt.Color color1 = java.awt.Color.decode("UnitType.RELATIVE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UnitType.RELATIVE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        double double5 = intervalMarker2.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.lang.String str22 = xYPlot17.getPlotType();
        xYPlot17.clearRangeAxes();
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        xYPlot17.setDomainTickBandPaint((java.awt.Paint) color24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot17.getRenderer(6);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = dateAxis30.getLabelInsets();
        double double32 = dateAxis30.getLowerBound();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = dateAxis30.valueToJava2D((double) 6, rectangle2D34, rectangleEdge35);
        java.awt.Color color37 = java.awt.Color.ORANGE;
        boolean boolean38 = dateAxis30.equals((java.lang.Object) color37);
        try {
            xYPlot17.setQuadrantPaint((-1), (java.awt.Paint) color37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot26.setDomainAxisLocation((int) (short) 1, axisLocation28);
        xYPlot14.setRangeAxisLocation(axisLocation28);
        boolean boolean31 = xYPlot14.isSubplot();
        try {
            xYPlot14.setBackgroundImageAlpha((float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) "DatasetRenderingOrder.FORWARD");
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot10.setDomainAxisLocation((int) (short) 1, axisLocation12);
        boolean boolean14 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        int int16 = categoryPlot10.getIndexOf(categoryItemRenderer15);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        boolean boolean18 = categoryAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        objectList0.clear();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.Color color6 = color5.brighter();
        java.awt.color.ColorSpace colorSpace7 = color5.getColorSpace();
        objectList0.set(0, (java.lang.Object) colorSpace7);
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit23, false, false);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit23);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        java.util.TimeZone timeZone33 = dateAxis30.getTimeZone();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27, timeZone33);
        org.jfree.data.general.Dataset dataset36 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset36);
        int int38 = day34.compareTo((java.lang.Object) datasetChangeEvent37);
        org.jfree.data.general.Dataset dataset39 = datasetChangeEvent37.getDataset();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(dataset39);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot8.getRowRenderingOrder();
        categoryPlot8.setDrawSharedDomainAxis(false);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot8.getFixedLegendItems();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(legendItemCollection20);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot26.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot26.getLegendItems();
        xYPlot14.setFixedLegendItems(legendItemCollection28);
        java.awt.Paint paint30 = xYPlot14.getRangeGridlinePaint();
        xYPlot14.setRangeZeroBaselineVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot14.setRenderer(5, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        try {
            xYPlot14.setRangeAxisLocation(axisLocation36, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot10.setDomainAxisLocation((int) (short) 1, axisLocation12);
        boolean boolean14 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        int int16 = categoryPlot10.getIndexOf(categoryItemRenderer15);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        categoryPlot10.clearDomainMarkers((int) ' ');
        categoryPlot10.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setTickMarkStroke(stroke8);
        java.util.TimeZone timeZone10 = dateAxis7.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis7.setTickUnit(dateTickUnit11, false, false);
        java.awt.Color color15 = java.awt.Color.green;
        int int16 = color15.getBlue();
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) dateTickUnit11, (java.awt.Paint) color15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = null;
        dateAxis8.setTickUnit(dateTickUnit9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setAxisLineStroke(stroke11);
        java.awt.Shape shape13 = dateAxis8.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer14);
        boolean boolean16 = xYPlot15.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        xYPlot15.drawBackgroundImage(graphics2D17, rectangle2D18);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer24 = null;
        xYPlot15.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker23, layer24, false);
        java.awt.Paint paint27 = intervalMarker23.getPaint();
        boolean boolean28 = datasetRenderingOrder0.equals((java.lang.Object) paint27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        java.lang.Comparable comparable3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setTickMarkStroke(stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis11.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, categoryItemRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot16.setDomainAxisLocation((int) (short) 1, axisLocation18);
        boolean boolean20 = categoryPlot16.isDomainZoomable();
        java.awt.Paint paint21 = categoryPlot16.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis25.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot30.setDomainAxisLocation((int) (short) 1, axisLocation32);
        boolean boolean34 = categoryPlot30.isDomainZoomable();
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = categoryPlot30.getRangeMarkers(5, layer36);
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot30.getRowRenderingOrder();
        categoryPlot16.setColumnRenderingOrder(sortOrder38);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setTickMarkStroke(stroke43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = dateAxis42.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = null;
        dateAxis47.setTickUnit(dateTickUnit48);
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setAxisLineStroke(stroke50);
        java.awt.Shape shape52 = dateAxis47.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer53);
        org.jfree.chart.plot.IntervalMarker intervalMarker57 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer58 = null;
        intervalMarker57.setGradientPaintTransformer(gradientPaintTransformer58);
        boolean boolean60 = xYPlot54.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker57);
        java.awt.Font font61 = intervalMarker57.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = dateAxis63.getLabelInsets();
        double double65 = dateAxis63.getLowerBound();
        java.awt.Font font66 = dateAxis63.getTickLabelFont();
        intervalMarker57.setLabelFont(font66);
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis69.setTickMarkStroke(stroke70);
        java.util.TimeZone timeZone72 = dateAxis69.getTimeZone();
        dateAxis69.setLabelAngle(0.0d);
        java.awt.Font font75 = dateAxis69.getTickLabelFont();
        intervalMarker57.setLabelFont(font75);
        categoryPlot16.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker57);
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = categoryPlot16.getRangeAxisEdge();
        try {
            double double79 = categoryAxis0.getCategorySeriesMiddle(comparable3, (java.lang.Comparable) 6, categoryDataset5, (double) (byte) 0, rectangle2D7, rectangleEdge78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNotNull(font75);
        org.junit.Assert.assertNotNull(rectangleEdge78);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot24.setDomainAxisLocation((int) (short) 1, axisLocation26);
        boolean boolean28 = categoryPlot24.isDomainZoomable();
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot24.getRangeMarkers(5, layer30);
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot24.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        categoryPlot24.setDataset(0, categoryDataset34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot24.setRangeCrosshairStroke(stroke36);
        categoryPlot8.setRangeCrosshairStroke(stroke36);
        categoryPlot8.setForegroundAlpha((float) 10L);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        boolean boolean17 = categoryPlot8.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke4);
        java.awt.Shape shape6 = dateAxis1.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis8.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setTickMarkStroke(stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis11.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = null;
        dateAxis16.setTickUnit(dateTickUnit17);
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis16.setRangeWithMargins((org.jfree.data.Range) dateRange19);
        dateAxis11.setRangeWithMargins((org.jfree.data.Range) dateRange19, true, false);
        dateAxis8.setRange((org.jfree.data.Range) dateRange19);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setTickMarkStroke(stroke27);
        java.util.TimeZone timeZone29 = dateAxis26.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis26.setTickUnit(dateTickUnit30, false, false);
        java.util.Date date34 = dateAxis8.calculateLowestVisibleTickValue(dateTickUnit30);
        java.util.Date date35 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit30);
        dateAxis1.setTickMarkInsideLength((float) 2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(dateRange19);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Stroke stroke17 = xYPlot14.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = color1.brighter();
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray4 = null;
        try {
            float[] floatArray5 = color2.getColorComponents(colorSpace3, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot14.removeChangeListener(plotChangeListener18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            xYPlot14.handleClick(8, (int) (short) -1, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        java.lang.Object obj5 = categoryAxis0.clone();
        categoryAxis0.setMaximumCategoryLabelLines(13);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setTickMarkStroke(stroke15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis14.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot19.setDomainAxisLocation((int) (short) 1, axisLocation21);
        boolean boolean23 = categoryPlot19.isDomainZoomable();
        java.awt.Paint paint24 = categoryPlot19.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setTickMarkStroke(stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = dateAxis28.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis28, categoryItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot33.setDomainAxisLocation((int) (short) 1, axisLocation35);
        boolean boolean37 = categoryPlot33.isDomainZoomable();
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot33.getRangeMarkers(5, layer39);
        org.jfree.chart.util.SortOrder sortOrder41 = categoryPlot33.getRowRenderingOrder();
        categoryPlot19.setColumnRenderingOrder(sortOrder41);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis45.setTickMarkStroke(stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = dateAxis45.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = null;
        dateAxis50.setTickUnit(dateTickUnit51);
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis50.setAxisLineStroke(stroke53);
        java.awt.Shape shape55 = dateAxis50.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) dateAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis50, xYItemRenderer56);
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer61 = null;
        intervalMarker60.setGradientPaintTransformer(gradientPaintTransformer61);
        boolean boolean63 = xYPlot57.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker60);
        java.awt.Font font64 = intervalMarker60.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = dateAxis66.getLabelInsets();
        double double68 = dateAxis66.getLowerBound();
        java.awt.Font font69 = dateAxis66.getTickLabelFont();
        intervalMarker60.setLabelFont(font69);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke73 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis72.setTickMarkStroke(stroke73);
        java.util.TimeZone timeZone75 = dateAxis72.getTimeZone();
        dateAxis72.setLabelAngle(0.0d);
        java.awt.Font font78 = dateAxis72.getTickLabelFont();
        intervalMarker60.setLabelFont(font78);
        categoryPlot19.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker60);
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = categoryPlot19.getRangeAxisEdge();
        try {
            double double82 = categoryAxis0.getCategoryEnd((int) (byte) 1, 0, rectangle2D10, rectangleEdge81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(sortOrder41);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertNotNull(rectangleEdge81);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.setLowerMargin((double) 6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        java.awt.Shape shape20 = dateAxis15.getUpArrow();
        dateAxis9.setLeftArrow(shape20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis25.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        boolean boolean35 = categoryPlot30.render(graphics2D31, rectangle2D32, (int) (short) 100, plotRenderingInfo34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot30.setFixedDomainAxisSpace(axisSpace36, false);
        double double39 = categoryPlot30.getRangeCrosshairValue();
        dateAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer41);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = null;
        dateAxis19.setTickUnit(dateTickUnit20);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke22);
        java.awt.Shape shape24 = dateAxis19.getUpArrow();
        dateAxis1.setUpArrow(shape24);
        dateAxis1.centerRange(3.0d);
        try {
            dateAxis1.setRange(0.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        categoryAxis0.configure();
        double double6 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.setRangeCrosshairValue((double) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot8.zoomRangeAxes(0.0d, 0.0d, plotRenderingInfo15, point2D16);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            categoryPlot8.addAnnotation(categoryAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        java.awt.Paint paint12 = categoryPlot8.getNoDataMessagePaint();
        java.awt.Color color13 = java.awt.Color.white;
        float[] floatArray18 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray19 = color13.getRGBColorComponents(floatArray18);
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot8.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setTickMarkStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis7.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot12.render(graphics2D13, rectangle2D14, (int) (short) 100, plotRenderingInfo16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot12.setFixedDomainAxisSpace(axisSpace18, false);
        double double21 = categoryPlot12.getRangeCrosshairValue();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot12);
        boolean boolean23 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double3 = dateAxis1.getLowerBound();
        java.awt.Font font4 = dateAxis1.getTickLabelFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setTickMarkStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis8.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = null;
        dateAxis13.setTickUnit(dateTickUnit14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setAxisLineStroke(stroke16);
        java.awt.Shape shape18 = dateAxis13.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        xYPlot20.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot20.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer28 = null;
        xYPlot20.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker27, layer28, true);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        xYPlot20.setDataset(xYDataset31);
        int int33 = xYPlot20.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot20.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint36 = xYPlot20.getRangeCrosshairPaint();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace40 = dateAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) xYPlot20, rectangle2D37, rectangleEdge38, axisSpace39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setDomainAxisLocation((int) (short) 1, axisLocation30);
        boolean boolean32 = categoryPlot28.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot28.addDomainMarker((int) (byte) -1, categoryMarker35, layer36);
        java.util.Collection collection38 = xYPlot14.getDomainMarkers(100, layer36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot14.setRangeAxis(valueAxis39);
        xYPlot14.clearAnnotations();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection38);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setTickMarkStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis7.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot12.render(graphics2D13, rectangle2D14, (int) (short) 100, plotRenderingInfo16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot12.setFixedDomainAxisSpace(axisSpace18, false);
        double double21 = categoryPlot12.getRangeCrosshairValue();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis25.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = null;
        dateAxis30.setTickUnit(dateTickUnit31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke33);
        java.awt.Shape shape35 = dateAxis30.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer36);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        xYPlot37.addChangeListener(plotChangeListener38);
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot37.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis44.setTickMarkStroke(stroke45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = dateAxis44.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer48);
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot49.setDomainAxisLocation((int) (short) 1, axisLocation51);
        xYPlot37.setRangeAxisLocation(axisLocation51);
        categoryPlot12.setRangeAxisLocation(axisLocation51);
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        java.lang.Comparable comparable57 = categoryMarker56.getKey();
        org.jfree.data.xy.XYDataset xYDataset58 = null;
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke61 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis60.setTickMarkStroke(stroke61);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = dateAxis60.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit66 = null;
        dateAxis65.setTickUnit(dateTickUnit66);
        java.awt.Stroke stroke68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis65.setAxisLineStroke(stroke68);
        java.awt.Shape shape70 = dateAxis65.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot(xYDataset58, (org.jfree.chart.axis.ValueAxis) dateAxis60, (org.jfree.chart.axis.ValueAxis) dateAxis65, xYItemRenderer71);
        boolean boolean73 = xYPlot72.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup74 = xYPlot72.getDatasetGroup();
        java.awt.Paint paint75 = xYPlot72.getDomainTickBandPaint();
        xYPlot72.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker80 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.05d);
        org.jfree.chart.util.Layer layer81 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean82 = xYPlot72.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker80, layer81);
        categoryPlot12.addDomainMarker(categoryMarker56, layer81);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + 100.0d + "'", comparable57.equals(100.0d));
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(shape70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNull(datasetGroup74);
        org.junit.Assert.assertNull(paint75);
        org.junit.Assert.assertNotNull(layer81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = null;
        dateAxis19.setTickUnit(dateTickUnit20);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke22);
        java.awt.Shape shape24 = dateAxis19.getUpArrow();
        dateAxis1.setUpArrow(shape24);
        dateAxis1.centerRange(3.0d);
        double double28 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot14.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker22, layer23, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = dateAxis30.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = null;
        dateAxis35.setTickUnit(dateTickUnit36);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setAxisLineStroke(stroke38);
        java.awt.Shape shape40 = dateAxis35.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer41);
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        xYPlot42.addChangeListener(plotChangeListener43);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot42.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis49.setTickMarkStroke(stroke50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = dateAxis49.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis49, categoryItemRenderer53);
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot54.setDomainAxisLocation((int) (short) 1, axisLocation56);
        xYPlot42.setRangeAxisLocation(axisLocation56);
        boolean boolean59 = xYPlot42.isSubplot();
        java.awt.geom.Point2D point2D60 = xYPlot42.getQuadrantOrigin();
        xYPlot14.zoomDomainAxes((double) 1L, plotRenderingInfo27, point2D60, false);
        double double63 = xYPlot14.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(point2D60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        java.awt.Paint paint12 = categoryPlot8.getNoDataMessagePaint();
        java.awt.Color color13 = java.awt.Color.white;
        float[] floatArray18 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray19 = color13.getRGBColorComponents(floatArray18);
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color13);
        double double21 = categoryPlot8.getAnchorValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot8.getRenderer(0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        int int17 = xYPlot14.getWeight();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis22.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer26);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot27.getDomainAxis();
        org.jfree.chart.plot.Plot plot29 = null;
        categoryPlot27.setParent(plot29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot27.getDomainAxisLocation((int) (short) -1);
        xYPlot14.setDomainAxisLocation((int) ' ', axisLocation32, false);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        int int36 = xYPlot14.indexOf(xYDataset35);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNull(categoryAxis28);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setTickMarkStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis17.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = null;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setAxisLineStroke(stroke25);
        java.awt.Shape shape27 = dateAxis22.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        xYPlot29.addChangeListener(plotChangeListener30);
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot29.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis36.setTickMarkStroke(stroke37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = dateAxis36.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer40);
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot41.setDomainAxisLocation((int) (short) 1, axisLocation43);
        xYPlot29.setRangeAxisLocation(axisLocation43);
        boolean boolean46 = xYPlot29.isSubplot();
        java.awt.geom.Point2D point2D47 = xYPlot29.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            categoryPlot8.draw(graphics2D13, rectangle2D14, point2D47, plotState48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        dateAxis1.setLeftArrow(shape12);
        float float14 = dateAxis1.getTickMarkInsideLength();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setTickMarkStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis18.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot23.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot23.getLegendItems();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        try {
            categoryPlot23.setRenderer((int) (byte) -1, categoryItemRenderer28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNotNull(legendItemCollection25);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        boolean boolean19 = categoryPlot8.isDomainGridlinesVisible();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color22 = java.awt.Color.getColor("", color21);
        categoryPlot8.setOutlinePaint((java.awt.Paint) color22);
        int int24 = color22.getBlue();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        dateAxis1.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setTickLabelInsets(rectangleInsets12);
        double double14 = rectangleInsets12.getRight();
        java.lang.Object obj15 = null;
        boolean boolean16 = rectangleInsets12.equals(obj15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke4);
        java.awt.Shape shape6 = dateAxis1.getDownArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setLabelInsets(rectangleInsets11);
        dateAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        categoryPlot8.setOutlineStroke(stroke18);
        java.lang.Object obj21 = categoryPlot8.clone();
        int int22 = categoryPlot8.getWeight();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Paint paint16 = xYPlot14.getDomainTickBandPaint();
        java.awt.Stroke stroke17 = xYPlot14.getRangeGridlineStroke();
        xYPlot14.setDomainCrosshairValue((double) 0, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot14.getRenderer();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYItemRenderer21);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange9, true, false);
        boolean boolean14 = dateAxis1.isPositiveArrowVisible();
        java.awt.Color color16 = java.awt.Color.WHITE;
        java.awt.Color color17 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=0]", color16);
        dateAxis1.setTickMarkPaint((java.awt.Paint) color16);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = dateAxis1.draw(graphics2D19, 100.0d, rectangle2D21, rectangle2D22, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis34.setTickMarkStroke(stroke35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = dateAxis34.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = null;
        dateAxis39.setTickUnit(dateTickUnit40);
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis39.setAxisLineStroke(stroke42);
        java.awt.Shape shape44 = dateAxis39.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis39, xYItemRenderer45);
        org.jfree.chart.event.PlotChangeListener plotChangeListener47 = null;
        xYPlot46.addChangeListener(plotChangeListener47);
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot46.getDomainAxisLocation();
        intervalMarker31.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setTickMarkStroke(stroke56);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = dateAxis55.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = null;
        dateAxis60.setTickUnit(dateTickUnit61);
        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis60.setAxisLineStroke(stroke63);
        java.awt.Shape shape65 = dateAxis60.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) dateAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis60, xYItemRenderer66);
        org.jfree.chart.event.PlotChangeListener plotChangeListener68 = null;
        xYPlot67.addChangeListener(plotChangeListener68);
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot67.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset71 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke75 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis74.setTickMarkStroke(stroke75);
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = dateAxis74.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis72, (org.jfree.chart.axis.ValueAxis) dateAxis74, categoryItemRenderer78);
        org.jfree.chart.axis.AxisLocation axisLocation81 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot79.setDomainAxisLocation((int) (short) 1, axisLocation81);
        xYPlot67.setRangeAxisLocation(axisLocation81);
        boolean boolean84 = xYPlot67.isSubplot();
        java.awt.geom.Point2D point2D85 = xYPlot67.getQuadrantOrigin();
        xYPlot46.zoomRangeAxes((double) (short) 0, plotRenderingInfo52, point2D85);
        org.jfree.chart.plot.PlotState plotState87 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = null;
        try {
            categoryPlot8.draw(graphics2D27, rectangle2D28, point2D85, plotState87, plotRenderingInfo88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertNotNull(axisLocation81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(point2D85);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        dateAxis1.setLeftArrow(shape12);
        float float14 = dateAxis1.getTickMarkInsideLength();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setTickMarkStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis18.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot23.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot23.getLegendItems();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot23);
        java.awt.Paint paint27 = categoryPlot23.getNoDataMessagePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot23.getRenderer((int) (short) 10);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        categoryPlot8.setOutlineStroke(stroke18);
        java.lang.Object obj21 = categoryPlot8.clone();
        java.awt.Paint paint22 = categoryPlot8.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit23, false, false);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit23);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        java.util.TimeZone timeZone33 = dateAxis30.getTimeZone();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27, timeZone33);
        org.jfree.data.general.Dataset dataset36 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset36);
        int int38 = day34.compareTo((java.lang.Object) datasetChangeEvent37);
        java.util.Calendar calendar39 = null;
        try {
            day34.peg(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer8);
        try {
            dateAxis7.setAutoRangeMinimumSize((double) (-1.0f), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setWeight((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot14.zoomRangeAxes((double) 1.0f, plotRenderingInfo21, point2D22, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = xYPlot14.getRenderer();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(xYItemRenderer25);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        xYPlot14.setDomainCrosshairValue((double) (-52), false);
        java.awt.Stroke stroke22 = xYPlot14.getDomainCrosshairStroke();
        boolean boolean23 = xYPlot14.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.lang.Comparable comparable2 = null;
        try {
            java.lang.String str3 = categoryAxis0.getCategoryLabelToolTip(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        java.text.DateFormat dateFormat18 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNull(dateFormat18);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        dateAxis1.setLeftArrow(shape12);
        float float14 = dateAxis1.getTickMarkInsideLength();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setTickMarkStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis18.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot23.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot23.getLegendItems();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot23);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        boolean boolean29 = dateAxis28.isVerticalTickLabels();
        boolean boolean30 = dateAxis28.isNegativeArrowVisible();
        java.awt.Font font31 = dateAxis28.getTickLabelFont();
        dateAxis1.setTickLabelFont(font31);
        dateAxis1.centerRange(100.0d);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        categoryPlot8.configureRangeAxes();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange9, true, false);
        double double14 = dateAxis1.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis16.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        org.jfree.data.time.DateRange dateRange27 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis24.setRangeWithMargins((org.jfree.data.Range) dateRange27);
        dateAxis19.setRangeWithMargins((org.jfree.data.Range) dateRange27, true, false);
        dateAxis16.setRange((org.jfree.data.Range) dateRange27);
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange27);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setTickMarkStroke(stroke36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = dateAxis35.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = null;
        dateAxis40.setTickUnit(dateTickUnit41);
        org.jfree.data.time.DateRange dateRange43 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis40.setRangeWithMargins((org.jfree.data.Range) dateRange43);
        dateAxis35.setRangeWithMargins((org.jfree.data.Range) dateRange43, true, false);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = null;
        dateAxis49.setTickUnit(dateTickUnit50);
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis49.setAxisLineStroke(stroke52);
        java.awt.Shape shape54 = dateAxis49.getDownArrow();
        dateAxis35.setUpArrow(shape54);
        dateAxis1.setUpArrow(shape54);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(dateRange27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(dateRange43);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(shape54);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        boolean boolean2 = dateAxis1.isVerticalTickLabels();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getTickLabelInsets();
        java.lang.String str5 = dateAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        java.awt.Shape shape15 = dateAxis2.getRightArrow();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        xYPlot14.clearDomainMarkers((int) (byte) 10);
        boolean boolean20 = xYPlot14.isSubplot();
        java.awt.Color color21 = java.awt.Color.yellow;
        xYPlot14.setDomainCrosshairPaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        int int24 = xYPlot14.getIndexOf(xYItemRenderer23);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        int int22 = xYPlot17.getRangeAxisCount();
        xYPlot17.clearRangeMarkers();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setTickMarkStroke(stroke27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = dateAxis26.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = null;
        dateAxis31.setTickUnit(dateTickUnit32);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis31.setAxisLineStroke(stroke34);
        java.awt.Shape shape36 = dateAxis31.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer37);
        org.jfree.data.Range range39 = xYPlot17.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.lang.String str22 = xYPlot17.getPlotType();
        xYPlot17.clearRangeAxes();
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        xYPlot17.setDomainTickBandPaint((java.awt.Paint) color24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot17.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot17.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setTickMarkStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis17.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = null;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setAxisLineStroke(stroke25);
        java.awt.Shape shape27 = dateAxis22.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer28);
        boolean boolean30 = xYPlot29.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot29.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer38 = null;
        xYPlot29.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker37, layer38, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = intervalMarker37.getLabelOffsetType();
        boolean boolean42 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker37);
        java.lang.Class class43 = null;
        try {
            java.util.EventListener[] eventListenerArray44 = intervalMarker37.getListeners(class43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        boolean boolean19 = categoryPlot8.isDomainGridlinesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            boolean boolean22 = categoryPlot8.removeAnnotation(categoryAnnotation20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        xYPlot14.setRenderer(xYItemRenderer17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        xYPlot14.datasetChanged(datasetChangeEvent19);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation21 = null;
        try {
            xYPlot14.addAnnotation(xYAnnotation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        float float4 = intervalMarker2.getAlpha();
        intervalMarker2.setLabel("SortOrder.ASCENDING");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.lang.Class class0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis10.setRangeWithMargins((org.jfree.data.Range) dateRange13);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange13, true, false);
        dateAxis2.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        java.util.TimeZone timeZone23 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis20.setTickUnit(dateTickUnit24, false, false);
        java.util.Date date28 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit24);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = dateAxis30.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setTickMarkStroke(stroke34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = dateAxis33.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = null;
        dateAxis38.setTickUnit(dateTickUnit39);
        org.jfree.data.time.DateRange dateRange41 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis38.setRangeWithMargins((org.jfree.data.Range) dateRange41);
        dateAxis33.setRangeWithMargins((org.jfree.data.Range) dateRange41, true, false);
        dateAxis30.setRange((org.jfree.data.Range) dateRange41);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis48.setTickMarkStroke(stroke49);
        java.util.TimeZone timeZone51 = dateAxis48.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis48.setTickUnit(dateTickUnit52, false, false);
        java.util.Date date56 = dateAxis30.calculateLowestVisibleTickValue(dateTickUnit52);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke60 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis59.setTickMarkStroke(stroke60);
        java.util.TimeZone timeZone62 = dateAxis59.getTimeZone();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date56, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date28, timeZone62);
        org.jfree.chart.axis.TickUnitSource tickUnitSource65 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone62);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(dateRange41);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(dateTickUnit52);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(tickUnitSource65);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Paint paint16 = xYPlot14.getDomainTickBandPaint();
        java.awt.Stroke stroke17 = xYPlot14.getRangeGridlineStroke();
        xYPlot14.setDomainCrosshairValue((double) 0, true);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        dateAxis22.setLowerMargin((double) 8);
        dateAxis22.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis22.setTickLabelInsets(rectangleInsets33);
        int int35 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis22);
        try {
            dateAxis22.setRange((double) 1L, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange9, true, false);
        double double14 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = dateAxis1.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            rectangleInsets15.trim(rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        java.util.List list18 = categoryPlot8.getAnnotations();
        java.awt.Paint paint19 = null;
        try {
            categoryPlot8.setDomainGridlinePaint(paint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        xYPlot14.setRenderer(xYItemRenderer17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        xYPlot14.datasetChanged(datasetChangeEvent19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color23 = java.awt.Color.getColor("", color22);
        xYPlot14.setDomainTickBandPaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange9, true, false);
        double double14 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = dateAxis1.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets15.createOutsetRectangle(rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        double double12 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        java.lang.Object obj19 = datasetChangeEvent15.getSource();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertTrue("'" + obj19 + "' != '" + (-1.0f) + "'", obj19.equals((-1.0f)));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot8.setRenderer(11, categoryItemRenderer13, false);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot8.setDataset(categoryDataset16);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        java.lang.Object obj5 = categoryAxis0.clone();
        double double6 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        int int17 = xYPlot14.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot26.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot26.getLegendItems();
        categoryPlot26.clearDomainMarkers();
        double double30 = categoryPlot26.getRangeCrosshairValue();
        java.awt.Color color31 = java.awt.Color.white;
        java.awt.Color color32 = color31.brighter();
        categoryPlot26.setNoDataMessagePaint((java.awt.Paint) color31);
        xYPlot14.setOutlinePaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.plot.Plot plot10 = null;
        categoryPlot8.setParent(plot10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot8.getDomainAxisLocation((int) (short) -1);
        double double14 = categoryPlot8.getAnchorValue();
        java.lang.String str15 = categoryPlot8.getNoDataMessage();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        java.awt.Paint paint12 = categoryPlot8.getNoDataMessagePaint();
        java.awt.Color color13 = java.awt.Color.white;
        float[] floatArray18 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray19 = color13.getRGBColorComponents(floatArray18);
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color13);
        int int21 = color13.getAlpha();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot8.getDataset((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis28.setTickUnit(dateTickUnit29);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setAxisLineStroke(stroke31);
        java.awt.Shape shape33 = dateAxis28.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer34);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = null;
        intervalMarker38.setGradientPaintTransformer(gradientPaintTransformer39);
        boolean boolean41 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        java.awt.Font font42 = intervalMarker38.getLabelFont();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis45.setMaximumCategoryLabelWidthRatio(0.0f);
        int int48 = categoryAxis45.getMaximumCategoryLabelLines();
        double double49 = categoryAxis45.getLowerMargin();
        java.lang.Object obj50 = categoryAxis45.clone();
        categoryAxis45.setMaximumCategoryLabelLines(13);
        categoryPlot8.setDomainAxis(0, categoryAxis45, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.05d + "'", double49 == 0.05d);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            dateAxis1.setRange(date4, date5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot8.addDomainMarker((int) (byte) -1, categoryMarker15, layer16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot26.render(graphics2D27, rectangle2D28, (int) (short) 100, plotRenderingInfo30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot26.setFixedDomainAxisSpace(axisSpace32, false);
        double double35 = categoryPlot26.getRangeCrosshairValue();
        categoryPlot26.configureDomainAxes();
        java.awt.Font font37 = categoryPlot26.getNoDataMessageFont();
        java.awt.Color color38 = java.awt.Color.yellow;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color38);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis41.setTickMarkStroke(stroke42);
        dateAxis41.setLowerMargin((double) 8);
        dateAxis41.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis41.setTickLabelInsets(rectangleInsets52);
        double double54 = rectangleInsets52.getRight();
        categoryPlot26.setAxisOffset(rectangleInsets52);
        boolean boolean56 = categoryMarker15.equals((java.lang.Object) rectangleInsets52);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 10.0d + "'", double54 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color2 = java.awt.Color.GRAY;
        boolean boolean3 = plotOrientation1.equals((java.lang.Object) color2);
        java.awt.Color color4 = java.awt.Color.white;
        float[] floatArray9 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray10 = color4.getRGBColorComponents(floatArray9);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray10, jFreeChart11);
        float[] floatArray13 = color2.getComponents(floatArray10);
        int int14 = color2.getBlue();
        java.awt.Color color15 = java.awt.Color.getColor("DatasetRenderingOrder.FORWARD", color2);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = color1.brighter();
        java.awt.Color color3 = java.awt.Color.white;
        float[] floatArray8 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray9 = color3.getRGBColorComponents(floatArray8);
        float[] floatArray10 = color1.getRGBColorComponents(floatArray8);
        int int11 = color1.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot14.setRenderer(1, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = dateAxis30.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = null;
        dateAxis35.setTickUnit(dateTickUnit36);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setAxisLineStroke(stroke38);
        java.awt.Shape shape40 = dateAxis35.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer41);
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        xYPlot42.addChangeListener(plotChangeListener43);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot42.getDomainAxisLocation();
        intervalMarker27.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis51.setTickMarkStroke(stroke52);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = dateAxis51.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = null;
        dateAxis56.setTickUnit(dateTickUnit57);
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis56.setAxisLineStroke(stroke59);
        java.awt.Shape shape61 = dateAxis56.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis56, xYItemRenderer62);
        org.jfree.chart.event.PlotChangeListener plotChangeListener64 = null;
        xYPlot63.addChangeListener(plotChangeListener64);
        org.jfree.chart.axis.AxisLocation axisLocation66 = xYPlot63.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset67 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = null;
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis70.setTickMarkStroke(stroke71);
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = dateAxis70.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset67, categoryAxis68, (org.jfree.chart.axis.ValueAxis) dateAxis70, categoryItemRenderer74);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot75.setDomainAxisLocation((int) (short) 1, axisLocation77);
        xYPlot63.setRangeAxisLocation(axisLocation77);
        boolean boolean80 = xYPlot63.isSubplot();
        java.awt.geom.Point2D point2D81 = xYPlot63.getQuadrantOrigin();
        xYPlot42.zoomRangeAxes((double) (short) 0, plotRenderingInfo48, point2D81);
        xYPlot14.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo24, point2D81);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(point2D81);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8, false, false);
        double double13 = dateAxis1.getFixedAutoRange();
        boolean boolean14 = dateAxis1.isTickMarksVisible();
        dateAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis20.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setAxisLineStroke(stroke28);
        java.awt.Shape shape30 = dateAxis25.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot32.getDomainAxisLocation();
        categoryPlot8.setRangeAxisLocation(13, axisLocation35, false);
        java.awt.Image image38 = categoryPlot8.getBackgroundImage();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNull(image38);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot14.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot14.setFixedDomainAxisSpace(axisSpace19, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis6.setTickUnit(dateTickUnit7);
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange9, true, false);
        double double14 = dateAxis1.getUpperMargin();
        java.awt.Stroke stroke15 = dateAxis1.getTickMarkStroke();
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = dateAxis1.getTickLabelInsets();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot8.getRowRenderingOrder();
        categoryPlot8.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot8.setFixedRangeAxisSpace(axisSpace20);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder17);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        xYPlot14.setDomainCrosshairValue((double) (-52), false);
        java.awt.Stroke stroke22 = xYPlot14.getDomainCrosshairStroke();
        boolean boolean23 = xYPlot14.isDomainCrosshairLockedOnData();
        int int24 = xYPlot14.getWeight();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer9);
        java.text.DateFormat dateFormat11 = dateAxis5.getDateFormatOverride();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRange((org.jfree.data.Range) dateRange12, true, true);
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange12);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertNotNull(dateRange12);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        java.util.TimeZone timeZone6 = dateAxis3.getTimeZone();
        dateAxis3.setLabelAngle(0.0d);
        java.awt.Font font9 = dateAxis3.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke14);
        java.awt.Shape shape16 = dateAxis11.getUpArrow();
        dateAxis3.setRightArrow(shape16);
        objectList0.set((int) ' ', (java.lang.Object) dateAxis3);
        dateAxis3.setFixedAutoRange(0.2d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        dateAxis1.setRange((double) 100.0f, (double) 255);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot8.addDomainMarker((int) (byte) -1, categoryMarker15, layer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot8.setDomainAxisLocation((int) (byte) 1, axisLocation19, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot14.getRangeAxis((int) (byte) 100);
        java.awt.Paint paint30 = xYPlot14.getRangeCrosshairPaint();
        boolean boolean31 = xYPlot14.isDomainCrosshairLockedOnData();
        xYPlot14.setBackgroundAlpha((float) 15);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot8.getInsets();
        java.awt.Paint paint13 = categoryPlot8.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        java.awt.Shape shape15 = null;
        try {
            dateAxis2.setUpArrow(shape15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        try {
            java.awt.Paint paint22 = xYPlot14.getQuadrantPaint(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (500) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        double double6 = dateAxis1.getLabelAngle();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = null;
        dateAxis8.setTickUnit(dateTickUnit9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setAxisLineStroke(stroke11);
        java.awt.Shape shape13 = dateAxis8.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = dateAxis15.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setTickMarkStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis18.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = null;
        dateAxis23.setTickUnit(dateTickUnit24);
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis23.setRangeWithMargins((org.jfree.data.Range) dateRange26);
        dateAxis18.setRangeWithMargins((org.jfree.data.Range) dateRange26, true, false);
        dateAxis15.setRange((org.jfree.data.Range) dateRange26);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setTickMarkStroke(stroke34);
        java.util.TimeZone timeZone36 = dateAxis33.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis33.setTickUnit(dateTickUnit37, false, false);
        java.util.Date date41 = dateAxis15.calculateLowestVisibleTickValue(dateTickUnit37);
        java.util.Date date42 = dateAxis8.calculateLowestVisibleTickValue(dateTickUnit37);
        dateAxis1.setTickUnit(dateTickUnit37, true, true);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Color color0 = java.awt.Color.GREEN;
        int int1 = color0.getAlpha();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8, false, false);
        java.awt.Paint paint13 = dateAxis1.getLabelPaint();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setTickMarkStroke(stroke16);
        java.util.TimeZone timeZone18 = dateAxis15.getTimeZone();
        dateAxis15.setLabelAngle(0.0d);
        dateAxis15.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition23 = dateAxis15.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis25.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setTickMarkStroke(stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = dateAxis28.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = null;
        dateAxis33.setTickUnit(dateTickUnit34);
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis33.setRangeWithMargins((org.jfree.data.Range) dateRange36);
        dateAxis28.setRangeWithMargins((org.jfree.data.Range) dateRange36, true, false);
        dateAxis25.setRange((org.jfree.data.Range) dateRange36);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = null;
        dateAxis43.setTickUnit(dateTickUnit44);
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis43.setAxisLineStroke(stroke46);
        java.awt.Shape shape48 = dateAxis43.getUpArrow();
        dateAxis25.setUpArrow(shape48);
        dateAxis15.setDownArrow(shape48);
        dateAxis1.setLeftArrow(shape48);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(dateTickMarkPosition23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(shape48);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis10.setRangeWithMargins((org.jfree.data.Range) dateRange13);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange13, true, false);
        dateAxis2.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        java.util.TimeZone timeZone23 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis20.setTickUnit(dateTickUnit24, false, false);
        java.util.Date date28 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit24);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis31.setTickMarkStroke(stroke32);
        java.util.TimeZone timeZone34 = dateAxis31.getTimeZone();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date28, timeZone34);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!", timeZone34);
        try {
            dateAxis36.zoomRange((double) 'a', (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (7.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(timeZone34);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        boolean boolean17 = categoryPlot8.getDrawSharedDomainAxis();
        categoryPlot8.clearDomainMarkers();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot14.getRangeAxisForDataset(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 7 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.setRangeCrosshairValue((double) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot8.zoomRangeAxes(0.0d, 0.0d, plotRenderingInfo15, point2D16);
        categoryPlot8.setDrawSharedDomainAxis(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot8.getRenderer();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNull(categoryItemRenderer20);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot8.getRendererForDataset(categoryDataset10);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot8.getDataset((int) (byte) 10);
        boolean boolean21 = categoryPlot8.isSubplot();
        boolean boolean22 = categoryPlot8.isRangeCrosshairVisible();
        categoryPlot8.setForegroundAlpha((float) 11);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        double double6 = dateAxis1.getLabelAngle();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setTickMarkStroke(stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = dateAxis10.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer14);
        categoryPlot15.mapDatasetToRangeAxis(0, (int) (short) 10);
        double double19 = categoryPlot15.getAnchorValue();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot15);
        java.awt.Paint paint21 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) 0, (double) (-1L), rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        java.awt.Paint paint13 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot8.getDomainAxis((int) ' ');
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        dateAxis1.setLeftArrow(shape12);
        float float14 = dateAxis1.getTickMarkInsideLength();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setTickMarkStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis18.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot23.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot23.getLegendItems();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot23);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setTickMarkStroke(stroke29);
        java.util.TimeZone timeZone31 = dateAxis28.getTimeZone();
        dateAxis28.setLabelAngle(0.0d);
        dateAxis28.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition36 = dateAxis28.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition36);
        java.util.TimeZone timeZone38 = dateAxis1.getTimeZone();
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(dateTickMarkPosition36);
        org.junit.Assert.assertNotNull(timeZone38);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        float float2 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        xYPlot14.setRenderer(xYItemRenderer17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        xYPlot14.datasetChanged(datasetChangeEvent19);
        java.awt.Paint paint21 = xYPlot14.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = intervalMarker21.getLabelAnchor();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot8.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = categoryPlot8.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot14.getRangeAxis((int) (byte) 100);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot14.setOrientation(plotOrientation30);
        java.awt.Paint paint32 = xYPlot14.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setWeight((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot14.zoomRangeAxes((double) 1.0f, plotRenderingInfo21, point2D22, false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        xYPlot14.removeChangeListener(plotChangeListener25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot14.getDomainAxisForDataset(0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(valueAxis28);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        dateAxis1.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setTickLabelInsets(rectangleInsets12);
        dateAxis1.setVerticalTickLabels(false);
        java.awt.Paint paint16 = dateAxis1.getAxisLinePaint();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setTickMarkStroke(stroke19);
        java.util.TimeZone timeZone21 = dateAxis18.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis18.setTickUnit(dateTickUnit22, false, false);
        org.jfree.data.Range range26 = dateAxis18.getDefaultAutoRange();
        dateAxis1.setRange(range26);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double3 = dateAxis1.getLowerBound();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis1.valueToJava2D((double) 6, rectangle2D5, rectangleEdge6);
        boolean boolean8 = dateAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot9.setDomainAxisLocation((int) (short) 1, axisLocation11);
        boolean boolean13 = categoryPlot9.isDomainZoomable();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot9.getRangeMarkers(5, layer15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        categoryPlot9.setDomainAxisLocation(axisLocation34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot9.setDatasetRenderingOrder(datasetRenderingOrder36);
        boolean boolean38 = categoryAnchor0.equals((java.lang.Object) categoryPlot9);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.lang.Comparable comparable2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setTickMarkStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis7.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = null;
        dateAxis12.setTickUnit(dateTickUnit13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis12.setRangeWithMargins((org.jfree.data.Range) dateRange15);
        dateAxis7.setRangeWithMargins((org.jfree.data.Range) dateRange15, true, false);
        dateAxis4.setRange((org.jfree.data.Range) dateRange15);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        java.util.TimeZone timeZone25 = dateAxis22.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis22.setTickUnit(dateTickUnit26, false, false);
        java.util.Date date30 = dateAxis4.calculateLowestVisibleTickValue(dateTickUnit26);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setTickMarkStroke(stroke34);
        java.util.TimeZone timeZone36 = dateAxis33.getTimeZone();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date30, timeZone36);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis40.setTickMarkStroke(stroke41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = dateAxis40.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = null;
        dateAxis45.setTickUnit(dateTickUnit46);
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis45.setAxisLineStroke(stroke48);
        java.awt.Shape shape50 = dateAxis45.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer51);
        boolean boolean53 = xYPlot52.isDomainGridlinesVisible();
        int int54 = day37.compareTo((java.lang.Object) boolean53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis63.setTickMarkStroke(stroke64);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = dateAxis63.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit69 = null;
        dateAxis68.setTickUnit(dateTickUnit69);
        java.awt.Stroke stroke71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis68.setAxisLineStroke(stroke71);
        java.awt.Shape shape73 = dateAxis68.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = null;
        org.jfree.chart.plot.XYPlot xYPlot75 = new org.jfree.chart.plot.XYPlot(xYDataset61, (org.jfree.chart.axis.ValueAxis) dateAxis63, (org.jfree.chart.axis.ValueAxis) dateAxis68, xYItemRenderer74);
        org.jfree.chart.event.PlotChangeListener plotChangeListener76 = null;
        xYPlot75.addChangeListener(plotChangeListener76);
        org.jfree.chart.axis.AxisLocation axisLocation78 = xYPlot75.getDomainAxisLocation();
        intervalMarker60.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot75);
        java.lang.String str80 = xYPlot75.getPlotType();
        xYPlot75.clearRangeAxes();
        java.awt.Color color82 = java.awt.Color.MAGENTA;
        xYPlot75.setDomainTickBandPaint((java.awt.Paint) color82);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = xYPlot75.getDomainAxisEdge();
        try {
            double double85 = categoryAxis0.getCategorySeriesMiddle(comparable2, (java.lang.Comparable) boolean53, categoryDataset55, (double) 0.5f, rectangle2D57, rectangleEdge84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(axisLocation78);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "XY Plot" + "'", str80.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(rectangleEdge84);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit5, false, false);
        java.awt.Stroke stroke9 = dateAxis1.getAxisLineStroke();
        java.awt.Color color10 = java.awt.Color.ORANGE;
        dateAxis1.setLabelPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        categoryPlot8.setOutlineStroke(stroke18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot8.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot8.setRenderer(categoryItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot8.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis22.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis22, categoryItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot27.setDomainAxisLocation((int) (short) 1, axisLocation29);
        boolean boolean31 = categoryPlot27.isDomainZoomable();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot27.getRangeMarkers(5, layer33);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setTickMarkStroke(stroke38);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = dateAxis37.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = null;
        dateAxis42.setTickUnit(dateTickUnit43);
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setAxisLineStroke(stroke45);
        java.awt.Shape shape47 = dateAxis42.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis42, xYItemRenderer48);
        org.jfree.chart.event.PlotChangeListener plotChangeListener50 = null;
        xYPlot49.addChangeListener(plotChangeListener50);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot49.getDomainAxisLocation();
        categoryPlot27.setDomainAxisLocation(axisLocation52);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot27.setDatasetRenderingOrder(datasetRenderingOrder54);
        categoryPlot8.setDatasetRenderingOrder(datasetRenderingOrder54);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        xYPlot14.clearDomainMarkers((int) (byte) 10);
        xYPlot14.setRangeCrosshairValue(0.0d);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation22 = null;
        try {
            xYPlot14.addAnnotation(xYAnnotation22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot14.getDomainAxis((int) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setTickMarkStroke(stroke30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = dateAxis29.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = null;
        dateAxis34.setTickUnit(dateTickUnit35);
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis34.setAxisLineStroke(stroke37);
        java.awt.Shape shape39 = dateAxis34.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer40);
        org.jfree.chart.event.PlotChangeListener plotChangeListener42 = null;
        xYPlot41.addChangeListener(plotChangeListener42);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot41.getDomainAxisLocation();
        intervalMarker26.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis50.setTickMarkStroke(stroke51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = dateAxis50.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit56 = null;
        dateAxis55.setTickUnit(dateTickUnit56);
        java.awt.Stroke stroke58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setAxisLineStroke(stroke58);
        java.awt.Shape shape60 = dateAxis55.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis55, xYItemRenderer61);
        org.jfree.chart.event.PlotChangeListener plotChangeListener63 = null;
        xYPlot62.addChangeListener(plotChangeListener63);
        org.jfree.chart.axis.AxisLocation axisLocation65 = xYPlot62.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset66 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis69.setTickMarkStroke(stroke70);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = dateAxis69.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer73 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset66, categoryAxis67, (org.jfree.chart.axis.ValueAxis) dateAxis69, categoryItemRenderer73);
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot74.setDomainAxisLocation((int) (short) 1, axisLocation76);
        xYPlot62.setRangeAxisLocation(axisLocation76);
        boolean boolean79 = xYPlot62.isSubplot();
        java.awt.geom.Point2D point2D80 = xYPlot62.getQuadrantOrigin();
        xYPlot41.zoomRangeAxes((double) (short) 0, plotRenderingInfo47, point2D80);
        xYPlot14.zoomDomainAxes((double) (-1.0f), (double) 3, plotRenderingInfo23, point2D80);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(point2D80);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        java.util.TimeZone timeZone6 = dateAxis3.getTimeZone();
        dateAxis3.setLabelAngle(0.0d);
        java.awt.Font font9 = dateAxis3.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke14);
        java.awt.Shape shape16 = dateAxis11.getUpArrow();
        dateAxis3.setRightArrow(shape16);
        objectList0.set((int) ' ', (java.lang.Object) dateAxis3);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str20 = datasetRenderingOrder19.toString();
        boolean boolean21 = objectList0.equals((java.lang.Object) str20);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str20.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot8.getDatasetRenderingOrder();
        int int12 = categoryPlot8.getDomainAxisCount();
        categoryPlot8.clearAnnotations();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit23, false, false);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit23);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        long long29 = day28.getMiddleMillisecond();
        java.util.Calendar calendar30 = null;
        try {
            long long31 = day28.getFirstMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 71999999L + "'", long29 == 71999999L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.setRangeGridlinesVisible(false);
        categoryPlot8.setAnchorValue((double) 0.0f);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot26.setDomainAxisLocation((int) (short) 1, axisLocation28);
        xYPlot14.setRangeAxisLocation(axisLocation28);
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot14.getRangeAxis();
        int int32 = xYPlot14.getRangeAxisCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        categoryPlot8.setOutlineStroke(stroke18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot8.getRangeAxisLocation();
        categoryPlot8.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        java.awt.Font font21 = intervalMarker17.getLabelFont();
        java.awt.Stroke stroke22 = intervalMarker17.getStroke();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setTickMarkStroke(stroke27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = dateAxis26.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot31.setDomainAxisLocation((int) (short) 1, axisLocation33);
        boolean boolean35 = categoryPlot31.isDomainZoomable();
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot31.getRangeMarkers(5, layer37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setTickMarkStroke(stroke43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = dateAxis42.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot47.setDomainAxisLocation((int) (short) 1, axisLocation49);
        boolean boolean51 = categoryPlot47.isDomainZoomable();
        org.jfree.chart.util.Layer layer53 = null;
        java.util.Collection collection54 = categoryPlot47.getRangeMarkers(5, layer53);
        org.jfree.chart.util.SortOrder sortOrder55 = categoryPlot47.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        categoryPlot47.setDataset(0, categoryDataset57);
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot47.setRangeCrosshairStroke(stroke59);
        categoryPlot31.setRangeCrosshairStroke(stroke59);
        intervalMarker17.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot31);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertNotNull(sortOrder55);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        categoryPlot8.setOutlineStroke(stroke18);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis25.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot30.setDomainAxisLocation((int) (short) 1, axisLocation32);
        boolean boolean34 = categoryPlot30.isDomainZoomable();
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = categoryPlot30.getRangeMarkers(5, layer36);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis40.setTickMarkStroke(stroke41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = dateAxis40.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = null;
        dateAxis45.setTickUnit(dateTickUnit46);
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis45.setAxisLineStroke(stroke48);
        java.awt.Shape shape50 = dateAxis45.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer51);
        org.jfree.chart.event.PlotChangeListener plotChangeListener53 = null;
        xYPlot52.addChangeListener(plotChangeListener53);
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot52.getDomainAxisLocation();
        categoryPlot30.setDomainAxisLocation(axisLocation55);
        categoryPlot8.setRangeAxisLocation(255, axisLocation55);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        categoryPlot8.setRenderer(6, categoryItemRenderer59, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        java.awt.Stroke stroke18 = null;
        try {
            xYPlot14.setRangeGridlineStroke(stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot8.setRenderer(11, categoryItemRenderer13, false);
        java.lang.String str16 = categoryPlot8.getPlotType();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
//        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
//        categoryAxis1.setCategoryMargin((double) 0.0f);
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        int int12 = day10.getDayOfMonth();
//        java.awt.Paint paint13 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) day10);
//        categoryAxis1.setCategoryLabelPositionOffset((int) (short) 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//        org.junit.Assert.assertNotNull(paint13);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        dateAxis1.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setTickLabelInsets(rectangleInsets12);
        dateAxis1.setVerticalTickLabels(false);
        java.awt.Paint paint16 = dateAxis1.getAxisLinePaint();
        boolean boolean17 = dateAxis1.isAutoRange();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.lang.Class class0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis10.setRangeWithMargins((org.jfree.data.Range) dateRange13);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange13, true, false);
        dateAxis2.setRange((org.jfree.data.Range) dateRange13);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        java.util.TimeZone timeZone23 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis20.setTickUnit(dateTickUnit24, false, false);
        java.util.Date date28 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit24);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date28, timeZone30);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        xYPlot14.clearDomainMarkers((int) (byte) 10);
        boolean boolean20 = xYPlot14.isSubplot();
        java.awt.Color color21 = java.awt.Color.yellow;
        xYPlot14.setDomainCrosshairPaint((java.awt.Paint) color21);
        java.awt.Paint paint23 = xYPlot14.getOutlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot8.getRowRenderingOrder();
        categoryPlot8.setDrawSharedDomainAxis(false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        java.awt.Paint paint22 = intervalMarker21.getLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setTickMarkStroke(stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis25.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = null;
        dateAxis30.setTickUnit(dateTickUnit31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke33);
        java.awt.Shape shape35 = dateAxis30.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer36);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        xYPlot37.addChangeListener(plotChangeListener38);
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot37.getDomainAxisLocation();
        xYPlot37.setWeight((int) (byte) -1);
        java.awt.Paint paint43 = xYPlot37.getDomainGridlinePaint();
        intervalMarker21.setLabelPaint(paint43);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setTickMarkStroke(stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = dateAxis47.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit53 = null;
        dateAxis52.setTickUnit(dateTickUnit53);
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis52.setAxisLineStroke(stroke55);
        java.awt.Shape shape57 = dateAxis52.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis52, xYItemRenderer58);
        org.jfree.chart.event.PlotChangeListener plotChangeListener60 = null;
        xYPlot59.addChangeListener(plotChangeListener60);
        org.jfree.chart.axis.AxisLocation axisLocation62 = xYPlot59.getDomainAxisLocation();
        xYPlot59.setDomainCrosshairVisible(true);
        xYPlot59.setRangeCrosshairValue((double) 11);
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis69.setTickMarkStroke(stroke70);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = dateAxis69.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit75 = null;
        dateAxis74.setTickUnit(dateTickUnit75);
        java.awt.Stroke stroke77 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis74.setAxisLineStroke(stroke77);
        java.awt.Shape shape79 = dateAxis74.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer80 = null;
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot(xYDataset67, (org.jfree.chart.axis.ValueAxis) dateAxis69, (org.jfree.chart.axis.ValueAxis) dateAxis74, xYItemRenderer80);
        org.jfree.chart.event.PlotChangeListener plotChangeListener82 = null;
        xYPlot81.addChangeListener(plotChangeListener82);
        org.jfree.chart.axis.AxisLocation axisLocation84 = xYPlot81.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker88 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer89 = null;
        xYPlot81.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker88, layer89, true);
        org.jfree.chart.util.Layer layer92 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean93 = xYPlot59.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker88, layer92);
        boolean boolean94 = categoryPlot8.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker21, layer92);
        java.lang.String str95 = categoryPlot8.getNoDataMessage();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(layer92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNull(str95);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        java.lang.Comparable comparable2 = categoryMarker1.getKey();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        boolean boolean18 = xYPlot17.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup19 = xYPlot17.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        dateAxis22.setLowerMargin((double) 8);
        dateAxis22.setFixedDimension((double) (byte) 1);
        int int29 = xYPlot17.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis22);
        boolean boolean30 = xYPlot17.isDomainCrosshairVisible();
        categoryMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.awt.Paint paint32 = null;
        xYPlot17.setDomainTickBandPaint(paint32);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0d + "'", comparable2.equals(100.0d));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(datasetGroup19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, 500, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        java.util.TimeZone timeZone5 = dateAxis2.getTimeZone();
        dateAxis2.setLabelAngle(0.0d);
        java.awt.Font font8 = dateAxis2.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        dateAxis2.setRightArrow(shape15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis20.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot25.setDomainAxisLocation((int) (short) 1, axisLocation27);
        boolean boolean29 = categoryPlot25.isDomainZoomable();
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot25.getRangeMarkers(5, layer31);
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot25.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        categoryPlot25.setDataset(0, categoryDataset35);
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot25.setRangeCrosshairStroke(stroke37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis40.setTickMarkStroke(stroke41);
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis40, xYItemRenderer44);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = dateAxis47.getLabelInsets();
        double double49 = dateAxis47.getLowerBound();
        java.awt.Font font50 = dateAxis47.getTickLabelFont();
        xYPlot45.setNoDataMessageFont(font50);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(font50);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot14.getRangeAxis((int) (short) 1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setDomainAxisLocation((int) (short) 1, axisLocation30);
        boolean boolean32 = categoryPlot28.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot28.addDomainMarker((int) (byte) -1, categoryMarker35, layer36);
        java.util.Collection collection38 = xYPlot14.getDomainMarkers(100, layer36);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis41.setTickMarkStroke(stroke42);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = dateAxis41.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = null;
        dateAxis46.setTickUnit(dateTickUnit47);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis46.setAxisLineStroke(stroke49);
        java.awt.Shape shape51 = dateAxis46.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis46, xYItemRenderer52);
        boolean boolean54 = xYPlot53.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = xYPlot53.getRangeAxisEdge(500);
        boolean boolean57 = xYPlot53.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        xYPlot53.setRenderer(1, xYItemRenderer59);
        java.awt.Stroke stroke61 = xYPlot53.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis63.setTickMarkStroke(stroke64);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = dateAxis63.getLabelInsets();
        double double68 = rectangleInsets66.calculateTopOutset((double) '#');
        double double70 = rectangleInsets66.calculateRightInset((double) 'a');
        xYPlot53.setInsets(rectangleInsets66);
        boolean boolean72 = layer36.equals((java.lang.Object) xYPlot53);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 3.0d + "'", double68 == 3.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 3.0d + "'", double70 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        java.awt.Stroke stroke27 = categoryPlot8.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setWeight((int) (byte) -1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        boolean boolean22 = seriesRenderingOrder20.equals((java.lang.Object) '#');
        xYPlot14.setSeriesRenderingOrder(seriesRenderingOrder20);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot14.getLegendItems();
        java.awt.Paint paint25 = null;
        try {
            xYPlot14.setNoDataMessagePaint(paint25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(legendItemCollection24);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        java.awt.Stroke stroke18 = xYPlot14.getDomainCrosshairStroke();
        double double19 = xYPlot14.getDomainCrosshairValue();
        xYPlot14.setBackgroundImageAlignment((int) (short) 10);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot8.zoomRangeAxes((double) (byte) 100, plotRenderingInfo13, point2D14);
        double double16 = categoryPlot8.getAnchorValue();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8, false, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setTickMarkStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis18.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = null;
        dateAxis23.setTickUnit(dateTickUnit24);
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setAxisLineStroke(stroke26);
        java.awt.Shape shape28 = dateAxis23.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        xYPlot30.addChangeListener(plotChangeListener31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot30.getDomainAxisLocation();
        intervalMarker15.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot30);
        java.lang.String str35 = xYPlot30.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot30.getRangeAxis();
        java.awt.Shape shape37 = valueAxis36.getUpArrow();
        dateAxis1.setRightArrow(shape37);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "XY Plot" + "'", str35.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis36);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot14.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker22, layer23, false);
        java.awt.Paint paint26 = intervalMarker22.getPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.LEFT;
        intervalMarker22.setLabelAnchor(rectangleAnchor27);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        double double6 = rectangleInsets4.calculateTopOutset((double) '#');
        java.lang.Object obj7 = null;
        boolean boolean8 = rectangleInsets4.equals(obj7);
        double double9 = rectangleInsets4.getRight();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        dateAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Color color2 = java.awt.Color.getColor("UnitType.RELATIVE", (int) (short) 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis(0, (int) (short) 10);
        double double12 = categoryPlot8.getAnchorValue();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = null;
        dateAxis21.setTickUnit(dateTickUnit22);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setAxisLineStroke(stroke24);
        java.awt.Shape shape26 = dateAxis21.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer27);
        boolean boolean29 = xYPlot28.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup30 = xYPlot28.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot28.getDomainAxisLocation();
        categoryPlot8.setDomainAxisLocation((int) (short) 0, axisLocation31, true);
        java.lang.String str34 = axisLocation31.toString();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str34.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot8.getRowRenderingOrder();
        categoryPlot8.setDrawSharedDomainAxis(false);
        categoryPlot8.setAnchorValue((double) 11, true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder17);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot14.setRenderer(0, xYItemRenderer29, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setDomainCrosshairVisible(true);
        xYPlot14.setRangeCrosshairValue((double) 11);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setTickMarkStroke(stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis24.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = null;
        dateAxis29.setTickUnit(dateTickUnit30);
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setAxisLineStroke(stroke32);
        java.awt.Shape shape34 = dateAxis29.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer35);
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        xYPlot36.addChangeListener(plotChangeListener37);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot36.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer44 = null;
        xYPlot36.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker43, layer44, true);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean48 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker43, layer47);
        boolean boolean49 = xYPlot14.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        java.lang.Object obj25 = intervalMarker21.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = intervalMarker21.getLabelOffset();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        dateAxis1.setLeftArrow(shape12);
        float float14 = dateAxis1.getTickMarkInsideLength();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setTickMarkStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis18.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot23.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot23.getLegendItems();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot23);
        try {
            dateAxis1.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNotNull(legendItemCollection25);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        dateAxis1.setFixedDimension((double) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        java.awt.Shape shape20 = dateAxis15.getUpArrow();
        dateAxis9.setLeftArrow(shape20);
        float float22 = dateAxis9.getTickMarkInsideLength();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis26.setTickMarkStroke(stroke27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = dateAxis26.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, categoryItemRenderer30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot31.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot31.getLegendItems();
        dateAxis9.setPlot((org.jfree.chart.plot.Plot) categoryPlot31);
        java.awt.Paint paint35 = categoryPlot31.getNoDataMessagePaint();
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot31);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(categoryAxis32);
        org.junit.Assert.assertNotNull(legendItemCollection33);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        int int18 = xYPlot14.getWeight();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis22.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setAxisLineStroke(stroke30);
        java.awt.Shape shape32 = dateAxis27.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer33);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        xYPlot34.addChangeListener(plotChangeListener35);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot34.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(10, axisLocation37, false);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        xYPlot14.drawAnnotations(graphics2D40, rectangle2D41, plotRenderingInfo42);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        double double4 = dateAxis1.getLowerMargin();
        boolean boolean5 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot26.setDomainAxisLocation((int) (short) 1, axisLocation28);
        xYPlot14.setRangeAxisLocation(axisLocation28);
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot14.getRangeAxis();
        double double32 = valueAxis31.getFixedAutoRange();
        valueAxis31.setLowerBound((double) 5);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot8.getRowRenderingOrder();
        categoryPlot8.setDrawSharedDomainAxis(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            categoryPlot8.addAnnotation(categoryAnnotation20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder17);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        xYPlot14.setDomainTickBandPaint((java.awt.Paint) color18);
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color18.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintContext25);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        markerChangeEvent21.setChart(jFreeChart22);
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        markerChangeEvent21.setChart(jFreeChart24);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Color color1 = java.awt.Color.BLACK;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis9.setAxisLineStroke(stroke12);
        java.awt.Shape shape14 = dateAxis9.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        xYPlot16.addChangeListener(plotChangeListener17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot16.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setDomainAxisLocation((int) (short) 1, axisLocation30);
        xYPlot16.setRangeAxisLocation(axisLocation30);
        boolean boolean33 = xYPlot16.isSubplot();
        java.awt.Stroke stroke34 = xYPlot16.getDomainGridlineStroke();
        java.awt.Paint paint35 = null;
        java.awt.Stroke stroke36 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(2.0d, (java.awt.Paint) color1, stroke34, paint35, stroke36, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot14.getDomainAxis((int) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis28.setTickUnit(dateTickUnit29);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setAxisLineStroke(stroke31);
        java.awt.Shape shape33 = dateAxis28.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer34);
        boolean boolean36 = xYPlot35.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot35.getRangeAxisEdge(500);
        boolean boolean39 = xYPlot35.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        xYPlot35.setRenderer(1, xYItemRenderer41);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis45.setTickMarkStroke(stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = dateAxis45.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = null;
        dateAxis50.setTickUnit(dateTickUnit51);
        org.jfree.data.time.DateRange dateRange53 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis50.setRangeWithMargins((org.jfree.data.Range) dateRange53);
        dateAxis45.setRangeWithMargins((org.jfree.data.Range) dateRange53, true, false);
        dateAxis45.setVisible(false);
        dateAxis45.setTickLabelsVisible(true);
        xYPlot35.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) dateAxis45);
        xYPlot14.setParent((org.jfree.chart.plot.Plot) xYPlot35);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.data.category.CategoryDataset categoryDataset66 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis69.setTickMarkStroke(stroke70);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = dateAxis69.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer73 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset66, categoryAxis67, (org.jfree.chart.axis.ValueAxis) dateAxis69, categoryItemRenderer73);
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = categoryPlot74.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection76 = categoryPlot74.getLegendItems();
        categoryPlot74.clearDomainMarkers();
        float float78 = categoryPlot74.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset79 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = null;
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke83 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis82.setTickMarkStroke(stroke83);
        org.jfree.chart.util.RectangleInsets rectangleInsets85 = dateAxis82.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer86 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot87 = new org.jfree.chart.plot.CategoryPlot(categoryDataset79, categoryAxis80, (org.jfree.chart.axis.ValueAxis) dateAxis82, categoryItemRenderer86);
        org.jfree.chart.axis.CategoryAxis categoryAxis88 = categoryPlot87.getDomainAxis();
        org.jfree.chart.plot.Plot plot89 = null;
        categoryPlot87.setParent(plot89);
        org.jfree.chart.axis.AxisLocation axisLocation92 = categoryPlot87.getDomainAxisLocation((int) (short) -1);
        categoryPlot74.setDomainAxisLocation(axisLocation92, false);
        java.util.List list95 = categoryPlot74.getAnnotations();
        xYPlot14.drawDomainTickBands(graphics2D64, rectangle2D65, list95);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(dateRange53);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNull(categoryAxis75);
        org.junit.Assert.assertNotNull(legendItemCollection76);
        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 1.0f + "'", float78 == 1.0f);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(rectangleInsets85);
        org.junit.Assert.assertNull(categoryAxis88);
        org.junit.Assert.assertNotNull(axisLocation92);
        org.junit.Assert.assertNotNull(list95);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        xYPlot14.setDomainCrosshairValue((double) (-52), false);
        java.awt.Stroke stroke22 = xYPlot14.getDomainCrosshairStroke();
        boolean boolean23 = xYPlot14.isDomainCrosshairLockedOnData();
        xYPlot14.setDomainCrosshairVisible(true);
        xYPlot14.mapDatasetToDomainAxis(0, 11);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("UnitType.RELATIVE");
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot8.getDataset((int) (byte) 10);
        java.awt.Stroke stroke21 = categoryPlot8.getRangeCrosshairStroke();
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot8.setNoDataMessagePaint(paint22);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.05d);
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker26);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        xYPlot14.setDomainCrosshairValue((double) (-52), false);
        java.awt.Stroke stroke22 = xYPlot14.getDomainCrosshairStroke();
        boolean boolean23 = xYPlot14.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot14.getDomainAxisEdge((int) (byte) 0);
        boolean boolean26 = xYPlot14.isOutlineVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        objectList0.clear();
        java.lang.Object obj5 = objectList0.get((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        dateAxis1.setLabelAngle(0.0d);
        dateAxis1.setNegativeArrowVisible(true);
        dateAxis1.setLowerMargin((double) 1.0f);
        boolean boolean11 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot8.getDataset((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis28.setTickUnit(dateTickUnit29);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setAxisLineStroke(stroke31);
        java.awt.Shape shape33 = dateAxis28.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer34);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = null;
        intervalMarker38.setGradientPaintTransformer(gradientPaintTransformer39);
        boolean boolean41 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        java.awt.Font font42 = intervalMarker38.getLabelFont();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        java.awt.Paint paint44 = intervalMarker38.getLabelPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Color color6 = java.awt.Color.white;
        float[] floatArray11 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray12 = color6.getRGBColorComponents(floatArray11);
        float[] floatArray13 = java.awt.Color.RGBtoHSB((-52), 1, 500, floatArray12);
        float[] floatArray14 = java.awt.Color.RGBtoHSB(3, (int) (short) 10, 1, floatArray12);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setTickMarkStroke(stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot26.getDomainAxis();
        org.jfree.chart.plot.Plot plot28 = null;
        categoryPlot26.setParent(plot28);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot26.getRowRenderingOrder();
        categoryPlot8.setColumnRenderingOrder(sortOrder30);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNotNull(sortOrder30);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = null;
        dateAxis19.setTickUnit(dateTickUnit20);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke22);
        java.awt.Shape shape24 = dateAxis19.getUpArrow();
        dateAxis1.setUpArrow(shape24);
        dateAxis1.centerRange(3.0d);
        dateAxis1.resizeRange((double) (short) 100);
        dateAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=192,g=192,b=0]" + "'", str1.equals("java.awt.Color[r=192,g=192,b=0]"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot14.getRangeAxis(2);
        xYPlot14.mapDatasetToRangeAxis((int) (short) 0, 5);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(valueAxis28);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setTickMarkStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis17.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = null;
        dateAxis22.setTickUnit(dateTickUnit23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setAxisLineStroke(stroke25);
        java.awt.Shape shape27 = dateAxis22.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer28);
        boolean boolean30 = xYPlot29.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot29.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer38 = null;
        xYPlot29.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker37, layer38, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = intervalMarker37.getLabelOffsetType();
        boolean boolean42 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker37);
        xYPlot14.setBackgroundAlpha(0.0f);
        java.awt.Paint paint46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        xYPlot14.setQuadrantPaint(0, paint46);
        java.awt.Font font48 = xYPlot14.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot49 = xYPlot14.getRootPlot();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(plot49);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        double double12 = categoryPlot8.getRangeCrosshairValue();
        java.awt.Color color13 = java.awt.Color.white;
        java.awt.Color color14 = color13.brighter();
        categoryPlot8.setNoDataMessagePaint((java.awt.Paint) color13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot8.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot14.getInsets();
        java.awt.Paint paint19 = xYPlot14.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        xYPlot14.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.05d);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean24 = xYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker22, layer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot14.getRangeAxisLocation();
        xYPlot14.clearDomainMarkers(11);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.plot.CrosshairState crosshairState32 = null;
        boolean boolean33 = xYPlot14.render(graphics2D28, rectangle2D29, (int) (byte) 1, plotRenderingInfo31, crosshairState32);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit23, false, false);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit23);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        java.util.TimeZone timeZone33 = dateAxis30.getTimeZone();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27, timeZone33);
        long long35 = day34.getSerialIndex();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 25569L + "'", long35 == 25569L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=192,g=192,b=0]");
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot14.getRangeAxis(0);
        double double27 = valueAxis26.getLowerMargin();
        valueAxis26.setInverted(false);
        org.jfree.chart.plot.Plot plot30 = valueAxis26.getPlot();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(plot30);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot8.setRenderer(10, categoryItemRenderer13);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        java.awt.Font font21 = intervalMarker17.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis23.getLabelInsets();
        double double25 = dateAxis23.getLowerBound();
        java.awt.Font font26 = dateAxis23.getTickLabelFont();
        intervalMarker17.setLabelFont(font26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis31.setTickMarkStroke(stroke32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = dateAxis31.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, categoryItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot36.setDomainAxisLocation((int) (short) 1, axisLocation38);
        boolean boolean40 = categoryPlot36.isDomainZoomable();
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = categoryPlot36.getRangeMarkers(5, layer42);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier44 = null;
        categoryPlot36.setDrawingSupplier(drawingSupplier44);
        categoryPlot36.configureDomainAxes();
        intervalMarker17.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot36);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer48 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer48);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis52.setTickMarkStroke(stroke53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = dateAxis52.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit58 = null;
        dateAxis57.setTickUnit(dateTickUnit58);
        java.awt.Stroke stroke60 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis57.setAxisLineStroke(stroke60);
        java.awt.Shape shape62 = dateAxis57.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset50, (org.jfree.chart.axis.ValueAxis) dateAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis57, xYItemRenderer63);
        boolean boolean65 = xYPlot64.isDomainGridlinesVisible();
        java.awt.Paint paint66 = xYPlot64.getDomainTickBandPaint();
        java.awt.Stroke stroke67 = xYPlot64.getRangeGridlineStroke();
        xYPlot64.setDomainCrosshairValue((double) 0, true);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke73 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis72.setTickMarkStroke(stroke73);
        dateAxis72.setLowerMargin((double) 8);
        dateAxis72.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis72.setTickLabelInsets(rectangleInsets83);
        int int85 = xYPlot64.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis72);
        intervalMarker17.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot64);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        java.awt.Stroke stroke18 = xYPlot14.getDomainCrosshairStroke();
        double double19 = xYPlot14.getDomainCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot14.setRangeAxisLocation(11, axisLocation21);
        java.lang.String str23 = xYPlot14.getPlotType();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "XY Plot" + "'", str23.equals("XY Plot"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Color color17 = java.awt.Color.white;
        java.awt.Color color18 = color17.brighter();
        xYPlot14.setRangeTickBandPaint((java.awt.Paint) color17);
        xYPlot14.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        dateAxis22.setLowerMargin((double) 8);
        dateAxis22.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis22.setTickLabelInsets(rectangleInsets33);
        java.lang.String str35 = dateAxis22.getLabelToolTip();
        xYPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = null;
        dateAxis8.setTickUnit(dateTickUnit9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setAxisLineStroke(stroke11);
        java.awt.Shape shape13 = dateAxis8.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot15.addChangeListener(plotChangeListener16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot15.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot15.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker22, layer23, true);
        boolean boolean26 = sortOrder0.equals((java.lang.Object) xYPlot15);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot14.setDataset(xYDataset25);
        int int27 = xYPlot14.getRangeAxisCount();
        xYPlot14.setDomainZeroBaselineVisible(true);
        int int30 = xYPlot14.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        dateAxis1.setLowerMargin((double) 8);
        dateAxis1.setFixedDimension((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setTickLabelInsets(rectangleInsets12);
        dateAxis1.setVerticalTickLabels(false);
        java.awt.Paint paint16 = dateAxis1.getAxisLinePaint();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        java.awt.Stroke stroke35 = xYPlot31.getDomainCrosshairStroke();
        dateAxis1.setTickMarkStroke(stroke35);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot14.setRenderer(1, xYItemRenderer20);
        boolean boolean22 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot14.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        java.awt.Paint paint12 = categoryPlot8.getNoDataMessagePaint();
        java.awt.Color color13 = java.awt.Color.white;
        float[] floatArray18 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray19 = color13.getRGBColorComponents(floatArray18);
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color13);
        double double21 = categoryPlot8.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot8.getDomainAxisLocation((-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        categoryPlot8.zoom((double) 10L);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = color0.brighter();
        float[] floatArray2 = null;
        float[] floatArray3 = color0.getColorComponents(floatArray2);
        java.lang.String str4 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str4.equals("java.awt.Color[r=255,g=255,b=255]"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setWeight((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot14.zoomRangeAxes((double) 1.0f, plotRenderingInfo21, point2D22, false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        xYPlot14.removeChangeListener(plotChangeListener25);
        float float27 = xYPlot14.getBackgroundImageAlpha();
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setTickMarkStroke(stroke34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = dateAxis33.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = null;
        dateAxis38.setTickUnit(dateTickUnit39);
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis38.setAxisLineStroke(stroke41);
        java.awt.Shape shape43 = dateAxis38.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer44);
        org.jfree.chart.event.PlotChangeListener plotChangeListener46 = null;
        xYPlot45.addChangeListener(plotChangeListener46);
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot45.getDomainAxisLocation();
        intervalMarker30.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot45);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker30);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(axisLocation48);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = null;
        dateAxis19.setTickUnit(dateTickUnit20);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke22);
        java.awt.Shape shape24 = dateAxis19.getUpArrow();
        dateAxis1.setUpArrow(shape24);
        dateAxis1.centerRange(3.0d);
        dateAxis1.resizeRange((double) (short) 100);
        java.awt.Paint paint30 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.plot.Plot plot31 = dateAxis1.getPlot();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(plot31);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int4 = color3.getAlpha();
        java.awt.Color color5 = java.awt.Color.white;
        java.awt.Color color6 = java.awt.Color.white;
        float[] floatArray11 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray12 = color6.getRGBColorComponents(floatArray11);
        float[] floatArray13 = color5.getRGBColorComponents(floatArray11);
        float[] floatArray14 = color3.getColorComponents(floatArray11);
        float[] floatArray15 = java.awt.Color.RGBtoHSB(0, 255, (int) (byte) -1, floatArray11);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.awt.Color color0 = java.awt.Color.RED;
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = null;
        int int3 = objectList1.indexOf(obj2);
        objectList1.clear();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = color6.brighter();
        java.awt.color.ColorSpace colorSpace8 = color6.getColorSpace();
        objectList1.set(0, (java.lang.Object) colorSpace8);
        java.awt.Color color10 = java.awt.Color.white;
        float[] floatArray15 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray16 = color10.getRGBColorComponents(floatArray15);
        float[] floatArray17 = color0.getComponents(colorSpace8, floatArray15);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        int int4 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        try {
            categoryPlot9.setRangeAxisLocation(axisLocation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot14.getDomainAxis((int) (short) 1);
        java.awt.Stroke stroke21 = xYPlot14.getRangeCrosshairStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot14.getFixedLegendItems();
        float float23 = xYPlot14.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        java.lang.Object obj5 = categoryAxis0.clone();
        categoryAxis0.setMaximumCategoryLabelLines(13);
        java.lang.Comparable comparable8 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setTickMarkStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis8.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = null;
        dateAxis13.setTickUnit(dateTickUnit14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setAxisLineStroke(stroke16);
        java.awt.Shape shape18 = dateAxis13.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = null;
        intervalMarker23.setGradientPaintTransformer(gradientPaintTransformer24);
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Font font27 = intervalMarker23.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis29.getLabelInsets();
        double double31 = dateAxis29.getLowerBound();
        java.awt.Font font32 = dateAxis29.getTickLabelFont();
        intervalMarker23.setLabelFont(font32);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setTickMarkStroke(stroke36);
        java.util.TimeZone timeZone38 = dateAxis35.getTimeZone();
        dateAxis35.setLabelAngle(0.0d);
        java.awt.Font font41 = dateAxis35.getTickLabelFont();
        intervalMarker23.setLabelFont(font41);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "XY Plot", font41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis44.setMaximumCategoryLabelWidthRatio(0.0f);
        int int47 = categoryAxis44.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions48 = categoryAxis44.getCategoryLabelPositions();
        categoryAxis44.setLowerMargin((double) 6);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis51.setMaximumCategoryLabelWidthRatio(0.0f);
        int int54 = categoryAxis51.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions55 = categoryAxis51.getCategoryLabelPositions();
        categoryAxis44.setCategoryLabelPositions(categoryLabelPositions55);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions55);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions48);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions55);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        java.awt.Font font21 = intervalMarker17.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = dateAxis23.getLabelInsets();
        double double25 = dateAxis23.getLowerBound();
        java.awt.Font font26 = dateAxis23.getTickLabelFont();
        intervalMarker17.setLabelFont(font26);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setTickMarkStroke(stroke30);
        java.util.TimeZone timeZone32 = dateAxis29.getTimeZone();
        dateAxis29.setLabelAngle(0.0d);
        java.awt.Font font35 = dateAxis29.getTickLabelFont();
        intervalMarker17.setLabelFont(font35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = intervalMarker17.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets37.createInsetRectangle(rectangle2D38, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis0.setTickMarkInsideLength((float) 7);
        categoryAxis0.setTickMarkOutsideLength((float) 255);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        double double6 = rectangleInsets4.calculateTopOutset((double) '#');
        double double8 = rectangleInsets4.calculateLeftInset((double) (short) -1);
        double double9 = rectangleInsets4.getBottom();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setDomainAxisLocation((int) (short) 1, axisLocation30);
        boolean boolean32 = categoryPlot28.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot28.addDomainMarker((int) (byte) -1, categoryMarker35, layer36);
        java.util.Collection collection38 = xYPlot14.getDomainMarkers(100, layer36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot14.setRangeAxis(valueAxis39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        try {
            xYPlot14.handleClick((int) '4', 8, plotRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection38);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis20.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setAxisLineStroke(stroke28);
        java.awt.Shape shape30 = dateAxis25.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot32.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation35);
        java.awt.Stroke stroke37 = xYPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot14.setDomainAxis((int) (short) 100, valueAxis39);
        xYPlot14.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis45.setTickMarkStroke(stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = dateAxis45.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer49);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        boolean boolean55 = categoryPlot50.render(graphics2D51, rectangle2D52, (int) (short) 100, plotRenderingInfo54);
        org.jfree.chart.axis.AxisSpace axisSpace56 = null;
        categoryPlot50.setFixedDomainAxisSpace(axisSpace56, false);
        double double59 = categoryPlot50.getRangeCrosshairValue();
        categoryPlot50.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset62 = categoryPlot50.getDataset((int) (byte) 10);
        java.awt.Stroke stroke63 = categoryPlot50.getRangeCrosshairStroke();
        xYPlot14.setDomainGridlineStroke(stroke63);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset62);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        xYPlot14.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.05d);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean24 = xYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker22, layer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot14.getRangeAxisLocation();
        double double26 = xYPlot14.getDomainCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.Range range28 = xYPlot14.getDataRange(valueAxis27);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(range28);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        java.awt.Font font19 = categoryPlot8.getNoDataMessageFont();
        java.awt.Color color20 = java.awt.Color.yellow;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color20);
        categoryPlot8.clearRangeMarkers((int) '#');
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis27.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot32.setDomainAxisLocation((int) (short) 1, axisLocation34);
        boolean boolean36 = categoryPlot32.isDomainZoomable();
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = categoryPlot32.getRangeMarkers(5, layer38);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setTickMarkStroke(stroke43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = dateAxis42.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = null;
        dateAxis47.setTickUnit(dateTickUnit48);
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setAxisLineStroke(stroke50);
        java.awt.Shape shape52 = dateAxis47.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer53);
        org.jfree.chart.event.PlotChangeListener plotChangeListener55 = null;
        xYPlot54.addChangeListener(plotChangeListener55);
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot54.getDomainAxisLocation();
        categoryPlot32.setDomainAxisLocation(axisLocation57);
        categoryPlot8.setDomainAxisLocation(axisLocation57);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(axisLocation57);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.lang.String str22 = xYPlot17.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot17.getRangeAxis();
        xYPlot17.setNoDataMessage("UnitType.RELATIVE");
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setTickMarkStroke(stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = dateAxis28.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = null;
        dateAxis33.setTickUnit(dateTickUnit34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setAxisLineStroke(stroke36);
        java.awt.Shape shape38 = dateAxis33.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis33, xYItemRenderer39);
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer44 = null;
        intervalMarker43.setGradientPaintTransformer(gradientPaintTransformer44);
        boolean boolean46 = xYPlot40.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker43);
        java.awt.Font font47 = intervalMarker43.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = dateAxis49.getLabelInsets();
        double double51 = dateAxis49.getLowerBound();
        java.awt.Font font52 = dateAxis49.getTickLabelFont();
        intervalMarker43.setLabelFont(font52);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setTickMarkStroke(stroke56);
        java.util.TimeZone timeZone58 = dateAxis55.getTimeZone();
        dateAxis55.setLabelAngle(0.0d);
        java.awt.Font font61 = dateAxis55.getTickLabelFont();
        intervalMarker43.setLabelFont(font61);
        boolean boolean63 = xYPlot17.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker43);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertNotNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot14.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker22, layer23, false);
        boolean boolean26 = xYPlot14.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot14.getDataset((int) (byte) 1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(xYDataset28);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = intervalMarker2.getLabelOffsetType();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        boolean boolean2 = dateAxis1.isVerticalTickLabels();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getTickLabelInsets();
        dateAxis1.setUpperBound((double) (-1L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit23, false, false);
        java.util.Date date27 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit23);
        java.util.Date date28 = dateAxis1.getMinimumDate();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        dateAxis19.setLowerMargin((double) 8);
        dateAxis19.setFixedDimension((double) (byte) 1);
        int int26 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        xYPlot14.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = null;
        dateAxis30.setTickUnit(dateTickUnit31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setAxisLineStroke(stroke33);
        java.awt.Shape shape35 = dateAxis30.getDownArrow();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace37, false);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setTickMarkStroke(stroke43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = dateAxis42.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = null;
        dateAxis47.setTickUnit(dateTickUnit48);
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setAxisLineStroke(stroke50);
        java.awt.Shape shape52 = dateAxis47.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer53);
        org.jfree.chart.event.PlotChangeListener plotChangeListener55 = null;
        xYPlot54.addChangeListener(plotChangeListener55);
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot54.getDomainAxisLocation();
        xYPlot54.setWeight((int) (byte) -1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        boolean boolean62 = seriesRenderingOrder60.equals((java.lang.Object) '#');
        xYPlot54.setSeriesRenderingOrder(seriesRenderingOrder60);
        xYPlot14.setSeriesRenderingOrder(seriesRenderingOrder60);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot8.getOrientation();
        java.util.List list13 = categoryPlot8.getCategories();
        categoryPlot8.configureRangeAxes();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNull(list13);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot8.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot8.setDataset(0, categoryDataset18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis28.setTickUnit(dateTickUnit29);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setAxisLineStroke(stroke31);
        java.awt.Shape shape33 = dateAxis28.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = dateAxis35.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis38.setTickMarkStroke(stroke39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = dateAxis38.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = null;
        dateAxis43.setTickUnit(dateTickUnit44);
        org.jfree.data.time.DateRange dateRange46 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis43.setRangeWithMargins((org.jfree.data.Range) dateRange46);
        dateAxis38.setRangeWithMargins((org.jfree.data.Range) dateRange46, true, false);
        dateAxis35.setRange((org.jfree.data.Range) dateRange46);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis53.setTickMarkStroke(stroke54);
        java.util.TimeZone timeZone56 = dateAxis53.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis53.setTickUnit(dateTickUnit57, false, false);
        java.util.Date date61 = dateAxis35.calculateLowestVisibleTickValue(dateTickUnit57);
        java.util.Date date62 = dateAxis28.calculateLowestVisibleTickValue(dateTickUnit57);
        java.util.Date date63 = dateAxis23.calculateHighestVisibleTickValue(dateTickUnit57);
        java.awt.Color color64 = java.awt.Color.cyan;
        dateAxis23.setAxisLinePaint((java.awt.Paint) color64);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(dateRange46);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNotNull(dateTickUnit57);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(color64);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        dateAxis19.setLowerMargin((double) 8);
        dateAxis19.setFixedDimension((double) (byte) 1);
        int int26 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        java.lang.Object obj27 = dateAxis19.clone();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        java.util.List list18 = categoryPlot8.getAnnotations();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = null;
        intervalMarker21.setGradientPaintTransformer(gradientPaintTransformer22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis27.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer31);
        categoryPlot32.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot32.setDatasetRenderingOrder(datasetRenderingOrder35);
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        java.lang.Object obj40 = null;
        boolean boolean41 = categoryMarker39.equals(obj40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis45.setTickMarkStroke(stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = dateAxis45.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer49);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        boolean boolean55 = categoryPlot50.render(graphics2D51, rectangle2D52, (int) (short) 100, plotRenderingInfo54);
        org.jfree.chart.axis.AxisSpace axisSpace56 = null;
        categoryPlot50.setFixedDomainAxisSpace(axisSpace56, false);
        double double59 = categoryPlot50.getRangeCrosshairValue();
        categoryPlot50.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset62 = categoryPlot50.getDataset((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation64 = null;
        categoryPlot50.setDomainAxisLocation((int) (byte) 10, axisLocation64);
        org.jfree.chart.util.Layer layer67 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection68 = categoryPlot50.getRangeMarkers(3, layer67);
        boolean boolean69 = categoryPlot32.removeDomainMarker(1, (org.jfree.chart.plot.Marker) categoryMarker39, layer67);
        boolean boolean70 = categoryPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker21, layer67);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset62);
        org.junit.Assert.assertNotNull(layer67);
        org.junit.Assert.assertNull(collection68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setTickMarkStroke(stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis7.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot12.setDomainAxisLocation((int) (short) 1, axisLocation14);
        java.awt.Paint paint16 = categoryPlot12.getNoDataMessagePaint();
        java.awt.Color color17 = java.awt.Color.white;
        float[] floatArray22 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray23 = color17.getRGBColorComponents(floatArray22);
        categoryPlot12.setRangeGridlinePaint((java.awt.Paint) color17);
        dateAxis1.setLabelPaint((java.awt.Paint) color17);
        java.lang.String str26 = dateAxis1.getLabelURL();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setTickMarkStroke(stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = dateAxis28.getLabelInsets();
        java.util.TimeZone timeZone32 = dateAxis28.getTimeZone();
        dateAxis1.setTimeZone(timeZone32);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(timeZone32);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot8.getOrientation();
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = null;
        intervalMarker15.setGradientPaintTransformer(gradientPaintTransformer16);
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(plotOrientation12);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setLowerMargin((double) 6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis9.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis12.setTickMarkStroke(stroke13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = dateAxis12.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        dateAxis17.setTickUnit(dateTickUnit18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis17.setRangeWithMargins((org.jfree.data.Range) dateRange20);
        dateAxis12.setRangeWithMargins((org.jfree.data.Range) dateRange20, true, false);
        dateAxis9.setRange((org.jfree.data.Range) dateRange20);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        java.util.TimeZone timeZone30 = dateAxis27.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis27.setTickUnit(dateTickUnit31, false, false);
        java.util.Date date35 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit31);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis42.setTickMarkStroke(stroke43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = dateAxis42.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = null;
        dateAxis47.setTickUnit(dateTickUnit48);
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setAxisLineStroke(stroke50);
        java.awt.Shape shape52 = dateAxis47.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer53);
        boolean boolean55 = xYPlot54.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        xYPlot54.drawBackgroundImage(graphics2D56, rectangle2D57);
        xYPlot54.setDomainCrosshairValue((double) (-52), false);
        java.awt.Stroke stroke62 = xYPlot54.getDomainCrosshairStroke();
        boolean boolean63 = xYPlot54.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = xYPlot54.getDomainAxisEdge((int) (byte) 0);
        try {
            double double66 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) (-52), (java.lang.Comparable) date35, categoryDataset37, 3.0d, rectangle2D39, rectangleEdge65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        double double12 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        categoryPlot8.axisChanged(axisChangeEvent19);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        java.util.TimeZone timeZone6 = dateAxis3.getTimeZone();
        dateAxis3.setLabelAngle(0.0d);
        java.awt.Font font9 = dateAxis3.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis11.setAxisLineStroke(stroke14);
        java.awt.Shape shape16 = dateAxis11.getUpArrow();
        dateAxis3.setRightArrow(shape16);
        objectList0.set((int) ' ', (java.lang.Object) dateAxis3);
        dateAxis3.setLowerMargin(0.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        intervalMarker21.setLabel("DatasetRenderingOrder.FORWARD");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = intervalMarker21.getLabelOffset();
        org.jfree.chart.util.UnitType unitType28 = rectangleInsets27.getUnitType();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(unitType28);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot14.setRenderer(1, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot14.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setTickMarkStroke(stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis24.getLabelInsets();
        double double29 = rectangleInsets27.calculateTopOutset((double) '#');
        double double31 = rectangleInsets27.calculateRightInset((double) 'a');
        xYPlot14.setInsets(rectangleInsets27);
        double double33 = rectangleInsets27.getRight();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.0d + "'", double31 == 3.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot14.getInsets();
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = xYPlot14.getDomainMarkers(layer19);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(collection20);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        dateAxis19.setLowerMargin((double) 8);
        dateAxis19.setFixedDimension((double) (byte) 1);
        int int26 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        xYPlot14.mapDatasetToDomainAxis(1, (int) '4');
        java.awt.Stroke stroke30 = xYPlot14.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        java.awt.Font font15 = xYPlot14.getNoDataMessageFont();
        java.awt.Color color16 = java.awt.Color.yellow;
        xYPlot14.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        int int19 = xYPlot14.indexOf(xYDataset18);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        xYPlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier20);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.mapDatasetToRangeAxis(0, (int) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot8.zoomDomainAxes((double) 11, plotRenderingInfo13, point2D14, true);
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        try {
            int int20 = categoryPlot8.getRangeAxisIndex(valueAxis19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot9.setDomainAxisLocation((int) (short) 1, axisLocation11);
        java.awt.Paint paint13 = categoryPlot9.getNoDataMessagePaint();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setTickMarkStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis17.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot22.setDomainAxisLocation((int) (short) 1, axisLocation24);
        boolean boolean26 = categoryPlot22.isDomainZoomable();
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot22.getRangeMarkers(5, layer28);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot22.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        categoryPlot22.setDataset(0, categoryDataset32);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot22.setRangeCrosshairStroke(stroke34);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setTickMarkStroke(stroke38);
        categoryPlot22.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        categoryPlot22.configureDomainAxes();
        categoryPlot22.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis46.setTickMarkStroke(stroke47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = dateAxis46.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis51.setAxisLineStroke(stroke54);
        java.awt.Shape shape56 = dateAxis51.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.axis.ValueAxis) dateAxis51, xYItemRenderer57);
        boolean boolean59 = xYPlot58.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = xYPlot58.getRangeAxisEdge(500);
        boolean boolean62 = xYPlot58.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        xYPlot58.setRenderer(1, xYItemRenderer64);
        java.awt.Stroke stroke66 = xYPlot58.getOutlineStroke();
        categoryPlot22.setOutlineStroke(stroke66);
        org.jfree.chart.plot.ValueMarker valueMarker68 = new org.jfree.chart.plot.ValueMarker((double) 1560409200000L, paint13, stroke66);
        double double69 = valueMarker68.getValue();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.5604092E12d + "'", double69 == 1.5604092E12d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot8.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot8.getDomainAxisForDataset(7);
        categoryPlot8.clearRangeAxes();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNull(categoryAxis14);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset14);
        java.lang.Object obj16 = datasetChangeEvent15.getSource();
        org.jfree.data.general.Dataset dataset17 = datasetChangeEvent15.getDataset();
        categoryPlot8.datasetChanged(datasetChangeEvent15);
        java.lang.String str19 = datasetChangeEvent15.toString();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + (-1.0f) + "'", obj16.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=-1.0]" + "'", str19.equals("org.jfree.data.general.DatasetChangeEvent[source=-1.0]"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot14.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker22, layer23, false);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis30.setTickMarkStroke(stroke31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = dateAxis30.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = categoryPlot35.getLegendItems();
        categoryPlot35.clearDomainMarkers();
        double double39 = categoryPlot35.getRangeCrosshairValue();
        org.jfree.data.general.Dataset dataset41 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (-1.0f), dataset41);
        java.lang.Object obj43 = datasetChangeEvent42.getSource();
        org.jfree.data.general.Dataset dataset44 = datasetChangeEvent42.getDataset();
        categoryPlot35.datasetChanged(datasetChangeEvent42);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str47 = axisLocation46.toString();
        categoryPlot35.setDomainAxisLocation(axisLocation46);
        xYPlot14.setDomainAxisLocation((int) (short) 10, axisLocation46);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(legendItemCollection37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + obj43 + "' != '" + (-1.0f) + "'", obj43.equals((-1.0f)));
        org.junit.Assert.assertNull(dataset44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str47.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Paint paint16 = xYPlot14.getDomainTickBandPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot14.markerChanged(markerChangeEvent17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot14.setFixedDomainAxisSpace(axisSpace19);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100.0d);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot8.addDomainMarker((int) (byte) -1, categoryMarker15, layer16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = null;
        dateAxis23.setTickUnit(dateTickUnit24);
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis23.setRangeWithMargins((org.jfree.data.Range) dateRange26);
        dateAxis19.setRange((org.jfree.data.Range) dateRange26, false, false);
        double double31 = dateAxis19.getFixedAutoRange();
        boolean boolean32 = categoryMarker15.equals((java.lang.Object) double31);
        java.lang.Comparable comparable33 = categoryMarker15.getKey();
        java.awt.Stroke stroke34 = categoryMarker15.getStroke();
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        categoryMarker15.setLabelTextAnchor(textAnchor35);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 100.0d + "'", comparable33.equals(100.0d));
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(textAnchor35);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot14.getRangeAxisEdge(500);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot14.getDomainAxis((int) (short) 1);
        java.awt.Stroke stroke21 = xYPlot14.getRangeCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis27.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = null;
        dateAxis32.setTickUnit(dateTickUnit33);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis32.setAxisLineStroke(stroke35);
        java.awt.Shape shape37 = dateAxis32.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer38);
        boolean boolean40 = xYPlot39.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        xYPlot39.drawBackgroundImage(graphics2D41, rectangle2D42);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer48 = null;
        xYPlot39.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker47, layer48, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setTickMarkStroke(stroke56);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = dateAxis55.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = null;
        dateAxis60.setTickUnit(dateTickUnit61);
        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis60.setAxisLineStroke(stroke63);
        java.awt.Shape shape65 = dateAxis60.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) dateAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis60, xYItemRenderer66);
        org.jfree.chart.event.PlotChangeListener plotChangeListener68 = null;
        xYPlot67.addChangeListener(plotChangeListener68);
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot67.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset71 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke75 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis74.setTickMarkStroke(stroke75);
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = dateAxis74.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis72, (org.jfree.chart.axis.ValueAxis) dateAxis74, categoryItemRenderer78);
        org.jfree.chart.axis.AxisLocation axisLocation81 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot79.setDomainAxisLocation((int) (short) 1, axisLocation81);
        xYPlot67.setRangeAxisLocation(axisLocation81);
        boolean boolean84 = xYPlot67.isSubplot();
        java.awt.geom.Point2D point2D85 = xYPlot67.getQuadrantOrigin();
        xYPlot39.zoomDomainAxes((double) 1L, plotRenderingInfo52, point2D85, false);
        try {
            xYPlot14.zoomRangeAxes(6.0d, (double) 3, plotRenderingInfo24, point2D85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (6.0) <= upper (3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertNotNull(axisLocation81);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(point2D85);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateBottomInset(0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        dateAxis1.setLabelAngle(0.0d);
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis12.setTickMarkStroke(stroke13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = dateAxis12.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot17.setDomainAxisLocation((int) (short) 1, axisLocation19);
        boolean boolean21 = categoryPlot17.isDomainZoomable();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot17.getRangeMarkers(5, layer23);
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot17.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        categoryPlot17.setDataset(0, categoryDataset27);
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot17.setRangeCrosshairStroke(stroke29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis32.setTickMarkStroke(stroke33);
        categoryPlot17.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = null;
        dateAxis37.setTickUnit(dateTickUnit38);
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setAxisLineStroke(stroke40);
        java.awt.Shape shape42 = dateAxis37.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = dateAxis44.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis47.setTickMarkStroke(stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = dateAxis47.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit53 = null;
        dateAxis52.setTickUnit(dateTickUnit53);
        org.jfree.data.time.DateRange dateRange55 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis52.setRangeWithMargins((org.jfree.data.Range) dateRange55);
        dateAxis47.setRangeWithMargins((org.jfree.data.Range) dateRange55, true, false);
        dateAxis44.setRange((org.jfree.data.Range) dateRange55);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis62.setTickMarkStroke(stroke63);
        java.util.TimeZone timeZone65 = dateAxis62.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit66 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis62.setTickUnit(dateTickUnit66, false, false);
        java.util.Date date70 = dateAxis44.calculateLowestVisibleTickValue(dateTickUnit66);
        java.util.Date date71 = dateAxis37.calculateLowestVisibleTickValue(dateTickUnit66);
        java.util.Date date72 = dateAxis32.calculateHighestVisibleTickValue(dateTickUnit66);
        java.util.Date date73 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit66);
        java.awt.Stroke stroke74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis1.setTickMarkStroke(stroke74);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(dateRange55);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNotNull(dateTickUnit66);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = null;
        int int3 = objectList1.indexOf(obj2);
        objectList1.clear();
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = color6.brighter();
        java.awt.color.ColorSpace colorSpace8 = color6.getColorSpace();
        objectList1.set(0, (java.lang.Object) colorSpace8);
        java.awt.Color color10 = java.awt.Color.white;
        java.awt.Color color11 = color10.brighter();
        float[] floatArray12 = null;
        float[] floatArray13 = color10.getColorComponents(floatArray12);
        java.awt.Color color14 = java.awt.Color.white;
        java.awt.Color color15 = java.awt.Color.white;
        float[] floatArray20 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray21 = color15.getRGBColorComponents(floatArray20);
        float[] floatArray22 = color14.getRGBColorComponents(floatArray20);
        float[] floatArray23 = color10.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color0.getColorComponents(colorSpace8, floatArray22);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer22 = null;
        xYPlot14.addRangeMarker(1, (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot14.getRangeAxis(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot14.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset29 = xYPlot14.getDataset(128);
        xYPlot14.setForegroundAlpha((float) 500);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(valueAxis26);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNull(xYDataset29);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier16);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = categoryPlot8.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot8.getRowRenderingOrder();
        categoryPlot8.clearDomainMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            categoryPlot8.handleClick(15, (int) '4', plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(sortOrder19);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        dateAxis1.setLabelAngle(0.0d);
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis1.getTickMarkPosition();
        java.util.Date date10 = dateAxis1.getMinimumDate();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier16);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = categoryPlot8.getOrientation();
        java.lang.String str19 = plotOrientation18.toString();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotOrientation.VERTICAL" + "'", str19.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot8.getDomainAxis(255);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis12);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color22);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer24);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabel();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setAxisLineStroke(stroke4);
        java.awt.Shape shape6 = dateAxis1.getDownArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) 3, (double) (byte) 10, (double) (byte) 10);
        dateAxis1.setLabelInsets(rectangleInsets11);
        double double14 = rectangleInsets11.trimHeight((double) (short) 10);
        double double16 = rectangleInsets11.calculateRightOutset(10.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.0d + "'", double16 == 10.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.extendWidth(0.0d);
        double double8 = rectangleInsets4.getRight();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 6.0d + "'", double7 == 6.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        double double6 = rectangleInsets4.calculateTopOutset((double) '#');
        double double8 = rectangleInsets4.calculateLeftInset((double) (short) -1);
        double double9 = rectangleInsets4.getLeft();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange12, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = null;
        dateAxis19.setTickUnit(dateTickUnit20);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setAxisLineStroke(stroke22);
        java.awt.Shape shape24 = dateAxis19.getUpArrow();
        dateAxis1.setUpArrow(shape24);
        dateAxis1.setUpperBound((double) (short) 1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot8.getOrientation();
        categoryPlot8.setWeight((-1));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(plotOrientation12);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot14.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker22, layer23, false);
        java.awt.geom.Point2D point2D26 = xYPlot14.getQuadrantOrigin();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(point2D26);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 10, 100.0d, (double) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        double double5 = intervalMarker2.getEndValue();
        double double6 = intervalMarker2.getStartValue();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot14.zoomDomainAxes((double) (-52), (double) (byte) 100, plotRenderingInfo38, point2D39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        xYPlot14.drawBackgroundImage(graphics2D41, rectangle2D42);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis45 = xYPlot14.getRangeAxisForDataset(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 13 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("XY Plot");
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis5.setTickMarkStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis5.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis10.setTickUnit(dateTickUnit11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setAxisLineStroke(stroke13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot17.getDomainAxisLocation();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot17);
        xYPlot17.setDomainCrosshairLockedOnData(true);
        xYPlot17.clearAnnotations();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setTickMarkStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis8.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = null;
        dateAxis13.setTickUnit(dateTickUnit14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setAxisLineStroke(stroke16);
        java.awt.Shape shape18 = dateAxis13.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = null;
        intervalMarker23.setGradientPaintTransformer(gradientPaintTransformer24);
        boolean boolean26 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        java.awt.Font font27 = intervalMarker23.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis29.getLabelInsets();
        double double31 = dateAxis29.getLowerBound();
        java.awt.Font font32 = dateAxis29.getTickLabelFont();
        intervalMarker23.setLabelFont(font32);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis35.setTickMarkStroke(stroke36);
        java.util.TimeZone timeZone38 = dateAxis35.getTimeZone();
        dateAxis35.setLabelAngle(0.0d);
        java.awt.Font font41 = dateAxis35.getTickLabelFont();
        intervalMarker23.setLabelFont(font41);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "XY Plot", font41);
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(font41);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        double double6 = dateAxis1.getLabelAngle();
        float float7 = dateAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot8.getDataset((int) (byte) 10);
        boolean boolean21 = categoryPlot8.isSubplot();
        boolean boolean22 = categoryPlot8.isRangeCrosshairVisible();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        categoryPlot8.setDataset(categoryDataset23);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        xYPlot14.setDomainZeroBaselineVisible(false);
        java.awt.Stroke stroke23 = xYPlot14.getRangeCrosshairStroke();
        int int24 = xYPlot14.getSeriesCount();
        java.awt.Paint paint25 = xYPlot14.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer18);
        boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot14.setRenderer(5, xYItemRenderer22, false);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setTickMarkStroke(stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = dateAxis28.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = null;
        dateAxis33.setTickUnit(dateTickUnit34);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis33.setAxisLineStroke(stroke36);
        java.awt.Shape shape38 = dateAxis33.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis33, xYItemRenderer39);
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer44 = null;
        intervalMarker43.setGradientPaintTransformer(gradientPaintTransformer44);
        boolean boolean46 = xYPlot40.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker43);
        java.awt.Font font47 = intervalMarker43.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = dateAxis49.getLabelInsets();
        double double51 = dateAxis49.getLowerBound();
        java.awt.Font font52 = dateAxis49.getTickLabelFont();
        intervalMarker43.setLabelFont(font52);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setTickMarkStroke(stroke56);
        java.util.TimeZone timeZone58 = dateAxis55.getTimeZone();
        dateAxis55.setLabelAngle(0.0d);
        java.awt.Font font61 = dateAxis55.getTickLabelFont();
        intervalMarker43.setLabelFont(font61);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = intervalMarker43.getLabelOffset();
        org.jfree.data.category.CategoryDataset categoryDataset64 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = null;
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis67.setTickMarkStroke(stroke68);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = dateAxis67.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset64, categoryAxis65, (org.jfree.chart.axis.ValueAxis) dateAxis67, categoryItemRenderer71);
        java.awt.Graphics2D graphics2D73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        boolean boolean77 = categoryPlot72.render(graphics2D73, rectangle2D74, (int) (short) 100, plotRenderingInfo76);
        org.jfree.chart.axis.AxisSpace axisSpace78 = null;
        categoryPlot72.setFixedDomainAxisSpace(axisSpace78, false);
        double double81 = categoryPlot72.getRangeCrosshairValue();
        categoryPlot72.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset84 = categoryPlot72.getDataset((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation86 = null;
        categoryPlot72.setDomainAxisLocation((int) (byte) 10, axisLocation86);
        org.jfree.chart.util.Layer layer89 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection90 = categoryPlot72.getRangeMarkers(3, layer89);
        boolean boolean92 = xYPlot14.removeRangeMarker((int) '#', (org.jfree.chart.plot.Marker) intervalMarker43, layer89, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset84);
        org.junit.Assert.assertNotNull(layer89);
        org.junit.Assert.assertNull(collection90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        java.lang.String str4 = intervalMarker2.getLabel();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot8.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot8.getDataset((int) (byte) 10);
        java.awt.Color color15 = java.awt.Color.white;
        java.awt.Color color16 = color15.brighter();
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int3 = color2.getAlpha();
        java.awt.Color color4 = java.awt.Color.white;
        java.awt.Color color5 = java.awt.Color.white;
        float[] floatArray10 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray11 = color5.getRGBColorComponents(floatArray10);
        float[] floatArray12 = color4.getRGBColorComponents(floatArray10);
        float[] floatArray13 = color2.getColorComponents(floatArray10);
        float[] floatArray14 = color1.getRGBColorComponents(floatArray10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isDomainZoomable();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot8.getRangeMarkers(5, layer14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setTickMarkStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis18.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = null;
        dateAxis23.setTickUnit(dateTickUnit24);
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setAxisLineStroke(stroke26);
        java.awt.Shape shape28 = dateAxis23.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        xYPlot30.addChangeListener(plotChangeListener31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot30.getDomainAxisLocation();
        categoryPlot8.setDomainAxisLocation(axisLocation33);
        java.awt.Image image35 = null;
        categoryPlot8.setBackgroundImage(image35);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot8.getDataset((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot8.setDomainAxisLocation((int) (byte) 10, axisLocation22);
        categoryPlot8.mapDatasetToDomainAxis(11, (int) (short) -1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis4.setTickMarkStroke(stroke5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis4.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, categoryItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot9.setDomainAxisLocation((int) (short) 1, axisLocation11);
        java.awt.Paint paint13 = categoryPlot9.getNoDataMessagePaint();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis17.setTickMarkStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = dateAxis17.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot22.setDomainAxisLocation((int) (short) 1, axisLocation24);
        boolean boolean26 = categoryPlot22.isDomainZoomable();
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot22.getRangeMarkers(5, layer28);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot22.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        categoryPlot22.setDataset(0, categoryDataset32);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot22.setRangeCrosshairStroke(stroke34);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis37.setTickMarkStroke(stroke38);
        categoryPlot22.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        categoryPlot22.configureDomainAxes();
        categoryPlot22.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis46.setTickMarkStroke(stroke47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = dateAxis46.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis51.setAxisLineStroke(stroke54);
        java.awt.Shape shape56 = dateAxis51.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.axis.ValueAxis) dateAxis51, xYItemRenderer57);
        boolean boolean59 = xYPlot58.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = xYPlot58.getRangeAxisEdge(500);
        boolean boolean62 = xYPlot58.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        xYPlot58.setRenderer(1, xYItemRenderer64);
        java.awt.Stroke stroke66 = xYPlot58.getOutlineStroke();
        categoryPlot22.setOutlineStroke(stroke66);
        org.jfree.chart.plot.ValueMarker valueMarker68 = new org.jfree.chart.plot.ValueMarker((double) 1560409200000L, paint13, stroke66);
        valueMarker68.setValue((double) 8);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        java.lang.Object obj3 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot14.drawBackgroundImage(graphics2D16, rectangle2D17);
        boolean boolean19 = xYPlot14.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis22.setTickMarkStroke(stroke23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = dateAxis22.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setAxisLineStroke(stroke30);
        java.awt.Shape shape32 = dateAxis27.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer33);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer38 = null;
        intervalMarker37.setGradientPaintTransformer(gradientPaintTransformer38);
        boolean boolean40 = xYPlot34.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker37);
        java.awt.Font font41 = intervalMarker37.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = dateAxis43.getLabelInsets();
        double double45 = dateAxis43.getLowerBound();
        java.awt.Font font46 = dateAxis43.getTickLabelFont();
        intervalMarker37.setLabelFont(font46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis51.setTickMarkStroke(stroke52);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = dateAxis51.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, (org.jfree.chart.axis.ValueAxis) dateAxis51, categoryItemRenderer55);
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot56.setDomainAxisLocation((int) (short) 1, axisLocation58);
        boolean boolean60 = categoryPlot56.isDomainZoomable();
        org.jfree.chart.util.Layer layer62 = null;
        java.util.Collection collection63 = categoryPlot56.getRangeMarkers(5, layer62);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier64 = null;
        categoryPlot56.setDrawingSupplier(drawingSupplier64);
        categoryPlot56.configureDomainAxes();
        intervalMarker37.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot56);
        boolean boolean68 = xYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker37);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation69 = null;
        try {
            xYPlot14.addAnnotation(xYAnnotation69, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(collection63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setMaximumCategoryLabelWidthRatio(0.0f);
        int int7 = categoryAxis4.getMaximumCategoryLabelLines();
        double double8 = categoryAxis4.getLowerMargin();
        java.lang.Object obj9 = categoryAxis4.clone();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setTickMarkStroke(stroke14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = dateAxis13.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot18.setDomainAxisLocation((int) (short) 1, axisLocation20);
        boolean boolean22 = categoryPlot18.isSubplot();
        java.util.List list23 = categoryPlot18.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setAxisLineStroke(stroke28);
        categoryPlot18.setOutlineStroke(stroke28);
        boolean boolean31 = categoryAxis4.equals((java.lang.Object) stroke28);
        categoryAxis4.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis40.setTickMarkStroke(stroke41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = dateAxis40.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis40, categoryItemRenderer44);
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot45.setDomainAxisLocation((int) (short) 1, axisLocation47);
        boolean boolean49 = categoryPlot45.isDomainZoomable();
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = categoryPlot45.getRangeMarkers(5, layer51);
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis55.setTickMarkStroke(stroke56);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = dateAxis55.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = null;
        dateAxis60.setTickUnit(dateTickUnit61);
        java.awt.Stroke stroke63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis60.setAxisLineStroke(stroke63);
        java.awt.Shape shape65 = dateAxis60.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) dateAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis60, xYItemRenderer66);
        org.jfree.chart.event.PlotChangeListener plotChangeListener68 = null;
        xYPlot67.addChangeListener(plotChangeListener68);
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot67.getDomainAxisLocation();
        categoryPlot45.setDomainAxisLocation(axisLocation70);
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = categoryPlot45.getDomainAxisEdge(0);
        double double74 = categoryAxis4.getCategoryJava2DCoordinate(categoryAnchor33, (int) (byte) 1, 5, rectangle2D36, rectangleEdge73);
        try {
            double double75 = categoryAxis0.getCategoryEnd((int) (byte) 1, 5, rectangle2D3, rectangleEdge73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        dateAxis1.setLabelAngle(0.0d);
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis1.getTickMarkPosition();
        boolean boolean10 = dateAxis1.isTickLabelsVisible();
        boolean boolean11 = dateAxis1.isAutoRange();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Paint paint17 = xYPlot14.getDomainTickBandPaint();
        xYPlot14.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker(10.0d, 0.05d);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean24 = xYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker22, layer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot14.getRangeAxisLocation();
        double double26 = xYPlot14.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        int int28 = xYPlot14.indexOf(xYDataset27);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        double double17 = categoryPlot8.getRangeCrosshairValue();
        categoryPlot8.configureDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot8.getDataset((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis23.setTickMarkStroke(stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis23.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis28.setTickUnit(dateTickUnit29);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setAxisLineStroke(stroke31);
        java.awt.Shape shape33 = dateAxis28.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer34);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = null;
        intervalMarker38.setGradientPaintTransformer(gradientPaintTransformer39);
        boolean boolean41 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        java.awt.Font font42 = intervalMarker38.getLabelFont();
        categoryPlot8.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        org.jfree.chart.text.TextAnchor textAnchor44 = intervalMarker38.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(textAnchor44);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        categoryAxis0.configure();
        double double6 = categoryAxis0.getCategoryMargin();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis10.setTickMarkStroke(stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = dateAxis10.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot15.setDomainAxisLocation((int) (short) 1, axisLocation17);
        boolean boolean19 = categoryPlot15.isDomainZoomable();
        java.awt.Paint paint20 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setTickMarkStroke(stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis24.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot29.setDomainAxisLocation((int) (short) 1, axisLocation31);
        boolean boolean33 = categoryPlot29.isDomainZoomable();
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = categoryPlot29.getRangeMarkers(5, layer35);
        org.jfree.chart.util.SortOrder sortOrder37 = categoryPlot29.getRowRenderingOrder();
        categoryPlot15.setColumnRenderingOrder(sortOrder37);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(sortOrder37);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        dateAxis1.setLabelAngle(0.0d);
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis11.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis14.setTickMarkStroke(stroke15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = dateAxis14.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = null;
        dateAxis19.setTickUnit(dateTickUnit20);
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis19.setRangeWithMargins((org.jfree.data.Range) dateRange22);
        dateAxis14.setRangeWithMargins((org.jfree.data.Range) dateRange22, true, false);
        dateAxis11.setRange((org.jfree.data.Range) dateRange22);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = null;
        dateAxis29.setTickUnit(dateTickUnit30);
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis29.setAxisLineStroke(stroke32);
        java.awt.Shape shape34 = dateAxis29.getUpArrow();
        dateAxis11.setUpArrow(shape34);
        dateAxis1.setDownArrow(shape34);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis38.setTickMarkStroke(stroke39);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = null;
        dateAxis42.setTickUnit(dateTickUnit43);
        org.jfree.data.time.DateRange dateRange45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis42.setRangeWithMargins((org.jfree.data.Range) dateRange45);
        dateAxis38.setRange((org.jfree.data.Range) dateRange45, false, false);
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange45);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(dateRange45);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 15, (double) (short) -1, (-1.0d), (double) (byte) 10);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 100L, (double) 1L);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        intervalMarker2.setStartValue((double) 100);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis8.setTickMarkStroke(stroke9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis8.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = null;
        dateAxis13.setTickUnit(dateTickUnit14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setAxisLineStroke(stroke16);
        java.awt.Shape shape18 = dateAxis13.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer19);
        boolean boolean21 = xYPlot20.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup22 = xYPlot20.getDatasetGroup();
        java.awt.Paint paint23 = xYPlot20.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = xYPlot20.getInsets();
        intervalMarker2.setLabelOffset(rectangleInsets24);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation((int) (short) 1, axisLocation10);
        boolean boolean12 = categoryPlot8.isSubplot();
        java.util.List list13 = categoryPlot8.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = null;
        dateAxis15.setTickUnit(dateTickUnit16);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis15.setAxisLineStroke(stroke18);
        categoryPlot8.setOutlineStroke(stroke18);
        java.lang.Object obj21 = categoryPlot8.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot8.setRenderer(categoryItemRenderer22, false);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        dateAxis27.setLowerMargin((double) 8);
        dateAxis27.setFixedDimension((double) (byte) 1);
        categoryPlot8.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        categoryPlot8.zoom((double) (byte) 1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot8.getLegendItems();
        categoryPlot8.clearDomainMarkers();
        float float12 = categoryPlot8.getForegroundAlpha();
        java.awt.Image image13 = categoryPlot8.getBackgroundImage();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            categoryPlot8.drawBackground(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNull(image13);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        java.lang.Object obj5 = categoryAxis0.clone();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis9.setTickMarkStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis9.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setDomainAxisLocation((int) (short) 1, axisLocation16);
        boolean boolean18 = categoryPlot14.isSubplot();
        java.util.List list19 = categoryPlot14.getAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = null;
        dateAxis21.setTickUnit(dateTickUnit22);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setAxisLineStroke(stroke24);
        categoryPlot14.setOutlineStroke(stroke24);
        boolean boolean27 = categoryAxis0.equals((java.lang.Object) stroke24);
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis36.setTickMarkStroke(stroke37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = dateAxis36.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis36, categoryItemRenderer40);
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot41.setDomainAxisLocation((int) (short) 1, axisLocation43);
        boolean boolean45 = categoryPlot41.isDomainZoomable();
        org.jfree.chart.util.Layer layer47 = null;
        java.util.Collection collection48 = categoryPlot41.getRangeMarkers(5, layer47);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis51.setTickMarkStroke(stroke52);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = dateAxis51.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = null;
        dateAxis56.setTickUnit(dateTickUnit57);
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis56.setAxisLineStroke(stroke59);
        java.awt.Shape shape61 = dateAxis56.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis51, (org.jfree.chart.axis.ValueAxis) dateAxis56, xYItemRenderer62);
        org.jfree.chart.event.PlotChangeListener plotChangeListener64 = null;
        xYPlot63.addChangeListener(plotChangeListener64);
        org.jfree.chart.axis.AxisLocation axisLocation66 = xYPlot63.getDomainAxisLocation();
        categoryPlot41.setDomainAxisLocation(axisLocation66);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = categoryPlot41.getDomainAxisEdge(0);
        double double70 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor29, (int) (byte) 1, 5, rectangle2D32, rectangleEdge69);
        categoryAxis0.setMaximumCategoryLabelLines(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        dateAxis1.setRange((org.jfree.data.Range) dateRange8, false, false);
        double double13 = dateAxis1.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis16.setTickMarkStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis16.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = null;
        dateAxis21.setTickUnit(dateTickUnit22);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis21.setAxisLineStroke(stroke24);
        java.awt.Shape shape26 = dateAxis21.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer27);
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        xYPlot28.addChangeListener(plotChangeListener29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot28.getDomainAxisLocation();
        xYPlot28.setWeight((int) (byte) -1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder34 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        boolean boolean36 = seriesRenderingOrder34.equals((java.lang.Object) '#');
        xYPlot28.setSeriesRenderingOrder(seriesRenderingOrder34);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = xYPlot28.getLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str40 = datasetRenderingOrder39.toString();
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder39);
        boolean boolean42 = dateAxis1.hasListener((java.util.EventListener) xYPlot28);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(seriesRenderingOrder34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str40.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis1.setTickMarkStroke(stroke2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        dateAxis1.setLabelAngle(0.0d);
        java.awt.Font font7 = dateAxis1.getTickLabelFont();
        double double8 = dateAxis1.getAutoRangeMinimumSize();
        double double9 = dateAxis1.getUpperMargin();
        dateAxis1.setLowerBound((double) 128);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isDomainGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot14.getDatasetGroup();
        java.awt.Color color17 = java.awt.Color.white;
        java.awt.Color color18 = color17.brighter();
        xYPlot14.setRangeTickBandPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot14.getDomainMarkers(layer20);
        java.awt.Paint paint22 = xYPlot14.getRangeTickBandPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot14.notifyListeners(plotChangeEvent23);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        double double5 = categoryAxis0.getUpperMargin();
        int int6 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        org.jfree.chart.plot.Plot plot10 = null;
        categoryPlot8.setParent(plot10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot8.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis19.setTickMarkStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis19.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis24.setTickUnit(dateTickUnit25);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis24.setAxisLineStroke(stroke27);
        java.awt.Shape shape29 = dateAxis24.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot31.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation34);
        java.awt.Paint paint36 = xYPlot14.getRangeCrosshairPaint();
        xYPlot14.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        double double4 = categoryAxis0.getLowerMargin();
        java.lang.Object obj5 = categoryAxis0.clone();
        categoryAxis0.setMaximumCategoryLabelLines(13);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis13.setTickMarkStroke(stroke14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = dateAxis13.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = null;
        dateAxis18.setTickUnit(dateTickUnit19);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setAxisLineStroke(stroke21);
        java.awt.Shape shape23 = dateAxis18.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer24);
        boolean boolean26 = xYPlot25.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot25.getRangeAxisEdge(500);
        try {
            double double29 = categoryAxis0.getCategoryEnd((-52), 7, rectangle2D10, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        dateAxis1.setLeftArrow(shape12);
        float float14 = dateAxis1.getTickMarkInsideLength();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis18.setTickMarkStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis18.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, categoryItemRenderer22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot23.getDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot23.getLegendItems();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot23);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis28.setTickMarkStroke(stroke29);
        java.util.TimeZone timeZone31 = dateAxis28.getTimeZone();
        dateAxis28.setLabelAngle(0.0d);
        dateAxis28.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition36 = dateAxis28.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition36);
        java.util.Date date38 = dateAxis1.getMaximumDate();
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(dateTickMarkPosition36);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis3.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot8.render(graphics2D9, rectangle2D10, (int) (short) 100, plotRenderingInfo12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace14, false);
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot8.getRowRenderingOrder();
        categoryPlot8.setDrawSharedDomainAxis(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot8.getRenderer(0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(categoryItemRenderer21);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis20.setTickMarkStroke(stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis20.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis25.setAxisLineStroke(stroke28);
        java.awt.Shape shape30 = dateAxis25.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot32.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(axisLocation35);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot14.setDataset(255, xYDataset38);
        boolean boolean40 = xYPlot14.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis2.setTickMarkStroke(stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis2.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis7.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis7.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot14.getDomainAxisLocation();
        xYPlot14.setWeight((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot14.zoomRangeAxes((double) 1.0f, plotRenderingInfo21, point2D22, false);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis27.setTickMarkStroke(stroke28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis27.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = null;
        dateAxis32.setTickUnit(dateTickUnit33);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        dateAxis32.setAxisLineStroke(stroke35);
        java.awt.Shape shape37 = dateAxis32.getUpArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer38);
        boolean boolean40 = xYPlot39.isDomainGridlinesVisible();
        java.awt.Paint paint41 = xYPlot39.getDomainTickBandPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = null;
        xYPlot39.markerChanged(markerChangeEvent42);
        xYPlot14.setParent((org.jfree.chart.plot.Plot) xYPlot39);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(paint41);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color1 = java.awt.Color.GRAY;
        boolean boolean2 = plotOrientation0.equals((java.lang.Object) color1);
        java.awt.Color color3 = java.awt.Color.white;
        float[] floatArray8 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray9 = color3.getRGBColorComponents(floatArray8);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray9, jFreeChart10);
        float[] floatArray12 = color1.getComponents(floatArray9);
        org.jfree.chart.util.ObjectList objectList13 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj14 = null;
        int int15 = objectList13.indexOf(obj14);
        objectList13.clear();
        java.awt.Color color18 = java.awt.Color.white;
        java.awt.Color color19 = color18.brighter();
        java.awt.color.ColorSpace colorSpace20 = color18.getColorSpace();
        objectList13.set(0, (java.lang.Object) colorSpace20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int23 = color22.getAlpha();
        java.awt.Color color24 = java.awt.Color.white;
        java.awt.Color color25 = java.awt.Color.white;
        float[] floatArray30 = new float[] { (byte) 100, (-1), (short) 0, 10L };
        float[] floatArray31 = color25.getRGBColorComponents(floatArray30);
        float[] floatArray32 = color24.getRGBColorComponents(floatArray30);
        float[] floatArray33 = color22.getColorComponents(floatArray30);
        float[] floatArray34 = color1.getComponents(colorSpace20, floatArray33);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }
}

