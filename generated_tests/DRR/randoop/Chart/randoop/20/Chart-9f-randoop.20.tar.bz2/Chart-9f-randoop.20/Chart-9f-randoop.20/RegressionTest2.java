import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int8 = spreadsheetDate1.getMonth();
        java.util.Date date9 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate11.getFollowingDayOfWeek(7);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate21 = null;
        try {
            boolean boolean22 = spreadsheetDate11.isOnOrAfter(serialDate21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-459), (int) 'a', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        int int17 = day0.compareTo((java.lang.Object) timeSeriesDataItem16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 1577865599999L);
        timeSeriesDataItem19.setValue((java.lang.Number) 43626L);
        java.lang.Number number22 = timeSeriesDataItem19.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61851744000000L) + "'", long15 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 43626L + "'", number22.equals(43626L));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.lang.Number number11 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, 0.0d);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class27);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        int int30 = timeSeries28.getItemCount();
        java.lang.Class class31 = timeSeries28.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 1);
        int int34 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
        int int36 = year18.compareTo((java.lang.Object) regularTimePeriod35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year18);
        java.util.Calendar calendar38 = null;
        try {
            year18.peg(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10L + "'", number11.equals(10L));
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(class31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 10L);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int31 = month30.getMonth();
        int int32 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (-1.0d));
        long long35 = month30.getSerialIndex();
        long long36 = month30.getSerialIndex();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 121L + "'", long35 == 121L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 121L + "'", long36 == 121L);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        long long6 = year5.getFirstMillisecond();
        int int7 = year5.getYear();
        long long8 = year5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getYear();
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        boolean boolean10 = spreadsheetDate3.isOn(serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate12.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean25 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int43 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        int int45 = day44.getYear();
        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
        boolean boolean47 = spreadsheetDate40.isOn(serialDate46);
        boolean boolean48 = spreadsheetDate38.isOnOrAfter(serialDate46);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate46);
        boolean boolean50 = spreadsheetDate32.isAfter(serialDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int55 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate54);
        int int56 = spreadsheetDate52.getYYYY();
        boolean boolean57 = spreadsheetDate32.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int62 = spreadsheetDate59.compare((org.jfree.data.time.SerialDate) spreadsheetDate61);
        int int63 = spreadsheetDate59.getYYYY();
        int int64 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate59);
        int int65 = spreadsheetDate59.getDayOfWeek();
        int int66 = spreadsheetDate59.getDayOfWeek();
        boolean boolean67 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate59);
        boolean boolean69 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate59, 0);
        boolean boolean70 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate71 = null;
        try {
            boolean boolean72 = spreadsheetDate1.isAfter(serialDate71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1900 + "'", int56 == 1900);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1900 + "'", int63 == 1900);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 3 + "'", int65 == 3);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 3 + "'", int66 == 3);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        int int7 = timeSeries5.getItemCount();
        java.lang.Class<?> wildcardClass8 = timeSeries5.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long12 = fixedMillisecond11.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond11.getLastMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond11.getTime();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond11.getFirstMillisecond(calendar16);
        long long18 = fixedMillisecond11.getFirstMillisecond();
        long long19 = fixedMillisecond11.getLastMillisecond();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class24);
        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
        int int27 = timeSeries25.getItemCount();
        java.lang.Class<?> wildcardClass28 = timeSeries25.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond11, (java.lang.Class) wildcardClass28);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(class30);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-43574));
        int int14 = timeSeries4.getItemCount();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class13);
        timeSeries14.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long20 = month19.getFirstMillisecond();
        long long21 = month19.getLastMillisecond();
        java.lang.Number number22 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.String str23 = timeSeries14.getRangeDescription();
        boolean boolean24 = fixedMillisecond1.equals((java.lang.Object) timeSeries14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61851744000000L) + "'", long20 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61849065600001L) + "'", long21 == (-61849065600001L));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Preceding" + "'", str23.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str6 = spreadsheetDate2.getDescription();
        java.lang.String str7 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.String str13 = spreadsheetDate9.getDescription();
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int23 = spreadsheetDate18.getYYYY();
        boolean boolean24 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "20-February-1900" + "'", str7.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long10 = fixedMillisecond9.getMiddleMillisecond();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getLastMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond9.getTime();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond9.getFirstMillisecond(calendar14);
        long long16 = fixedMillisecond9.getFirstMillisecond();
        long long17 = fixedMillisecond9.getMiddleMillisecond();
        java.util.Date date18 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        java.lang.String str20 = month19.toString();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class25);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        int int28 = timeSeries26.getItemCount();
        java.lang.Class<?> wildcardClass29 = timeSeries26.getClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19, (java.lang.Class) wildcardClass29);
        java.util.Date date32 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long35 = fixedMillisecond34.getMiddleMillisecond();
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond34.getLastMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond34.getTime();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date32, timeZone39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date18, timeZone39);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class46);
        java.lang.Class class48 = timeSeries47.getTimePeriodClass();
        timeSeries47.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries47.addPropertyChangeListener(propertyChangeListener51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
        java.lang.Number number55 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day53);
        java.util.Date date56 = day53.getStart();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        int int58 = day57.getYear();
        org.jfree.data.time.SerialDate serialDate59 = day57.getSerialDate();
        java.util.Date date60 = day57.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond(date60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(date60, timeZone62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date56, timeZone62);
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date18, timeZone62);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date5, timeZone62);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date5);
        java.lang.Class class71 = null;
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class71);
        java.lang.Class class73 = timeSeries72.getTimePeriodClass();
        timeSeries72.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timeSeries72.addPropertyChangeListener(propertyChangeListener76);
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day78.previous();
        java.lang.Number number80 = timeSeries72.getValue((org.jfree.data.time.RegularTimePeriod) day78);
        java.util.Date date81 = day78.getStart();
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
        int int83 = day82.getYear();
        org.jfree.data.time.SerialDate serialDate84 = day82.getSerialDate();
        java.util.Date date85 = day82.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond(date85);
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month88 = new org.jfree.data.time.Month(date85, timeZone87);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date81, timeZone87);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date81);
        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date81, timeZone91);
        org.jfree.data.time.Month month93 = new org.jfree.data.time.Month(date5, timeZone91);
        java.lang.String str94 = month93.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNull(class48);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNull(number55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(class73);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNull(number80);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 2019 + "'", int83 == 2019);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNotNull(timeZone91);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "December 1969" + "'", str94.equals("December 1969"));
    }
}

