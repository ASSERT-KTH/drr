import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ', (int) (byte) 1, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        try {
            org.jfree.data.time.Year year3 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Preceding");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        try {
            java.lang.Number number6 = timeSeries4.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SerialDate serialDate4 = null;
        try {
            boolean boolean5 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        try {
            timeSeries4.add(regularTimePeriod9, (double) (short) 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year6.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries4.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Preceding");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        int int6 = timeSeries4.getItemCount();
        try {
            timeSeries4.delete(4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2958465, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        java.util.Calendar calendar10 = null;
        try {
            year6.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year5);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class11);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 10L);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        int int19 = day18.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) (byte) 10);
        try {
            timeSeries4.add(timeSeriesDataItem21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.lang.String str9 = year8.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 10);
//        boolean boolean16 = fixedMillisecond1.equals((java.lang.Object) day12);
//        int int17 = day12.getDayOfMonth();
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries4.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        try {
            timeSeries4.add(regularTimePeriod11, (java.lang.Number) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.TimeSeries timeSeries13 = null;
        try {
            java.util.Collection collection14 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str13 = timeSeries4.getRangeDescription();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getYear();
        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
        java.util.Date date17 = day14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Preceding" + "'", str13.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(date17);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate3.getPreviousDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getYear();
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        boolean boolean10 = spreadsheetDate3.isOn(serialDate9);
        boolean boolean11 = spreadsheetDate1.isOnOrAfter(serialDate9);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 10L);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        int int23 = day22.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) (byte) 10);
        try {
            int int26 = spreadsheetDate1.compareTo((java.lang.Object) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Byte cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getYear();
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        boolean boolean10 = spreadsheetDate3.isOn(serialDate9);
        boolean boolean11 = spreadsheetDate1.isOnOrAfter(serialDate9);
        try {
            org.jfree.data.time.SerialDate serialDate13 = serialDate9.getFollowingDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        int int6 = timeSeries4.getItemCount();
        int int7 = timeSeries4.getItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            java.lang.Number number9 = timeSeries4.getValue(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries2.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 1);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.String str23 = year22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 10L);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 10);
        boolean boolean30 = fixedMillisecond15.equals((java.lang.Object) day26);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int6 = spreadsheetDate3.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        int int6 = timeSeries4.getItemCount();
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        try {
            java.lang.Class<?> wildcardClass13 = number12.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month12.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        try {
//            timeSeries3.delete(6, 2958465);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
//        java.lang.String str14 = day10.toString();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day10.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        timeSeries16.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        java.lang.Number number24 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day22);
        int int25 = year7.compareTo((java.lang.Object) timeSeries16);
        try {
            org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(20, year7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("10-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long13 = month12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
        long long15 = month12.getLastMillisecond();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61851744000000L) + "'", long13 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61849065600001L) + "'", long15 == (-61849065600001L));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str13 = timeSeries4.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year7);
        long long13 = year7.getFirstMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = year7.equals(obj14);
        long long16 = year7.getLastMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year7.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate3.getFollowingDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int7 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        int int9 = day8.getYear();
        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
        boolean boolean11 = spreadsheetDate4.isOn(serialDate10);
        boolean boolean12 = spreadsheetDate2.isOnOrAfter(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate15 = serialDate13.getFollowingDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day7.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
        int int14 = day10.getYear();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day10.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#', (-1), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        timeSeries4.setMaximumItemAge((long) 2019);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries4.createCopy(1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
        int int14 = timeSeries4.getItemCount();
        java.util.Collection collection15 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(collection15);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
//        java.lang.String str14 = day10.toString();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class18);
//        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        java.lang.String str22 = year21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 10L);
//        long long25 = year21.getLastMillisecond();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class29);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        timeSeries30.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries30.addPropertyChangeListener(propertyChangeListener34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        java.lang.Number number38 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) day36);
//        int int39 = year21.compareTo((java.lang.Object) timeSeries30);
//        int int40 = day10.compareTo((java.lang.Object) int39);
//        long long41 = day10.getFirstMillisecond();
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNull(class20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(number38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560150000000L + "'", long41 == 1560150000000L);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
//        int int14 = timeSeries4.getItemCount();
//        timeSeries4.setRangeDescription("10-June-2019");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.previous();
//        long long24 = month22.getFirstMillisecond();
//        java.lang.String str25 = month22.toString();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.createCopy(regularTimePeriod19, (org.jfree.data.time.RegularTimePeriod) month22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61851744000000L) + "'", long24 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "January 10" + "'", str25.equals("January 10"));
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        try {
            timeSeries4.update(9, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        timeSeries17.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        long long24 = month22.getLastMillisecond();
        java.lang.Number number25 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        java.lang.String str26 = timeSeries17.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries4.addAndOrUpdate(timeSeries17);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries27.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries27);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int8 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int10 = day9.getYear();
        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
        boolean boolean12 = spreadsheetDate5.isOn(serialDate11);
        boolean boolean13 = spreadsheetDate3.isOnOrAfter(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate11);
        try {
            org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '4', serialDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 10L);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        int int24 = day23.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) (byte) 10);
        int int27 = day23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day23.previous();
        int int29 = day23.getYear();
        int int30 = day23.getYear();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.Comparable comparable0 = null;
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class9);
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        int int12 = timeSeries10.getItemCount();
        java.lang.Class<?> wildcardClass13 = timeSeries10.getClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "org.jfree.data.time.TimePeriodFormatException: ", "", (java.lang.Class) wildcardClass13);
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries(comparable0, "Nearest", "", (java.lang.Class) wildcardClass13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class11);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 10L);
        long long18 = year14.getLastMillisecond();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class22);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        timeSeries23.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
        java.lang.Number number31 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) day29);
        int int32 = year14.compareTo((java.lang.Object) timeSeries23);
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean14 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = day20.getYear();
        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
        boolean boolean23 = spreadsheetDate16.isOn(serialDate22);
        boolean boolean24 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        try {
            org.jfree.data.time.SerialDate serialDate26 = spreadsheetDate16.getNearestDayOfWeek(52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) 0, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str6 = spreadsheetDate2.getDescription();
        java.lang.String str7 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.String str13 = spreadsheetDate9.getDescription();
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int23 = spreadsheetDate18.getYYYY();
        boolean boolean24 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((-460), (org.jfree.data.time.SerialDate) spreadsheetDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "20-February-1900" + "'", str7.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900, class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
        int int14 = day10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day10.previous();
        int int16 = day10.getYear();
        int int17 = day10.getMonth();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        timeSeries11.clear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 10L);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        int int24 = day23.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) (byte) 10);
        try {
            timeSeries11.add(timeSeriesDataItem26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        int int9 = timeSeries7.getItemCount();
        java.lang.Class<?> wildcardClass10 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass10);
        try {
            timeSeries12.delete(3, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        timeSeries17.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        long long24 = month22.getLastMillisecond();
        java.lang.Number number25 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        java.lang.String str26 = timeSeries17.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries4.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries4.addOrUpdate(regularTimePeriod29, (java.lang.Number) 1L);
        try {
            java.lang.Number number33 = timeSeries4.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        boolean boolean7 = timeSeries4.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            timeSeries4.update(regularTimePeriod8, (java.lang.Number) (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = day13.getYear();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        boolean boolean16 = spreadsheetDate9.isOn(serialDate15);
        boolean boolean17 = spreadsheetDate7.isOnOrAfter(serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate15);
        boolean boolean19 = spreadsheetDate1.isAfter(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate21.getYYYY();
        boolean boolean26 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class30);
        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
        timeSeries31.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.previous();
        java.lang.Number number39 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class43);
        timeSeries44.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long50 = month49.getFirstMillisecond();
        long long51 = month49.getLastMillisecond();
        java.lang.Number number52 = timeSeries44.getValue((org.jfree.data.time.RegularTimePeriod) month49);
        java.lang.String str53 = timeSeries44.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries31.addAndOrUpdate(timeSeries44);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries31.addOrUpdate(regularTimePeriod56, (java.lang.Number) 1L);
        boolean boolean59 = spreadsheetDate1.equals((java.lang.Object) 1L);
        org.jfree.data.time.SerialDate serialDate60 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int65 = spreadsheetDate62.compare((org.jfree.data.time.SerialDate) spreadsheetDate64);
        java.lang.String str66 = spreadsheetDate62.getDescription();
        java.lang.String str67 = spreadsheetDate62.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int72 = spreadsheetDate69.compare((org.jfree.data.time.SerialDate) spreadsheetDate71);
        java.lang.String str73 = spreadsheetDate69.getDescription();
        boolean boolean74 = spreadsheetDate62.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate69);
        try {
            boolean boolean75 = spreadsheetDate1.isInRange(serialDate60, (org.jfree.data.time.SerialDate) spreadsheetDate69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61851744000000L) + "'", long50 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61849065600001L) + "'", long51 == (-61849065600001L));
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "20-February-1900" + "'", str67.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        java.util.Calendar calendar12 = null;
        try {
            year7.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 2147483647, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate6 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getYear();
        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
        boolean boolean18 = spreadsheetDate11.isOn(serialDate17);
        boolean boolean19 = spreadsheetDate9.isOnOrAfter(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate17);
        try {
            boolean boolean21 = spreadsheetDate3.isInRange(serialDate6, serialDate20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        long long10 = year6.getLastMillisecond();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class14);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        timeSeries15.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        java.lang.Number number23 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day21);
        int int24 = year6.compareTo((java.lang.Object) timeSeries15);
        boolean boolean26 = year6.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year6.previous();
        java.util.Calendar calendar28 = null;
        try {
            year6.peg(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        int int9 = timeSeries7.getItemCount();
        java.lang.Class<?> wildcardClass10 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass10);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month0.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2147483647);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(20, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        long long12 = year8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(4, year8);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year8.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            java.lang.Number number11 = timeSeries4.getValue(regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(4, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 10.0d);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        java.lang.String str15 = timeSeries4.getDomainDescription();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        timeSeries20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
        java.lang.Number number28 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int34 = spreadsheetDate31.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean35 = day26.equals((java.lang.Object) int34);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        long long8 = fixedMillisecond1.getFirstMillisecond();
        long long9 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getMiddleMillisecond(calendar10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setRangeDescription("");
//        timeSeries4.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        int int12 = day10.getDayOfMonth();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
//        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
//        timeSeries18.setRangeDescription("");
//        boolean boolean22 = day10.equals((java.lang.Object) "");
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNull(class19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesException3);
        java.lang.Throwable[] throwableArray6 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        try {
            org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = day13.getYear();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        boolean boolean16 = spreadsheetDate9.isOn(serialDate15);
        boolean boolean17 = spreadsheetDate7.isOnOrAfter(serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate15);
        boolean boolean19 = spreadsheetDate1.isAfter(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate21.getYYYY();
        boolean boolean26 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class30);
        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
        timeSeries31.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.previous();
        java.lang.Number number39 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class43);
        timeSeries44.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long50 = month49.getFirstMillisecond();
        long long51 = month49.getLastMillisecond();
        java.lang.Number number52 = timeSeries44.getValue((org.jfree.data.time.RegularTimePeriod) month49);
        java.lang.String str53 = timeSeries44.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries31.addAndOrUpdate(timeSeries44);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries31.addOrUpdate(regularTimePeriod56, (java.lang.Number) 1L);
        boolean boolean59 = spreadsheetDate1.equals((java.lang.Object) 1L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int67 = spreadsheetDate64.compare((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
        int int69 = day68.getYear();
        org.jfree.data.time.SerialDate serialDate70 = day68.getSerialDate();
        boolean boolean71 = spreadsheetDate64.isOn(serialDate70);
        boolean boolean72 = spreadsheetDate62.isOnOrAfter(serialDate70);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate70);
        boolean boolean74 = spreadsheetDate1.isOnOrAfter(serialDate70);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61851744000000L) + "'", long50 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61849065600001L) + "'", long51 == (-61849065600001L));
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2019 + "'", int69 == 2019);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(3, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "March" + "'", str2.equals("March"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.getDescription();
        java.lang.String str6 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.getDescription();
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int22 = spreadsheetDate17.getYYYY();
        boolean boolean23 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class27);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.lang.String str31 = year30.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 10L);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        int int35 = day34.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) (byte) 10);
        try {
            int int38 = spreadsheetDate17.compareTo((java.lang.Object) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Byte cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20-February-1900" + "'", str6.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int3 = month2.getYearValue();
        try {
            org.jfree.data.time.Year year4 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("20-February-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4', (int) (short) -1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("10-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        timeSeries17.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        long long24 = month22.getLastMillisecond();
        java.lang.Number number25 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        java.lang.String str26 = timeSeries17.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries4.addAndOrUpdate(timeSeries17);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class31);
        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.lang.String str35 = year34.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 10L);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        int int39 = day38.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) (byte) 10);
        timeSeries27.setKey((java.lang.Comparable) timeSeriesDataItem41);
        java.util.Collection collection43 = timeSeries27.getTimePeriods();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(class33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(collection43);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean15 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        int int22 = day21.getYear();
        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
        boolean boolean24 = spreadsheetDate17.isOn(serialDate23);
        boolean boolean25 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate2.getFollowingDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8, (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getLastMillisecond();
        int int5 = month2.getMonth();
        try {
            org.jfree.data.time.Year year6 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int6 = spreadsheetDate3.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        long long12 = year8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(4, year8);
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(0, year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        timeSeries17.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        long long24 = month22.getLastMillisecond();
        java.lang.Number number25 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        java.lang.String str26 = timeSeries17.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries4.addAndOrUpdate(timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries17.removeChangeListener(seriesChangeListener28);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries17.removeChangeListener(seriesChangeListener30);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class36);
        java.lang.Class class38 = timeSeries37.getTimePeriodClass();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.lang.String str40 = year39.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 10L);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (byte) 1, year39);
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year39, (double) 9223372036854775807L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(class38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019" + "'", str40.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem42);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = day13.getYear();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        boolean boolean16 = spreadsheetDate9.isOn(serialDate15);
        boolean boolean17 = spreadsheetDate7.isOnOrAfter(serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate15);
        boolean boolean19 = spreadsheetDate1.isAfter(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate21.getYYYY();
        boolean boolean26 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class31);
        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.lang.String str35 = year34.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 10L);
        long long38 = year34.getLastMillisecond();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(4, year34);
        try {
            int int40 = spreadsheetDate1.compareTo((java.lang.Object) month39);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Month cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(class33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 12);
        timeSeries11.setNotify(true);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class25);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.lang.String str29 = year28.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 10L);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        int int33 = day32.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        int int37 = timeSeriesDataItem35.compareTo((java.lang.Object) day36);
        try {
            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 1L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 10L);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        int int24 = day23.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        int int28 = timeSeriesDataItem26.compareTo((java.lang.Object) day27);
        boolean boolean29 = year7.equals((java.lang.Object) int28);
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        java.lang.String str6 = spreadsheetDate2.getDescription();
//        java.lang.String str7 = spreadsheetDate2.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        java.lang.String str13 = spreadsheetDate9.getDescription();
//        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        boolean boolean22 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int23 = spreadsheetDate18.getYYYY();
//        boolean boolean24 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getYear();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        boolean boolean35 = spreadsheetDate28.isOn(serialDate34);
//        boolean boolean36 = spreadsheetDate26.isOnOrAfter(serialDate34);
//        int int37 = spreadsheetDate9.compareTo((java.lang.Object) serialDate34);
//        try {
//            org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, serialDate34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "20-February-1900" + "'", str7.equals("20-February-1900"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-43574) + "'", int37 == (-43574));
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        timeSeries11.clear();
        try {
            timeSeries11.setMaximumItemAge((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class13);
        timeSeries14.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long20 = month19.getFirstMillisecond();
        long long21 = month19.getLastMillisecond();
        java.lang.Number number22 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.String str23 = timeSeries14.getRangeDescription();
        boolean boolean24 = fixedMillisecond1.equals((java.lang.Object) timeSeries14);
        timeSeries14.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61851744000000L) + "'", long20 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61849065600001L) + "'", long21 == (-61849065600001L));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Preceding" + "'", str23.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class11);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        timeSeries12.setRangeDescription("");
//        timeSeries12.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        int int20 = day18.getDayOfMonth();
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        try {
//            int int22 = spreadsheetDate4.compareTo((java.lang.Object) day18);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Day cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        long long4 = day0.getFirstMillisecond();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        java.util.Collection collection3 = timeSeries2.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries2.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = day13.getYear();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        boolean boolean16 = spreadsheetDate9.isOn(serialDate15);
        boolean boolean17 = spreadsheetDate7.isOnOrAfter(serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate15);
        boolean boolean19 = spreadsheetDate1.isAfter(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate21.getYYYY();
        boolean boolean26 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate27 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int32 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.String str33 = spreadsheetDate29.getDescription();
        java.lang.String str34 = spreadsheetDate29.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int39 = spreadsheetDate36.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.lang.String str40 = spreadsheetDate36.getDescription();
        boolean boolean41 = spreadsheetDate29.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int48 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate43.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int56 = spreadsheetDate53.compare((org.jfree.data.time.SerialDate) spreadsheetDate55);
        boolean boolean57 = spreadsheetDate51.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean59 = spreadsheetDate53.equals((java.lang.Object) 100.0f);
        spreadsheetDate53.setDescription("hi!");
        boolean boolean63 = spreadsheetDate36.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, (org.jfree.data.time.SerialDate) spreadsheetDate53, 0);
        try {
            boolean boolean65 = spreadsheetDate1.isInRange(serialDate27, (org.jfree.data.time.SerialDate) spreadsheetDate53, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "20-February-1900" + "'", str34.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int7 = day6.getYear();
        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
        java.util.Date date9 = day6.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date5, timeZone11);
        java.util.Calendar calendar14 = null;
        try {
            month13.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 12, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        long long10 = year6.getLastMillisecond();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class14);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        timeSeries15.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        java.lang.Number number23 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day21);
        int int24 = year6.compareTo((java.lang.Object) timeSeries15);
        boolean boolean26 = year6.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year6.previous();
        long long29 = regularTimePeriod28.getMiddleMillisecond();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1530561599999L + "'", long29 == 1530561599999L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        timeSeries17.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        long long24 = month22.getLastMillisecond();
        java.lang.Number number25 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        java.lang.String str26 = timeSeries17.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries4.addAndOrUpdate(timeSeries17);
        try {
            java.lang.Number number29 = timeSeries27.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries27);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 10);
        boolean boolean16 = fixedMillisecond1.equals((java.lang.Object) day12);
        java.util.Calendar calendar17 = null;
        fixedMillisecond1.peg(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond1.previous();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        try {
            timeSeries4.removeAgedItems((long) 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
        int int14 = timeSeries4.getItemCount();
        timeSeries4.setRangeDescription("10-June-2019");
        java.lang.String str17 = timeSeries4.getRangeDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries4.createCopy((int) 'a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int6 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SerialDate serialDate7 = null;
        try {
            boolean boolean8 = spreadsheetDate3.isAfter(serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.lang.Number number11 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, 0.0d);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class28);
        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.lang.String str32 = year31.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 10L);
        long long35 = year31.getLastMillisecond();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(4, year31);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10L + "'", number11.equals(10L));
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNull(class30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long13 = month12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int18 = month17.getMonth();
        int int19 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month17);
        java.util.Calendar calendar20 = null;
        try {
            month17.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61851744000000L) + "'", long13 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setMaximumItemCount(0);
        int int8 = timeSeries4.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries4.addChangeListener(seriesChangeListener9);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        int int9 = timeSeries7.getItemCount();
        java.lang.Class<?> wildcardClass10 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass10);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        java.lang.Class class15 = timeSeries4.getTimePeriodClass();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.String str23 = year22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 10L);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 10);
        int int30 = day26.getYear();
        java.lang.Number number31 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        int int33 = day32.getYear();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class37);
        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.lang.String str41 = year40.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 10L);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long47 = month46.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) month46);
        int int49 = day32.compareTo((java.lang.Object) timeSeriesDataItem48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) 1577865599999L);
        try {
            timeSeries4.add(timeSeriesDataItem51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 12 + "'", number31.equals(12));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNull(class39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year7);
        long long13 = year7.getFirstMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = year7.equals(obj14);
        long long16 = year7.getLastMillisecond();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class20);
        java.lang.Class class22 = timeSeries21.getTimePeriodClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.lang.String str24 = year23.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 10L);
        long long27 = year23.getLastMillisecond();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class31);
        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
        timeSeries32.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
        java.lang.Number number40 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day38);
        int int41 = year23.compareTo((java.lang.Object) timeSeries32);
        boolean boolean43 = year23.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year23.previous();
        int int45 = year7.compareTo((java.lang.Object) regularTimePeriod44);
        java.util.Calendar calendar46 = null;
        try {
            long long47 = year7.getLastMillisecond(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNull(class22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertNull(class33);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-43574));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day10.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
        timeSeries2.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries2.addChangeListener(seriesChangeListener6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        int int15 = month8.getMonth();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        timeSeries20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
        java.lang.Number number28 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class32);
        timeSeries33.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long39 = month38.getFirstMillisecond();
        long long40 = month38.getLastMillisecond();
        java.lang.Number number41 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) month38);
        java.lang.String str42 = timeSeries33.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries20.addAndOrUpdate(timeSeries33);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class47);
        java.lang.Class class49 = timeSeries48.getTimePeriodClass();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        java.lang.String str51 = year50.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year50, (java.lang.Number) 10L);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        int int55 = day54.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day54, (java.lang.Number) (byte) 10);
        timeSeries43.setKey((java.lang.Comparable) timeSeriesDataItem57);
        boolean boolean59 = month8.equals((java.lang.Object) timeSeriesDataItem57);
        java.util.Calendar calendar60 = null;
        try {
            long long61 = month8.getLastMillisecond(calendar60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61851744000000L) + "'", long39 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61849065600001L) + "'", long40 == (-61849065600001L));
        org.junit.Assert.assertNull(number41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNull(class49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2019" + "'", str51.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long9 = month8.getFirstMillisecond();
//        long long10 = month8.getLastMillisecond();
//        int int11 = month8.getMonth();
//        java.lang.String str12 = month8.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
//        java.lang.Class class15 = timeSeries4.getTimePeriodClass();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        java.lang.String str23 = year22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 10);
//        int int30 = day26.getYear();
//        java.lang.Number number31 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day26);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        java.lang.String str38 = year37.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year37);
//        int int40 = day26.compareTo((java.lang.Object) year37);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class44);
//        java.lang.Class class46 = timeSeries45.getTimePeriodClass();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
//        java.lang.String str48 = year47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) (byte) 10);
//        java.lang.Class class58 = null;
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class58);
//        java.lang.Class class60 = timeSeries59.getTimePeriodClass();
//        timeSeries59.setRangeDescription("");
//        timeSeries59.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day65.previous();
//        int int67 = day65.getDayOfMonth();
//        timeSeries59.delete((org.jfree.data.time.RegularTimePeriod) day65);
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries45.addAndOrUpdate(timeSeries59);
//        long long70 = timeSeries69.getMaximumItemAge();
//        int int71 = day26.compareTo((java.lang.Object) long70);
//        java.util.Calendar calendar72 = null;
//        try {
//            long long73 = day26.getFirstMillisecond(calendar72);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNull(class15);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 12 + "'", number31.equals(12));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNull(class46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019" + "'", str48.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
//        org.junit.Assert.assertNull(class60);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 10 + "'", int67 == 10);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 9223372036854775807L + "'", long70 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 4);
        timeSeriesDataItem6.setValue((java.lang.Number) 7);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class12);
        timeSeries13.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long19 = month18.getFirstMillisecond();
        long long20 = month18.getLastMillisecond();
        java.lang.Number number21 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month18);
        int int22 = timeSeriesDataItem6.compareTo((java.lang.Object) number21);
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61851744000000L) + "'", long19 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61849065600001L) + "'", long20 == (-61849065600001L));
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(20, (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int8 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int10 = day9.getYear();
        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
        boolean boolean12 = spreadsheetDate5.isOn(serialDate11);
        boolean boolean13 = spreadsheetDate3.isOnOrAfter(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate11);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(2019, serialDate11);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        int int19 = day18.getYear();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        boolean boolean21 = spreadsheetDate14.isOn(serialDate20);
        boolean boolean22 = spreadsheetDate12.isOnOrAfter(serialDate20);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate20);
        boolean boolean24 = spreadsheetDate6.isAfter(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int29 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = spreadsheetDate26.getYYYY();
        boolean boolean31 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate33.getYYYY();
        int int38 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate33.getDayOfWeek();
        int int40 = spreadsheetDate33.getDayOfWeek();
        boolean boolean41 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int42 = spreadsheetDate33.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        timeSeries11.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries11.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        int int6 = timeSeries4.getItemCount();
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        long long10 = year6.getLastMillisecond();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class14);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        timeSeries15.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        java.lang.Number number23 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day21);
        int int24 = year6.compareTo((java.lang.Object) timeSeries15);
        boolean boolean26 = year6.equals((java.lang.Object) 1.0f);
        long long27 = year6.getSerialIndex();
        java.util.Calendar calendar28 = null;
        try {
            year6.peg(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 10);
        boolean boolean16 = fixedMillisecond1.equals((java.lang.Object) day12);
        int int17 = day12.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.previous();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = day13.getYear();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        boolean boolean16 = spreadsheetDate9.isOn(serialDate15);
        boolean boolean17 = spreadsheetDate7.isOnOrAfter(serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate15);
        boolean boolean19 = spreadsheetDate1.isAfter(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate21.getYYYY();
        boolean boolean26 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int32 = spreadsheetDate28.getYYYY();
        int int33 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int34 = spreadsheetDate28.getDayOfWeek();
        java.lang.Class<?> wildcardClass35 = spreadsheetDate28.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int40 = spreadsheetDate37.compare((org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 20 + "'", int41 == 20);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setRangeDescription("");
//        timeSeries4.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        int int12 = day10.getDayOfMonth();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
//        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long23 = month22.getFirstMillisecond();
//        long long24 = month22.getLastMillisecond();
//        int int25 = month22.getMonth();
//        java.lang.String str26 = month22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 12);
//        java.util.Collection collection29 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getYear();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class35);
//        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        java.lang.String str39 = year38.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 10L);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long45 = month44.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) month44);
//        int int47 = day30.compareTo((java.lang.Object) timeSeriesDataItem46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 1577865599999L);
//        try {
//            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNull(class19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "January 10" + "'", str26.equals("January 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNull(class37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61851744000000L) + "'", long45 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        timeSeries4.setKey((java.lang.Comparable) '4');
        boolean boolean9 = timeSeries4.isEmpty();
        java.lang.Comparable comparable10 = timeSeries4.getKey();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + '4' + "'", comparable10.equals('4'));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond5.getLastMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getYear();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        java.util.Date date13 = day10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13, timeZone15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date9, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date3, timeZone15);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class22);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.lang.String str26 = year25.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 10L);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        int int30 = day29.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) (byte) 10);
        int int33 = day29.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
        int int35 = day18.compareTo((java.lang.Object) day29);
        org.jfree.data.time.SerialDate serialDate36 = day18.getSerialDate();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year7);
        long long13 = year7.getFirstMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = year7.equals(obj14);
        long long16 = year7.getLastMillisecond();
        long long17 = year7.getMiddleMillisecond();
        long long18 = year7.getMiddleMillisecond();
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1562097599999L + "'", long18 == 1562097599999L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        timeSeries4.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries4.addChangeListener(seriesChangeListener16);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class21);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.lang.String str25 = year24.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 10L);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long31 = month30.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int36 = month35.getMonth();
        int int37 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = month35.getFirstMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61851744000000L) + "'", long31 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year7);
        long long13 = year7.getFirstMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = year7.equals(obj14);
        long long16 = year7.getFirstMillisecond();
        long long17 = year7.getFirstMillisecond();
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = regularTimePeriod1.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-June-2019" + "'", str2.equals("9-June-2019"));
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        timeSeries4.setKey((java.lang.Comparable) '4');
        boolean boolean9 = timeSeries4.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            java.lang.Number number11 = timeSeries4.getValue(regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        boolean boolean9 = spreadsheetDate3.equals((java.lang.Object) 100.0f);
        spreadsheetDate3.setDescription("hi!");
        try {
            org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate3.getNearestDayOfWeek(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getYear();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        boolean boolean8 = spreadsheetDate1.isOn(serialDate7);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries13.clear();
        java.lang.Object obj18 = null;
        boolean boolean19 = timeSeries13.equals(obj18);
        try {
            int int20 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = day20.getYear();
        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
        boolean boolean23 = spreadsheetDate16.isOn(serialDate22);
        boolean boolean24 = spreadsheetDate14.isOnOrAfter(serialDate22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate22);
        boolean boolean26 = spreadsheetDate8.isAfter(serialDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int32 = spreadsheetDate28.getYYYY();
        boolean boolean33 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int38 = spreadsheetDate35.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int39 = spreadsheetDate35.getYYYY();
        int int40 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int45 = spreadsheetDate42.compare((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int53 = spreadsheetDate50.compare((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        int int55 = day54.getYear();
        org.jfree.data.time.SerialDate serialDate56 = day54.getSerialDate();
        boolean boolean57 = spreadsheetDate50.isOn(serialDate56);
        boolean boolean58 = spreadsheetDate48.isOnOrAfter(serialDate56);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate56);
        boolean boolean60 = spreadsheetDate42.isAfter(serialDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int65 = spreadsheetDate62.compare((org.jfree.data.time.SerialDate) spreadsheetDate64);
        int int66 = spreadsheetDate62.getYYYY();
        boolean boolean67 = spreadsheetDate42.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int72 = spreadsheetDate69.compare((org.jfree.data.time.SerialDate) spreadsheetDate71);
        int int73 = spreadsheetDate69.getYYYY();
        int int74 = spreadsheetDate62.compare((org.jfree.data.time.SerialDate) spreadsheetDate69);
        int int75 = spreadsheetDate69.getDayOfWeek();
        int int76 = spreadsheetDate69.getDayOfWeek();
        boolean boolean78 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, (org.jfree.data.time.SerialDate) spreadsheetDate69, (int) (short) 10);
        org.jfree.data.time.Month month81 = new org.jfree.data.time.Month();
        java.lang.String str82 = month81.toString();
        java.lang.Class class87 = null;
        org.jfree.data.time.TimeSeries timeSeries88 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class87);
        java.lang.Class class89 = timeSeries88.getTimePeriodClass();
        int int90 = timeSeries88.getItemCount();
        java.lang.Class<?> wildcardClass91 = timeSeries88.getClass();
        org.jfree.data.time.TimeSeries timeSeries92 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass91);
        org.jfree.data.time.TimeSeries timeSeries93 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month81, (java.lang.Class) wildcardClass91);
        org.jfree.data.time.TimeSeries timeSeries94 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate28, "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: 2019]", "org.jfree.data.general.SeriesException: 2019", (java.lang.Class) wildcardClass91);
        org.jfree.data.time.SerialDate serialDate95 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        try {
            org.jfree.data.time.SerialDate serialDate97 = serialDate95.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1900 + "'", int66 == 1900);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1900 + "'", int73 == 1900);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 3 + "'", int75 == 3);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 3 + "'", int76 == 3);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "June 2019" + "'", str82.equals("June 2019"));
        org.junit.Assert.assertNull(class89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNotNull(serialDate95);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.util.Date date13 = day10.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getYear();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        java.util.Date date17 = day14.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date13, timeZone19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date13);
//        long long23 = day22.getMiddleMillisecond();
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560193199999L + "'", long23 == 1560193199999L);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class23);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long29 = month28.getFirstMillisecond();
        long long30 = month28.getLastMillisecond();
        int int31 = month28.getMonth();
        java.lang.String str32 = month28.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 12);
        boolean boolean35 = year17.equals((java.lang.Object) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener37);
        java.lang.Comparable comparable39 = timeSeries4.getKey();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61851744000000L) + "'", long29 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61849065600001L) + "'", long30 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January 10" + "'", str32.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + 3 + "'", comparable39.equals(3));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setRangeDescription("");
//        timeSeries4.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        int int12 = day10.getDayOfMonth();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
//        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long23 = month22.getFirstMillisecond();
//        long long24 = month22.getLastMillisecond();
//        int int25 = month22.getMonth();
//        java.lang.String str26 = month22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 12);
//        java.util.Collection collection29 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        java.lang.String str30 = timeSeries18.getDescription();
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNull(class19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "January 10" + "'", str26.equals("January 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertNull(str30);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-43574));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Number number11 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
//        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.lang.String str21 = year20.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) (byte) 10);
//        long long28 = day24.getLastMillisecond();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) (byte) 0, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10L + "'", number11.equals(10L));
//        org.junit.Assert.assertNull(class19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str6 = spreadsheetDate2.getDescription();
        java.lang.String str7 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.String str13 = spreadsheetDate9.getDescription();
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int23 = spreadsheetDate18.getYYYY();
        boolean boolean24 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((-458), (org.jfree.data.time.SerialDate) spreadsheetDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "20-February-1900" + "'", str7.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = day4.getYear();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        java.util.Date date7 = day4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1560193199999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries4.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setMaximumItemCount(0);
        int int8 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str14 = spreadsheetDate10.getDescription();
        java.lang.String str15 = spreadsheetDate10.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.lang.String str21 = spreadsheetDate17.getDescription();
        boolean boolean22 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean23 = timeSeries4.equals((java.lang.Object) boolean22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class27);
        timeSeries28.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long34 = month33.getFirstMillisecond();
        long long35 = month33.getLastMillisecond();
        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month33.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 12);
        java.util.Collection collection40 = timeSeries4.getTimePeriods();
        timeSeries4.setRangeDescription("");
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "20-February-1900" + "'", str15.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61851744000000L) + "'", long34 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61849065600001L) + "'", long35 == (-61849065600001L));
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(collection40);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        long long12 = year8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(4, year8);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        java.util.Calendar calendar15 = null;
        try {
            month14.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 9, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem6.getPeriod();
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        java.lang.Class class15 = timeSeries4.getTimePeriodClass();
        try {
            timeSeries4.update(7, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class15);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        long long5 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0, 9, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int8 = spreadsheetDate5.toSerial();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2958465, (org.jfree.data.time.SerialDate) spreadsheetDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, (int) '#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        int int6 = timeSeries4.getItemCount();
        java.lang.Class<?> wildcardClass7 = timeSeries4.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = null;
        try {
            timeSeries2.add(timeSeriesDataItem3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getPreviousDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class13);
        timeSeries14.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long20 = month19.getFirstMillisecond();
        long long21 = month19.getLastMillisecond();
        java.lang.Number number22 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.String str23 = timeSeries14.getRangeDescription();
        boolean boolean24 = fixedMillisecond1.equals((java.lang.Object) timeSeries14);
        long long25 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61851744000000L) + "'", long20 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61849065600001L) + "'", long21 == (-61849065600001L));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Preceding" + "'", str23.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setRangeDescription("");
//        timeSeries4.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        int int12 = day10.getDayOfMonth();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.getDataItem(regularTimePeriod14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getYear();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        boolean boolean22 = spreadsheetDate15.isOn(serialDate21);
        boolean boolean23 = spreadsheetDate13.isOnOrAfter(serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate21);
        boolean boolean25 = spreadsheetDate7.isAfter(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate27.getYYYY();
        boolean boolean32 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int37 = spreadsheetDate34.compare((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int38 = spreadsheetDate34.getYYYY();
        int int39 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int44 = spreadsheetDate41.compare((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int52 = spreadsheetDate49.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        int int54 = day53.getYear();
        org.jfree.data.time.SerialDate serialDate55 = day53.getSerialDate();
        boolean boolean56 = spreadsheetDate49.isOn(serialDate55);
        boolean boolean57 = spreadsheetDate47.isOnOrAfter(serialDate55);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate55);
        boolean boolean59 = spreadsheetDate41.isAfter(serialDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int64 = spreadsheetDate61.compare((org.jfree.data.time.SerialDate) spreadsheetDate63);
        int int65 = spreadsheetDate61.getYYYY();
        boolean boolean66 = spreadsheetDate41.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int71 = spreadsheetDate68.compare((org.jfree.data.time.SerialDate) spreadsheetDate70);
        int int72 = spreadsheetDate68.getYYYY();
        int int73 = spreadsheetDate61.compare((org.jfree.data.time.SerialDate) spreadsheetDate68);
        int int74 = spreadsheetDate68.getDayOfWeek();
        int int75 = spreadsheetDate68.getDayOfWeek();
        boolean boolean77 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate68, (int) (short) 10);
        try {
            org.jfree.data.time.SerialDate serialDate79 = spreadsheetDate68.getFollowingDayOfWeek(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1900 + "'", int65 == 1900);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1900 + "'", int72 == 1900);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 3 + "'", int74 == 3);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 3 + "'", int75 == 3);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
//        java.lang.String str14 = day10.toString();
//        org.jfree.data.time.SerialDate serialDate15 = day10.getSerialDate();
//        long long16 = day10.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day10.next();
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("January 10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int8 = spreadsheetDate1.getMonth();
        int int9 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate10 = null;
        try {
            int int11 = spreadsheetDate1.compare(serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 12);
        java.util.Calendar calendar20 = null;
        try {
            day17.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.lang.Number number11 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        long long24 = month22.getLastMillisecond();
        int int25 = month22.getMonth();
        java.lang.String str26 = month22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 12);
        java.lang.String str29 = timeSeries18.getDomainDescription();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class33);
        java.lang.Class class35 = timeSeries34.getTimePeriodClass();
        timeSeries34.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
        java.lang.Number number42 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) day40);
        int int44 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day40);
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class48);
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        java.lang.String str52 = year51.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 10L);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        int int56 = day55.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) (byte) 10);
        int int59 = day55.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day55.previous();
        int int61 = day55.getYear();
        int int62 = day55.getYear();
        java.util.Date date63 = day55.getEnd();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) 5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10L + "'", number11.equals(10L));
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "January 10" + "'", str26.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNull(class35);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(number42);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2019" + "'", str52.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
        org.junit.Assert.assertNotNull(date63);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean14 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = day20.getYear();
        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
        boolean boolean23 = spreadsheetDate16.isOn(serialDate22);
        boolean boolean24 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int25 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 20 + "'", int25 == 20);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long9 = month8.getFirstMillisecond();
//        long long10 = month8.getLastMillisecond();
//        int int11 = month8.getMonth();
//        java.lang.String str12 = month8.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
//        java.lang.String str15 = timeSeries4.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener16);
//        java.lang.Object obj18 = timeSeries4.clone();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class22);
//        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        java.lang.String str26 = year25.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) (byte) 10);
//        java.lang.String str33 = day29.toString();
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class37);
//        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        java.lang.String str41 = year40.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 10L);
//        long long44 = year40.getLastMillisecond();
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class48);
//        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
//        timeSeries49.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener53 = null;
//        timeSeries49.addPropertyChangeListener(propertyChangeListener53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.previous();
//        java.lang.Number number57 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) day55);
//        int int58 = year40.compareTo((java.lang.Object) timeSeries49);
//        int int59 = day29.compareTo((java.lang.Object) int58);
//        org.jfree.data.time.SerialDate serialDate60 = day29.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries62 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day29, regularTimePeriod61);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNull(class24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertNull(class39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
//        org.junit.Assert.assertNull(class50);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNull(number57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertNotNull(serialDate60);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year5);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class11);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long17 = month16.getFirstMillisecond();
        long long18 = month16.getLastMillisecond();
        int int19 = month16.getMonth();
        java.lang.String str20 = month16.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 12);
        boolean boolean23 = year5.equals((java.lang.Object) 12);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year5.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61851744000000L) + "'", long17 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61849065600001L) + "'", long18 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "January 10" + "'", str20.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long8 = fixedMillisecond7.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond7.getLastMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond7.getTime();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond7.getFirstMillisecond(calendar12);
        long long14 = fixedMillisecond7.getFirstMillisecond();
        long long15 = fixedMillisecond7.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond7.getTime();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.lang.String str18 = month17.toString();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class23);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        int int26 = timeSeries24.getItemCount();
        java.lang.Class<?> wildcardClass27 = timeSeries24.getClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass27);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, (java.lang.Class) wildcardClass27);
        java.util.Date date30 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long33 = fixedMillisecond32.getMiddleMillisecond();
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond32.getLastMillisecond(calendar34);
        java.util.Date date36 = fixedMillisecond32.getTime();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date30, timeZone37);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date16, timeZone37);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) (-43574));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.util.Date date13 = day10.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getYear();
        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
        java.util.Date date17 = day14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date13, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date13, timeZone23);
        java.util.Calendar calendar25 = null;
        try {
            year24.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone23);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str13 = timeSeries4.getRangeDescription();
        try {
            timeSeries4.update(3, (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Preceding" + "'", str13.equals("Preceding"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str13 = timeSeries4.getDomainDescription();
        int int14 = timeSeries4.getMaximumItemCount();
        try {
            java.lang.Number number16 = timeSeries4.getValue(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class13);
        timeSeries14.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long20 = month19.getFirstMillisecond();
        long long21 = month19.getLastMillisecond();
        java.lang.Number number22 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.String str23 = timeSeries14.getRangeDescription();
        boolean boolean24 = fixedMillisecond1.equals((java.lang.Object) timeSeries14);
        java.util.Calendar calendar25 = null;
        fixedMillisecond1.peg(calendar25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61851744000000L) + "'", long20 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61849065600001L) + "'", long21 == (-61849065600001L));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Preceding" + "'", str23.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        long long12 = year8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(4, year8);
        long long14 = year8.getFirstMillisecond();
        java.lang.Object obj15 = null;
        boolean boolean16 = year8.equals(obj15);
        long long17 = year8.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) '#', year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        java.util.Collection collection3 = timeSeries2.getTimePeriods();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        long long8 = month6.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (double) 4);
        java.lang.Object obj11 = timeSeriesDataItem10.clone();
        try {
            timeSeries2.add(timeSeriesDataItem10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection3);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61851744000000L) + "'", long8 == (-61851744000000L));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.util.Date date13 = day10.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getYear();
        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
        java.util.Date date17 = day14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date13, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date13);
        java.util.Calendar calendar24 = null;
        try {
            year23.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int8 = spreadsheetDate5.toSerial();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(12, (org.jfree.data.time.SerialDate) spreadsheetDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class23);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long29 = month28.getFirstMillisecond();
        long long30 = month28.getLastMillisecond();
        int int31 = month28.getMonth();
        java.lang.String str32 = month28.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 12);
        boolean boolean35 = year17.equals((java.lang.Object) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61851744000000L) + "'", long29 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61849065600001L) + "'", long30 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January 10" + "'", str32.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Preceding" + "'", str39.equals("Preceding"));
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        java.lang.Class<?> wildcardClass3 = day0.getClass();
//        java.lang.String str4 = day0.toString();
//        int int5 = day0.getDayOfMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str13 = timeSeries4.getDomainDescription();
        try {
            timeSeries4.delete(2958465, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-458) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setRangeDescription("");
//        timeSeries4.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        int int12 = day10.getDayOfMonth();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
//        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long23 = month22.getFirstMillisecond();
//        long long24 = month22.getLastMillisecond();
//        int int25 = month22.getMonth();
//        java.lang.String str26 = month22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 12);
//        java.util.Collection collection29 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        timeSeries4.setRangeDescription("10-June-2019");
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNull(class19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "January 10" + "'", str26.equals("January 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(collection29);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        serialDate7.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int22 = spreadsheetDate19.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        int int24 = day23.getYear();
        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
        boolean boolean26 = spreadsheetDate19.isOn(serialDate25);
        boolean boolean27 = spreadsheetDate17.isOnOrAfter(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate25);
        boolean boolean29 = spreadsheetDate11.isAfter(serialDate25);
        org.jfree.data.time.SerialDate serialDate30 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate31 = null;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        int int33 = day32.getYear();
        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
        java.util.Date date35 = day32.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date35);
        try {
            boolean boolean39 = spreadsheetDate11.isInRange(serialDate31, serialDate38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate38);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        int int6 = timeSeries4.getItemCount();
        int int7 = timeSeries4.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean17 = spreadsheetDate11.equals((java.lang.Object) 100.0f);
        spreadsheetDate11.setDescription("hi!");
        boolean boolean20 = timeSeries4.equals((java.lang.Object) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int25 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int39 = spreadsheetDate36.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        int int41 = day40.getYear();
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        boolean boolean43 = spreadsheetDate36.isOn(serialDate42);
        boolean boolean44 = spreadsheetDate34.isOnOrAfter(serialDate42);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate42);
        boolean boolean46 = spreadsheetDate28.isAfter(serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int51 = spreadsheetDate48.compare((org.jfree.data.time.SerialDate) spreadsheetDate50);
        int int52 = spreadsheetDate48.getYYYY();
        boolean boolean53 = spreadsheetDate28.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int58 = spreadsheetDate55.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        int int59 = spreadsheetDate55.getYYYY();
        int int60 = spreadsheetDate48.compare((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int65 = spreadsheetDate62.compare((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int73 = spreadsheetDate70.compare((org.jfree.data.time.SerialDate) spreadsheetDate72);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
        int int75 = day74.getYear();
        org.jfree.data.time.SerialDate serialDate76 = day74.getSerialDate();
        boolean boolean77 = spreadsheetDate70.isOn(serialDate76);
        boolean boolean78 = spreadsheetDate68.isOnOrAfter(serialDate76);
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate76);
        boolean boolean80 = spreadsheetDate62.isAfter(serialDate76);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate84 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int85 = spreadsheetDate82.compare((org.jfree.data.time.SerialDate) spreadsheetDate84);
        int int86 = spreadsheetDate82.getYYYY();
        boolean boolean87 = spreadsheetDate62.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate82);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate89 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate91 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int92 = spreadsheetDate89.compare((org.jfree.data.time.SerialDate) spreadsheetDate91);
        int int93 = spreadsheetDate89.getYYYY();
        int int94 = spreadsheetDate82.compare((org.jfree.data.time.SerialDate) spreadsheetDate89);
        int int95 = spreadsheetDate89.getDayOfWeek();
        int int96 = spreadsheetDate89.getDayOfWeek();
        boolean boolean98 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate48, (org.jfree.data.time.SerialDate) spreadsheetDate89, (int) (short) 10);
        org.jfree.data.time.SerialDate serialDate99 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1900 + "'", int52 == 1900);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1900 + "'", int59 == 1900);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2019 + "'", int75 == 2019);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1900 + "'", int86 == 1900);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1900 + "'", int93 == 1900);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 3 + "'", int95 == 3);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 3 + "'", int96 == 3);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
        org.junit.Assert.assertNotNull(serialDate99);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.Date date5 = fixedMillisecond4.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        int int7 = timeSeries5.getItemCount();
        java.lang.Class<?> wildcardClass8 = timeSeries5.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long12 = fixedMillisecond11.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond11.getLastMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond11.getTime();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond11.getFirstMillisecond(calendar16);
        long long18 = fixedMillisecond11.getFirstMillisecond();
        long long19 = fixedMillisecond11.getLastMillisecond();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        try {
            timeSeries9.update((-458), (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int7 = day6.getYear();
        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
        boolean boolean9 = spreadsheetDate2.isOn(serialDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean19 = spreadsheetDate13.equals((java.lang.Object) 100.0f);
        boolean boolean20 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int25 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        java.lang.String str26 = spreadsheetDate22.getDescription();
        java.lang.String str27 = spreadsheetDate22.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int32 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.String str33 = spreadsheetDate29.getDescription();
        boolean boolean34 = spreadsheetDate22.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int41 = spreadsheetDate38.compare((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean42 = spreadsheetDate36.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int43 = spreadsheetDate38.getYYYY();
        boolean boolean44 = spreadsheetDate29.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean45 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        try {
            org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(8, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20-February-1900" + "'", str27.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1900 + "'", int43 == 1900);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = timeSeriesDataItem13.compareTo((java.lang.Object) day14);
//        long long16 = day14.getFirstMillisecond();
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day14.getFirstMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        timeSeries17.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        long long24 = month22.getLastMillisecond();
        java.lang.Number number25 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        java.lang.String str26 = timeSeries17.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries4.addAndOrUpdate(timeSeries17);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class31);
        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.lang.String str35 = year34.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 10L);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        int int39 = day38.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) (byte) 10);
        timeSeries27.setKey((java.lang.Comparable) timeSeriesDataItem41);
        timeSeries27.setDescription("10-June-2019");
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries27.removePropertyChangeListener(propertyChangeListener45);
        java.lang.Comparable comparable47 = timeSeries27.getKey();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(class33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(comparable47);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.util.Date date13 = day10.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        int int15 = day14.getYear();
//        long long16 = day14.getFirstMillisecond();
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2147483647, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.util.Date date0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        int int2 = day1.getYear();
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        java.util.Date date4 = day1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date0, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, (-43574), 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long9 = month8.getFirstMillisecond();
//        long long10 = month8.getLastMillisecond();
//        int int11 = month8.getMonth();
//        java.lang.String str12 = month8.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
//        java.lang.String str15 = timeSeries4.getDomainDescription();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long25 = month24.getFirstMillisecond();
//        long long26 = month24.getLastMillisecond();
//        int int27 = month24.getMonth();
//        java.lang.String str28 = month24.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 12);
//        java.lang.Class class31 = timeSeries20.getTimePeriodClass();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class35);
//        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        java.lang.String str39 = year38.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        int int43 = day42.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) (byte) 10);
//        int int46 = day42.getYear();
//        java.lang.Number number47 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) day42);
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        java.lang.String str54 = year53.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries52.getDataItem((org.jfree.data.time.RegularTimePeriod) year53);
//        int int56 = day42.compareTo((java.lang.Object) year53);
//        java.lang.Class class60 = null;
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class60);
//        java.lang.Class class62 = timeSeries61.getTimePeriodClass();
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
//        java.lang.String str64 = year63.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year63, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        int int68 = day67.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day67, (java.lang.Number) (byte) 10);
//        java.lang.Class class74 = null;
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class74);
//        java.lang.Class class76 = timeSeries75.getTimePeriodClass();
//        timeSeries75.setRangeDescription("");
//        timeSeries75.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = day81.previous();
//        int int83 = day81.getDayOfMonth();
//        timeSeries75.delete((org.jfree.data.time.RegularTimePeriod) day81);
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries61.addAndOrUpdate(timeSeries75);
//        long long86 = timeSeries85.getMaximumItemAge();
//        int int87 = day42.compareTo((java.lang.Object) long86);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day42, (double) 9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61851744000000L) + "'", long25 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61849065600001L) + "'", long26 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "January 10" + "'", str28.equals("January 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertNull(class37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 12 + "'", number47.equals(12));
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019" + "'", str54.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertNull(class62);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "2019" + "'", str64.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem70);
//        org.junit.Assert.assertNull(class76);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 10 + "'", int83 == 10);
//        org.junit.Assert.assertNotNull(timeSeries85);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 9223372036854775807L + "'", long86 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1, 2, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Preceding");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.lang.Number number11 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 10L);
        long long23 = year19.getLastMillisecond();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(4, year19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries4.getDataItem(regularTimePeriod25);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10L + "'", number11.equals(10L));
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int8 = spreadsheetDate2.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.previous();
        java.util.Calendar calendar13 = null;
        try {
            year7.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class7);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        timeSeries8.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day14);
        java.util.Date date17 = day14.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        int int19 = day18.getYear();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        java.util.Date date21 = day18.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date21, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date17, timeZone23);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.SerialDate serialDate28 = day26.getSerialDate();
        java.util.Date date29 = day26.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date29, timeZone31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date17, timeZone31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        int int35 = day34.getYear();
        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
        java.util.Date date37 = day34.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long40 = fixedMillisecond39.getMiddleMillisecond();
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond39.getLastMillisecond(calendar41);
        java.util.Date date43 = fixedMillisecond39.getTime();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        int int45 = day44.getYear();
        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
        java.util.Date date47 = day44.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date47, timeZone49);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date43, timeZone49);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date37, timeZone49);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date17, timeZone49);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date17);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1L + "'", long42 == 1L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone49);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        java.lang.String str15 = timeSeries4.getDomainDescription();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        timeSeries20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
        java.lang.Number number28 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Calendar calendar30 = null;
        try {
            day26.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond5.getLastMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond5.getTime();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getYear();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        java.util.Date date13 = day10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13, timeZone15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date9, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date3, timeZone15);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class22);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.lang.String str26 = year25.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 10L);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        int int30 = day29.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) (byte) 10);
        int int33 = day29.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
        int int35 = day18.compareTo((java.lang.Object) day29);
        java.util.Calendar calendar36 = null;
        try {
            long long37 = day29.getFirstMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.util.Date date0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long3 = fixedMillisecond2.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getLastMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date0, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year7);
        java.util.Calendar calendar13 = null;
        try {
            year7.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long10 = fixedMillisecond9.getMiddleMillisecond();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getLastMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13, timeZone14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date3, timeZone14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year7);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year7.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        long long10 = year6.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str12 = month5.toString();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 10L);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int31 = month30.getMonth();
        int int32 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (-1.0d));
        try {
            org.jfree.data.time.Year year35 = month30.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setMaximumItemCount(0);
        int int8 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str14 = spreadsheetDate10.getDescription();
        java.lang.String str15 = spreadsheetDate10.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.lang.String str21 = spreadsheetDate17.getDescription();
        boolean boolean22 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean23 = timeSeries4.equals((java.lang.Object) boolean22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class27);
        timeSeries28.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long34 = month33.getFirstMillisecond();
        long long35 = month33.getLastMillisecond();
        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month33.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 12);
        java.util.Collection collection40 = timeSeries4.getTimePeriods();
        boolean boolean41 = timeSeries4.isEmpty();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "20-February-1900" + "'", str15.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61851744000000L) + "'", long34 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61849065600001L) + "'", long35 == (-61849065600001L));
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(collection40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        long long12 = year8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(4, year8);
        long long14 = year8.getFirstMillisecond();
        java.lang.Object obj15 = null;
        boolean boolean16 = year8.equals(obj15);
        try {
            org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) '#', year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) '4', 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class8);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 10L);
        long long15 = year11.getLastMillisecond();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(4, year11);
        long long17 = year11.getFirstMillisecond();
        java.lang.Object obj18 = null;
        boolean boolean19 = year11.equals(obj18);
        int int20 = year11.getYear();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-447) + "'", int1 == (-447));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getYear();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        boolean boolean8 = spreadsheetDate1.isOn(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean18 = spreadsheetDate12.equals((java.lang.Object) 100.0f);
        boolean boolean19 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int20 = spreadsheetDate12.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20 + "'", int20 == 20);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.util.Date date13 = day10.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getYear();
        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
        java.util.Date date17 = day14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date13, timeZone19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date13);
        long long24 = year23.getFirstMillisecond();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long6 = fixedMillisecond5.getMiddleMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getLastMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        java.lang.Number number11 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day10.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(number11);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.lang.Number number11 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        long long24 = month22.getLastMillisecond();
        int int25 = month22.getMonth();
        java.lang.String str26 = month22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 12);
        java.lang.String str29 = timeSeries18.getDomainDescription();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class33);
        java.lang.Class class35 = timeSeries34.getTimePeriodClass();
        timeSeries34.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
        java.lang.Number number42 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) day40);
        int int44 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day40);
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener45);
        int int47 = timeSeries4.getItemCount();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.previous();
        long long52 = month50.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month50, (double) 4);
        java.lang.Object obj55 = timeSeriesDataItem54.clone();
        boolean boolean57 = timeSeriesDataItem54.equals((java.lang.Object) (-1L));
        boolean boolean59 = timeSeriesDataItem54.equals((java.lang.Object) 2019);
        try {
            timeSeries4.add(timeSeriesDataItem54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10L + "'", number11.equals(10L));
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "January 10" + "'", str26.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNull(class35);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(number42);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-61851744000000L) + "'", long52 == (-61851744000000L));
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 12);
        timeSeries11.setNotify(true);
        boolean boolean22 = timeSeries11.isEmpty();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.util.Date date3 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        long long6 = fixedMillisecond4.getLastMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getYear();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class14);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.lang.String str18 = year17.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 10L);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long24 = month23.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
//        int int26 = day9.compareTo((java.lang.Object) timeSeriesDataItem25);
//        int int27 = fixedMillisecond4.compareTo((java.lang.Object) int26);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61851744000000L) + "'", long24 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getYear();
        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
        boolean boolean17 = spreadsheetDate10.isOn(serialDate16);
        boolean boolean18 = spreadsheetDate8.isOnOrAfter(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate16);
        boolean boolean20 = spreadsheetDate2.isAfter(serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int25 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate22.getYYYY();
        boolean boolean27 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int32 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        int int33 = spreadsheetDate29.getYYYY();
        int int34 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int35 = spreadsheetDate29.getDayOfWeek();
        java.lang.Class<?> wildcardClass36 = spreadsheetDate29.getClass();
        try {
            org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(20, (org.jfree.data.time.SerialDate) spreadsheetDate29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
        org.junit.Assert.assertNotNull(wildcardClass36);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
//        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
//        timeSeries18.setRangeDescription("");
//        timeSeries18.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
//        int int26 = day24.getDayOfMonth();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day24);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        java.lang.String str29 = timeSeries18.getDescription();
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNull(class19);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNull(str29);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        int int6 = timeSeries4.getItemCount();
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        java.lang.String str8 = timeSeries4.getRangeDescription();
        timeSeries4.setDomainDescription("");
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class14);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        timeSeries15.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        java.lang.Number number23 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day21);
        java.util.Date date24 = day21.getStart();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        int int26 = day25.getYear();
        org.jfree.data.time.SerialDate serialDate27 = day25.getSerialDate();
        java.util.Date date28 = day25.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date28, timeZone30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date24, timeZone30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day33);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Preceding" + "'", str8.equals("Preceding"));
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month12.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
        int int17 = day0.compareTo((java.lang.Object) timeSeriesDataItem16);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class21);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.lang.String str25 = year24.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 10L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries22.removeChangeListener(seriesChangeListener28);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.lang.String str36 = year35.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) year35);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class41);
        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long47 = month46.getFirstMillisecond();
        long long48 = month46.getLastMillisecond();
        int int49 = month46.getMonth();
        java.lang.String str50 = month46.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month46, (java.lang.Number) 12);
        boolean boolean53 = year35.equals((java.lang.Object) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) year35);
        int int55 = timeSeriesDataItem16.compareTo((java.lang.Object) timeSeriesDataItem54);
        java.lang.Number number56 = timeSeriesDataItem54.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61851744000000L) + "'", long15 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNull(class43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61849065600001L) + "'", long48 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "January 10" + "'", str50.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 10L + "'", number56.equals(10L));
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
//        java.lang.String str14 = day10.toString();
//        org.jfree.data.time.SerialDate serialDate15 = day10.getSerialDate();
//        long long16 = day10.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day10.previous();
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        java.util.Collection collection3 = timeSeries2.getTimePeriods();
        timeSeries2.setNotify(false);
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-447));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, year8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(8, year8);
        long long14 = month13.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = spreadsheetDate16.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int25 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int33 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        int int35 = day34.getYear();
        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
        boolean boolean37 = spreadsheetDate30.isOn(serialDate36);
        boolean boolean38 = spreadsheetDate28.isOnOrAfter(serialDate36);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate36);
        boolean boolean40 = spreadsheetDate22.isAfter(serialDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int45 = spreadsheetDate42.compare((org.jfree.data.time.SerialDate) spreadsheetDate44);
        int int46 = spreadsheetDate42.getYYYY();
        boolean boolean47 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int52 = spreadsheetDate49.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int53 = spreadsheetDate49.getYYYY();
        int int54 = spreadsheetDate42.compare((org.jfree.data.time.SerialDate) spreadsheetDate49);
        int int55 = spreadsheetDate49.getDayOfWeek();
        java.lang.Class<?> wildcardClass56 = spreadsheetDate49.getClass();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate16, (java.lang.Class) wildcardClass56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long60 = fixedMillisecond59.getMiddleMillisecond();
        java.util.Calendar calendar61 = null;
        long long62 = fixedMillisecond59.getLastMillisecond(calendar61);
        java.util.Date date63 = fixedMillisecond59.getTime();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        int int65 = day64.getYear();
        org.jfree.data.time.SerialDate serialDate66 = day64.getSerialDate();
        java.util.Date date67 = day64.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond(date67);
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(date67, timeZone69);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date63, timeZone69);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month71);
        int int73 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) month71);
        boolean boolean74 = month13.equals((java.lang.Object) int73);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1565981999999L + "'", long14 == 1565981999999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1900 + "'", int53 == 1900);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1L + "'", long60 == 1L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1L + "'", long62 == 1L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.util.Date date13 = day10.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getYear();
        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
        java.util.Date date17 = day14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date13, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone23 = null;
        try {
            org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date13, timeZone23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        timeSeries17.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        long long24 = month22.getLastMillisecond();
        java.lang.Number number25 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        java.lang.String str26 = timeSeries17.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries4.addAndOrUpdate(timeSeries17);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class31);
        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.lang.String str35 = year34.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 10L);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        int int39 = day38.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) (byte) 10);
        timeSeries27.setKey((java.lang.Comparable) timeSeriesDataItem41);
        timeSeries27.setDescription("10-June-2019");
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class48);
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        java.lang.String str52 = year51.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 10L);
        long long55 = year51.getLastMillisecond();
        java.lang.Class class59 = null;
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class59);
        java.lang.Class class61 = timeSeries60.getTimePeriodClass();
        timeSeries60.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timeSeries60.addPropertyChangeListener(propertyChangeListener64);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day66.previous();
        java.lang.Number number68 = timeSeries60.getValue((org.jfree.data.time.RegularTimePeriod) day66);
        int int69 = year51.compareTo((java.lang.Object) timeSeries60);
        boolean boolean71 = year51.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year51.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year51.previous();
        long long74 = year51.getSerialIndex();
        try {
            timeSeries27.add((org.jfree.data.time.RegularTimePeriod) year51, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(class33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2019" + "'", str52.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertNull(class61);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(number68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 2019L + "'", long74 == 2019L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean16 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        int int23 = day22.getYear();
        org.jfree.data.time.SerialDate serialDate24 = day22.getSerialDate();
        boolean boolean25 = spreadsheetDate18.isOn(serialDate24);
        boolean boolean26 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(8, serialDate27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class13);
        timeSeries14.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long20 = month19.getFirstMillisecond();
        long long21 = month19.getLastMillisecond();
        java.lang.Number number22 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.String str23 = timeSeries14.getRangeDescription();
        boolean boolean24 = fixedMillisecond1.equals((java.lang.Object) timeSeries14);
        timeSeries14.setDomainDescription("June 2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        int int33 = day32.getYear();
        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
        boolean boolean35 = spreadsheetDate28.isOn(serialDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int42 = spreadsheetDate39.compare((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean43 = spreadsheetDate37.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean45 = spreadsheetDate39.equals((java.lang.Object) 100.0f);
        boolean boolean46 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
        timeSeries14.setKey((java.lang.Comparable) spreadsheetDate28);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61851744000000L) + "'", long20 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61849065600001L) + "'", long21 == (-61849065600001L));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Preceding" + "'", str23.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str13 = timeSeries4.getDomainDescription();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 10L);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        int int29 = timeSeriesDataItem27.compareTo((java.lang.Object) day28);
        int int30 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = day28.getMiddleMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.lang.String str5 = spreadsheetDate1.getDescription();
//        java.lang.String str6 = spreadsheetDate1.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        java.lang.String str12 = spreadsheetDate8.getDescription();
//        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        boolean boolean21 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int22 = spreadsheetDate17.getYYYY();
//        boolean boolean23 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getYear();
//        org.jfree.data.time.SerialDate serialDate33 = day31.getSerialDate();
//        boolean boolean34 = spreadsheetDate27.isOn(serialDate33);
//        boolean boolean35 = spreadsheetDate25.isOnOrAfter(serialDate33);
//        int int36 = spreadsheetDate8.compareTo((java.lang.Object) serialDate33);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int43 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        boolean boolean44 = spreadsheetDate38.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        int int45 = spreadsheetDate38.getMonth();
//        java.util.Date date46 = spreadsheetDate38.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int53 = spreadsheetDate50.compare((org.jfree.data.time.SerialDate) spreadsheetDate52);
//        boolean boolean54 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SerialDate serialDate56 = spreadsheetDate48.getFollowingDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate57 = spreadsheetDate38.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        boolean boolean58 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        int int59 = spreadsheetDate38.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20-February-1900" + "'", str6.equals("20-February-1900"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-43574) + "'", int36 == (-43574));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        int int19 = day18.getYear();
        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
        boolean boolean21 = spreadsheetDate14.isOn(serialDate20);
        boolean boolean22 = spreadsheetDate12.isOnOrAfter(serialDate20);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate20);
        boolean boolean24 = spreadsheetDate6.isAfter(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int29 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = spreadsheetDate26.getYYYY();
        boolean boolean31 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate33.getYYYY();
        int int38 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate33.getDayOfWeek();
        int int40 = spreadsheetDate33.getDayOfWeek();
        boolean boolean41 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int48 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate43.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int50 = spreadsheetDate43.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int53 = spreadsheetDate43.compare((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean54 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SerialDate serialDate55 = null;
        try {
            boolean boolean56 = spreadsheetDate3.isOnOrAfter(serialDate55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        int int9 = timeSeries7.getItemCount();
        java.lang.Class<?> wildcardClass10 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass10);
        int int14 = month0.compareTo((java.lang.Object) 1);
        org.jfree.data.time.Year year15 = month0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 10.0d);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long24 = month23.getFirstMillisecond();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int28 = month27.getMonth();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries29.clear();
        int int31 = year15.compareTo((java.lang.Object) timeSeries29);
        try {
            java.lang.Number number33 = timeSeries29.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61851744000000L) + "'", long24 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
//        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
//        timeSeries18.setRangeDescription("");
//        timeSeries18.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
//        int int26 = day24.getDayOfMonth();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day24);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries4.addAndOrUpdate(timeSeries18);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class30);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long35 = month34.getFirstMillisecond();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        int int39 = month38.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) month38);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 0, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNull(class19);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61851744000000L) + "'", long35 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(timeSeries40);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.String str5 = month2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 10" + "'", str5.equals("January 10"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2019, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
//        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        java.lang.String str8 = year7.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) (byte) 10);
//        java.lang.String str15 = day11.toString();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        java.lang.String str23 = year22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 10L);
//        long long26 = year22.getLastMillisecond();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class30);
//        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
//        timeSeries31.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries31.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.previous();
//        java.lang.Number number39 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day37);
//        int int40 = year22.compareTo((java.lang.Object) timeSeries31);
//        int int41 = day11.compareTo((java.lang.Object) int40);
//        org.jfree.data.time.SerialDate serialDate42 = day11.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2958465, serialDate42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(class6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
//        org.junit.Assert.assertNull(class32);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNull(number39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(serialDate42);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setMaximumItemCount(0);
        int int8 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str14 = spreadsheetDate10.getDescription();
        java.lang.String str15 = spreadsheetDate10.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.lang.String str21 = spreadsheetDate17.getDescription();
        boolean boolean22 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean23 = timeSeries4.equals((java.lang.Object) boolean22);
        java.lang.Class class24 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("January 10");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "20-February-1900" + "'", str15.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(class24);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 3, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long14 = fixedMillisecond13.getSerialIndex();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.String str23 = year22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 10L);
        long long26 = year22.getLastMillisecond();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(4, year22);
        long long28 = year22.getFirstMillisecond();
        java.lang.Object obj29 = null;
        boolean boolean30 = year22.equals(obj29);
        long long31 = year22.getLastMillisecond();
        try {
            org.jfree.data.time.TimeSeries timeSeries32 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) year22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        int int6 = timeSeries4.getItemCount();
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        java.lang.String str8 = timeSeries4.getRangeDescription();
        timeSeries4.setDomainDescription("");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getYear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 10L);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) month25);
        int int28 = day11.compareTo((java.lang.Object) timeSeriesDataItem27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1577865599999L);
        try {
            timeSeries4.add(timeSeriesDataItem30, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Preceding" + "'", str8.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.lang.Number number11 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, 0.0d);
        java.util.Calendar calendar24 = null;
        try {
            year18.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10L + "'", number11.equals(10L));
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getYear();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        boolean boolean22 = spreadsheetDate15.isOn(serialDate21);
        boolean boolean23 = spreadsheetDate13.isOnOrAfter(serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate21);
        boolean boolean25 = spreadsheetDate7.isAfter(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate27.getYYYY();
        boolean boolean32 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int37 = spreadsheetDate34.compare((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int38 = spreadsheetDate34.getYYYY();
        int int39 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int40 = spreadsheetDate34.getDayOfWeek();
        java.lang.Class<?> wildcardClass41 = spreadsheetDate34.getClass();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass41);
        java.lang.String str43 = timeSeries42.getDomainDescription();
        boolean boolean44 = timeSeries42.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Time" + "'", str43.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        timeSeries4.setKey((java.lang.Comparable) '4');
        int int9 = timeSeries4.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries3.getDataItem(31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        int int8 = timeSeries6.getItemCount();
        java.lang.Class<?> wildcardClass9 = timeSeries6.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560150000000L, (java.lang.Class) wildcardClass9);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = timeSeriesDataItem13.compareTo((java.lang.Object) day14);
        java.lang.Number number16 = timeSeriesDataItem13.getValue();
        java.lang.Number number17 = timeSeriesDataItem13.getValue();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10L + "'", number16.equals(10L));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 10L + "'", number17.equals(10L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("2019");
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException6);
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("2019");
        seriesException12.addSuppressed((java.lang.Throwable) seriesException14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesException14);
        seriesException6.addSuppressed((java.lang.Throwable) seriesException14);
        java.lang.Throwable[] throwableArray18 = seriesException6.getSuppressed();
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("2019");
        seriesException20.addSuppressed((java.lang.Throwable) seriesException22);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException27 = new org.jfree.data.general.SeriesException("2019");
        seriesException25.addSuppressed((java.lang.Throwable) seriesException27);
        seriesException20.addSuppressed((java.lang.Throwable) seriesException25);
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("2019");
        seriesException31.addSuppressed((java.lang.Throwable) seriesException33);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesException33);
        seriesException25.addSuppressed((java.lang.Throwable) seriesException33);
        java.lang.Throwable[] throwableArray37 = seriesException25.getSuppressed();
        seriesException6.addSuppressed((java.lang.Throwable) seriesException25);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray37);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        timeSeries4.removeAgedItems(false);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class13);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long18 = month17.getFirstMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int22 = month21.getMonth();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (double) 12);
        timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 1546329600000L);
        long long34 = day29.getFirstMillisecond();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61851744000000L) + "'", long18 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-2204640000000L) + "'", long34 == (-2204640000000L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        timeSeries17.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        long long24 = month22.getLastMillisecond();
        java.lang.Number number25 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        java.lang.String str26 = timeSeries17.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries4.addAndOrUpdate(timeSeries17);
        int int28 = timeSeries17.getMaximumItemCount();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getYear();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        boolean boolean22 = spreadsheetDate15.isOn(serialDate21);
        boolean boolean23 = spreadsheetDate13.isOnOrAfter(serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate21);
        boolean boolean25 = spreadsheetDate7.isAfter(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate27.getYYYY();
        boolean boolean32 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int37 = spreadsheetDate34.compare((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int38 = spreadsheetDate34.getYYYY();
        int int39 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int40 = spreadsheetDate34.getDayOfWeek();
        java.lang.Class<?> wildcardClass41 = spreadsheetDate34.getClass();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass41);
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(class43);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900, class1);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 10L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries7.removeChangeListener(seriesChangeListener13);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class26);
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long32 = month31.getFirstMillisecond();
        long long33 = month31.getLastMillisecond();
        int int34 = month31.getMonth();
        java.lang.String str35 = month31.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) 12);
        boolean boolean38 = year20.equals((java.lang.Object) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
        java.util.Collection collection40 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        try {
            timeSeries2.removeAgedItems((long) (-460), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNull(class28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61851744000000L) + "'", long32 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61849065600001L) + "'", long33 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "January 10" + "'", str35.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(collection40);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            timeSeries4.delete(regularTimePeriod15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.lang.String str9 = year8.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long15 = month14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
//        int int17 = day0.compareTo((java.lang.Object) timeSeriesDataItem16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 1577865599999L);
//        long long20 = day0.getFirstMillisecond();
//        long long21 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61851744000000L) + "'", long15 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.lang.Object obj8 = null;
        int int9 = fixedMillisecond1.compareTo(obj8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int6 = spreadsheetDate3.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.Calendar calendar5 = null;
        fixedMillisecond4.peg(calendar5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        int int6 = timeSeries4.getItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries4.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        long long4 = day0.getFirstMillisecond();
//        java.lang.String str5 = day0.toString();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day0.equals(obj6);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("January 10");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-458));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, (int) (short) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.getDescription();
        java.lang.String str6 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.getDescription();
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean31 = spreadsheetDate25.equals((java.lang.Object) 100.0f);
        spreadsheetDate25.setDescription("hi!");
        boolean boolean35 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate25, 0);
        try {
            int int37 = spreadsheetDate8.compareTo((java.lang.Object) (-447));
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20-February-1900" + "'", str6.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        java.lang.Class class15 = timeSeries4.getTimePeriodClass();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.String str23 = year22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 10L);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 10);
        int int30 = day26.getYear();
        java.lang.Number number31 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.lang.String str38 = year37.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year37);
        int int40 = day26.compareTo((java.lang.Object) year37);
        java.util.Calendar calendar41 = null;
        try {
            long long42 = year37.getLastMillisecond(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 12 + "'", number31.equals(12));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getYear();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        boolean boolean22 = spreadsheetDate15.isOn(serialDate21);
        boolean boolean23 = spreadsheetDate13.isOnOrAfter(serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate21);
        boolean boolean25 = spreadsheetDate7.isAfter(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate27.getYYYY();
        boolean boolean32 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int37 = spreadsheetDate34.compare((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int38 = spreadsheetDate34.getYYYY();
        int int39 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int40 = spreadsheetDate34.getDayOfWeek();
        java.lang.Class<?> wildcardClass41 = spreadsheetDate34.getClass();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long45 = fixedMillisecond44.getMiddleMillisecond();
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond44.getLastMillisecond(calendar46);
        java.util.Date date48 = fixedMillisecond44.getTime();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        int int50 = day49.getYear();
        org.jfree.data.time.SerialDate serialDate51 = day49.getSerialDate();
        java.util.Date date52 = day49.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date52, timeZone54);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date48, timeZone54);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month56);
        int int58 = timeSeries42.getIndex((org.jfree.data.time.RegularTimePeriod) month56);
        timeSeries42.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1L + "'", long45 == 1L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        long long14 = timeSeries11.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int8 = spreadsheetDate5.toSerial();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        java.lang.String str15 = spreadsheetDate11.getDescription();
        boolean boolean16 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int25 = spreadsheetDate22.toSerial();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean27 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("20-February-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
        java.util.List list5 = timeSeries2.getItems();
        java.lang.Comparable comparable6 = timeSeries2.getKey();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 10 + "'", comparable6.equals(10));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, year8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(8, year8);
        int int14 = year8.getYear();
        long long15 = year8.getLastMillisecond();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        timeSeries4.setKey((java.lang.Comparable) '4');
        int int9 = timeSeries4.getItemCount();
        boolean boolean10 = timeSeries4.getNotify();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) -1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getYear();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        boolean boolean22 = spreadsheetDate15.isOn(serialDate21);
        boolean boolean23 = spreadsheetDate13.isOnOrAfter(serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate21);
        boolean boolean25 = spreadsheetDate7.isAfter(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate27.getYYYY();
        boolean boolean32 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int37 = spreadsheetDate34.compare((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int38 = spreadsheetDate34.getYYYY();
        int int39 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int40 = spreadsheetDate34.getDayOfWeek();
        java.lang.Class<?> wildcardClass41 = spreadsheetDate34.getClass();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass41);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries42.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.previous();
        long long13 = year7.getLastMillisecond();
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.lang.Number number11 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, 0.0d);
        java.lang.Object obj24 = timeSeriesDataItem23.clone();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10L + "'", number11.equals(10L));
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int7 = day6.getYear();
        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
        boolean boolean9 = spreadsheetDate2.isOn(serialDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean19 = spreadsheetDate13.equals((java.lang.Object) 100.0f);
        boolean boolean20 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        try {
            org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9999, (org.jfree.data.time.SerialDate) spreadsheetDate13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long13 = month12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int18 = month17.getMonth();
        int int19 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month17);
        boolean boolean20 = timeSeries4.isEmpty();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61851744000000L) + "'", long13 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str14 = spreadsheetDate10.getDescription();
        boolean boolean15 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int16 = spreadsheetDate10.getYYYY();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month9.next();
        int int14 = month9.getMonth();
        int int15 = month9.getYearValue();
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 10);
        boolean boolean16 = fixedMillisecond1.equals((java.lang.Object) day12);
        int int17 = day12.getYear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class24);
        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
        int int27 = timeSeries25.getItemCount();
        java.lang.Class<?> wildcardClass28 = timeSeries25.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass28);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, (java.lang.Class) wildcardClass28);
        java.util.Date date31 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long34 = fixedMillisecond33.getMiddleMillisecond();
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond33.getLastMillisecond(calendar35);
        java.util.Date date37 = fixedMillisecond33.getTime();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date31, timeZone38);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int17, (java.lang.Class) wildcardClass28);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod40);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10, 7, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        timeSeries16.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
        java.lang.Number number24 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day22);
        int int25 = year7.compareTo((java.lang.Object) timeSeries16);
        int int26 = year7.getYear();
        try {
            org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(52, year7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.util.Date date3 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.next();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getMiddleMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getYear();
        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
        boolean boolean17 = spreadsheetDate10.isOn(serialDate16);
        boolean boolean18 = spreadsheetDate8.isOnOrAfter(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate16);
        boolean boolean20 = spreadsheetDate2.isAfter(serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int25 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate22.getYYYY();
        boolean boolean27 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int28 = spreadsheetDate22.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year5);
        timeSeries4.clear();
        timeSeries4.setRangeDescription("March");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100, (int) (byte) 1, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        long long10 = year6.getLastMillisecond();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class14);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        timeSeries15.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        java.lang.Number number23 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day21);
        int int24 = year6.compareTo((java.lang.Object) timeSeries15);
        int int25 = year6.getYear();
        long long26 = year6.getLastMillisecond();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        int int9 = timeSeries7.getItemCount();
        java.lang.Class<?> wildcardClass10 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "org.jfree.data.time.TimePeriodFormatException: ", "", (java.lang.Class) wildcardClass10);
        java.util.List list12 = timeSeries11.getItems();
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(list12);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        java.lang.String str6 = spreadsheetDate2.getDescription();
//        java.lang.String str7 = spreadsheetDate2.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        java.lang.String str13 = spreadsheetDate9.getDescription();
//        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        boolean boolean22 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int23 = spreadsheetDate18.getYYYY();
//        boolean boolean24 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getYear();
//        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
//        boolean boolean35 = spreadsheetDate28.isOn(serialDate34);
//        boolean boolean36 = spreadsheetDate26.isOnOrAfter(serialDate34);
//        int int37 = spreadsheetDate9.compareTo((java.lang.Object) serialDate34);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int44 = spreadsheetDate41.compare((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        boolean boolean45 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        int int46 = spreadsheetDate39.getMonth();
//        java.util.Date date47 = spreadsheetDate39.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int54 = spreadsheetDate51.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        boolean boolean55 = spreadsheetDate49.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.SerialDate serialDate57 = spreadsheetDate49.getFollowingDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate39.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        boolean boolean59 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate39);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "20-February-1900" + "'", str7.equals("20-February-1900"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-43574) + "'", int37 == (-43574));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(serialDate60);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class23);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long29 = month28.getFirstMillisecond();
        long long30 = month28.getLastMillisecond();
        int int31 = month28.getMonth();
        java.lang.String str32 = month28.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 12);
        boolean boolean35 = year17.equals((java.lang.Object) 12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        java.util.Calendar calendar37 = null;
        try {
            year17.peg(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61851744000000L) + "'", long29 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61849065600001L) + "'", long30 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January 10" + "'", str32.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        long long10 = year6.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year6.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 10L);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int31 = month30.getMonth();
        int int32 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month30);
        try {
            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month30, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, year8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(8, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getYear();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        boolean boolean8 = spreadsheetDate1.isOn(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean18 = spreadsheetDate12.equals((java.lang.Object) 100.0f);
        boolean boolean19 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int21 = day20.getYear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1900 + "'", int21 == 1900);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long3 = month2.getFirstMillisecond();
//        long long4 = month2.getLastMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class8);
//        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
//        timeSeries9.setRangeDescription("");
//        timeSeries9.setMaximumItemAge((long) 2019);
//        boolean boolean15 = month2.equals((java.lang.Object) timeSeries9);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long25 = month24.getFirstMillisecond();
//        long long26 = month24.getLastMillisecond();
//        int int27 = month24.getMonth();
//        java.lang.String str28 = month24.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 12);
//        timeSeries20.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries20.addChangeListener(seriesChangeListener32);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class37);
//        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        java.lang.String str41 = year40.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 10L);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long47 = month46.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) month46);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        int int52 = month51.getMonth();
//        int int53 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) month51);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) month51);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int56 = day55.getYear();
//        org.jfree.data.time.SerialDate serialDate57 = day55.getSerialDate();
//        java.util.Date date58 = day55.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long61 = fixedMillisecond60.getMiddleMillisecond();
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond60.getLastMillisecond(calendar62);
//        java.util.Date date64 = fixedMillisecond60.getTime();
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        int int66 = day65.getYear();
//        org.jfree.data.time.SerialDate serialDate67 = day65.getSerialDate();
//        java.util.Date date68 = day65.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date68, timeZone70);
//        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month(date64, timeZone70);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date58, timeZone70);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day73, (double) (byte) -1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day73, (java.lang.Number) 10.0f);
//        java.beans.PropertyChangeListener propertyChangeListener78 = null;
//        timeSeries9.removePropertyChangeListener(propertyChangeListener78);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener80 = null;
//        timeSeries9.addChangeListener(seriesChangeListener80);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
//        int int83 = day82.getDayOfMonth();
//        java.lang.Class class84 = null;
//        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day82, class84);
//        try {
//            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day82, (java.lang.Number) 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
//        org.junit.Assert.assertNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61851744000000L) + "'", long25 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61849065600001L) + "'", long26 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "January 10" + "'", str28.equals("January 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNull(class39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNull(timeSeriesDataItem75);
//        org.junit.Assert.assertNull(timeSeriesDataItem77);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 10 + "'", int83 == 10);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long3 = fixedMillisecond2.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getLastMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = day7.getYear();
        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
        java.util.Date date10 = day7.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date10, timeZone12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date6, timeZone12);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class18);
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        int int21 = timeSeries19.getItemCount();
        java.lang.Class<?> wildcardClass22 = timeSeries19.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6, (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, (java.lang.Class) wildcardClass22);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        int int8 = timeSeries6.getItemCount();
        java.lang.Class<?> wildcardClass9 = timeSeries6.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560150000000L, (java.lang.Class) wildcardClass9);
        int int12 = timeSeries11.getItemCount();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        long long12 = year8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(4, year8);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        java.lang.String str15 = month14.toString();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 2019" + "'", str15.equals("October 2019"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = day13.getYear();
        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
        boolean boolean16 = spreadsheetDate9.isOn(serialDate15);
        boolean boolean17 = spreadsheetDate7.isOnOrAfter(serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate15);
        boolean boolean19 = spreadsheetDate1.isAfter(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate21.getYYYY();
        boolean boolean26 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        try {
            org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate21.getNearestDayOfWeek(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.util.Date date13 = day10.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getYear();
        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
        java.util.Date date17 = day14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date13, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long26 = fixedMillisecond25.getMiddleMillisecond();
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond25.getLastMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond25.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long34 = fixedMillisecond33.getMiddleMillisecond();
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond33.getLastMillisecond(calendar35);
        java.util.Date date37 = fixedMillisecond33.getTime();
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond33.getFirstMillisecond(calendar38);
        long long40 = fixedMillisecond33.getFirstMillisecond();
        long long41 = fixedMillisecond33.getMiddleMillisecond();
        java.util.Date date42 = fixedMillisecond33.getTime();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.lang.String str44 = month43.toString();
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class49);
        java.lang.Class class51 = timeSeries50.getTimePeriodClass();
        int int52 = timeSeries50.getItemCount();
        java.lang.Class<?> wildcardClass53 = timeSeries50.getClass();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass53);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month43, (java.lang.Class) wildcardClass53);
        java.util.Date date56 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long59 = fixedMillisecond58.getMiddleMillisecond();
        java.util.Calendar calendar60 = null;
        long long61 = fixedMillisecond58.getLastMillisecond(calendar60);
        java.util.Date date62 = fixedMillisecond58.getTime();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date62, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date56, timeZone63);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date42, timeZone63);
        java.lang.Class class70 = null;
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class70);
        java.lang.Class class72 = timeSeries71.getTimePeriodClass();
        timeSeries71.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener75 = null;
        timeSeries71.addPropertyChangeListener(propertyChangeListener75);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = day77.previous();
        java.lang.Number number79 = timeSeries71.getValue((org.jfree.data.time.RegularTimePeriod) day77);
        java.util.Date date80 = day77.getStart();
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
        int int82 = day81.getYear();
        org.jfree.data.time.SerialDate serialDate83 = day81.getSerialDate();
        java.util.Date date84 = day81.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond85 = new org.jfree.data.time.FixedMillisecond(date84);
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month87 = new org.jfree.data.time.Month(date84, timeZone86);
        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date80, timeZone86);
        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month(date42, timeZone86);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date29, timeZone86);
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(date13, timeZone86);
        java.util.Calendar calendar92 = null;
        try {
            long long93 = day91.getFirstMillisecond(calendar92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1L + "'", long41 == 1L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
        org.junit.Assert.assertNull(class51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1L + "'", long59 == 1L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(class72);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNull(number79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2019 + "'", int82 == 2019);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeZone86);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, year8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(8, year8);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month13.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        timeSeries4.removeAgedItems(false);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
//        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.lang.String str19 = year18.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Number number23 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener24);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class29);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long35 = month34.getFirstMillisecond();
//        long long36 = month34.getLastMillisecond();
//        int int37 = month34.getMonth();
//        java.lang.String str38 = month34.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 12);
//        java.lang.String str41 = timeSeries30.getDomainDescription();
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class45);
//        java.lang.Class class47 = timeSeries46.getTimePeriodClass();
//        timeSeries46.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timeSeries46.addPropertyChangeListener(propertyChangeListener50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day52.previous();
//        java.lang.Number number54 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) day52);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) day52);
//        int int56 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) day52);
//        long long57 = day52.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day52);
//        long long59 = day52.getFirstMillisecond();
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNull(class17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 10L + "'", number23.equals(10L));
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61851744000000L) + "'", long35 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61849065600001L) + "'", long36 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "January 10" + "'", str38.equals("January 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
//        org.junit.Assert.assertNull(class47);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNull(number54);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560236399999L + "'", long57 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560150000000L + "'", long59 == 1560150000000L);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        int int9 = timeSeries7.getItemCount();
        java.lang.Class<?> wildcardClass10 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass10);
        int int14 = month0.compareTo((java.lang.Object) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int14);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 10);
        boolean boolean16 = fixedMillisecond1.equals((java.lang.Object) day12);
        java.util.Calendar calendar17 = null;
        fixedMillisecond1.peg(calendar17);
        java.util.Date date19 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(6, (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long9 = month8.getFirstMillisecond();
//        long long10 = month8.getLastMillisecond();
//        int int11 = month8.getMonth();
//        java.lang.String str12 = month8.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
//        java.lang.Class class15 = timeSeries4.getTimePeriodClass();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        java.lang.String str23 = year22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 10);
//        int int30 = day26.getYear();
//        java.lang.Number number31 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day26);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        java.lang.String str38 = year37.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year37);
//        int int40 = day26.compareTo((java.lang.Object) year37);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class44);
//        java.lang.Class class46 = timeSeries45.getTimePeriodClass();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
//        java.lang.String str48 = year47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) (byte) 10);
//        java.lang.Class class58 = null;
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class58);
//        java.lang.Class class60 = timeSeries59.getTimePeriodClass();
//        timeSeries59.setRangeDescription("");
//        timeSeries59.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day65.previous();
//        int int67 = day65.getDayOfMonth();
//        timeSeries59.delete((org.jfree.data.time.RegularTimePeriod) day65);
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries45.addAndOrUpdate(timeSeries59);
//        long long70 = timeSeries69.getMaximumItemAge();
//        int int71 = day26.compareTo((java.lang.Object) long70);
//        java.util.Calendar calendar72 = null;
//        try {
//            day26.peg(calendar72);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNull(class15);
//        org.junit.Assert.assertNull(class21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 12 + "'", number31.equals(12));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNull(class46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019" + "'", str48.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
//        org.junit.Assert.assertNull(class60);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 10 + "'", int67 == 10);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 9223372036854775807L + "'", long70 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.general.SeriesException: 2019]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getLastMillisecond();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class8);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        timeSeries9.setRangeDescription("");
        timeSeries9.setMaximumItemAge((long) 2019);
        boolean boolean15 = month2.equals((java.lang.Object) timeSeries9);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long25 = month24.getFirstMillisecond();
        long long26 = month24.getLastMillisecond();
        int int27 = month24.getMonth();
        java.lang.String str28 = month24.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 12);
        timeSeries20.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries20.addChangeListener(seriesChangeListener32);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class37);
        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.lang.String str41 = year40.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 10L);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long47 = month46.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int52 = month51.getMonth();
        int int53 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        int int56 = day55.getYear();
        org.jfree.data.time.SerialDate serialDate57 = day55.getSerialDate();
        java.util.Date date58 = day55.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long61 = fixedMillisecond60.getMiddleMillisecond();
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond60.getLastMillisecond(calendar62);
        java.util.Date date64 = fixedMillisecond60.getTime();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
        int int66 = day65.getYear();
        org.jfree.data.time.SerialDate serialDate67 = day65.getSerialDate();
        java.util.Date date68 = day65.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond(date68);
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date68, timeZone70);
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month(date64, timeZone70);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date58, timeZone70);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day73, (double) (byte) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day73, (java.lang.Number) 10.0f);
        java.beans.PropertyChangeListener propertyChangeListener78 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries9.addOrUpdate(regularTimePeriod80, (double) (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61851744000000L) + "'", long25 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61849065600001L) + "'", long26 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "January 10" + "'", str28.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNull(class39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        long long10 = year6.getLastMillisecond();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class14);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        timeSeries15.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        java.lang.Number number23 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day21);
        int int24 = year6.compareTo((java.lang.Object) timeSeries15);
        java.lang.String str25 = timeSeries15.getDomainDescription();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Number number11 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class15);
//        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.lang.String str19 = year18.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 10L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, 0.0d);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class27);
//        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
//        timeSeries28.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries28.addPropertyChangeListener(propertyChangeListener32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.previous();
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) day34);
//        int int37 = day34.getYear();
//        long long38 = day34.getLastMillisecond();
//        int int39 = timeSeriesDataItem23.compareTo((java.lang.Object) long38);
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10L + "'", number11.equals(10L));
//        org.junit.Assert.assertNull(class17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNull(class29);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560236399999L + "'", long38 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        timeSeries4.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        long long11 = month9.getLastMillisecond();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month9);
        long long13 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.getDataItem(52);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
        java.util.Date date13 = day10.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getYear();
        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
        java.util.Date date17 = day14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date13, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        int int23 = day22.getYear();
        org.jfree.data.time.SerialDate serialDate24 = day22.getSerialDate();
        java.util.Date date25 = day22.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date25, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date13, timeZone27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        int int31 = day30.getYear();
        org.jfree.data.time.SerialDate serialDate32 = day30.getSerialDate();
        java.util.Date date33 = day30.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long36 = fixedMillisecond35.getMiddleMillisecond();
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond35.getLastMillisecond(calendar37);
        java.util.Date date39 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        int int41 = day40.getYear();
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        java.util.Date date43 = day40.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date43, timeZone45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date39, timeZone45);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date33, timeZone45);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date13, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year49.next();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
//        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.util.Date date13 = day10.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        long long15 = day14.getLastMillisecond();
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getLastMillisecond();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class8);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        timeSeries9.setRangeDescription("");
        timeSeries9.setMaximumItemAge((long) 2019);
        boolean boolean15 = month2.equals((java.lang.Object) timeSeries9);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long25 = month24.getFirstMillisecond();
        long long26 = month24.getLastMillisecond();
        int int27 = month24.getMonth();
        java.lang.String str28 = month24.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 12);
        timeSeries20.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries20.addChangeListener(seriesChangeListener32);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class37);
        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.lang.String str41 = year40.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 10L);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long47 = month46.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) month46);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int52 = month51.getMonth();
        int int53 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) month51);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        int int56 = day55.getYear();
        org.jfree.data.time.SerialDate serialDate57 = day55.getSerialDate();
        java.util.Date date58 = day55.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long61 = fixedMillisecond60.getMiddleMillisecond();
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond60.getLastMillisecond(calendar62);
        java.util.Date date64 = fixedMillisecond60.getTime();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
        int int66 = day65.getYear();
        org.jfree.data.time.SerialDate serialDate67 = day65.getSerialDate();
        java.util.Date date68 = day65.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond(date68);
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date68, timeZone70);
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month(date64, timeZone70);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date58, timeZone70);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day73, (double) (byte) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day73, (java.lang.Number) 10.0f);
        java.beans.PropertyChangeListener propertyChangeListener78 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener78);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener80 = null;
        timeSeries9.addChangeListener(seriesChangeListener80);
        timeSeries9.clear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61851744000000L) + "'", long25 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61849065600001L) + "'", long26 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "January 10" + "'", str28.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNull(class39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        int int9 = timeSeries7.getItemCount();
        java.lang.Class<?> wildcardClass10 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass10);
        java.lang.Object obj13 = timeSeries12.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(obj13);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.util.Date date3 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        long long6 = fixedMillisecond4.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getLastMillisecond(calendar7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long11 = fixedMillisecond10.getMiddleMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond10.getLastMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond10.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean16 = fixedMillisecond4.equals((java.lang.Object) date14);
//        java.lang.Object obj17 = null;
//        boolean boolean18 = fixedMillisecond4.equals(obj17);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 4);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        boolean boolean9 = timeSeriesDataItem6.equals((java.lang.Object) (-1L));
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class13);
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 10L);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.lang.Number number21 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class25);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.lang.String str29 = year28.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year28, 0.0d);
        boolean boolean34 = timeSeriesDataItem6.equals((java.lang.Object) timeSeriesDataItem33);
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10L + "'", number21.equals(10L));
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        int int6 = day5.getYear();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        boolean boolean8 = spreadsheetDate1.isOn(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean18 = spreadsheetDate12.equals((java.lang.Object) 100.0f);
        boolean boolean19 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        long long21 = day20.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2204553600001L) + "'", long21 == (-2204553600001L));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int7 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        boolean boolean8 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int9 = spreadsheetDate2.getMonth();
        int int10 = spreadsheetDate2.getDayOfWeek();
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year7);
        long long13 = year7.getFirstMillisecond();
        java.lang.Object obj14 = null;
        boolean boolean15 = year7.equals(obj14);
        int int16 = year7.getYear();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year7.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        long long8 = fixedMillisecond1.getFirstMillisecond();
        long long9 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date10 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.String str12 = month11.toString();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class17);
        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
        int int20 = timeSeries18.getItemCount();
        java.lang.Class<?> wildcardClass21 = timeSeries18.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 20, (java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, (java.lang.Class) wildcardClass21);
        java.util.Date date24 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long27 = fixedMillisecond26.getMiddleMillisecond();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond26.getLastMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond26.getTime();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date24, timeZone31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date10, timeZone31);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class38);
        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
        timeSeries39.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries39.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.previous();
        java.lang.Number number47 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) day45);
        java.util.Date date48 = day45.getStart();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        int int50 = day49.getYear();
        org.jfree.data.time.SerialDate serialDate51 = day49.getSerialDate();
        java.util.Date date52 = day49.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date52, timeZone54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date48, timeZone54);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date10, timeZone54);
        org.jfree.data.time.Year year58 = month57.getYear();
        long long59 = month57.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(class40);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(year58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 28799999L + "'", long59 == 28799999L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        timeSeries4.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries4.addChangeListener(seriesChangeListener16);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class21);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.lang.String str25 = year24.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 10L);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long31 = month30.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int36 = month35.getMonth();
        int int37 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month35.previous();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61851744000000L) + "'", long31 == (-61851744000000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        java.lang.Class class15 = timeSeries4.getTimePeriodClass();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.String str23 = year22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 10L);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        int int27 = day26.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 10);
        int int30 = day26.getYear();
        java.lang.Number number31 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.lang.String str38 = year37.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year37);
        int int40 = day26.compareTo((java.lang.Object) year37);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class44);
        java.lang.Class class46 = timeSeries45.getTimePeriodClass();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        java.lang.String str48 = year47.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 10L);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        int int52 = day51.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) (byte) 10);
        int int55 = timeSeries45.getItemCount();
        java.lang.String str56 = timeSeries45.getRangeDescription();
        int int57 = year37.compareTo((java.lang.Object) timeSeries45);
        timeSeries45.setMaximumItemAge((long) 2147483647);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 12 + "'", number31.equals(12));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNull(class46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019" + "'", str48.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Preceding" + "'", str56.equals("Preceding"));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
        int int8 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month2.previous();
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900, class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900, class5);
        java.lang.String str7 = timeSeries6.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries2.addAndOrUpdate(timeSeries6);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class4);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 10L);
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(4, year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        long long14 = month12.getLastMillisecond();
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1556693999999L + "'", long14 == 1556693999999L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 12);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener20);
        java.lang.Comparable comparable22 = timeSeries11.getKey();
        timeSeries11.update(0, (java.lang.Number) 2958465);
        try {
            timeSeries11.update(11, (java.lang.Number) 24232L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 10 + "'", comparable22.equals(10));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getLastMillisecond();
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class5);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.lang.String str9 = year8.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 10L);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long15 = month14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month14);
//        int int17 = day0.compareTo((java.lang.Object) timeSeriesDataItem16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 1577865599999L);
//        long long20 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day0.previous();
//        long long22 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long25 = fixedMillisecond24.getMiddleMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond24.getLastMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond24.getTime();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond24.getFirstMillisecond(calendar29);
//        java.util.Calendar calendar31 = null;
//        fixedMillisecond24.peg(calendar31);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class36);
//        timeSeries37.setKey((java.lang.Comparable) 'a');
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long43 = month42.getFirstMillisecond();
//        long long44 = month42.getLastMillisecond();
//        java.lang.Number number45 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) month42);
//        java.lang.String str46 = timeSeries37.getRangeDescription();
//        boolean boolean47 = fixedMillisecond24.equals((java.lang.Object) timeSeries37);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long51 = month50.getFirstMillisecond();
//        long long52 = month50.getLastMillisecond();
//        int int53 = month50.getMonth();
//        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) month50);
//        java.lang.String str55 = month50.toString();
//        boolean boolean56 = day0.equals((java.lang.Object) str55);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61851744000000L) + "'", long15 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61851744000000L) + "'", long43 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-61849065600001L) + "'", long44 == (-61849065600001L));
//        org.junit.Assert.assertNull(number45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Preceding" + "'", str46.equals("Preceding"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61851744000000L) + "'", long51 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-61849065600001L) + "'", long52 == (-61849065600001L));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "January 10" + "'", str55.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        serialDate8.setDescription("hi!");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getYear();
        org.jfree.data.time.SerialDate serialDate26 = day24.getSerialDate();
        boolean boolean27 = spreadsheetDate20.isOn(serialDate26);
        boolean boolean28 = spreadsheetDate18.isOnOrAfter(serialDate26);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate26);
        boolean boolean30 = spreadsheetDate12.isAfter(serialDate26);
        org.jfree.data.time.SerialDate serialDate31 = serialDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        try {
            org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), (org.jfree.data.time.SerialDate) spreadsheetDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        long long10 = month8.getLastMillisecond();
        int int11 = month8.getMonth();
        java.lang.String str12 = month8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 12);
        java.lang.String str15 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int17 = day16.getYear();
        int int18 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day16);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61849065600001L) + "'", long10 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 10" + "'", str12.equals("January 10"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long6 = month5.getFirstMillisecond();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        int int10 = month9.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class13);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        long long18 = month17.getFirstMillisecond();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, 10);
//        int int22 = month21.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) month21);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
//        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (double) 12);
//        java.lang.Class class32 = timeSeries23.getTimePeriodClass();
//        boolean boolean33 = month5.equals((java.lang.Object) timeSeries23);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class37);
//        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        java.lang.String str41 = year40.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = day44.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) (byte) 10);
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class51);
//        java.lang.Class class53 = timeSeries52.getTimePeriodClass();
//        timeSeries52.setRangeDescription("");
//        timeSeries52.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
//        int int60 = day58.getDayOfMonth();
//        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day58);
//        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries38.addAndOrUpdate(timeSeries52);
//        boolean boolean63 = month5.equals((java.lang.Object) timeSeries52);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61851744000000L) + "'", long18 == (-61851744000000L));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNull(class32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNull(class39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
//        org.junit.Assert.assertNull(class53);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertNotNull(timeSeries62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        timeSeries4.removeAgedItems(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 10L);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 10);
        int int14 = day10.getYear();
        java.lang.Class<?> wildcardClass15 = day10.getClass();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.getDescription();
        java.lang.String str6 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.getDescription();
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int22 = spreadsheetDate17.getYYYY();
        boolean boolean23 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.lang.String str29 = spreadsheetDate25.getDescription();
        java.lang.String str30 = spreadsheetDate25.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        java.lang.String str36 = spreadsheetDate32.getDescription();
        boolean boolean37 = spreadsheetDate25.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int44 = spreadsheetDate41.compare((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean45 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int52 = spreadsheetDate49.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean53 = spreadsheetDate47.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean55 = spreadsheetDate49.equals((java.lang.Object) 100.0f);
        spreadsheetDate49.setDescription("hi!");
        boolean boolean59 = spreadsheetDate32.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, (org.jfree.data.time.SerialDate) spreadsheetDate49, 0);
        boolean boolean60 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20-February-1900" + "'", str6.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "20-February-1900" + "'", str30.equals("20-February-1900"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        int int6 = timeSeries4.getItemCount();
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 1);
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate13.getYYYY();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean19 = fixedMillisecond9.equals((java.lang.Object) 9999);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        int int14 = timeSeries11.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        long long7 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getLastMillisecond(calendar8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class13);
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        timeSeries14.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
        java.lang.Number number22 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class26);
        timeSeries27.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long33 = month32.getFirstMillisecond();
        long long34 = month32.getLastMillisecond();
        java.lang.Number number35 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) month32);
        java.lang.String str36 = timeSeries27.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries14.addAndOrUpdate(timeSeries27);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, "hi!", "Preceding", class41);
        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        java.lang.String str45 = year44.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 10L);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        int int49 = day48.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) (byte) 10);
        timeSeries37.setKey((java.lang.Comparable) timeSeriesDataItem51);
        timeSeries37.setDescription("10-June-2019");
        int int55 = fixedMillisecond1.compareTo((java.lang.Object) "10-June-2019");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61851744000000L) + "'", long33 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61849065600001L) + "'", long34 == (-61849065600001L));
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNull(class43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 12);
        java.lang.String str20 = day17.toString();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "20-February-1900" + "'", str20.equals("20-February-1900"));
    }
}

